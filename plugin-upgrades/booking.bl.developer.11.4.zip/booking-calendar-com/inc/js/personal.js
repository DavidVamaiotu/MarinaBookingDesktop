(function () {
	var a = setInterval( function () {
		if ( ('undefined' === typeof jQuery) || !window.jQuery ) {
			return;
		}
		clearInterval( a );
		// Here can  be executed jQuery functions
		jQuery( document ).ready( function () {
			// Here is my code start
			if ( jQuery( '.wpdev-validates-as-time' ).length > 0 ) {
				jQuery( '.wpdev-validates-as-time' ).attr( 'alt', 'time' );
				jQuery( '.wpdev-validates-as-time' ).setMask();
			}
		} );
	}, 500 );
})();

/**
 mask0.destroy();
var mask0 = IMask(temp1, {    mask: 'HH:MM PM',
  lazy: false,  // make placeholder always visible

  blocks: {
    MM: {
      mask: IMask.MaskedRange,
      from: 0,
      to: 59

    },
    HH: {
      mask: IMask.MaskedRange,
      from: 0,
      to: 12
    },

    PM: {
      mask: IMask.MaskedEnum,
      enum: ['AM', 'PM']
    }
  }  });
 */

// ---------------------------------------------------------------------------------------------------------------------

// Send booking Cancel by visitor
function wpbc_customer_action__booking_cancel( booking_hash, bk_type, wpdev_active_locale ){

    if ( booking_hash != '' ){

        wpbc__spin_loader__mini__show( 'submiting' + bk_type, {  'show_here': { 'where': 'inside', 'jq_node': '#submiting' + bk_type }  } );

        var ajax_type_action='DELETE_BY_VISITOR';

        jQuery.ajax({                                           // Start Ajax Sending
            url: wpbc_url_ajax,
            type:'POST',
            success: function (data, textStatus){if( textStatus == 'success')   jQuery('#ajax_respond_insert' + bk_type).html( data ) ;},
            error:function (XMLHttpRequest, textStatus, errorThrown){window.status = 'Ajax sending Error status:'+ textStatus;console.error( XMLHttpRequest.status + ' ' + XMLHttpRequest.statusText);if (XMLHttpRequest.status == 500) {console.error( 'Please check at this page according this error:' + ' https://wpbookingcalendar.com/faq/#ajax-sending-error');}},
            // beforeSend: someFunction,
            data:{
                // ajax_action : ajax_type_action,
                action : ajax_type_action,
                booking_hash : booking_hash,
                bk_type : bk_type,
                wpdev_active_locale:wpdev_active_locale,
                wpbc_nonce: document.getElementById('wpbc_nonce_delete'+bk_type).value 
            }
        });
        return false;
    }
    return true;
}

// ---------------------------------------------------------------------------------------------------------------------

/**
 * Set checkbox in booking form Exclusive on click
 *
 * @param element
 */
function wpbc_in_form__make_exclusive_checkbox( element ){
    var is_checked = jQuery( element ).is( ':checked' );                            // FixIn: 10.1.5.1.
    jQuery( '[name="' + element.name + '"]' ).prop( "checked", false );             // Uncheck  all checkboxes with  this name
    element.checked = is_checked;
}

/**
 * Set select-box with multiple selections - Exclusive
 * @param element
 */
function wpbc_in_form__make_exclusive_selectbox( element ){

    // Get all selected elements.
    var selectedOptions = jQuery.find( '[name="' + element.name + '"] option:selected' );

    // Check if we have more than 1 selection
    if ( selectedOptions.length > 1 ){

        var ind = selectedOptions[ 0 ].index;                                             // Get index of the first  selected element
        jQuery( '[name="' + element.name + '"] option' ).prop( "selected", false );             // Uncheck  all checkboxes with  this name
        jQuery( '[name="' + element.name + '"] option:eq(' + ind + ')' ).prop( "selected", true );  // Set the first element selected
    }
}

