// --------------------------------------------------------------------------------------------------------------------
// >= Business Large ...
// --------------------------------------------------------------------------------------------------------------------

/**
 * Is  LESS than required    of    MAX AVAILABLE SLOTS per each dates in each slot (child resource)
 *
 * @param resource_id	ID of booking resource
 * @param html_field	visitors HTML/DOM field   - or other field for definition  number of booked slots
 * @returns {boolean}
 */
function wpbc__is_less_than_required__of_max_available_slots__bl( resource_id, html_field ){

    // Field for getting number of booked slots
    var booking_capacity_field = _wpbc.calendar__get_param_value( resource_id, 'booking_capacity_field' );          // 'visitors'

    if ( booking_capacity_field + resource_id != html_field.name ){
        // Because this is not the field for checking number of available
        return false;
    }

    var required_slots_to_book;

    //TODO: Check about some URL parameter to book parent resource as single resource!  see the same message,  where todo  the same
    if ( 1=== _wpbc.calendar__get_param_value( resource_id, 'is_parent_resource' ) ){
        required_slots_to_book = jQuery( html_field ).val();
        required_slots_to_book = parseInt( required_slots_to_book );
    } else {                                                                                // if this single booking resource:   resource_id then  required_slots_to_book have to == 1
        required_slots_to_book = 1;
    }

    var time_to_book__as_seconds_arr = wpbc_get_start_end_times__in_booking_form__as_seconds( resource_id )
    var available_slots = wpbc__get_available_slots__for_selected_dates_times__bl( resource_id, time_to_book__as_seconds_arr );

    /**
     *   [   '2023-09-10': [     0: Object { resource_id: 2,  is_available: false, booked__seconds: (1) […], … }
                                1: Object { resource_id: 12, is_available: false, booked__seconds: (1) […], … }
                                2: Object { resource_id: 10, is_available: false, booked__seconds: (1) […], … }
                                3: Object { resource_id: 11, is_available: false, booked__seconds: (1) […], … }
                          ],
            '2023-09-14': [
                            0: Object { resource_id: 2,  is_available: true, booked__seconds: (1) […], … }
                            1: Object { resource_id: 12, is_available: true, booked__seconds: (1) […], … }
                            2: Object { resource_id: 10, is_available: false, booked__seconds: (1) […], … }
                            3: Object { resource_id: 11, is_available: true, booked__seconds: (1) […], … }
                          ]
        ]
     */

    var is_in_same_resource = _wpbc.calendar__get_param_value( resource_id, 'booking_is_dissbale_booking_for_different_sub_resources' );        // 'On' | 'Off'

    // -------------------------------------------------------------------------------------------------------------
    // Check if available slots in the same (child resource) for all  dates.
    // -------------------------------------------------------------------------------------------------------------

    // I F :
    if ( 'On' === is_in_same_resource ){
        // 1. Get child booking resources  or single booking resource  that  exist  in dates :	                    [1] | [1,14,15,17]
        var child_resources_arr = wpbc_clone_obj( _wpbc.booking__get_param_value( resource_id, 'resources_id_arr__in_dates' ) );
        var availability_in_same_child_resources = wpbc_clone_obj( child_resources_arr );

        for ( var i = 0; i < child_resources_arr.length; i++ ){                                                     // [1,14,15,17]
            for ( var day_sql_key in available_slots ){                                                             // '2023-09-10': [], '2023-09-14': [],
                for ( var ind in available_slots[ day_sql_key ] ){                                                  // [ 0:{ resource_id: 2,  is_available: false,...} , .... ]
                    if (
                           ( child_resources_arr[ i ] == available_slots[ day_sql_key ][ ind ].resource_id )
                        && ( ! available_slots[ day_sql_key ][ ind ].is_available )
                    ){
                        // Remove child booking resource ID from availability array (because it's not available
                        availability_in_same_child_resources = availability_in_same_child_resources.filter( function ( e ){  return e !== child_resources_arr[ i ];  } );
                        break;
                    }
                }
            }
        }

        // [ 2, 12, 11 ]  	<- 		ID of child booking resources, where we can  save our booking in the same child booking resource!
        if ( availability_in_same_child_resources.length >= required_slots_to_book ){
            return false;
        } else {

// We can not store booking in the same child booking resource !
console.groupCollapsed( 'WPBC__IS_LESS_THAN_REQUIRED__OF_MAX_AVAILABLE_SLOTS__BL' );
console.groupCollapsed( '== AVAILABILITY_IN_SAME_CHILD_RESOURCES ==' );
console.log( availability_in_same_child_resources, available_slots, required_slots_to_book );
console.groupEnd();

            wpbc_front_end__show_message__warning( html_field,
                                      '<div>' + _wpbc.get_message( 'message_dates_times_unavailable' )     + '</div>'
                                    + '<div>' + _wpbc.get_message( 'message_cannot_save_in_one_resource' ) + '</div>'
                                    + '<div><strong>' + _wpbc.get_message( 'message_choose_alternative_dates' )    + '</strong></div>'
                            );
            return true;
        } // -------------------------------------------------------------------------------------------------------------

    }

    // E L S E :

    // -------------------------------------------------------------------------------------------------------------
    // Check if available slots in ANY (child resource) for all  dates.
    // -------------------------------------------------------------------------------------------------------------

    var availability_in_any_child_resources = {};

    for ( var day_sql_key in available_slots ){
        // '2023-09-10': [], '2023-09-14': [],
        availability_in_any_child_resources[ day_sql_key ] = [];

        for ( var ind in available_slots[ day_sql_key ] ){
            // [ 0:{ resource_id: 2,  is_available: false,...} , .... ]
            if ( available_slots[ day_sql_key ][ ind ].is_available ){
                availability_in_any_child_resources[ day_sql_key ].push( available_slots[ day_sql_key ][ ind ].resource_id );
            }
        }
    }
    /**
     * {    "2023-09-10": [ 2, 10, 11 ]				<- available ID of child resources in this date
            "2023-09-14": [ 4 ]						<- available ID of child resources in this date
       }
     */

    for ( var day_sql_key2 in availability_in_any_child_resources ){
        if ( availability_in_any_child_resources[ day_sql_key2 ].length < required_slots_to_book ){

// We can not store booking in this date  day_sql_key2,  number of available child booking resources less than  required
console.groupCollapsed( 'WPBC__IS_LESS_THAN_REQUIRED__OF_MAX_AVAILABLE_SLOTS__BL' );
console.groupCollapsed( '== AVAILABILITY_IN_ANY_CHILD_RESOURCES ==' );
console.log( availability_in_any_child_resources, available_slots, required_slots_to_book );
console.groupEnd();

            wpbc_front_end__show_message__warning( html_field,
                                      '<div>' + _wpbc.get_message( 'message_dates_times_unavailable' )     + '</div>'
                                    + '<div><strong>' + _wpbc.get_message( 'message_choose_alternative_dates' )    + '</strong></div>'
                                        );
            return true;
        }
    }

    return false; // Good save it.
}


/**
 * Get selected SECONDS to book:  [ 0 , 24 * 60 * 60 ]  |  [ 12*60*60 , 14*60*60 ]   ->   get  array of start and end time in seconds,  from  the booking form  fields
 *
 * @param resource_id
 * @returns {number[]}
 */
function wpbc_get_start_end_times__in_booking_form__as_seconds( resource_id ){

    // 2.1 Get selected time ---------------------------------------------------------------------------------------
    // [ {jquery_option: {}, name: "rangetime2", times_as_seconds:[ 36000, 43200 ], value_option_24h: "10:00 - 12:00"} , ... ]
    var selected_time_fields = wpbc_get__selected_time_fields__in_booking_form__as_arr( resource_id  );

    // 2.2 Get selected SECONDS to  book ---------------------------------------------------------------------------
    var time_fields_obj = false;
    var time_as_seconds_arr = [ 0 , 24 * 60 * 60 ];                  // Full day  by  default

    for ( var field_key in selected_time_fields ){
        time_fields_obj = selected_time_fields[ field_key ];        // { times_as_seconds: [ 21600, 23400 ], value_option_24h: '06:00 - 06:30', name: 'rangetime2[]', jquery_option: jQuery_Object {}}

        if ( -1 !== time_fields_obj.name.indexOf( 'rangetime' ) ){
            time_as_seconds_arr[ 0 ] = time_fields_obj.times_as_seconds[ 0 ];
            time_as_seconds_arr[ 1 ] = time_fields_obj.times_as_seconds[ 1 ];
            //break;       // We can not break  here,  because possible using change over dates with  start/end time,  which has high priority     // If we have range-time then  skip  this loop
        }

        if ( -1 !== time_fields_obj.name.indexOf( 'starttime' ) ){
            time_as_seconds_arr[ 0 ] = time_fields_obj.times_as_seconds[ 0 ];
        }

        if ( -1 !== time_fields_obj.name.indexOf( 'endtime' ) ){
            time_as_seconds_arr[ 1 ] = time_fields_obj.times_as_seconds[ 0 ];
        }
    }

    // For duration time we need to  make a new loop,  because we need to be sure that was defined START_TIME before this,
    // and end time was NOT defined,  e.g. ==  (otherwise it's means that  we already  used END_TIME or RANGE_TIME)
    if (
           (           ( 0 ) !== time_as_seconds_arr[ 0 ] )
        && ( (24 * 60 * 60 ) === time_as_seconds_arr[ 1 ] )
    ){
        for ( var field_key in selected_time_fields ){
            time_fields_obj = selected_time_fields[ field_key ]; // { times_as_seconds: [ 21600, 23400 ], value_option_24h: '06:00 - 06:30', name: 'rangetime2[]', jquery_option: jQuery_Object {}}

            if ( -1 !== time_fields_obj.name.indexOf( 'durationtime' ) ){
                time_as_seconds_arr[ 1 ] = time_as_seconds_arr[ 0 ] + time_fields_obj.times_as_seconds[ 0 ];
                break;
            }
        }
    }

    return time_as_seconds_arr;
}


/**
 * Get available slots per each date in each slot (child resource). It's checking times as well.
 *
 * @param resource_id	            ID of booking resource
 * @param time_to_book__as_seconds_arr       TIME FOR BOOKING   Full day:[ 0 , 24 * 60 * 60 ]  |   time slot:[ 12*60*60 , 14*60*60 ]
 * @returns []
 *
 *	Example:  	[
 *					'2023-09-10': [
 *										0: Object { resource_id: 2,  is_available: false, booked__seconds: (1) […], … }
 *										1: Object { resource_id: 12, is_available: false, booked__seconds: (1) […], … }
 *										2: Object { resource_id: 10, is_available: false, booked__seconds: (1) […], … }
 *										3: Object { resource_id: 11, is_available: false, booked__seconds: (1) […], … }
 *								  ],
 *					'2023-09-14': [
 *									0: Object { resource_id: 2,  is_available: true, booked__seconds: (1) […], … }
 *									1: Object { resource_id: 12, is_available: true, booked__seconds: (1) […], … }
 *									2: Object { resource_id: 10, is_available: false, booked__seconds: (1) […], … }
 *									3: Object { resource_id: 11, is_available: true, booked__seconds: (1) […], … }
 *								  ]
 *				]
 */
function wpbc__get_available_slots__for_selected_dates_times__bl( resource_id , time_to_book__as_seconds_arr ){

    // 1. Get selected dates ---------------------------------------------------------------------------------------
    // [ "2023-10-15", "2023-10-16", "2023-10-17", "2023-10-18", "2023-10-19", "2023-10-20", "2023-10-21" ]
    var selected_dates_sql__as_arr = wpbc_get__selected_dates_sql__as_arr(resource_id);


    // Shift time interval  in 30 seconds
    time_to_book__as_seconds_arr[ 0 ] = time_to_book__as_seconds_arr[ 0 ] + 30;
    time_to_book__as_seconds_arr[ 1 ] = time_to_book__as_seconds_arr[ 1 ] - 30;


    // 3.1 Get Data ------------------------------------------------------------------------------------------------
    var sql_class_day;
    var available_resources_arr = [];

    for ( var sql_class_day_number in selected_dates_sql__as_arr ){
        sql_class_day = selected_dates_sql__as_arr[ sql_class_day_number ]; // '2023-08-21'

        available_resources_arr[ sql_class_day ] = [];

        var date_bookings_obj = _wpbc.bookings_in_calendar__get_for_date( resource_id, sql_class_day );

        // ---------------------------------------------------------------------------------------------------------
        // 1. Get child booking resources  or single booking resource  that  exist  in dates :	[1] | [1,14,15,17]

        var child_resources_arr = wpbc_clone_obj( _wpbc.booking__get_param_value( resource_id, 'resources_id_arr__in_dates' ) );
        var child_resource_id;
        var merged_seconds;
        var is_intersect;

        var this_date_time_as_seconds_arr = wpbc_clone_obj( time_to_book__as_seconds_arr );

        // If we are using not time slot but the check in/out times ?
        var is_time_slots = _wpbc.calendar__get_param_value( resource_id, 'booking_recurrent_time' );               // 'On' | 'Off'
        if (
                ( 'On' !== is_time_slots )
             && ( selected_dates_sql__as_arr.length > 1 )
        ){
            if ( 0 == sql_class_day_number ){          // check in
                this_date_time_as_seconds_arr[ 1 ] = 24 * 60 * 60;
            } else if ( (selected_dates_sql__as_arr.length - 1) == sql_class_day_number ){      // check out
                this_date_time_as_seconds_arr[ 0 ] = 0;
            } else {
                this_date_time_as_seconds_arr = [0, 24 * 60 * 60];
            }
        }


        // Loop all resources ID.
        if (child_resources_arr !== null) {
            for (child_resource_id of child_resources_arr) {                                                                // FixIn: 10.9.5.1.
                // [ 2, 10, 12 ,11 ,9 ]  | [3].

                //                                       date_bookings_obj [12].booked_time_slots.merged_seconds
                // _wpbc.bookings_in_calendar__get_for_date(2,'2023-08-21')[12].booked_time_slots.merged_seconds		= [ "07:00:11 - 07:30:02", "10:00:11 - 00:00:00" ]

                if (false !== date_bookings_obj) {
                    if (date_bookings_obj[child_resource_id].is_day_unavailable) {
                        // Unavailable
                        merged_seconds = [[0, 24 * 60 * 60]];
                    } else {
                        // Time slots or Available
                        merged_seconds = date_bookings_obj[child_resource_id].booked_time_slots.merged_seconds;       // [  [ 25211, 27002 ], [ 36011, 86400 ]  ]
                    }

                    is_intersect = wpbc_is_intersect__range_time_interval(
                        [
                            [
                                parseInt(this_date_time_as_seconds_arr[0]) + 20
                                , parseInt(this_date_time_as_seconds_arr[1]) - 20,
                            ],
                        ]
                        , merged_seconds);

                    // Convert Back - Shift time intervals
                    var return_time_to_book = [
                        ((parseInt(this_date_time_as_seconds_arr[0]) - 30) < 0) ? 0 : (parseInt(this_date_time_as_seconds_arr[0]) - 30),
                        ((parseInt(this_date_time_as_seconds_arr[1]) + 30) > 86400) ? 86400 : (parseInt(this_date_time_as_seconds_arr[1]) + 30),
                    ];

                    available_resources_arr[sql_class_day].push({
                        'resource_id'           : child_resource_id,
                        'is_available'          : (!is_intersect),
                        'booked__seconds'       : merged_seconds,
                        'booked__readable'      : date_bookings_obj[child_resource_id].booked_time_slots.merged_readable,
                        'time_to_book__seconds' : return_time_to_book,
                        'time_to_book__readable': [
                            wpbc_js_convert__seconds__to_time_24(return_time_to_book[0]),
                            wpbc_js_convert__seconds__to_time_24(return_time_to_book[1]),
                        ],
                    });
                }
            } // End loop child resources --
        }
    } // End loop dates ----------------

    return available_resources_arr;
}
