<?php

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

require_once( dirname( __FILE__ ) . '/redsys_codes.php' );
require_once( dirname( __FILE__ ) . '/class-redsysapi.php' );