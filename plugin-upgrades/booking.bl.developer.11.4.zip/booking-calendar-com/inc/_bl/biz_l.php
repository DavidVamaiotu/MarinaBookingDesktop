<?php
/*
This is COMMERCIAL SCRIPT
We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
*/

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/booking_resources_l.php' );				// Functions for booking resources		// FixIn: 9.7.3.13.
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/lib_l.php' );
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/update_capacity_hint_shortcode.php' );

require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/l-toolbar.php' );
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/admin/api-settings-l.php' );            // Settings page
// ---------------------------------------------------------------------------------------------------------------------
// Search  availability 																		// FixIn: 10.0.0.18.
// ---------------------------------------------------------------------------------------------------------------------
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/page-search.php' );               // Search Settings page
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/do_search.php' );    							// New Search Engine
// Admin Side
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/searchable__demo_example.php' );    				// Demo examples
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/ui_modal__search/ui_modal_search.php' );			// Modal for Search Filter options
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/page-searchable.php' );    						// Searchable Resources Settings page
// Front-End Side
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/tpl_search_form.php' );    						// New Search Form
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/search/tpl_search_results.php' );    					// New Search Results
// ---------------------------------------------------------------------------------------------------------------------
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/admin/wpbc-coupons-table.php' );
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/admin/page-coupons.php' );              // Settings page
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/admin/activation-l.php' );              // Activate / Deactivate
require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_bl/wpdev-booking-search-widget.php' );

if (file_exists(WPBC_PRO_PLUGIN_DIR. '/inc/_mu/multiuser.php')) { require_once(WPBC_PRO_PLUGIN_DIR. '/inc/_mu/multiuser.php' ); }


class wpdev_bk_biz_l {

    var $wpdev_bk_multiuser;

    function __construct(){

	    add_action( 'wpbc_define_js_vars',      array( &$this, 'wpbc_define_js_vars' ) );
	    add_action( 'wpbc_enqueue_js_files',    array( &$this, 'wpbc_enqueue_js_files' ) );
	    add_action( 'wpbc_enqueue_css_files',   array( &$this, 'wpbc_enqueue_css_files' ) );

	    // Coupons advanced cost customization option.
	    add_bk_filter( 'coupons_discount_apply',                            array( &$this, 'coupons_discount_apply' ) );
	    add_bk_filter( 'get_coupons_discount_info',                         array( &$this, 'get_coupons_discount_info' ) );
	    add_bk_filter( 'wpdev_get_additional_description_about_coupons',    array( &$this, 'wpdev_get_additional_description_about_coupons' ) );
	    add_bk_filter( 'wpbc_get_coupon_code_discount_value',               array( &$this, 'wpbc_get_coupon_code_discount_value' ) );
	    add_bk_action( 'wpbc_set_coupon_inactive',                          array( &$this, 'wpbc_set_coupon_inactive' ) );

	    add_bk_filter( 'cancel_pending_same_resource_bookings_for_specific_dates', array( &$this, 'cancel_pending_same_resource_bookings_for_specific_dates' ) );  // Modify Result of dates

	    // If number = 1 - its means that  booking resource - single
	    add_bk_filter( 'wpbc_get_number_of_child_resources',    array( &$this, 'get_max_available_items_for_resource' ) );

	    // Booking Page  - Show only for PARENT booking resource
	    add_bk_action( 'check_if_bk_res_parent_with_childs_set_parent_res', array( &$this, 'check_if_bk_res_parent_with_childs_set_parent_res' ) );


	    $this->wpdev_bk_multiuser = ( class_exists( 'wpdev_bk_multiuser' ) ) ? new wpdev_bk_multiuser() : false;
    }


	// <editor-fold defaultstate="collapsed" desc=" S U P P O R T       F u n c t i o n s ">


		/**
		 * Define JavaScripts Variables
		 *
		 * @param $where_to_load
		 *
		 * @return void
		 */
		function wpbc_define_js_vars( $where_to_load = 'both' ){

			$my_page = 'client';                                            // Get a page.
			if ( wpbc_is_new_booking_page() ) {
				$my_page = 'add';
			} else if ( wpbc_is_bookings_page() ) {
				$my_page = 'booking';
			}

			if (
				   ( 'add' === $my_page )
				&& ( ! isset( $_GET['booking_type'] ) )                           // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing                   // For situation, when default bk resource is not set and this is parent resource
				&& ( '' == get_bk_option( 'booking_default_booking_resource' ) )  // and default booking resource == 'All resources'.
			) {
				wpbc_set_default_resource_to__get();
			}
		}


		/**
		 * Load JavaScripts Files
		 *
		 * @param $where_to_load
		 *
		 * @return void
		 */
		function wpbc_enqueue_js_files( $where_to_load = 'both' ){
			wp_enqueue_script( 'wpbc-bl', WPBC_PRO_PLUGIN_URL . '/inc/js/biz_l.js', array( 'wpbc_all' ), WPBC_PRO_VERSION_NUM, array( 'in_footer' => WPBC_PRO_JS_IN_FOOTER ) );
			wp_enqueue_script( 'wpbc-bl-hints', WPBC_PRO_PLUGIN_URL . '/inc/js/_out/capacity_hints.js', array( 'wpbc_all' ), WPBC_PRO_VERSION_NUM, array( 'in_footer' => WPBC_PRO_JS_IN_FOOTER ) );
		}


		/**
		 * Load CSS Files
		 *
		 * @param $where_to_load
		 *
		 * @return void
		 */
		function wpbc_enqueue_css_files( $where_to_load = 'both' ) {
			// if ( ( $where_to_load == 'client' ) || ( $where_to_load == 'both' ) ) {
			//   wp_enqueue_style('wpbc-css-search-form', WPBC_PRO_PLUGIN_URL . '/inc/css/search-form.css', array( ), WPBC_PRO_VERSION_NUM );
			// }
		}

	// </editor-fold>


	// <editor-fold defaultstate="collapsed" desc=" C O U P O N S  ">

        // Apply advanced cost to the cost from PayPal form
        function coupons_discount_apply( $summ , $form , $bktype  ){

	        $original_summ = $summ;                                         // Original cost for booking

	        $this->delete_expire_coupons();  // Delete some coupons if they are expire already

	        $coupons = $this->get_coupons_for_this_resource( $bktype );

	        if ( count( $coupons ) <= 0 ) {
		        return $original_summ;
	        }               // No coupons so return as it is

	        $booking_form_show = wpbc__legacy__get_form_content_arr( $form, $bktype );

	        if ( isset( $booking_form_show['coupon'] ) ) {
		        if ( ! empty( $booking_form_show['coupon'] ) ) {

			        $entered_code = $booking_form_show['coupon'];
			        $entered_code = trim( stripslashes( $entered_code ) );
			        foreach ( $coupons as $coupon ) {

				        $entered_code        = strtolower( $entered_code );                                            // FixIn: 7.2.1.3.
				        $coupon->coupon_code = strtolower( $coupon->coupon_code );                                    // FixIn: 7.2.1.3.

				        if ( $entered_code == $coupon->coupon_code ) {

					        if ( ( $summ >= $coupon->coupon_min_sum ) && ( ! empty( $coupon->coupon_active ) ) ) {        //FixIn: 5.4.2
						        if ( $coupon->coupon_type == 'fixed' ) {      // Fixed discount
							        if ( $coupon->coupon_value < $summ ) {
								        return ( $original_summ - $coupon->coupon_value );
							        } else {
								        return 0;                                                                    // FixIn: 8.1.2.2.
							        }
						        }
						        if ( $coupon->coupon_type == '%' ) {          // Procent of
							        if ( $coupon->coupon_value <= 100 ) {
								        return ( $original_summ - $coupon->coupon_value * $original_summ / 100 );
							        }
						        }
					        }
				        }
			        }

		        }
	        }
	        return $original_summ;
        }


        //FixIn: 5.4.2
        /**
	 * Set coupons inactive after specific number of usage
         *
         * @global type $wpdb
         * @param type $booking_id
         * @param type $bktype
         * @param type $booking_days_count
         * @param type $times_array
         * @param type $form
         * @return boolean
         */
		function wpbc_set_coupon_inactive( $booking_id, $bktype, $booking_days_count, $times_array, $form  ) {

	        global $wpdb;

	        $coupons = $this->get_coupons_for_this_resource( $bktype );

	        if ( count( $coupons ) <= 0 ) {
		        return false;
	        }                            // No coupons so return as it is

	        $booking_form_show = wpbc__legacy__get_form_content_arr( $form, $bktype );
	        if ( isset( $booking_form_show['coupon'] ) ) {
		        if ( ! empty( $booking_form_show['coupon'] ) ) {

			        $entered_code = $booking_form_show['coupon'];
			        $entered_code = trim( stripslashes( $entered_code ) );
			        $entered_code = strtolower( $entered_code );                                                    // FixIn: 8.2.1.19.

			        foreach ( $coupons as $coupon ) {

				        if ( $entered_code == $coupon->coupon_code ) {
					        if ( /*( $summ >= $coupon->coupon_min_sum ) &&*/ ( ! empty( $coupon->coupon_active ) ) ) {
						        // Set  coupon one time lower
						        $coupon_active = ( (int) $coupon->coupon_active ) - 1;
						        $wp_query      = "UPDATE {$wpdb->prefix}booking_coupons SET coupon_active = {$coupon_active} WHERE coupon_id = {$coupon->coupon_id}";
								// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
								$wpdb->query( $wp_query );

						        return true;
					        }
				        }
			        }
		        }
	        }

	        return false;
        }


		/**
		 * Get > Array discount information,   if it can be applied to the specific bk_resource and summ or return FALSE
		 *
		 * @param $summ
		 * @param $form
		 * @param $bktype
		 *
		 * @return array|false
		 */
		function get_coupons_discount_info( $summ, $form, $bktype ) {

			$original_summ = $summ;                                         // Original cost for booking

			$coupons = $this->get_coupons_for_this_resource( $bktype );

			if ( count( $coupons ) <= 0 ) {
				return false;
			}               // No coupons so return as it is

			$booking_form_show = wpbc__legacy__get_form_content_arr( $form, $bktype );

			if ( isset( $booking_form_show['coupon'] ) ) {
				if ( ! empty( $booking_form_show['coupon'] ) ) {

					$entered_code = $booking_form_show['coupon'];
					$entered_code = trim( stripslashes( $entered_code ) );
					$entered_code = strtolower( $entered_code );                                                    // FixIn: 8.0.2.7.

					foreach ( $coupons as $coupon ) {

						if ( $entered_code == $coupon->coupon_code ) {
							if ( ( $summ >= $coupon->coupon_min_sum ) && ( ! empty( $coupon->coupon_active ) ) ) {          //FixIn: 5.4.2
								if ( $coupon->coupon_type == 'fixed' ) {      // Fixed discount
									if ( $coupon->coupon_value < $summ ) {

										$currency = wpbc_get_currency_symbol_for_user( $bktype );

										// FixIn: 8.7.3.8.
										return ( array(
											$original_summ ,
											number_format( (float) $coupon->coupon_value, wpbc_get_cost_decimals(), '.', '' ) ,
											addslashes( $entered_code ) ,
											$currency . number_format( (float) $coupon->coupon_value, wpbc_get_cost_decimals(), '.', '' )
										) );
									} else {

										$currency = wpbc_get_currency_symbol_for_user( $bktype );                        // FixIn: 8.1.2.2.
										// FixIn: 8.7.3.8.
										return ( array(
											$original_summ ,
											number_format( (float) $coupon->coupon_value, wpbc_get_cost_decimals(), '.', '' ) ,
											addslashes( $entered_code ) ,
											$currency . number_format( (float) $original_summ, wpbc_get_cost_decimals(), '.', '' )
										) );

									}
								}
								if ( $coupon->coupon_type == '%' ) {          // Procent of
									if ( $coupon->coupon_value < 100 ) {
										// FixIn: 8.7.3.8.
										return ( array(
											$original_summ ,
											number_format( (float) ( $coupon->coupon_value * $original_summ / 100 ), wpbc_get_cost_decimals(), '.', '' ) ,
											addslashes( $entered_code ) ,
											round( $coupon->coupon_value, 0 ) . '%'
										) );
									}
								}
							}
						}
					}
				}
			}
			return false;
        }


		function wpbc_get_coupon_code_discount_value( $blank, $bk_type, $dates, $time_array, $form_post ) {

			// Get COST without discount 																				// FixIn: 8.7.11.2.
			$is_discount_calculate = false;

			$is_booking_coupon_code_directly_to_days = get_bk_option( 'booking_coupon_code_directly_to_days' );
			if ( 'On' == $is_booking_coupon_code_directly_to_days ) {
				$is_only_original_cost = true;
			} else {
				$is_only_original_cost = false;
			}

			$summ_without_discounts = wpbc_calc__booking_cost( array(
																		'resource_id'           => $bk_type ,
																		'str_dates__dd_mm_yyyy' => $dates, 						// '14.11.2023, 15.11.2023, 16.11.2023, 17.11.2023'
																		'times_array'           => $time_array ,
																		'form_data'             => $form_post,  				// 'text^selected_short_timedates_hint4^06/11/2018 14:00...'
																		'is_discount_calculate' => $is_discount_calculate ,
																		'is_only_original_cost' => $is_only_original_cost
																	) );

			// Get Array with info according discount
			$additional_discount_info = $this->get_coupons_discount_info( $summ_without_discounts, $form_post, $bk_type );

			$coupon_value = 0;

			if ( $additional_discount_info !== false ) {                      											// If discount is exist

				$coupon_value = $additional_discount_info[1];                                                           //  % with currency
			}

			return $coupon_value;
		}


        // Get Line with description according Coupon Discount, which is applied
		function wpdev_get_additional_description_about_coupons( $blank, $bk_type, $dates, $time_array, $form_post ) {

			// get COST without discount 																				// FixIn: 8.7.11.2.
			$is_discount_calculate = false;

			$is_booking_coupon_code_directly_to_days = get_bk_option( 'booking_coupon_code_directly_to_days' );
			if ( 'On' == $is_booking_coupon_code_directly_to_days ) {
				$is_only_original_cost = true;
			} else {
				$is_only_original_cost = false;
			}
			$summ_without_discounts = wpbc_calc__booking_cost( array(
																		'resource_id'           => $bk_type,  // '2'
																		'str_dates__dd_mm_yyyy' => $dates,  // '14.11.2023, 15.11.2023, 16.11.2023, 17.11.2023'
																		'times_array'           => $time_array ,
																		'form_data'             => $form_post,  // 'text^selected_short_timedates_hint4^06/11/2018 14:00...'
																		'is_discount_calculate' => $is_discount_calculate ,
																		'is_only_original_cost' => $is_only_original_cost
																	) );
			// Get Array with info according discount
			$additional_discount_info = $this->get_coupons_discount_info( $summ_without_discounts, $form_post, $bk_type );

			if ( $additional_discount_info !== false ) {                      											// If discount is exist

				$currency = wpbc_get_currency_symbol_for_user( $bk_type );

				if ( strpos( $additional_discount_info[3], '%' ) !== false )    										// % or $
				{
					$coupon_value = $additional_discount_info[3] . ' (' . $currency . $additional_discount_info[1] . ')';		//  % with currency
				} else {
					$coupon_value = $additional_discount_info[3];
				}                                                          												// Only currency


				$blank  = '<div class="coupon_description_wrapper">';
				$blank .= 	'<div class="coupon_description">';
				$blank .= 	  '[ ' . __( 'Discounts applied', 'booking' ) . ': <strong>&quot;' . $additional_discount_info[2] . '&quot;</strong>: ' . $coupon_value . ' ]';
				$blank .= 	'</div>';
				$blank .= '</div>';

				// FixIn: 8.3.3.2.
				$blank = wpbc_replace_shortcode_hint( $blank, array(
					'shortcode'  => '[coupon_discount_hint]' ,
					'span_class' => 'coupon_discount_hint_tip' . $bk_type,
					'span_value' => '...' ,
					'input_name' => 'coupon_discount_hint_hint' . $bk_type,
					'input_data' => '...'
				) );

			}

			return $blank;
        }


	// Delete all expire coupons
	function delete_expire_coupons() {
		global $wpdb;
		$wpbc_bdtb_coupons = $wpdb->prefix . "booking_coupons";
		$sql               = "DELETE FROM $wpbc_bdtb_coupons WHERE expiration_date < " . wpbc_sql_date_math_expr_explicit('', 'curdate') . " ";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
		if ( false === $wpdb->query( $sql ) ) {
			echo '<div class="error_message ajax_message textleft" style="font-size:12px;font-weight:600;">';
			debuge_error( 'Error during deleting from DB coupon', __FILE__, __LINE__ );
			echo '</div>';
		}
	}


	// Get coupons for specific resource
	function get_coupons_for_this_resource( $my_bk_type_id = '' ) {
		global $wpdb;
		$wpbc_bdtb_coupons = $wpdb->prefix . "booking_coupons";
		$sql               = "SELECT * FROM $wpbc_bdtb_coupons WHERE expiration_date >= " . wpbc_sql_date_math_expr_explicit('', 'curdate') . "";
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$result = $wpdb->get_results( $sql . " AND (support_bk_types='all' OR support_bk_types LIKE '%," . $my_bk_type_id . ",%')" );

		return $result;
	}

 	// </editor-fold>


	// <editor-fold defaultstate="collapsed" desc=" S U P P O R T     A D M I N     F u n c t i o n s ">

		/**
		 * Get Maximum available of items for this resource. Based on capacity.
		 *
		 * @param $bk_type
		 *
		 * @return int|mixed
		 */
		function get_max_available_items_for_resource( $bk_type ) {
			$bk_types = wpbc_get_booking_resources_bl__from_db__arr( $bk_type );
			$bk_types = wpbc_get_booking_resources_as_hierarchy_arr( $bk_types );
			if ( isset( $bk_types[ $bk_type ] ) ) {
				if ( isset( $bk_types[ $bk_type ]['count'] ) ) {
					$max_available_items = $bk_types[ $bk_type ]['count'];
				}
			}

			if ( isset( $max_available_items ) ) {
				return $max_available_items;
			} else {
				return 1;
			}
		}


	// </editor-fold>


	// <editor-fold defaultstate="collapsed" desc="  ==  Cancel Pending bookings  ==  ">

		/**
		 * Cancel Pending bookings for the specific dates of bookings list, of the same booking resource
		 *
		 * @param $blank
		 * @param $approved_id_str
		 *
		 * @return mixed|string
		 */
		function cancel_pending_same_resource_bookings_for_specific_dates( $blank, $approved_id_str ) {

			$is_show_pending_days_as_available                      = get_bk_option( 'booking_is_show_pending_days_as_available' );
			$booking_auto_cancel_pending_bookings_for_approved_date = get_bk_option( 'booking_auto_cancel_pending_bookings_for_approved_date' );

			// If the show pending as available AND auto cancellation is not activated so  then SKIP
			if ( ( $is_show_pending_days_as_available != 'On' ) ||
				 ( $booking_auto_cancel_pending_bookings_for_approved_date != 'On' )
			) {
				return $blank;
			}

			global $wpdb;

			$approved_id_str_array = explode( ',', $approved_id_str );

			$my_bk_array = array();

			// Because we can have the several ID from the different Booking resources,
			// So that's why we are need to work separately with  each booking, because we
			// are need to cancel  only the bookings from the same Booking Resource
			foreach ( $approved_id_str_array as $approved_id_str ) {

				$trash_bookings = ' AND bk.trash != 1 ';                                //FixIn: 6.1.1.10  - check also  below usage of {$trash_bookings}

				$approved_id_str = (int) $approved_id_str;
				// Select the Dates and Booking Resources of the Bookings, what  was APPROVED
				$mysql = "SELECT DISTINCT (dt.booking_date) AS date, bk.booking_type
							  FROM {$wpdb->prefix}bookingdates as dt
								 INNER JOIN {$wpdb->prefix}booking as bk
								 ON    bk.booking_id = dt.booking_id                                     
							   WHERE dt.booking_id = {$approved_id_str} {$trash_bookings}  
							  ORDER BY date ASC";

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$my_dates = $wpdb->get_results( $mysql );

				if ( count( $my_dates ) == 0 ) {
					break;
				}

				// Get Start and Last dates - its because we was order by dates
				$wh_booking_date  = $my_dates[0]->date;
				$wh_booking_date2 = $my_dates[ ( count( $my_dates ) - 1 ) ]->date;


				//Ceck  times - If we have the FULL date booking, so then set start and the end times in correct way as FULL
				$check_start_time = substr( $wh_booking_date, 11 );
				if ( $check_start_time == '00:00:01' ) {
					$wh_booking_date = substr( $wh_booking_date, 0, 11 ) . '00:00:00';
				}
				$check_end_time = substr( $wh_booking_date2, 11 );
				if ( ( $check_end_time == '00:00:00' ) || ( $check_end_time == '00:00:02' ) ) {
					$wh_booking_date2 = substr( $wh_booking_date2, 0, 11 ) . '23:59:59';
				}


				// Booking resource
				$wh_booking_type = $my_dates[0]->booking_type;

				// Pending
				$wh_approved = '0';

				// Get Pending bookings ID of the same Booking Resource
				$sql_start_select = " SELECT bk.booking_id as id ";
				$sql              = " FROM {$wpdb->prefix}booking as bk";
				$sql_where        = " WHERE " .                                                      // Date (single) connection (Its required for the correct Pages in SQL: LIMIT Keyword)
									"       EXISTS (
											 SELECT *
											 FROM {$wpdb->prefix}bookingdates as dt
											 WHERE  bk.booking_id = dt.booking_id {$trash_bookings} ";
				$sql_where        .= " AND dt.approved = " . $wh_approved . " ";            // Pending
				$sql_where        .= " AND ( dt.booking_date >= '" . $wh_booking_date . "' ) ";
				$sql_where        .= " AND ( dt.booking_date <= '" . $wh_booking_date2 . "' ) ";
				$sql_where        .= " AND (  ";
				$sql_where        .= "       ( bk.booking_type IN  ( " . $wh_booking_type . " ) ) ";     // BK Resource conections
				$sql_where        .= apply_bk_filter( 'get_l_bklist_sql_resources', '', $wh_booking_type, $wh_approved, $wh_booking_date, $wh_booking_date2 );
				$sql_where        .= "     )  ";
				$sql_where        .= "     )  ";

				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
				$my_bk = $wpdb->get_results( $sql_start_select . $sql . $sql_where );

				foreach ( $my_bk as $value ) {
					if ( ! in_array( $value->id, $my_bk_array ) ) {
						$my_bk_array[] = $value->id;
					}
				}
			}

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			if ( isset( $_POST['user_id'] ) ) {
				$user_bk_id = sanitize_text_field( wp_unslash( $_POST['user_id'] ) );  /* phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing */ /* FixIn: sanitize_unslash */
			} else {
				$user       = wpbc_get_current_user();
				$user_bk_id = $user->ID;
			}

			$all_bk_id = implode( '|', $my_bk_array );

			if ( ! empty( $my_bk_array ) ) {
				//FixIn: 9.7.4.5   9.7.4.5.1
				$action_result = wpbc_booking_do_action__trash_booking_or_restore( $my_bk_array
					, array(
						'user_id'          => $user_bk_id,
						'reason_of_action' => '',
						'is_trash'         => '1'
					)
				);
			}

			return $all_bk_id;
		}

	// </editor-fold>


	// <editor-fold defaultstate="collapsed" desc=" A d m i n   B O O K I N G   P a g e ">

		/**
		 * Check if this resource Parent and have some childs, so then assign to $_GET['parent_res'] = 1
		 *
		 * @param $bk_type_id
		 *
		 * @return void
		 */
		function check_if_bk_res_parent_with_childs_set_parent_res( $bk_type_id ) {

			if ( wpbc_get_child_resources_number( $bk_type_id ) ) {
				$_GET['parent_res'] = 1;
			}
		}

	 // </editor-fold>

}