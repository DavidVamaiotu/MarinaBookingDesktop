<?php
/**
 * @version     1.0
 * @package     General Settings API - Saving different options
 * @category    Settings API
 * @author      wpdevelop
 *
 * @web-site    https://wpbookingcalendar.com/
 * @email       info@wpbookingcalendar.com 
 * @modified    2016-02-28
 * 
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly


/**
	 * Check in/out  - Settings ( Calendar ) page
 * 
 * @param array $fields
 * @return array
 */
function wpbc_settings_calendar_check_in_out_times__bl( $fields, $default_options_values ) {
    
    //  Divider  ///////////////////////////////////////////////////////////////        
    $fields['hr_calendar_before_rcheck_in_available_for_parents'] = array( 'type' => 'hr', 'group' => 'calendar' , 'tr_class'    => 'wpbc_recurrent_check_in_out_time_slots wpbc_check_in_out_time_slots wpbc_sub_settings_grayed');
    
    $fields['booking_check_in_available_for_parents'] = array(   
                            'type'          => 'checkbox'
                            , 'default'     => $default_options_values['booking_check_in_available_for_parents']   //'Off'            
                            , 'title'       =>  ''
                            , 'label'       => __('Use "Check In" date as available in calendar for booking resources with capacity higher than 1 for search results' ,'booking')
                            , 'description' => ''
                            , 'group'       => 'calendar'
                            , 'tr_class'    => 'wpbc_recurrent_check_in_out_time_slots wpbc_check_in_out_time_slots wpbc_sub_settings_grayed'
        );    
    $fields['booking_check_out_available_for_parents'] = array(   
                            'type'          => 'checkbox'
                            , 'default'     => $default_options_values['booking_check_out_available_for_parents']   //'Off'            
                            , 'title'       =>  ''
                            , 'label'       => __('Use "Check Out" date as available in calendar for booking resources with capacity higher than 1 for search results' ,'booking')
                            , 'description' => ''
                            , 'group'       => 'calendar'
                            , 'tr_class'    => 'wpbc_recurrent_check_in_out_time_slots wpbc_check_in_out_time_slots wpbc_sub_settings_grayed'
        );    
    
    return $fields;
}
add_filter('wpbc_settings_calendar_check_in_out_times', 'wpbc_settings_calendar_check_in_out_times__bl' ,10, 2);            // Check In/Out Times


/**
	 * Showing availability in tooltip - Settings ( Calendar ) page
 * 
 * @param array $fields 
 * @return array
 */
function wpbc_settings_calendar_showing_info_in_cal__bl( $fields, $default_options_values ) {
    
    // Showing availability in tooltip
    $fields['booking_is_show_availability_in_tooltips'] = array(   
                            'type'          => 'checkbox'
                            , 'default'     => $default_options_values['booking_is_show_availability_in_tooltips']   //'Off'            
                            , 'title'       =>  __('Show availability in tooltip' ,'booking')
                            , 'label'       => __('Check this box to display the available number of booking resources with a tooltip, when mouse hovers over each day on the calendar(s).' ,'booking')
                            , 'description' => ''
                            , 'group'       => 'days_tooltips'
                            , 'tr_class'    => ''
        );       
    $fields['booking_highlight_availability_word'] = array(   
                                'type'          => 'text'
                                , 'default'     => $default_options_values['booking_highlight_availability_word']   //__('Available: ' ,'booking')
                                , 'placeholder' => __('Available: ' ,'booking')
                                , 'title'       => __('Availability Title' ,'booking')                                
                                /* translators: 1: ... */
                                , 'description' => sprintf( __( 'Type your %1$savailability%2$s description', 'booking' ),'<b>','</b>')
                                //,'description_tag' => 'span'
                                , 'class'       => 'regular-text'
                                , 'group'       => 'days_tooltips'
                                , 'tr_class'    => 'wpbc_show_availability_in_tooltips wpbc_sub_settings_grayed'
                        );

    // Showing availability in Date Cells 		// FixIn: 10.6.4.1.
    $fields['booking_is_show_availability_in_date_cell'] = array(
                            'type'          => 'checkbox'
                            , 'default'     => $default_options_values['booking_is_show_availability_in_date_cell']   //'Off'
                            , 'title'       =>  __('Show availability in date cell' ,'booking')
                            , 'label'       => __('Check this box to display the available number of booking resources at the date cells in the calendar(s).' ,'booking')
                            , 'description' => ''
                            , 'group'       => 'days_tooltips'
                            , 'tr_class'    => ''
        );
    $fields['booking_highlight_availability_word_in_date_cell'] = array(
                                'type'          => 'text'
                                , 'default'     => $default_options_values['booking_highlight_availability_word_in_date_cell']   //__('available' ,'booking')
                                , 'placeholder' => __( 'available', 'booking' ) . ' / ' . __( 'slots', 'booking' ) . ' / ' . __( 'rooms', 'booking' )
                                , 'title'       => __('Availability Title' ,'booking')
                                /* translators: 1: ... */
                                , 'description' => sprintf( __( 'Type your %1$savailability%2$s description', 'booking' ),'<b>','</b>')
                                //,'description_tag' => 'span'
                                , 'class'       => 'regular-text'
                                , 'group'       => 'days_tooltips'
                                , 'tr_class'    => 'wpbc_show_availability_in_date_cell wpbc_sub_settings_grayed'
                        );

    return $fields;
}
add_filter('wpbc_settings_calendar_showing_info_in_cal', 'wpbc_settings_calendar_showing_info_in_cal__bl' ,10, 2);


// FixIn: 10.10.1.2
/*
function wpbc_settings_resource_no_update__during_editing__bl( $fields, $default_options_values ) {


    //  Divider  ///////////////////////////////////////////////////////////////
    $fields['hr_booking_is_resource_no_update__during_editing'] = array( 'type' => 'hr', 'group' => 'bookings_options' );

	//FixIn: 9.4.2.3			in  Advanced section
    $fields['booking_is_resource_no_update__during_editing'] = array(
                            'type'          => 'checkbox'
                            , 'default'     => $default_options_values['booking_is_resource_no_update__during_editing']   //'On'
                            , 'title'       => __('Disable changing booking resource while editing a booking' ,'booking')
                            , 'label'       => __('Check this box to disable changing the booking resource when editing a booking.' ,'booking')
                            , 'description' => '<strong>' . esc_html__('Note' ,'booking') . '!</strong> ' . esc_html__('If this check box is not selected, the system updates the booking to the first available child booking resource based on the capacity and availability of the parent booking resource.' ,'booking')
                            , 'group'       => 'bookings_options'
                            , 'tr_class'    => ''
		//, 'disabled' => true
	);

	return $fields;
}
add_filter('wpbc_settings_resource_no_update__during_editing', 'wpbc_settings_resource_no_update__during_editing__bl' ,10, 2);
*/

/**
	 * JavaScript     at Bottom of Settings page
 *
 * @param string $page_tag
 */
function wpbc_settings_enqueue_js__bl( $page_tag, $active_page_tab, $active_page_subtab ) {

    // Check if this correct  page /////////////////////////////////////////////

	if ( ! (
		     ( 'wpbc-settings' === $page_tag ) &&                               // Load only at 'wpbc-settings' menu.
			 ( ( ! isset( $_GET['tab'] ) ) || ( 'general' === $_GET['tab'] ) )  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
	) ) {
		return;
	}

    // JavaScript //////////////////////////////////////////////////////////////
    $js_script = '';

    // Hide Availability Word sub-settings, if the checkbox have not checked
    $js_script .= " 
                    // Hide Availability Word sub-settings, if the checkbox have not checked
                    if ( ! jQuery('#set_gen_booking_is_show_availability_in_tooltips').is(':checked') ) {   
                        jQuery('.wpbc_show_availability_in_tooltips').addClass('hidden_items'); 
                    }
    
                    ";

    // Hide or show Availability Word in tooltip subsettings,  if the checkbox checked
    $js_script .= " jQuery('#set_gen_booking_is_show_availability_in_tooltips').on( 'change', function(){    
                            if ( this.checked ) { 
                                jQuery('.wpbc_show_availability_in_tooltips').removeClass('hidden_items');               // Show 
                            } else {
                                jQuery('.wpbc_show_availability_in_tooltips').addClass('hidden_items');                  // Hide 
                            }
                        } ); ";
	// FixIn: 10.6.4.1.
    // Hide Availability Word sub-settings, if the checkbox have not checked
    $js_script .= " 
                    // Hide Availability Word sub-settings, if the checkbox have not checked
                    if ( ! jQuery('#set_gen_booking_is_show_availability_in_date_cell').is(':checked') ) {   
                        jQuery('.wpbc_show_availability_in_date_cell').addClass('hidden_items'); 
                    }
    
                    ";

    // Hide or show Availability Word in tooltip subsettings,  if the checkbox checked
    $js_script .= " jQuery('#set_gen_booking_is_show_availability_in_date_cell').on( 'change', function(){    
                            if ( this.checked ) { 
                                jQuery('.wpbc_show_availability_in_date_cell').removeClass('hidden_items');               // Show 
                            } else {
                                jQuery('.wpbc_show_availability_in_date_cell').addClass('hidden_items');                  // Hide 
                            }
                        } ); ";

    wpbc_enqueue_js( $js_script );                                              // Eneque JS to  the footer of the page.
}
add_action( 'wpbc_after_settings_content',  'wpbc_settings_enqueue_js__bl', 10, 3 );




////////////////////////////////////////////////////////////////////////////////
// Booking Resources Table
////////////////////////////////////////////////////////////////////////////////


/**
	 * Add Column to Resources Table -- Header
 *
 * @param array $columns
 * @return array
 */
function wpbc_resources_table_header__parentchild_title__bl( $columns ) {

    $columns[ 'parent' ] = array(
                                  'title'   => __( 'Parent', 'booking' )
                                , 'style'   => 'width:12em;text-align:center;'
                                , 'class'   => 'wpbc_hide_mobile_xs'
                                //, 'sortable'=> true
                        );
    $columns[ 'prioritet' ] = array(
                                  'title'   => __( 'Priority', 'booking' )
                                , 'style'   => 'width:7em;'
                                , 'class'   => 'wpbc_hide_mobile'
                                , 'sortable'=> true
                        );

    return $columns;
}
add_filter( 'wpbc_resources_table_header__parentchild_title', 'wpbc_resources_table_header__parentchild_title__bl', 10, 1 );   // Hook for validated fields.

/**
	 * Add Column to Resources Table -- Header
 *
 * @param array $columns
 * @return array
 */
function wpbc_resources_table_header__info_title__bl( $columns ) {

    $columns[ 'info' ] = array(
                                  'title'   => __( 'Info', 'booking' )
                                , 'style'   => 'width:5em;text-align:center;'
                                , 'class'   => 'wpbc_hide_mobile'
                                //, 'sortable'=> true
                        );
    return $columns;
}
add_filter( 'wpbc_resources_table_header__info_title', 'wpbc_resources_table_header__info_title__bl', 10, 1 );   // Hook for validated fields.


//Maybe: to show button  with  selection of users for prevent of too many options...
/**
	 * Show Column in Resources Table - ROW
 *
 * @param int $row_num
 * @param array $resource
 */
function wpbc_resources_table_show_col__parentchild_field__bl( $row_num, $resource ) {

    $resources_cache = wpbc_br_cache();                                         // Get booking resources from  cache
    $resource_list = $resources_cache->get_single_parent_resources();

    // Parent resource

    $select_options = array();
    ?><div class="ui_element" style="flex:1 1 auto;">
		<label for="booking_resource_parent_<?php echo esc_attr( $resource['id' ] ); ?>"
			   class="wpbc_ui_control_label " style=""><span style="font-weight:400"><?php esc_html_e( 'Parent', 'booking' ); ?>: </span></label>
		<select autocomplete="off"
					id="booking_resource_parent_<?php echo esc_attr( $resource['id' ] ); ?>"
					name="booking_resource_parent_<?php echo esc_attr( $resource['id' ] ); ?>"
					class="wpbc_ui_control wpbc_ui_select"
			><option value="0" <?php selected(  $resource['parent'], '0' ); ?> > - </option><?php

				foreach ( $resource_list as $single_par_resource ) {

						if ($resource['id'] != $single_par_resource['id']) {													// FixIn: 7.1.2.3.
							?>
							<option value="<?php
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo $single_par_resource['id']; ?>" <?php selected(  $resource['parent'], $single_par_resource['id'] ); ?>
								><?php echo esc_html( $single_par_resource['title'] ); ?></option>
						<?php
						}
				}
		?></select><?php
	?></div><?php

    // Priority
    ?><div class="ui_element" style="flex:0 1 auto;">
		<label for="booking_resource_prioritet_<?php echo esc_attr( $resource['id' ] ); ?>"
			   class="wpbc_ui_control_label " style=""><span style="font-weight:400"><?php esc_html_e( 'Priority', 'booking' ); ?>: </span></label>
		<input  type="text"
                value="<?php echo esc_attr( $resource['prioritet'] ); ?>"
                id="booking_resource_prioritet_<?php echo esc_attr( $resource['id' ] ); ?>"
                name="booking_resource_prioritet_<?php echo esc_attr( $resource['id' ] ); ?>"
                class="wpbc_ui_control wpbc_ui_text "
				style="max-width: 69px;"
            />
	</div><?php
}
add_action( 'wpbc_resources_table_show_col__parentchild_field',  'wpbc_resources_table_show_col__parentchild_field__bl', 10, 2 );



/**
	 * Show Column in Resources Table - ROW
 *
 * @param int $row_num
 * @param array $resource
 */
function wpbc_resources_table_show_col__info_text__bl( $row_num, $resource ) {

    $resources_cache = wpbc_br_cache();                                         // Get booking resources from  cache
    $resource_list = $resources_cache->get_single_parent_resources();

        if ( intval($resource['count'] ) > 1 ) {
            ?><span style="font-weight:400;background-color: #e80;font-size: 1;" class="label label-default label-info"><?php esc_html_e( 'Capacity' , 'booking' ); ?>: &nbsp;&nbsp;<strong><?php echo esc_html( $resource['count'] ); ?></strong></span><?php
        } else {

            if ( empty( $resource['parent'] ) ) {
                ?><span style="font-weight:600;background-color: var( --wpbc_admin-default_label-color , #4c74a9);font-size: 1;" class="label label-default label-info"><?php echo esc_html( strtoupper(__( 'Single' , 'booking' ) ) ); ?></span><?php
            } else {
                ?><span style="font-weight:400;background-color: #39d;font-size: 0.8em;" class="label label-default label-info"><?php echo esc_html( strtoupper(__( 'Child' , 'booking' ) ) ); ?></span><?php
            }
        }
}
add_action( 'wpbc_resources_table_show_col__info_text',  'wpbc_resources_table_show_col__info_text__bl', 10, 2 );


/**
	 * Update SQL during Saving data at Booking > Resources page
 *
 * @param array $sql            array(
                                                            'sql' => array(
                                                                                  'start'   => "UPDATE {$wpdb->prefix}bookingtypes SET "
                                                                                , 'params' => array( 'title = %s' )
                                                                                , 'end'    => " WHERE booking_type_id = %d"
                                                                        )
                                                            , 'values' => array(
                                                                                  $validated_value
                                                                        )
                                                        )
 * @param int $resource_id
 * @param array $resource
 * @return string - updated SQL
 */
function wpbc_resources_table__update_sql_array__bl( $sql, $resource_id, $resource ) {

    // Priority
    $validated_prioritet = WPBC_Settings_API::validate_text_post_static( 'booking_resource_prioritet_' . $resource_id );
    $validated_prioritet = intval( $validated_prioritet );

    if ( $validated_prioritet < 0 )
        $validated_prioritet = 0;                                               // Minimum must be 1


    $sql['sql']['params'][] = 'prioritet = %d';
    $sql['values'][]        = $validated_prioritet;


	// Parent.
	$validated_parent = WPBC_Settings_API::validate_text_post_static( 'booking_resource_parent_' . $resource_id );
	$validated_parent = intval( $validated_parent );

	// Check if this booking resource  is not the child booking resource,  otherwise set 0    // FixIn: 9.5.3.2.
	if ( $validated_parent > 0 ) {
		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$is_it_child = $wpdb->get_row( "SELECT parent FROM {$wpdb->prefix}bookingtypes  WHERE booking_type_id = {$validated_parent}" );

		if ( 0 !== intval( $is_it_child->parent ) ) { // It's some child, so  this booking resource,  can  not become parent of some other resource, and we leave it as 0 - single or parent booking resource.
			$validated_parent = 0;
		}
	}

	$sql['sql']['params'][] = 'parent = %d';
	$sql['values'][]        = $validated_parent;


	// Max. Visitors.
	$temp_m_v_resource_id = $resource_id;
	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
	if ( ! isset( $_POST[ 'booking_resource_max_visitors_' . $temp_m_v_resource_id ] ) ) {
		// Check  about child booking resources,  here we need to get  max number of visitors from parent resource.
		if ( ! empty( $resource['parent'] ) ) {
			$temp_m_v_resource_id = $resource['parent'];                                   // Redefine resource ID to parent,  for saving info about max visitors from parent resource (usually  such  rows at  the sam page.
		}
	}

    // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
    if ( isset( $_POST[ 'booking_resource_max_visitors_' . $temp_m_v_resource_id ] ) ) {
        $validated_max_visitors = WPBC_Settings_API::validate_text_post_static( 'booking_resource_max_visitors_' . $temp_m_v_resource_id );
        $validated_max_visitors = intval( $validated_max_visitors );

        if ( $validated_max_visitors < 1 )
            $validated_max_visitors = 1;                                        //Minimum must be 1

        $sql['sql']['params'][] = 'visitors = %d';
        $sql['values'][]        = $validated_max_visitors;
    }

    return $sql;
}
add_filter( 'wpbc_resources_table__update_sql_array', 'wpbc_resources_table__update_sql_array__bl', 10, 3 );   // Hook for validated fields.


/**
	 * Update SQL during Inserting data at Booking > Resources page
 *
 * @param array $sql                                array(
                                                            'sql'       => array(
                                                                                  'start'      => "INSERT INTO {$wpdb->prefix}bookingtypes "
                                                                                , 'params'     => array( 'title' )
                                                                                , 'param_types' => array( '%s' )
                                                                        )
                                                            , 'values'  => array( $validated_title . $sufix )
                                                    )
 * @param array $params                             array( 'sufix' => $sufix )
 * @return array - updated SQL
 */
function wpbc_resources_table__add_new_sql_array__bl( $sql, $params ) {

    $resources_cache = wpbc_br_cache();                                         // Get booking resources from  cache
    $resource_list = $resources_cache->get_single_parent_resources();

    // Priority
    $validated_prioritet = WPBC_Settings_API::validate_text_post_static( 'resources_priority' );
    $validated_prioritet = intval( $validated_prioritet );
    if ( $validated_prioritet < 0 ) $validated_prioritet = 0;
    if ( isset($params['index'] ) ) $validated_prioritet += intval( $params['index'] );

    $sql['sql']['params'][]      = 'prioritet';
    $sql['sql']['param_types'][] = '%d';
    $sql['values'][]             = $validated_prioritet;

    // Parent
    $validated_parent = WPBC_Settings_API::validate_text_post_static( 'select_booking_resource' );
    $validated_parent = intval( $validated_parent );

    $sql['sql']['params'][]      = 'parent';
    $sql['sql']['param_types'][] = '%d';
    $sql['values'][]             = $validated_parent;


    // Get Cost and Max Visitors of parent resource,  if we submit child booking resources
    if (   ( ! empty( $validated_parent ) ) && ( isset( $resource_list[ $validated_parent ] ) )   ){

        $cost_parent = $resource_list[ $validated_parent ][ 'cost' ];

        $sql['sql']['params'][]      = 'cost';
        $sql['sql']['param_types'][] = '%s';
        $sql['values'][]             = $cost_parent;


        $validated_max_visitors = intval( $resource_list[ $validated_parent ][ 'visitors' ] );
        if ( $validated_max_visitors < 1 ) $validated_max_visitors = 1;                                        // Minimum must be 1

        $sql['sql']['params'][]      = 'visitors';
        $sql['sql']['param_types'][] = '%d';
        $sql['values'][]             = $validated_max_visitors;
    }

    return $sql;
}
add_filter( 'wpbc_resources_table__add_new_sql_array', 'wpbc_resources_table__add_new_sql_array__bl', 10, 2 );   // Hook for validated fields.
