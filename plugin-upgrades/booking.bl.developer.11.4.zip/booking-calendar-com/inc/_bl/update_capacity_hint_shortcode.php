<?php
/*
This is COMMERCIAL SCRIPT
We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
*/

if ( ! defined( 'ABSPATH' ) ) exit;                                                                                     // Exit if accessed directly


/**
 * Update [capacity_hint] to  specific number of available items per Date/Time
 *
 * @param string $form_content
 * @param int $resource_id
 * @param string $custom_booking_form_name
 *
 * @return string
 */
function wpbc_update_bookingform_content__capacity_hint( $form_content, $resource_id, $custom_booking_form_name = '' ) {


	$hint_html  = '<div class="wpbc_field_hint capacity_hint capacity_hint_' . $resource_id . '">&nbsp;...&nbsp;</div> ';

//	$hint_html .= '<scrit tye="text/javascript">';
//	$hint_html .= '	jQuery( ".booking_form_div" ).on(\'wpbc_booking_date_or_option_selected\', function( event, resource_id ) { ';
//	$hint_html .= '	  if( resource_id == '.intval($resource_id).') { wpbc_update_capacity_hint( resource_id, \'.capacity_hint_\' + resource_id ); } ';
//	$hint_html .= '	}); ';
//	$hint_html .= '</scrit>';

	$form_content = str_replace( '[capacity_hint]', $hint_html, $form_content );


	return $form_content;
}

add_filter( 'wpbc_booking_form_content__after_load', 'wpbc_update_bookingform_content__capacity_hint', 10, 3 );