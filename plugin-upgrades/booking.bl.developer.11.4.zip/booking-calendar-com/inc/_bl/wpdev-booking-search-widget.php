<?php /**
 * @version 1.0
 * @package  Booking Calendar
 * @category Booking Calendar Widgets
 * @author wpdevelop
 *
 * @web-site https://wpbookingcalendar.com/
 * @email info@wpbookingcalendar.com
 *
 * @modified 2024-10-08
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit, if accessed directly           // FixIn: 10.6.2.1.

// BookingWidget Class
class BookingSearchWidget extends WP_Widget {
    /** constructor */
    function __construct() {
        parent::__construct(false, $name = 'Booking Calendar - Search Form');
    }

    /** @see WP_Widget::widget */
    function widget($args, $instance) {

        extract( $args );

	    $booking_search_widget_title         = __( 'Search availability', 'booking' );                                    // FixIn: 6.1.1.11.
	    $booking_search_widget_searchresults = '';

	    if ( isset( $instance['booking_search_widget_title'] ) ) {                                                        // FixIn: 6.1.1.11.
		    $booking_search_widget_title = apply_filters( 'widget_title', $instance['booking_search_widget_title'] );
	    }
	    if ( function_exists( 'icl_translate' ) ) {
		    $booking_search_widget_title = icl_translate( 'wpml_custom', 'wpbc_custom_widget_bookingsearch_title1', $booking_search_widget_title );
	    }

	    $booking_search_widget_title = wpbc_lang( $booking_search_widget_title );                                        // FixIn: 9.2.3.2.

	    if ( isset( $instance['booking_search_widget_searchresults'] ) ) {                                                // FixIn: 6.1.1.11.
		    $booking_search_widget_searchresults = $instance['booking_search_widget_searchresults'];
	    }

        
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $before_widget;

	    if ( $booking_search_widget_title != '' ) {
			// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		    echo $before_title . esc_js( $booking_search_widget_title ) . $after_title;
	    }

        echo "<div class='widget_wpdev_booking'>";

			$booking_search_widget_searchresults = esc_js( $booking_search_widget_searchresults );
			$booking_search_widget_searchresults = wpbc_lang( $booking_search_widget_searchresults );

			echo do_shortcode( '[bookingsearch searchresults="' . esc_attr( $booking_search_widget_searchresults ) . '" ]' );

        echo "</div>";

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $after_widget;
    }



    /** @see WP_Widget::update */
    function update($new_instance, $old_instance) {

	    $instance = $old_instance;

	    $instance['booking_search_widget_title']         = sanitize_textarea_field( $new_instance['booking_search_widget_title'] );
	    $instance['booking_search_widget_searchresults'] = sanitize_textarea_field( $new_instance['booking_search_widget_searchresults'] );

	    return $instance;
    }

    /** @see WP_Widget::form */
	function form( $instance ) {

		$booking_search_widget_title         = ( isset( $instance['booking_search_widget_title'] ) )
			? esc_attr( $instance['booking_search_widget_title'] )
			: __( 'Search availability', 'booking' );
		$booking_search_widget_searchresults = ( isset( $instance['booking_search_widget_searchresults'] ) )
			? esc_attr( $instance['booking_search_widget_searchresults'] )
			: '';
		?>
		<p>
			<label
				for="<?php echo esc_attr( $this->get_field_id( 'booking_search_widget_title' ) ); ?>"><?php esc_html_e( 'Title of search widget', 'booking' ); ?>
				:</label><br/>
			<input value="<?php echo esc_attr( $booking_search_widget_title ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'booking_search_widget_title' ) ); ?>"
				   id="<?php echo esc_attr( $this->get_field_id( 'booking_search_widget_title' ) ); ?>"
				   type="text" class="widefat" style="width:100%;line-height: 1.5em;"/>
		</p>

		<p>
			<label
				for="<?php echo esc_attr( $this->get_field_id( 'booking_search_widget_searchresults' ) ); ?>"><?php esc_html_e( 'URL of Search Results', 'booking' ); ?>
				*:</label><br/>
			<input value="<?php echo esc_attr( $booking_search_widget_searchresults ); ?>"
				   name="<?php echo esc_attr( $this->get_field_name( 'booking_search_widget_searchresults' ) ); ?>"
				   id="<?php echo esc_attr( $this->get_field_id( 'booking_search_widget_searchresults' ) ); ?>"
				   type="text" class="widefat" style="width:100%;line-height: 1.5em;"/>
			<span
				style="font-size:10px;"><?php
				/* translators: 1: ... */
				echo wp_kses_post( sprintf( __( 'Please type the URL of the page %1$s(with %2$s shortcode in content)%3$s, where search results will show.', 'booking' ), '', '<strong>[bookingsearchresults]</strong>', '' ) ); ?></span>
		</p>
		<?php
	}

}

function register_wpbc_search_widget() {																				// FixIn: 8.1.3.18.
	register_widget( "BookingSearchWidget" );
}
add_action( 'widgets_init', 'register_wpbc_search_widget' );