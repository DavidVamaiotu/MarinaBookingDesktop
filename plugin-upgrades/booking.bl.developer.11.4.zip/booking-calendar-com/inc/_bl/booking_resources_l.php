<?php
/*
This is COMMERCIAL SCRIPT
We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
*/

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly            // FixIn: 9.7.3.13.


/**
 *  Get ALL booking resources from DB
 *
 * @param $resource_id
 * @param $where
 *
 * @return array|object|stdClass[]|null
 */
function wpbc_get_booking_resources_bl__from_db__arr( $resource_id = 0, $where = '' ) {


	// CACHE - GET    ::    check if such request was cached and get it  -----------------------------------------------    // FixIn: 9.7.3.14.
	$params_for_cache = maybe_serialize( array( intval( $resource_id ), trim( $where ) ) );
	$cache_result = wpbc_cache__get( 'wpbc_get_booking_resources_bl__from_db__arr', $params_for_cache );
	if ( ! is_null( $cache_result ) ) {
		return $cache_result;
	}
	// -----------------------------------------------------------------------------------------------------------------


	global $wpdb;
	$additional_fields = '';

	if ( $where === '' ) {
		$where = apply_bk_filter( 'multiuser_modify_SQL_for_current_user', $where );
		$us_id = apply_bk_filter( 'get_user_of_this_bk_resource', false, $resource_id );
		if ( $us_id !== false ) {
			$where = $wpdb->prepare( " users = %d ", $us_id );
		}
	}

	if ( $resource_id != 0 ) {

		$where1 = $wpdb->prepare( " WHERE ( booking_type_id = %d OR parent = %d ) ", $resource_id, $resource_id );

		if ( $where != '' ) {
			$where = $where1 . ' AND ' . $where;
		} else {
			$where = $where1;
		}

	} else {
		if ( $where != '' ) {
			$where = ' WHERE ' . $where;
		}
	}

	if ( class_exists( 'wpdev_bk_multiuser' ) ) {  // If Business Large then get resources from that
		$additional_fields = ', users ';
	}

	$wpbc_sql = "SELECT booking_type_id as id, title, parent, prioritet, cost, visitors {$additional_fields} 
                         FROM {$wpdb->prefix}bookingtypes {$where} ORDER BY parent, prioritet";

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared, PluginCheck.Security.DirectDB.UnescapedDBParameter
	$resources_db_arr = $wpdb->get_results( $wpbc_sql );


	// CACHE - SAVE ::  ------------------------------------------------------------------------------------------------        // FixIn: 9.7.3.14.
	$cache_result = wpbc_cache__save( 'wpbc_get_booking_resources_bl__from_db__arr', $params_for_cache, $resources_db_arr );

	return $resources_db_arr;
}



/**
 * Get hierarchy structure TREE of booking resources
 *
 * @param array $booking_resources_arr
 *
 * @return array
 */
function wpbc_get_booking_resources_as_hierarchy_arr( $booking_resources_arr = array() ) {

	if ( count( $booking_resources_arr ) == 0 ) {
		$booking_resources_arr = wpbc_get_booking_resources_bl__from_db__arr();
	}

	$res = array();

	foreach ( $booking_resources_arr as $bt ) {
		if ( $bt->parent == '0' ) {
			$res[ $bt->id ] = array( 'obj' => $bt, 'child' => array(), 'count' => 1 );
		}
	}

	foreach ( $booking_resources_arr as $bt ) {
		if ( $bt->parent != '0' ) {
			if ( ! isset( $res[ $bt->parent ]['child'][ $bt->prioritet ] ) ) {
				$res[ $bt->parent ]['child'][ $bt->prioritet ] = $bt;
			} else {
				$res[ $bt->parent ]['child'][ 100 * count( $res[ $bt->parent ]['child'] ) ] = $bt;
			}
			$res[ $bt->parent ]['count'] = count( $res[ $bt->parent ]['child'] ) + 1;
		}
	}

	return $res;
}



/**
 * Get linear structure of resources from hierarchy for showing it at the settings page
 *
 * FUNCTION  FOR SETTINGS
 *
 * @param array $resources_hierarchy_arr
 *
 * @return array
 */
function wpbc_get_booking_resources_as_linear_arr( $resources_hierarchy_arr = array() ) {

	if ( count( $resources_hierarchy_arr ) == 0 ) {
		$resources_hierarchy_arr = wpbc_get_booking_resources_as_hierarchy_arr();
	}

	$res = array();

	foreach ( $resources_hierarchy_arr as $bt ) {
		if ( isset( $bt['obj'] ) ) {
			$res[] = array( 'obj' => $bt['obj'], 'count' => $bt['count'] );
		}
		foreach ( $bt['child'] as $b ) {
			$res[] = array( 'obj' => $b, 'count' => '1' );
		}
	}

	return $res;
}
