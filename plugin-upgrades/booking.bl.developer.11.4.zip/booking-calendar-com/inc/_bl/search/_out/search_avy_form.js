"use strict";

/**
 * Init Datepick in search form for Check In
 */
function wpbc_init_datepick__search_check_in() {
  var datepick_params = {
    onSelect: wpbc_search_check_in_selected,
    beforeShowDay: wpbc_search_apply_css_before_show_check_in,
    showOn: 'focus',
    multiSelect: 0,
    numberOfMonths: 1,
    stepMonths: 1,
    prevText: '&lsaquo;',
    nextText: '&rsaquo;',
    dateFormat: _wpbc.get_other_param('search_avy__dates_format'),
    changeMonth: false,
    changeYear: false,
    minDate: 0,
    maxDate: _wpbc.get_other_param('calendars__max_monthes_in_calendar'),
    //'1Y',
    // minDate	  : new Date(2020, 2, 1), maxDate: new Date(2020, 9, 31),             	// Ability to set any  start and end date in calendar
    showStatus: false,
    multiSeparator: ', ',
    closeAtTop: false,
    firstDay: _wpbc.get_other_param('calendars__first_day'),
    gotoCurrent: false,
    hideIfNoPrevNext: true,
    useThemeRoller: false,
    mandatory: true,
    _mainDivId: ['datepick-div', 'ui-datepicker-div', 'widget_wpdev_booking']
  };
  var search_check_in_date = '';
  var url_params = location.href.split('?');
  if (url_params.length > 1) {
    url_params = url_params[1].split('&');
    for (var i = 0; i < url_params.length; i++) {
      var one_param = url_params[i].split('=');
      if (one_param[0] === 'search_field__display_check_in' && '' === search_check_in_date) {
        search_check_in_date = one_param[1];
      }
      if (one_param[0] === 'search_get__check_in_ymd') {
        search_check_in_date = one_param[1];
      }
    }
  }
  if ('' !== search_check_in_date && '2100-01-01' !== search_check_in_date) {
    datepick_params['defaultDate'] = jQuery.datepick.formatDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery.datepick.parseDate('yy-mm-dd', search_check_in_date));
    datepick_params['showDefault'] = true;
  }
  jQuery('#search_field__display_check_in').datepick(datepick_params);
}

/**
 * Init Datepick in search form for Check Out
 */
function wpbc_init_datepick__search_check_out() {
  var datepick_params = {
    beforeShowDay: wpbc_search_apply_css_before_show_check_out,
    showOn: 'focus',
    multiSelect: 0,
    numberOfMonths: 1,
    stepMonths: 1,
    prevText: '&lsaquo;',
    nextText: '&rsaquo;',
    dateFormat: _wpbc.get_other_param('search_avy__dates_format'),
    changeMonth: false,
    changeYear: false,
    minDate: 0,
    maxDate: _wpbc.get_other_param('calendars__max_monthes_in_calendar'),
    //'1Y',
    // minDate	  : new Date(2020, 2, 1), maxDate: new Date(2020, 9, 31),             	// Ability to set any  start and end date in calendar
    showStatus: false,
    multiSeparator: ', ',
    closeAtTop: false,
    firstDay: _wpbc.get_other_param('calendars__first_day'),
    gotoCurrent: false,
    hideIfNoPrevNext: true,
    useThemeRoller: false,
    mandatory: true,
    _mainDivId: ['datepick-div', 'ui-datepicker-div', 'widget_wpdev_booking']
  };
  var search_check_out_date = '';
  var url_params = location.href.split('?');
  if (url_params.length > 1) {
    url_params = url_params[1].split('&');
    for (var i = 0; i < url_params.length; i++) {
      var one_param = url_params[i].split('=');
      if (one_param[0] === 'search_field__display_check_out' && '' === search_check_out_date) {
        search_check_out_date = one_param[1];
      }
      if (one_param[0] === 'search_get__check_out_ymd') {
        search_check_out_date = one_param[1];
      }
    }
  }
  if ('' !== search_check_out_date && '2100-01-01' !== search_check_out_date) {
    datepick_params['defaultDate'] = jQuery.datepick.formatDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery.datepick.parseDate('yy-mm-dd', search_check_out_date));
    datepick_params['showDefault'] = true;
  }
  jQuery('#search_field__display_check_out').datepick(datepick_params);
}

/**
 * Set-up 	available | unavailable 	dates in Check In calendar  in search  form
 * @param date
 * @returns {(boolean|string)[]}
 */
function wpbc_search_apply_css_before_show_check_in(date) {
  var today_date = new Date(_wpbc.get_other_param('today_arr')[0], parseInt(_wpbc.get_other_param('today_arr')[1]) - 1, _wpbc.get_other_param('today_arr')[2], 0, 0, 0); // Today JS_Date_Obj.
  var class_day = wpbc__get__td_class_date(date); // '1-9-2023'

  // Unavailable Weekdays
  for (var i = 0; i < _wpbc.get_other_param('availability__week_days_unavailable').length; i++) {
    if (date.getDay() == _wpbc.get_other_param('availability__week_days_unavailable')[i]) {
      return [false, 'cal4date-' + class_day + ' date_user_unavailable'];
    }
  }
  // Unavailable dates relative to  Today date
  if (wpbc_dates__days_between(date, today_date) < parseInt(_wpbc.get_other_param('availability__unavailable_from_today')) || parseInt('0' + parseInt(_wpbc.get_other_param('availability__available_from_today'))) > 0 && wpbc_dates__days_between(date, today_date) > parseInt('0' + parseInt(_wpbc.get_other_param('availability__available_from_today')))) {
    return [false, 'cal4date-' + class_day + ' date_user_unavailable'];
  }

  // Available
  return [true, 'cal4date-' + class_day + ' date_available '];
}

/**
 * After Check In day selected in Search Form
 * @param date
 */
function wpbc_search_check_in_selected(date) {
  // Parse a string value into a date object
  var search_check_in_date = jQuery.datepick.parseDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery('#search_field__display_check_in').val());
  var date_to_check = new Date();
  date_to_check.setFullYear(search_check_in_date.getFullYear(), search_check_in_date.getMonth(), search_check_in_date.getDate());
  var startDay;
  var string_date;
  if ('fixed' == _wpbc.get_other_param('calendars__days_select_mode') && -1 != _wpbc.get_other_param('calendars__fixed__week_days__start')) {
    startDay = wpbc_get_abs_closest_value_in_arr(date_to_check.getDay(), _wpbc.get_other_param('calendars__fixed__week_days__start'));
    date_to_check.setDate(date_to_check.getDate() - (date_to_check.getDay() - startDay));
    string_date = jQuery.datepick.formatDate(_wpbc.get_other_param('search_avy__dates_format'), date_to_check); // Format a date object into a string value.

    jQuery('#search_field__display_check_in').val(string_date);
  }
  if (_wpbc.get_other_param('calendars__days_select_mode') == 'dynamic' && _wpbc.get_other_param('calendars__dynamic__week_days__start') != -1) {
    startDay = wpbc_get_abs_closest_value_in_arr(date_to_check.getDay(), _wpbc.get_other_param('calendars__dynamic__week_days__start'));
    date_to_check.setDate(date_to_check.getDate() - (date_to_check.getDay() - startDay));
    string_date = jQuery.datepick.formatDate(_wpbc.get_other_param('search_avy__dates_format'), date_to_check); // Format a date object into a string value.
    jQuery('#search_field__display_check_in').val(string_date);
  }
  if (document.getElementById('search_field__display_check_out') !== null) {
    var start_bk_month_4_check_out = jQuery.datepick.parseDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery('#search_field__display_check_in').val());
    var myDate = new Date();
    myDate.setFullYear(start_bk_month_4_check_out.getFullYear(), start_bk_month_4_check_out.getMonth(), start_bk_month_4_check_out.getDate());
    var days_interval = wpbc_get_min_days_selection();
    if (days_interval > 0) days_interval--;
    myDate.setDate(myDate.getDate() + days_interval);
    string_date = jQuery.datepick.formatDate(_wpbc.get_other_param('search_avy__dates_format'), myDate); // Format a date object into a string value.
    jQuery('#search_field__display_check_out').val(string_date);

    // Auto open Check Out calendar selection   																// FixIn: 10.0.0.39.
    if ('On' === _wpbc.get_other_param('search_avy__auto_open_checkout')) {
      setTimeout(function () {
        jQuery('#search_field__display_check_out').trigger('focus');
      }, 100);
    }
  }
}

/**
 * Set-up 	available | unavailable 	dates in Check Out calendar  in search  form
 * @param date
 * @returns {(boolean|string)[]}
 */
function wpbc_search_apply_css_before_show_check_out(date) {
  var today_date = new Date(_wpbc.get_other_param('today_arr')[0], parseInt(_wpbc.get_other_param('today_arr')[1]) - 1, _wpbc.get_other_param('today_arr')[2], 0, 0, 0); // Today JS_Date_Obj.
  var class_day = wpbc__get__td_class_date(date); // '1-9-2023'

  // Unavailable Weekdays
  for (var i = 0; i < _wpbc.get_other_param('availability__week_days_unavailable').length; i++) {
    if (date.getDay() == _wpbc.get_other_param('availability__week_days_unavailable')[i]) {
      return [false, 'cal4date-' + class_day + ' date_user_unavailable'];
    }
  }
  // Unavailable dates relative to  Today date
  if (wpbc_dates__days_between(date, today_date) < parseInt(_wpbc.get_other_param('availability__unavailable_from_today')) || parseInt('0' + parseInt(_wpbc.get_other_param('availability__available_from_today'))) > 0 && wpbc_dates__days_between(date, today_date) > parseInt('0' + parseInt(_wpbc.get_other_param('availability__available_from_today')))) {
    return [false, 'cal4date-' + class_day + ' date_user_unavailable'];
  }
  // ---------------------

  var additional_class = 'date_available ';
  if (document.getElementById('search_field__display_check_in') != null && document.getElementById('search_field__display_check_in').value != '') {
    // Parse a string value into a date object
    var checkInDate = jQuery.datepick.parseDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery('#search_field__display_check_in').val());
    var days_interval = wpbc_get_min_days_selection();
    if (days_interval > 0) days_interval--;
    checkInDate.setDate(checkInDate.getDate() + days_interval);
    var checkOutDate = jQuery.datepick.parseDate(_wpbc.get_other_param('search_avy__dates_format'), jQuery('#search_field__display_check_in').val());
    var days_interval_max = wpbc_get_max_days_selection();
    if (days_interval_max > 0) days_interval_max--;
    checkOutDate.setDate(checkOutDate.getDate() + days_interval_max);
    if (checkInDate <= date && checkOutDate >= date) {
      return [true, 'cal4date-' + class_day + ' ' + additional_class + ' ']; // Available
    } else {
      return [false, 'cal4date-' + class_day + ' date_user_unavailable']; // return [false, ''];  // Unavailable
    }
  } else {
    return [true, 'cal4date-' + class_day + ' ' + additional_class + ' ']; // Available
  }
}

/**
 * Get Minimum number of Days to Select from 	Settings General page
 * @returns {number}
 */
function wpbc_get_min_days_selection() {
  // FixIn: 8.6.1.21.

  if ('dynamic' === _wpbc.get_other_param('calendars__days_select_mode')) {
    return parseInt(_wpbc.get_other_param('calendars__dynamic__days_min'));
  }
  if ('fixed' === _wpbc.get_other_param('calendars__days_select_mode')) {
    return parseInt(_wpbc.get_other_param('calendars__fixed__days_num'));
  }
  return 0;
}

/**
 * Get Maximum number of Days to Select from 	Settings General page
 * @returns {number}
 */
function wpbc_get_max_days_selection() {
  // FixIn: 9.9.0.44.
  if ('dynamic' === _wpbc.get_other_param('calendars__days_select_mode')) {
    return parseInt(_wpbc.get_other_param('calendars__dynamic__days_max'));
  }
  if ('fixed' === _wpbc.get_other_param('calendars__days_select_mode')) {
    return parseInt(_wpbc.get_other_param('calendars__fixed__days_num'));
  }
  return 365;
}

// =====================================================================================================================

/**
 * Select 'search_quantity' | 'location' | ... options and Search Filters (previously custom fields).
 * Params in search form, after page loaded depends on GET params
 */
function wpbc_search_avy__auto_select_fields_in_search_form__if_params_in_url() {
  var url_params = new URLSearchParams(window.location.search);
  if (url_params.has('search_get__custom_params')) {
    var search_get__custom_params = url_params.get('search_get__custom_params');

    // Convert back.     Some systems do not like symbol '~' in URL, so  we need to replace to  some other symbols
    search_get__custom_params = search_get__custom_params.replaceAll('_^_', '~');
    var search_fields_arr = wpbc_auto_fill_search_fields__parse(search_get__custom_params);
    for (let i = 0; i < search_fields_arr.length; i++) {
      if (wpbc_in_array(['text', 'select-one', 'selectbox-one', 'select-multiple', 'selectbox-multiple', 'radio', 'checkbox'], search_fields_arr[i]['type']) && !wpbc_in_array(['search_field__display_check_in', 'search_field__display_check_out', /*'search_quantity',*/'search_field__extend_search_days'], search_fields_arr[i]['name'])) {
        var cleaned_name = search_fields_arr[i]['name'];
        var cleaned_value = search_fields_arr[i]['value'];
        jQuery('[name="' + cleaned_name + '"]').val(cleaned_value).trigger('change');
      }
    }
  }
  url_params.forEach((value, key) => {
    if (key.startsWith('booking_')) {
      jQuery('[name="' + key + '"]').val(value).trigger('change');
    }
  });
}

/** Icons Trigger to open calendars, if clicked on Calendar Icons */
jQuery('.wpbc_icn_check_in').on('click', function (event) {
  jQuery('#search_field__display_check_in').trigger('focus');
});
jQuery('.wpbc_icn_check_out').on('click', function (event) {
  jQuery('#search_field__display_check_out').trigger('focus');
});

/**
 *  Disable search button
 */
function wpbc_search_form__disable_submit_button() {
  // FixIn: 9.9.0.45.
  // jQuery( '#booking_search_form .search_booking' ).prop( 'disabled', true );
  jQuery('#booking_search_form .search_booking').attr('saved-button-color', jQuery('#booking_search_form .search_booking').css('color'));
  jQuery('#booking_search_form .search_booking').css('color', '#ccc');
  jQuery('#booking_search_form .search_booking').css('cursor', 'not-allowed');
}

/**
 * Enable search button
 */
function wpbc_search_form__enable_submit_button() {
  // FixIn: 9.9.0.45.
  jQuery('#booking_search_form .search_booking').prop('disabled', false);
  if (undefined != jQuery('#booking_search_form .search_booking').attr('saved-button-color')) {
    // FixIn: 9.5.1.2.
    jQuery('#booking_search_form .search_booking').css('color', jQuery('#booking_search_form .search_booking').attr('saved-button-color'));
  }
  jQuery('#booking_search_form .search_booking').css('cursor', 'pointer');
}

/**
 * Get as String the all Values from HTML Search Form fields. 		E.g.: 'select^search_quantity^2~....'
 *
 * @param search_form		- HTML Dom Form element: this.form
 * @returns {string}		- 'select^search_quantity^2~....'
 */
function wpbc_search_form__get_all_input_fields_data(search_form) {
  // FixIn: 7.1.2.9.

  var all_paramas = '';
  var inp_el;
  var inp_val;
  for (var i = 0; i < search_form.length; i++) {
    if (search_form[i].type == 'checkbox' && !search_form[i].checked) {
      continue;
    }
    inp_el = search_form[i].type + "^" + search_form[i].name + "^";
    inp_val = jQuery(search_form[i]).val();
    if (Array.isArray(inp_val)) {
      jQuery.each(inp_val, function (index) {
        all_paramas += inp_el + inp_val[index] + "~";
      });
    } else {
      all_paramas += inp_el + inp_val + "~";
    }
  }
  return all_paramas;
}

/**
 * Get Date value Parsed from  Search Date format  to  '2024-05-06' format
 *
 * @param html_id		'#search_field__display_check_in' | '#search_field__display_check_out'
 */
function wpbc_search_form__get_parsed_search_date__as_ymd(html_id) {
  var booking_search_date = '';
  if (jQuery(html_id).length) {
    booking_search_date = jQuery(html_id).val();
  }

  // Set JS  date to  some Future date,  that will be available for sure
  var search_js_date = new Date('2100-01-01');

  // Parse a string value into a date object
  if ('' !== booking_search_date) {
    search_js_date = jQuery.datepick.parseDate(_wpbc.get_other_param('search_avy__dates_format'), booking_search_date);

    // Format a date object into a string value.
    var search_string_date = jQuery.datepick.formatDate('yy-mm-dd', search_js_date);
    return search_string_date;
  } else {
    return '2100-01-01'; // FixIn: 10.2.2.1.
  }
}

// ---------------------------------------------------------------------------------------------------------------------
// Search Submit  -  New Page
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Prepare for submit Search Form  to New Page
 *
 * @param search_form			HTML Dom  form:  this.form
 * @param wpdbc_active_locale	string locale: 	'es_ES'
 * @returns {boolean}
 */
function wpbc_search_form_click_new_page(search_form, wpdbc_active_locale) {
  // FixIn: 8.6.1.21.

  if ('Off' != _wpbc.get_other_param('search_avy__warning__dates_required_enabled')) {
    if ('' == jQuery('#search_field__display_check_in').val() || '' == jQuery('#search_field__display_check_out').val()) {
      alert(_wpbc.get_other_param('search_avy__warning__dates_required_warning'));
      return false;
    }
  }
  wpbc_search_form__disable_submit_button();

  // -------------------------------------------------------------------------------------------------------------
  // Get Search Fields:
  // -------------------------------------------------------------------------------------------------------------
  var param__check_in_ymd = wpbc_search_form__get_parsed_search_date__as_ymd('#search_field__display_check_in'); // FixIn: 9.5.3.4.
  jQuery('[name="search_get__check_in_ymd"]').val(param__check_in_ymd); // in format  2024-05-06
  // -------------------------------------------------------------------------------------------------------------
  var param__check_out_ymd = wpbc_search_form__get_parsed_search_date__as_ymd('#search_field__display_check_out');
  jQuery('[name="search_get__check_out_ymd"]').val(param__check_out_ymd); // in format  2024-05-06
  // -------------------------------------------------------------------------------------------------------------
  var param__search_quantity = jQuery("[name='search_quantity']").length > 0 ? jQuery("[name='search_quantity']").val() : 1;
  jQuery('[name="search_get__quantity"]').val(param__search_quantity);
  var param__search_time = jQuery("[name='search_time']").length > 0 ? jQuery("[name='search_time']").val() : '';
  jQuery('[name="search_get__time"]').val(param__search_time);
  // -------------------------------------------------------------------------------------------------------------
  var param__users_id = jQuery('#search_field__users_id').length ? jQuery('#search_field__users_id').val() : '';
  jQuery('[name="search_get__users_id"]').val(param__users_id);
  // -------------------------------------------------------------------------------------------------------------
  var param__extended_days = jQuery("input[name='search_field__extend_search_days']:checked").length > 0 ? jQuery("input[name='search_field__extend_search_days']").val() : 0;
  jQuery('[name="search_get__extend"]').val(param__extended_days);
  // -------------------------------------------------------------------------------------------------------------
  // Get as String the all Values from HTML Search Form fields. 		E.g.: 'select^search_quantity^2~....'
  var param__all_as_str = wpbc_search_form__get_all_input_fields_data(search_form);
  param__all_as_str = param__all_as_str.replaceAll('~', '_^_'); // Some systems do not like symbol '~' in URL, so  we need to replace to  some other symbols

  jQuery('[name="search_get__custom_params"]').val(param__all_as_str); // in format  'select^search_quantity^2~....'
  // -------------------------------------------------------------------------------------------------------------

  return true;
}

// -------------------------------------------------------------------------------------------------------------
// Search Submit  -  Ajax
// -------------------------------------------------------------------------------------------------------------

/**
 * Submit Search Ajax request,  and show Loading spinner
 *
 * @param search_form           DOM Form -> this.form
 * @param wpdev_active_locale   Locale   -> 'es_ES'
 */
function wpbc_search_form_click_ajax(search_form, wpdev_active_locale) {
  if ('Off' != _wpbc.get_other_param('search_avy__warning__dates_required_enabled')) {
    if ('' === jQuery('#search_field__display_check_in').val() || '' === jQuery('#search_field__display_check_out').val()) {
      alert(_wpbc.get_other_param('search_avy__warning__dates_required_warning'));
      return false;
    }
  }

  // ---------------------------------------------------------------------
  // Show Loading Spinner
  // ---------------------------------------------------------------------
  //// :: Old ::
  //document.getElementById('booking_search_results' ).innerHTML = '<div style="height:20px;width:100%;text-align:center;margin:15px auto;"><img  style="vertical-align:middle;box-shadow:none;width:14px;" src="'+_wpbc.get_other_param( 'url_plugin' )+'/assets/img/ajax-loader.gif"><//div>';
  ////:: Big Loading Circle ::
  //jQuery( '#booking_search_results' ).html( '<div class="wpbc_booking_form_spin_loader" style="position: relative;margin-top: 70px;"><div class="wpbc_spins_loader_wrapper"><div class="wpbc_spins_loader"></div></div></div>' );

  ////:: Mini Loading Circle ::       // FixIn: 10.0.0.38.
  jQuery('#booking_search_results').html('<div class="wpbc_booking_form_spin_loader" style="position: relative;margin-top: 50px;"><div class="wpbc_spins_loader_wrapper"><div class="wpbc_spin_loader_one_new"></div></div></div>');
  wpbc_ajax_search_submit(search_form, wpdev_active_locale);
}

/**
 * Send Ajax Search Availability Request
 *
 * @param search_form			HTML Dom  form:  this.form
 * @param wpdbc_active_locale	string locale: 	'es_ES'
 */
function wpbc_ajax_search_submit(search_form, wpdbc_active_locale) {
  // FixIn: 6.0.1.1.

  // Disable Submit button
  wpbc_search_form__disable_submit_button(); // FixIn: 9.9.0.45.
  jQuery('#booking_search_form .search_booking').prop('disabled', true);

  // Clear search results
  jQuery('.booking_search_ajax_container').remove();

  // -------------------------------------------------------------------------------------------------------------
  // Get Search Fields:
  // -------------------------------------------------------------------------------------------------------------

  // Get as String the all Values from HTML Search Form fields. 		E.g.: 'select^search_quantity^2~....'
  var param__all_as_str = wpbc_search_form__get_all_input_fields_data(search_form);
  var param__check_in_ymd = wpbc_search_form__get_parsed_search_date__as_ymd('#search_field__display_check_in'); // FixIn: 8.6.1.21.
  var param__check_out_ymd = wpbc_search_form__get_parsed_search_date__as_ymd('#search_field__display_check_out');
  var param__users_id = jQuery('#search_field__users_id').length ? jQuery('#search_field__users_id').val() : '';
  var param__extended_days = jQuery("input[name='search_field__extend_search_days']:checked").length > 0 ? jQuery("input[name='search_field__extend_search_days']").val() : 0;
  var param__search_quantity = jQuery("[name='search_quantity']").length > 0 ? jQuery("[name='search_quantity']").val() : 1;
  var param__search_time = jQuery("[name='search_time']").length > 0 ? jQuery("[name='search_time']").val() : '';
  // -------------------------------------------------------------------------------------------------------------
  jQuery.ajax({
    url: wpbc_url_ajax,
    type: 'POST',
    success: function (data, textStatus) {
      if (textStatus == 'success') {
        if ('undefined' !== typeof data && 'undefined' !== typeof data.ajx_data_search_content) {
          jQuery('#booking_search_results').html(data.ajx_data_search_content); // '<div class="wpbc_booking_form_spin_loader"
          // jQuery( '#booking_search_ajax' ).html( data.ajx_data_search_content );
          // jQuery( "#booking_search_ajax" ).after( jQuery( "#booking_search_ajax .booking_search_ajax_container" ) );
          // jQuery( "#booking_search_ajax" ).hide();
        } else {
          console.log(' :: SEARCH RESPONSE ERROR :: ', data);
          var jq_node = jQuery('#booking_search_results');
          // Show Message
          wpbc_front_end__show_message(' :: SEARCH RESPONSE ERROR :: <br>' + JSON.stringify(data).replace(/\n/g, "<br />"), {
            'type': 'warning',
            'show_here': {
              'jq_node': jq_node,
              'where': 'after'
            },
            'is_append': true,
            'style': 'text-align:left;',
            'delay': 30000
          });
          jQuery('#booking_search_results .wpbc_booking_form_spin_loader').remove();
        }
        wpbc_search_form__enable_submit_button();
      }
    },
    error: function (XMLHttpRequest, textStatus, errorThrown) {
      console.log('WPBC Error :: Ajax search Error status:' + textStatus, XMLHttpRequest);
      alert(XMLHttpRequest.status + ' ' + XMLHttpRequest.statusText);
      if (XMLHttpRequest.status == 500) {
        alert('Please check at this page according this error:' + ' https://wpbookingcalendar.com/faq/#ajax-sending-error');
      }
    },
    data: {
      action: 'BOOKING_SEARCH',
      search_ajx__check_in_ymd: param__check_in_ymd,
      search_ajx__check_out_ymd: param__check_out_ymd,
      search_ajx__quantity: param__search_quantity,
      search_ajx__time: param__search_time,
      search_ajx__custom_params: param__all_as_str,
      search_ajx__extend: param__extended_days,
      search_ajx__users_id: param__users_id,
      wpdev_active_locale: wpdbc_active_locale,
      wpbc_nonce: document.getElementById('wpbc_search_nonce').value
    }
  });
}
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5jL19ibC9zZWFyY2gvX291dC9zZWFyY2hfYXZ5X2Zvcm0uanMiLCJuYW1lcyI6WyJ3cGJjX2luaXRfZGF0ZXBpY2tfX3NlYXJjaF9jaGVja19pbiIsImRhdGVwaWNrX3BhcmFtcyIsIm9uU2VsZWN0Iiwid3BiY19zZWFyY2hfY2hlY2tfaW5fc2VsZWN0ZWQiLCJiZWZvcmVTaG93RGF5Iiwid3BiY19zZWFyY2hfYXBwbHlfY3NzX2JlZm9yZV9zaG93X2NoZWNrX2luIiwic2hvd09uIiwibXVsdGlTZWxlY3QiLCJudW1iZXJPZk1vbnRocyIsInN0ZXBNb250aHMiLCJwcmV2VGV4dCIsIm5leHRUZXh0IiwiZGF0ZUZvcm1hdCIsIl93cGJjIiwiZ2V0X290aGVyX3BhcmFtIiwiY2hhbmdlTW9udGgiLCJjaGFuZ2VZZWFyIiwibWluRGF0ZSIsIm1heERhdGUiLCJzaG93U3RhdHVzIiwibXVsdGlTZXBhcmF0b3IiLCJjbG9zZUF0VG9wIiwiZmlyc3REYXkiLCJnb3RvQ3VycmVudCIsImhpZGVJZk5vUHJldk5leHQiLCJ1c2VUaGVtZVJvbGxlciIsIm1hbmRhdG9yeSIsIl9tYWluRGl2SWQiLCJzZWFyY2hfY2hlY2tfaW5fZGF0ZSIsInVybF9wYXJhbXMiLCJsb2NhdGlvbiIsImhyZWYiLCJzcGxpdCIsImxlbmd0aCIsImkiLCJvbmVfcGFyYW0iLCJqUXVlcnkiLCJkYXRlcGljayIsImZvcm1hdERhdGUiLCJwYXJzZURhdGUiLCJ3cGJjX2luaXRfZGF0ZXBpY2tfX3NlYXJjaF9jaGVja19vdXQiLCJ3cGJjX3NlYXJjaF9hcHBseV9jc3NfYmVmb3JlX3Nob3dfY2hlY2tfb3V0Iiwic2VhcmNoX2NoZWNrX291dF9kYXRlIiwiZGF0ZSIsInRvZGF5X2RhdGUiLCJEYXRlIiwicGFyc2VJbnQiLCJjbGFzc19kYXkiLCJ3cGJjX19nZXRfX3RkX2NsYXNzX2RhdGUiLCJnZXREYXkiLCJ3cGJjX2RhdGVzX19kYXlzX2JldHdlZW4iLCJ2YWwiLCJkYXRlX3RvX2NoZWNrIiwic2V0RnVsbFllYXIiLCJnZXRGdWxsWWVhciIsImdldE1vbnRoIiwiZ2V0RGF0ZSIsInN0YXJ0RGF5Iiwic3RyaW5nX2RhdGUiLCJ3cGJjX2dldF9hYnNfY2xvc2VzdF92YWx1ZV9pbl9hcnIiLCJzZXREYXRlIiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInN0YXJ0X2JrX21vbnRoXzRfY2hlY2tfb3V0IiwibXlEYXRlIiwiZGF5c19pbnRlcnZhbCIsIndwYmNfZ2V0X21pbl9kYXlzX3NlbGVjdGlvbiIsInNldFRpbWVvdXQiLCJ0cmlnZ2VyIiwiYWRkaXRpb25hbF9jbGFzcyIsInZhbHVlIiwiY2hlY2tJbkRhdGUiLCJjaGVja091dERhdGUiLCJkYXlzX2ludGVydmFsX21heCIsIndwYmNfZ2V0X21heF9kYXlzX3NlbGVjdGlvbiIsIndwYmNfc2VhcmNoX2F2eV9fYXV0b19zZWxlY3RfZmllbGRzX2luX3NlYXJjaF9mb3JtX19pZl9wYXJhbXNfaW5fdXJsIiwiVVJMU2VhcmNoUGFyYW1zIiwid2luZG93Iiwic2VhcmNoIiwiaGFzIiwic2VhcmNoX2dldF9fY3VzdG9tX3BhcmFtcyIsImdldCIsInJlcGxhY2VBbGwiLCJzZWFyY2hfZmllbGRzX2FyciIsIndwYmNfYXV0b19maWxsX3NlYXJjaF9maWVsZHNfX3BhcnNlIiwid3BiY19pbl9hcnJheSIsImNsZWFuZWRfbmFtZSIsImNsZWFuZWRfdmFsdWUiLCJmb3JFYWNoIiwia2V5Iiwic3RhcnRzV2l0aCIsIm9uIiwiZXZlbnQiLCJ3cGJjX3NlYXJjaF9mb3JtX19kaXNhYmxlX3N1Ym1pdF9idXR0b24iLCJhdHRyIiwiY3NzIiwid3BiY19zZWFyY2hfZm9ybV9fZW5hYmxlX3N1Ym1pdF9idXR0b24iLCJwcm9wIiwidW5kZWZpbmVkIiwid3BiY19zZWFyY2hfZm9ybV9fZ2V0X2FsbF9pbnB1dF9maWVsZHNfZGF0YSIsInNlYXJjaF9mb3JtIiwiYWxsX3BhcmFtYXMiLCJpbnBfZWwiLCJpbnBfdmFsIiwidHlwZSIsImNoZWNrZWQiLCJuYW1lIiwiQXJyYXkiLCJpc0FycmF5IiwiZWFjaCIsImluZGV4Iiwid3BiY19zZWFyY2hfZm9ybV9fZ2V0X3BhcnNlZF9zZWFyY2hfZGF0ZV9fYXNfeW1kIiwiaHRtbF9pZCIsImJvb2tpbmdfc2VhcmNoX2RhdGUiLCJzZWFyY2hfanNfZGF0ZSIsInNlYXJjaF9zdHJpbmdfZGF0ZSIsIndwYmNfc2VhcmNoX2Zvcm1fY2xpY2tfbmV3X3BhZ2UiLCJ3cGRiY19hY3RpdmVfbG9jYWxlIiwiYWxlcnQiLCJwYXJhbV9fY2hlY2tfaW5feW1kIiwicGFyYW1fX2NoZWNrX291dF95bWQiLCJwYXJhbV9fc2VhcmNoX3F1YW50aXR5IiwicGFyYW1fX3NlYXJjaF90aW1lIiwicGFyYW1fX3VzZXJzX2lkIiwicGFyYW1fX2V4dGVuZGVkX2RheXMiLCJwYXJhbV9fYWxsX2FzX3N0ciIsIndwYmNfc2VhcmNoX2Zvcm1fY2xpY2tfYWpheCIsIndwZGV2X2FjdGl2ZV9sb2NhbGUiLCJodG1sIiwid3BiY19hamF4X3NlYXJjaF9zdWJtaXQiLCJyZW1vdmUiLCJhamF4IiwidXJsIiwid3BiY191cmxfYWpheCIsInN1Y2Nlc3MiLCJkYXRhIiwidGV4dFN0YXR1cyIsImFqeF9kYXRhX3NlYXJjaF9jb250ZW50IiwiY29uc29sZSIsImxvZyIsImpxX25vZGUiLCJ3cGJjX2Zyb250X2VuZF9fc2hvd19tZXNzYWdlIiwiSlNPTiIsInN0cmluZ2lmeSIsInJlcGxhY2UiLCJlcnJvciIsIlhNTEh0dHBSZXF1ZXN0IiwiZXJyb3JUaHJvd24iLCJzdGF0dXMiLCJzdGF0dXNUZXh0IiwiYWN0aW9uIiwic2VhcmNoX2FqeF9fY2hlY2tfaW5feW1kIiwic2VhcmNoX2FqeF9fY2hlY2tfb3V0X3ltZCIsInNlYXJjaF9hanhfX3F1YW50aXR5Iiwic2VhcmNoX2FqeF9fdGltZSIsInNlYXJjaF9hanhfX2N1c3RvbV9wYXJhbXMiLCJzZWFyY2hfYWp4X19leHRlbmQiLCJzZWFyY2hfYWp4X191c2Vyc19pZCIsIndwYmNfbm9uY2UiXSwic291cmNlcyI6WyJpbmMvX2JsL3NlYXJjaC9fc3JjL3NlYXJjaF9hdnlfZm9ybS5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIvKipcclxuICogSW5pdCBEYXRlcGljayBpbiBzZWFyY2ggZm9ybSBmb3IgQ2hlY2sgSW5cclxuICovXHJcbmZ1bmN0aW9uIHdwYmNfaW5pdF9kYXRlcGlja19fc2VhcmNoX2NoZWNrX2luKCl7XHJcblxyXG5cdHZhciBkYXRlcGlja19wYXJhbXMgPSB7XHJcblx0XHRvblNlbGVjdCAgICAgIDogd3BiY19zZWFyY2hfY2hlY2tfaW5fc2VsZWN0ZWQsXHJcblx0XHRiZWZvcmVTaG93RGF5IDogd3BiY19zZWFyY2hfYXBwbHlfY3NzX2JlZm9yZV9zaG93X2NoZWNrX2luLFxyXG5cdFx0c2hvd09uICAgICAgICA6ICdmb2N1cycsXHJcblx0XHRtdWx0aVNlbGVjdCAgIDogMCxcclxuXHRcdG51bWJlck9mTW9udGhzOiAxLFxyXG5cdFx0c3RlcE1vbnRocyAgICA6IDEsXHJcblx0XHRwcmV2VGV4dCAgICAgIDogJyZsc2FxdW87JyxcclxuXHRcdG5leHRUZXh0ICAgICAgOiAnJnJzYXF1bzsnLFxyXG5cdFx0ZGF0ZUZvcm1hdCAgICA6IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSxcclxuXHRcdGNoYW5nZU1vbnRoICAgOiBmYWxzZSxcclxuXHRcdGNoYW5nZVllYXIgICAgOiBmYWxzZSxcclxuXHRcdG1pbkRhdGUgICAgICAgOiAwLFxyXG5cdFx0bWF4RGF0ZSAgICAgICA6IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2NhbGVuZGFyc19fbWF4X21vbnRoZXNfaW5fY2FsZW5kYXInICksIFx0XHQvLycxWScsXHJcblx0XHQvLyBtaW5EYXRlXHQgIDogbmV3IERhdGUoMjAyMCwgMiwgMSksIG1heERhdGU6IG5ldyBEYXRlKDIwMjAsIDksIDMxKSwgICAgICAgICAgICAgXHQvLyBBYmlsaXR5IHRvIHNldCBhbnkgIHN0YXJ0IGFuZCBlbmQgZGF0ZSBpbiBjYWxlbmRhclxyXG5cdFx0c2hvd1N0YXR1cyAgICAgIDogZmFsc2UsXHJcblx0XHRtdWx0aVNlcGFyYXRvciAgOiAnLCAnLFxyXG5cdFx0Y2xvc2VBdFRvcCAgICAgIDogZmFsc2UsXHJcblx0XHRmaXJzdERheSAgICAgICAgOiBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX2ZpcnN0X2RheScgKSxcclxuXHRcdGdvdG9DdXJyZW50ICAgICA6IGZhbHNlLFxyXG5cdFx0aGlkZUlmTm9QcmV2TmV4dDogdHJ1ZSxcclxuXHRcdHVzZVRoZW1lUm9sbGVyICA6IGZhbHNlLFxyXG5cdFx0bWFuZGF0b3J5ICAgICAgIDogdHJ1ZSxcclxuXHRcdF9tYWluRGl2SWQgICAgICA6IFsnZGF0ZXBpY2stZGl2JywgJ3VpLWRhdGVwaWNrZXItZGl2JywgJ3dpZGdldF93cGRldl9ib29raW5nJ11cclxuXHR9O1xyXG5cclxuXHR2YXIgc2VhcmNoX2NoZWNrX2luX2RhdGUgPSAnJztcclxuXHJcblx0dmFyIHVybF9wYXJhbXMgPSBsb2NhdGlvbi5ocmVmLnNwbGl0KCAnPycgKTtcclxuXHRpZiAoIHVybF9wYXJhbXMubGVuZ3RoID4gMSApe1xyXG5cdFx0dXJsX3BhcmFtcyA9IHVybF9wYXJhbXNbIDEgXS5zcGxpdCggJyYnICk7XHJcblx0XHRmb3IgKCB2YXIgaSA9IDA7IGkgPCB1cmxfcGFyYW1zLmxlbmd0aDsgaSsrICl7XHJcblx0XHRcdHZhciBvbmVfcGFyYW0gPSB1cmxfcGFyYW1zWyBpIF0uc3BsaXQoICc9JyApO1xyXG5cdFx0XHRpZiAoIChvbmVfcGFyYW1bIDAgXSA9PT0gJ3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19pbicpICYmICgnJyA9PT0gc2VhcmNoX2NoZWNrX2luX2RhdGUpICl7XHJcblx0XHRcdFx0c2VhcmNoX2NoZWNrX2luX2RhdGUgPSBvbmVfcGFyYW1bIDEgXTtcclxuXHRcdFx0fVxyXG5cdFx0XHRpZiAoIG9uZV9wYXJhbVsgMCBdID09PSAnc2VhcmNoX2dldF9fY2hlY2tfaW5feW1kJyApe1xyXG5cdFx0XHRcdHNlYXJjaF9jaGVja19pbl9kYXRlID0gb25lX3BhcmFtWyAxIF07XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHR9XHJcblx0aWYgKCAoJycgIT09IHNlYXJjaF9jaGVja19pbl9kYXRlKSAmJiAoJzIxMDAtMDEtMDEnICE9PSBzZWFyY2hfY2hlY2tfaW5fZGF0ZSkgKXtcclxuXHRcdGRhdGVwaWNrX3BhcmFtc1sgJ2RlZmF1bHREYXRlJyBdID0galF1ZXJ5LmRhdGVwaWNrLmZvcm1hdERhdGUoXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCBcdGpRdWVyeS5kYXRlcGljay5wYXJzZURhdGUoICd5eS1tbS1kZCcsIHNlYXJjaF9jaGVja19pbl9kYXRlIClcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCk7XHJcblx0XHRkYXRlcGlja19wYXJhbXNbICdzaG93RGVmYXVsdCcgXSA9IHRydWU7XHJcblx0fVxyXG5cclxuXHRqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLmRhdGVwaWNrKCBkYXRlcGlja19wYXJhbXMgKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEluaXQgRGF0ZXBpY2sgaW4gc2VhcmNoIGZvcm0gZm9yIENoZWNrIE91dFxyXG4gKi9cclxuZnVuY3Rpb24gd3BiY19pbml0X2RhdGVwaWNrX19zZWFyY2hfY2hlY2tfb3V0KCl7XHJcblxyXG5cdHZhciBkYXRlcGlja19wYXJhbXMgPSB7XHJcblx0XHRiZWZvcmVTaG93RGF5IDogd3BiY19zZWFyY2hfYXBwbHlfY3NzX2JlZm9yZV9zaG93X2NoZWNrX291dCxcclxuXHRcdHNob3dPbiAgICAgICAgOiAnZm9jdXMnLFxyXG5cdFx0bXVsdGlTZWxlY3QgICA6IDAsXHJcblx0XHRudW1iZXJPZk1vbnRoczogMSxcclxuXHRcdHN0ZXBNb250aHMgICAgOiAxLFxyXG5cdFx0cHJldlRleHQgICAgICA6ICcmbHNhcXVvOycsXHJcblx0XHRuZXh0VGV4dCAgICAgIDogJyZyc2FxdW87JyxcclxuXHRcdGRhdGVGb3JtYXQgICAgOiBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X19kYXRlc19mb3JtYXQnICksXHJcblx0XHRjaGFuZ2VNb250aCAgIDogZmFsc2UsXHJcblx0XHRjaGFuZ2VZZWFyICAgIDogZmFsc2UsXHJcblx0XHRtaW5EYXRlICAgICAgIDogMCxcclxuXHRcdG1heERhdGUgICAgICAgOiBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX21heF9tb250aGVzX2luX2NhbGVuZGFyJyApLCBcdFx0Ly8nMVknLFxyXG5cdFx0Ly8gbWluRGF0ZVx0ICA6IG5ldyBEYXRlKDIwMjAsIDIsIDEpLCBtYXhEYXRlOiBuZXcgRGF0ZSgyMDIwLCA5LCAzMSksICAgICAgICAgICAgIFx0Ly8gQWJpbGl0eSB0byBzZXQgYW55ICBzdGFydCBhbmQgZW5kIGRhdGUgaW4gY2FsZW5kYXJcclxuXHRcdHNob3dTdGF0dXMgICAgICA6IGZhbHNlLFxyXG5cdFx0bXVsdGlTZXBhcmF0b3IgIDogJywgJyxcclxuXHRcdGNsb3NlQXRUb3AgICAgICA6IGZhbHNlLFxyXG5cdFx0Zmlyc3REYXkgICAgICAgIDogX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19maXJzdF9kYXknICksXHJcblx0XHRnb3RvQ3VycmVudCAgICAgOiBmYWxzZSxcclxuXHRcdGhpZGVJZk5vUHJldk5leHQ6IHRydWUsXHJcblx0XHR1c2VUaGVtZVJvbGxlciAgOiBmYWxzZSxcclxuXHRcdG1hbmRhdG9yeSAgICAgICA6IHRydWUsXHJcblx0XHRfbWFpbkRpdklkICAgICAgOiBbJ2RhdGVwaWNrLWRpdicsICd1aS1kYXRlcGlja2VyLWRpdicsICd3aWRnZXRfd3BkZXZfYm9va2luZyddXHJcblx0fTtcclxuXHJcblx0dmFyIHNlYXJjaF9jaGVja19vdXRfZGF0ZSA9ICcnO1xyXG5cclxuXHR2YXIgdXJsX3BhcmFtcyA9IGxvY2F0aW9uLmhyZWYuc3BsaXQoICc/JyApO1xyXG5cdGlmICggdXJsX3BhcmFtcy5sZW5ndGggPiAxICl7XHJcblx0XHR1cmxfcGFyYW1zID0gdXJsX3BhcmFtc1sgMSBdLnNwbGl0KCAnJicgKTtcclxuXHRcdGZvciAoIHZhciBpID0gMDsgaSA8IHVybF9wYXJhbXMubGVuZ3RoOyBpKysgKXtcclxuXHRcdFx0dmFyIG9uZV9wYXJhbSA9IHVybF9wYXJhbXNbIGkgXS5zcGxpdCggJz0nICk7XHJcblx0XHRcdGlmICggKG9uZV9wYXJhbVsgMCBdID09PSAnc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX291dCcpICYmICgnJyA9PT0gc2VhcmNoX2NoZWNrX291dF9kYXRlKSApe1xyXG5cdFx0XHRcdHNlYXJjaF9jaGVja19vdXRfZGF0ZSA9IG9uZV9wYXJhbVsgMSBdO1xyXG5cdFx0XHR9XHJcblx0XHRcdGlmICggb25lX3BhcmFtWyAwIF0gPT09ICdzZWFyY2hfZ2V0X19jaGVja19vdXRfeW1kJyApe1xyXG5cdFx0XHRcdHNlYXJjaF9jaGVja19vdXRfZGF0ZSA9IG9uZV9wYXJhbVsgMSBdO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cdGlmICggKCcnICE9PSBzZWFyY2hfY2hlY2tfb3V0X2RhdGUpICYmICgnMjEwMC0wMS0wMScgIT09IHNlYXJjaF9jaGVja19vdXRfZGF0ZSkgKXtcclxuXHRcdGRhdGVwaWNrX3BhcmFtc1sgJ2RlZmF1bHREYXRlJyBdID0galF1ZXJ5LmRhdGVwaWNrLmZvcm1hdERhdGUoXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCBcdGpRdWVyeS5kYXRlcGljay5wYXJzZURhdGUoICd5eS1tbS1kZCcsIHNlYXJjaF9jaGVja19vdXRfZGF0ZSApXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQpO1xyXG5cdFx0ZGF0ZXBpY2tfcGFyYW1zWyAnc2hvd0RlZmF1bHQnIF0gPSB0cnVlO1xyXG5cdH1cclxuXHJcblx0alF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19vdXQnICkuZGF0ZXBpY2soIGRhdGVwaWNrX3BhcmFtcyApO1xyXG59XHJcblxyXG5cdC8qKlxyXG5cdCAqIFNldC11cCBcdGF2YWlsYWJsZSB8IHVuYXZhaWxhYmxlIFx0ZGF0ZXMgaW4gQ2hlY2sgSW4gY2FsZW5kYXIgIGluIHNlYXJjaCAgZm9ybVxyXG5cdCAqIEBwYXJhbSBkYXRlXHJcblx0ICogQHJldHVybnMgeyhib29sZWFufHN0cmluZylbXX1cclxuXHQgKi9cclxuXHRmdW5jdGlvbiB3cGJjX3NlYXJjaF9hcHBseV9jc3NfYmVmb3JlX3Nob3dfY2hlY2tfaW4oIGRhdGUgKXtcclxuXHJcblx0XHR2YXIgdG9kYXlfZGF0ZSA9IG5ldyBEYXRlKCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICd0b2RheV9hcnInIClbIDAgXSwgKHBhcnNlSW50KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICd0b2RheV9hcnInIClbIDEgXSApIC0gMSksIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3RvZGF5X2FycicgKVsgMiBdLCAwLCAwLCAwICk7XHRcdFx0XHRcdFx0XHRcdC8vIFRvZGF5IEpTX0RhdGVfT2JqLlxyXG5cdFx0dmFyIGNsYXNzX2RheSA9IHdwYmNfX2dldF9fdGRfY2xhc3NfZGF0ZSggZGF0ZSApO1x0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCBcdC8vICcxLTktMjAyMydcclxuXHJcblx0XHQvLyBVbmF2YWlsYWJsZSBXZWVrZGF5c1xyXG5cdFx0Zm9yICggdmFyIGkgPSAwOyBpIDwgX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X193ZWVrX2RheXNfdW5hdmFpbGFibGUnICkubGVuZ3RoOyBpKysgKXtcclxuXHRcdFx0aWYgKCBkYXRlLmdldERheSgpID09IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2F2YWlsYWJpbGl0eV9fd2Vla19kYXlzX3VuYXZhaWxhYmxlJyApWyBpIF0gKXtcclxuXHRcdFx0XHRyZXR1cm4gW2ZhbHNlLCAnY2FsNGRhdGUtJyArIGNsYXNzX2RheSArICcgZGF0ZV91c2VyX3VuYXZhaWxhYmxlJ107XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC8vIFVuYXZhaWxhYmxlIGRhdGVzIHJlbGF0aXZlIHRvICBUb2RheSBkYXRlXHJcblx0XHRpZiAoXHJcblx0XHRcdCAgICggd3BiY19kYXRlc19fZGF5c19iZXR3ZWVuKCBkYXRlLCB0b2RheV9kYXRlICkgPCBwYXJzZUludCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X191bmF2YWlsYWJsZV9mcm9tX3RvZGF5JyApICkpXHJcblx0XHRcdHx8IChcclxuXHRcdFx0XHQgICAoIHBhcnNlSW50KCAnMCcgKyBwYXJzZUludCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X19hdmFpbGFibGVfZnJvbV90b2RheScgKSApICkgPiAwIClcclxuXHRcdFx0XHQmJiAoIHdwYmNfZGF0ZXNfX2RheXNfYmV0d2VlbiggZGF0ZSwgdG9kYXlfZGF0ZSApID4gcGFyc2VJbnQoICcwJyArIHBhcnNlSW50KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdhdmFpbGFiaWxpdHlfX2F2YWlsYWJsZV9mcm9tX3RvZGF5JyApICkgKSApXHJcblx0XHRcdClcclxuXHRcdCl7XHJcblx0XHRcdHJldHVybiBbZmFsc2UsICdjYWw0ZGF0ZS0nICsgY2xhc3NfZGF5ICsgJyBkYXRlX3VzZXJfdW5hdmFpbGFibGUnXTtcclxuXHRcdH1cclxuXHJcblx0XHQvLyBBdmFpbGFibGVcclxuXHRcdHJldHVybiBbdHJ1ZSwgJ2NhbDRkYXRlLScgKyBjbGFzc19kYXkgKyAnIGRhdGVfYXZhaWxhYmxlICddO1xyXG5cdH1cclxuXHJcblx0LyoqXHJcblx0ICogQWZ0ZXIgQ2hlY2sgSW4gZGF5IHNlbGVjdGVkIGluIFNlYXJjaCBGb3JtXHJcblx0ICogQHBhcmFtIGRhdGVcclxuXHQgKi9cclxuXHRmdW5jdGlvbiB3cGJjX3NlYXJjaF9jaGVja19pbl9zZWxlY3RlZCggZGF0ZSApIHtcclxuXHJcbiAgICAgICAgLy8gUGFyc2UgYSBzdHJpbmcgdmFsdWUgaW50byBhIGRhdGUgb2JqZWN0XHJcbiAgICAgICAgdmFyIHNlYXJjaF9jaGVja19pbl9kYXRlID0galF1ZXJ5LmRhdGVwaWNrLnBhcnNlRGF0ZSggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnc2VhcmNoX2F2eV9fZGF0ZXNfZm9ybWF0JyApICwgalF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19pbicgKS52YWwoKSApO1xyXG5cclxuICAgICAgICB2YXIgZGF0ZV90b19jaGVjayA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgZGF0ZV90b19jaGVjay5zZXRGdWxsWWVhciggc2VhcmNoX2NoZWNrX2luX2RhdGUuZ2V0RnVsbFllYXIoKSwgc2VhcmNoX2NoZWNrX2luX2RhdGUuZ2V0TW9udGgoKSwgc2VhcmNoX2NoZWNrX2luX2RhdGUuZ2V0RGF0ZSgpICk7XHJcblxyXG5cdFx0dmFyIHN0YXJ0RGF5O1xyXG5cdFx0dmFyIHN0cmluZ19kYXRlO1xyXG5cclxuICAgICAgICBpZiAoXHJcblx0XHRcdCAgICggJ2ZpeGVkJyA9PSBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX2RheXNfc2VsZWN0X21vZGUnICkgKVxyXG5cdFx0XHQmJiAoICAgICAgLTEgIT0gX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19maXhlZF9fd2Vla19kYXlzX19zdGFydCcgKSApXHJcblx0XHQpe1xyXG5cclxuICAgICAgICAgICAgc3RhcnREYXkgPSB3cGJjX2dldF9hYnNfY2xvc2VzdF92YWx1ZV9pbl9hcnIoIGRhdGVfdG9fY2hlY2suZ2V0RGF5KCksIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2NhbGVuZGFyc19fZml4ZWRfX3dlZWtfZGF5c19fc3RhcnQnICkgKTtcclxuICAgICAgICAgICAgZGF0ZV90b19jaGVjay5zZXREYXRlKCBkYXRlX3RvX2NoZWNrLmdldERhdGUoKSAtIChkYXRlX3RvX2NoZWNrLmdldERheSgpIC0gc3RhcnREYXkpICk7XHJcblxyXG4gICAgICAgICAgICBzdHJpbmdfZGF0ZSA9IGpRdWVyeS5kYXRlcGljay5mb3JtYXREYXRlKCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X19kYXRlc19mb3JtYXQnICksIGRhdGVfdG9fY2hlY2sgKTsgICAgICAgIC8vIEZvcm1hdCBhIGRhdGUgb2JqZWN0IGludG8gYSBzdHJpbmcgdmFsdWUuXHJcblxyXG4gICAgICAgICAgICBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLnZhbCggc3RyaW5nX2RhdGUgKTtcclxuICAgICAgICB9XHJcbiAgICAgICAgaWYgKCAgKCAgX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19kYXlzX3NlbGVjdF9tb2RlJyApID09ICdkeW5hbWljJyApICYmICggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19keW5hbWljX193ZWVrX2RheXNfX3N0YXJ0JyApICE9IC0xICkgICl7XHJcblxyXG4gICAgICAgICAgICBzdGFydERheSA9IHdwYmNfZ2V0X2Fic19jbG9zZXN0X3ZhbHVlX2luX2FyciggZGF0ZV90b19jaGVjay5nZXREYXkoKSwgX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19keW5hbWljX193ZWVrX2RheXNfX3N0YXJ0JyApICk7XHJcbiAgICAgICAgICAgIGRhdGVfdG9fY2hlY2suc2V0RGF0ZSggZGF0ZV90b19jaGVjay5nZXREYXRlKCkgLSAoZGF0ZV90b19jaGVjay5nZXREYXkoKSAtIHN0YXJ0RGF5KSApO1xyXG5cclxuICAgICAgICAgICAgc3RyaW5nX2RhdGUgPSBqUXVlcnkuZGF0ZXBpY2suZm9ybWF0RGF0ZSggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnc2VhcmNoX2F2eV9fZGF0ZXNfZm9ybWF0JyApLCBkYXRlX3RvX2NoZWNrICk7ICAgICAgICAvLyBGb3JtYXQgYSBkYXRlIG9iamVjdCBpbnRvIGEgc3RyaW5nIHZhbHVlLlxyXG4gICAgICAgICAgICBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLnZhbCggc3RyaW5nX2RhdGUgKTtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGlmICggZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoICdzZWFyY2hfZmllbGRfX2Rpc3BsYXlfY2hlY2tfb3V0JyApICE9PSBudWxsICl7XHJcblxyXG4gICAgICAgICAgICB2YXIgc3RhcnRfYmtfbW9udGhfNF9jaGVja19vdXQgPSBqUXVlcnkuZGF0ZXBpY2sucGFyc2VEYXRlKCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X19kYXRlc19mb3JtYXQnICksIGpRdWVyeSggJyNzZWFyY2hfZmllbGRfX2Rpc3BsYXlfY2hlY2tfaW4nICkudmFsKCkgKTtcclxuICAgICAgICAgICAgdmFyIG15RGF0ZSA9IG5ldyBEYXRlKCk7XHJcbiAgICAgICAgICAgIG15RGF0ZS5zZXRGdWxsWWVhciggc3RhcnRfYmtfbW9udGhfNF9jaGVja19vdXQuZ2V0RnVsbFllYXIoKSwgc3RhcnRfYmtfbW9udGhfNF9jaGVja19vdXQuZ2V0TW9udGgoKSwgc3RhcnRfYmtfbW9udGhfNF9jaGVja19vdXQuZ2V0RGF0ZSgpICk7XHJcblxyXG4gICAgICAgICAgICB2YXIgZGF5c19pbnRlcnZhbCA9IHdwYmNfZ2V0X21pbl9kYXlzX3NlbGVjdGlvbigpO1xyXG4gICAgICAgICAgICBpZiAoIGRheXNfaW50ZXJ2YWwgPiAwICkgZGF5c19pbnRlcnZhbC0tO1xyXG4gICAgICAgICAgICBteURhdGUuc2V0RGF0ZSggbXlEYXRlLmdldERhdGUoKSArIGRheXNfaW50ZXJ2YWwgKTtcclxuXHJcbiAgICAgICAgICAgIHN0cmluZ19kYXRlID0galF1ZXJ5LmRhdGVwaWNrLmZvcm1hdERhdGUoIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSwgbXlEYXRlICk7ICAgICAgICAvLyBGb3JtYXQgYSBkYXRlIG9iamVjdCBpbnRvIGEgc3RyaW5nIHZhbHVlLlxyXG4gICAgICAgICAgICBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX291dCcgKS52YWwoIHN0cmluZ19kYXRlICk7XHJcblxyXG4gICAgICAgICAgICAvLyBBdXRvIG9wZW4gQ2hlY2sgT3V0IGNhbGVuZGFyIHNlbGVjdGlvbiAgIFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gRml4SW46IDEwLjAuMC4zOS5cclxuICAgICAgICAgICAgaWYgKCAnT24nID09PSBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X19hdXRvX29wZW5fY2hlY2tvdXQnICkgKXtcclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICAgICBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX291dCcgKS50cmlnZ2VyKCAnZm9jdXMnICk7XHJcbiAgICAgICAgICAgICAgICB9LCAxMDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgfVxyXG5cclxuXHQvKipcclxuXHQgKiBTZXQtdXAgXHRhdmFpbGFibGUgfCB1bmF2YWlsYWJsZSBcdGRhdGVzIGluIENoZWNrIE91dCBjYWxlbmRhciAgaW4gc2VhcmNoICBmb3JtXHJcblx0ICogQHBhcmFtIGRhdGVcclxuXHQgKiBAcmV0dXJucyB7KGJvb2xlYW58c3RyaW5nKVtdfVxyXG5cdCAqL1xyXG4gICAgZnVuY3Rpb24gd3BiY19zZWFyY2hfYXBwbHlfY3NzX2JlZm9yZV9zaG93X2NoZWNrX291dChkYXRlKXtcclxuXHJcblx0XHR2YXIgdG9kYXlfZGF0ZSA9IG5ldyBEYXRlKCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICd0b2RheV9hcnInIClbIDAgXSwgKHBhcnNlSW50KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICd0b2RheV9hcnInIClbIDEgXSApIC0gMSksIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3RvZGF5X2FycicgKVsgMiBdLCAwLCAwLCAwICk7XHRcdFx0XHRcdFx0XHRcdC8vIFRvZGF5IEpTX0RhdGVfT2JqLlxyXG5cdFx0dmFyIGNsYXNzX2RheSA9IHdwYmNfX2dldF9fdGRfY2xhc3NfZGF0ZSggZGF0ZSApO1x0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCBcdC8vICcxLTktMjAyMydcclxuXHJcblx0XHQvLyBVbmF2YWlsYWJsZSBXZWVrZGF5c1xyXG5cdFx0Zm9yICggdmFyIGkgPSAwOyBpIDwgX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X193ZWVrX2RheXNfdW5hdmFpbGFibGUnICkubGVuZ3RoOyBpKysgKXtcclxuXHRcdFx0aWYgKCBkYXRlLmdldERheSgpID09IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2F2YWlsYWJpbGl0eV9fd2Vla19kYXlzX3VuYXZhaWxhYmxlJyApWyBpIF0gKXtcclxuXHRcdFx0XHRyZXR1cm4gW2ZhbHNlLCAnY2FsNGRhdGUtJyArIGNsYXNzX2RheSArICcgZGF0ZV91c2VyX3VuYXZhaWxhYmxlJ107XHJcblx0XHRcdH1cclxuXHRcdH1cclxuXHRcdC8vIFVuYXZhaWxhYmxlIGRhdGVzIHJlbGF0aXZlIHRvICBUb2RheSBkYXRlXHJcblx0XHRpZiAoXHJcblx0XHRcdCAgICggd3BiY19kYXRlc19fZGF5c19iZXR3ZWVuKCBkYXRlLCB0b2RheV9kYXRlICkgPCBwYXJzZUludCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X191bmF2YWlsYWJsZV9mcm9tX3RvZGF5JyApICkpXHJcblx0XHRcdHx8IChcclxuXHRcdFx0XHQgICAoIHBhcnNlSW50KCAnMCcgKyBwYXJzZUludCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnYXZhaWxhYmlsaXR5X19hdmFpbGFibGVfZnJvbV90b2RheScgKSApICkgPiAwIClcclxuXHRcdFx0XHQmJiAoIHdwYmNfZGF0ZXNfX2RheXNfYmV0d2VlbiggZGF0ZSwgdG9kYXlfZGF0ZSApID4gcGFyc2VJbnQoICcwJyArIHBhcnNlSW50KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdhdmFpbGFiaWxpdHlfX2F2YWlsYWJsZV9mcm9tX3RvZGF5JyApICkgKSApXHJcblx0XHRcdClcclxuXHRcdCl7XHJcblx0XHRcdHJldHVybiBbZmFsc2UsICdjYWw0ZGF0ZS0nICsgY2xhc3NfZGF5ICsgJyBkYXRlX3VzZXJfdW5hdmFpbGFibGUnXTtcclxuXHRcdH1cclxuXHRcdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuXHRcdHZhciBhZGRpdGlvbmFsX2NsYXNzID0gJ2RhdGVfYXZhaWxhYmxlICc7XHJcbiAgICAgICAgaWYgKFxyXG4gICAgICAgICAgICAgICAoIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApICE9IG51bGwgKVxyXG4gICAgICAgICAgICAmJiAoIGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLnZhbHVlICE9ICcnIClcclxuICAgICAgICApe1xyXG5cclxuXHRcdFx0Ly8gUGFyc2UgYSBzdHJpbmcgdmFsdWUgaW50byBhIGRhdGUgb2JqZWN0XHJcblx0XHRcdHZhciBjaGVja0luRGF0ZSA9IGpRdWVyeS5kYXRlcGljay5wYXJzZURhdGUoIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSwgalF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19pbicgKS52YWwoKSApO1xyXG5cclxuXHRcdFx0dmFyIGRheXNfaW50ZXJ2YWwgPSB3cGJjX2dldF9taW5fZGF5c19zZWxlY3Rpb24oKTtcclxuXHRcdFx0aWYgKCBkYXlzX2ludGVydmFsID4gMCApIGRheXNfaW50ZXJ2YWwtLTtcclxuXHRcdFx0Y2hlY2tJbkRhdGUuc2V0RGF0ZSggY2hlY2tJbkRhdGUuZ2V0RGF0ZSgpICsgZGF5c19pbnRlcnZhbCApO1xyXG5cclxuXHRcdFx0dmFyIGNoZWNrT3V0RGF0ZSA9IGpRdWVyeS5kYXRlcGljay5wYXJzZURhdGUoIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX2RhdGVzX2Zvcm1hdCcgKSwgalF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19pbicgKS52YWwoKSApO1xyXG5cdFx0XHR2YXIgZGF5c19pbnRlcnZhbF9tYXggPSB3cGJjX2dldF9tYXhfZGF5c19zZWxlY3Rpb24oKTtcclxuXHRcdFx0aWYgKCBkYXlzX2ludGVydmFsX21heCA+IDAgKSBkYXlzX2ludGVydmFsX21heC0tO1xyXG5cdFx0XHRjaGVja091dERhdGUuc2V0RGF0ZSggY2hlY2tPdXREYXRlLmdldERhdGUoKSArIGRheXNfaW50ZXJ2YWxfbWF4ICk7XHJcblxyXG5cdFx0XHRpZiAoIChjaGVja0luRGF0ZSA8PSBkYXRlKSAmJiAoY2hlY2tPdXREYXRlID49IGRhdGUpICl7XHJcblx0XHRcdFx0cmV0dXJuIFt0cnVlLCAnY2FsNGRhdGUtJyArIGNsYXNzX2RheSArICcgJyArIGFkZGl0aW9uYWxfY2xhc3MgKyAnICddOyAvLyBBdmFpbGFibGVcclxuXHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRyZXR1cm4gW2ZhbHNlLCAnY2FsNGRhdGUtJyArIGNsYXNzX2RheSArICcgZGF0ZV91c2VyX3VuYXZhaWxhYmxlJ107XHRcdFx0XHRcdFx0XHRcdFx0XHQvLyByZXR1cm4gW2ZhbHNlLCAnJ107ICAvLyBVbmF2YWlsYWJsZVxyXG5cdFx0XHR9XHJcblxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJldHVybiBbdHJ1ZSwgJ2NhbDRkYXRlLScgKyBjbGFzc19kYXkgKyAnICcgKyBhZGRpdGlvbmFsX2NsYXNzICsgJyAnXTsgICAgICAvLyBBdmFpbGFibGVcclxuICAgICAgICB9XHJcbiAgICB9XHJcblxyXG5cdFx0LyoqXHJcblx0XHQgKiBHZXQgTWluaW11bSBudW1iZXIgb2YgRGF5cyB0byBTZWxlY3QgZnJvbSBcdFNldHRpbmdzIEdlbmVyYWwgcGFnZVxyXG5cdFx0ICogQHJldHVybnMge251bWJlcn1cclxuXHRcdCAqL1xyXG5cdFx0ZnVuY3Rpb24gd3BiY19nZXRfbWluX2RheXNfc2VsZWN0aW9uKCl7XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBGaXhJbjogOC42LjEuMjEuXHJcblxyXG5cdFx0XHRpZiAoICdkeW5hbWljJyA9PT0gX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19kYXlzX3NlbGVjdF9tb2RlJyApICl7XHJcblx0XHRcdFx0cmV0dXJuIHBhcnNlSW50KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX2R5bmFtaWNfX2RheXNfbWluJyApICk7XHJcblx0XHRcdH1cclxuXHRcdFx0aWYgKCAnZml4ZWQnID09PSBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX2RheXNfc2VsZWN0X21vZGUnICkgKXtcclxuXHRcdFx0XHRyZXR1cm4gcGFyc2VJbnQoIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2NhbGVuZGFyc19fZml4ZWRfX2RheXNfbnVtJyApICk7XHJcblx0XHRcdH1cclxuXHRcdFx0cmV0dXJuIDA7XHJcblx0XHR9XHJcblxyXG5cdFx0LyoqXHJcblx0XHQgKiBHZXQgTWF4aW11bSBudW1iZXIgb2YgRGF5cyB0byBTZWxlY3QgZnJvbSBcdFNldHRpbmdzIEdlbmVyYWwgcGFnZVxyXG5cdFx0ICogQHJldHVybnMge251bWJlcn1cclxuXHRcdCAqL1xyXG5cdFx0ZnVuY3Rpb24gd3BiY19nZXRfbWF4X2RheXNfc2VsZWN0aW9uKCl7XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQvLyBGaXhJbjogOS45LjAuNDQuXHJcblx0XHRcdGlmICggJ2R5bmFtaWMnID09PSBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdjYWxlbmRhcnNfX2RheXNfc2VsZWN0X21vZGUnICkgKXtcclxuXHRcdFx0XHRyZXR1cm4gcGFyc2VJbnQoIF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2NhbGVuZGFyc19fZHluYW1pY19fZGF5c19tYXgnICkgKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRpZiAoICdmaXhlZCcgPT09IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ2NhbGVuZGFyc19fZGF5c19zZWxlY3RfbW9kZScgKSApe1xyXG5cdFx0XHRcdHJldHVybiBwYXJzZUludCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnY2FsZW5kYXJzX19maXhlZF9fZGF5c19udW0nICkgKTtcclxuXHRcdFx0fVxyXG5cdFx0XHRyZXR1cm4gMzY1O1xyXG5cdFx0fVxyXG5cclxuLy8gPT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09PT09XHJcblxyXG4vKipcclxuICogU2VsZWN0ICdzZWFyY2hfcXVhbnRpdHknIHwgJ2xvY2F0aW9uJyB8IC4uLiBvcHRpb25zIGFuZCBTZWFyY2ggRmlsdGVycyAocHJldmlvdXNseSBjdXN0b20gZmllbGRzKS5cclxuICogUGFyYW1zIGluIHNlYXJjaCBmb3JtLCBhZnRlciBwYWdlIGxvYWRlZCBkZXBlbmRzIG9uIEdFVCBwYXJhbXNcclxuICovXHJcbmZ1bmN0aW9uIHdwYmNfc2VhcmNoX2F2eV9fYXV0b19zZWxlY3RfZmllbGRzX2luX3NlYXJjaF9mb3JtX19pZl9wYXJhbXNfaW5fdXJsKCl7XHJcblxyXG5cdHZhciB1cmxfcGFyYW1zID0gbmV3IFVSTFNlYXJjaFBhcmFtcyggd2luZG93LmxvY2F0aW9uLnNlYXJjaCApO1xyXG5cclxuXHRpZiAoXHJcblx0XHQoIHVybF9wYXJhbXMuaGFzKCAnc2VhcmNoX2dldF9fY3VzdG9tX3BhcmFtcycgKSApXHJcblx0KXtcclxuXHJcblx0XHR2YXIgc2VhcmNoX2dldF9fY3VzdG9tX3BhcmFtcyA9ICB1cmxfcGFyYW1zLmdldCggJ3NlYXJjaF9nZXRfX2N1c3RvbV9wYXJhbXMnICk7XHJcblxyXG5cdFx0Ly8gQ29udmVydCBiYWNrLiAgICAgU29tZSBzeXN0ZW1zIGRvIG5vdCBsaWtlIHN5bWJvbCAnficgaW4gVVJMLCBzbyAgd2UgbmVlZCB0byByZXBsYWNlIHRvICBzb21lIG90aGVyIHN5bWJvbHNcclxuXHRcdHNlYXJjaF9nZXRfX2N1c3RvbV9wYXJhbXMgPSBzZWFyY2hfZ2V0X19jdXN0b21fcGFyYW1zLnJlcGxhY2VBbGwoICdfXl8nLCAnficgKTtcclxuXHJcblx0XHR2YXIgc2VhcmNoX2ZpZWxkc19hcnIgPSB3cGJjX2F1dG9fZmlsbF9zZWFyY2hfZmllbGRzX19wYXJzZSggc2VhcmNoX2dldF9fY3VzdG9tX3BhcmFtcyApXHJcblxyXG5cdFx0Zm9yICggbGV0IGkgPSAwOyBpIDwgc2VhcmNoX2ZpZWxkc19hcnIubGVuZ3RoOyBpKysgKXtcclxuXHJcblx0XHRcdGlmIChcclxuXHRcdFx0XHRcdCAgIHdwYmNfaW5fYXJyYXkoIFsndGV4dCcsICdzZWxlY3Qtb25lJywnc2VsZWN0Ym94LW9uZScsICdzZWxlY3QtbXVsdGlwbGUnLCdzZWxlY3Rib3gtbXVsdGlwbGUnLCAncmFkaW8nLCAnY2hlY2tib3gnXSAgLCBzZWFyY2hfZmllbGRzX2FyclsgaSBdWyAndHlwZScgXSApXHJcblx0XHRcdFx0JiYgKCAhIHdwYmNfaW5fYXJyYXkoIFsnc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJywgJ3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19vdXQnLCAvKidzZWFyY2hfcXVhbnRpdHknLCovICdzZWFyY2hfZmllbGRfX2V4dGVuZF9zZWFyY2hfZGF5cycgXSAsIHNlYXJjaF9maWVsZHNfYXJyWyBpIF1bJ25hbWUnXSApIClcclxuXHRcdFx0KXtcclxuXHRcdFx0XHR2YXIgY2xlYW5lZF9uYW1lICA9ICBzZWFyY2hfZmllbGRzX2FyclsgaSBdWyduYW1lJ10gIDtcclxuXHRcdFx0XHR2YXIgY2xlYW5lZF92YWx1ZSA9ICBzZWFyY2hfZmllbGRzX2FyclsgaSBdWyd2YWx1ZSddIDtcclxuXHJcblx0XHRcdFx0alF1ZXJ5KCAnW25hbWU9XCInICsgY2xlYW5lZF9uYW1lICsgJ1wiXScgKS52YWwoIGNsZWFuZWRfdmFsdWUgKS50cmlnZ2VyKCAnY2hhbmdlJyApO1xyXG5cdFx0XHR9XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHR1cmxfcGFyYW1zLmZvckVhY2goICggdmFsdWUsIGtleSApID0+IHtcclxuXHRcdGlmICgga2V5LnN0YXJ0c1dpdGgoICdib29raW5nXycgKSApe1xyXG5cdFx0XHRqUXVlcnkoICdbbmFtZT1cIicgKyBrZXkgKyAnXCJdJyApLnZhbCggdmFsdWUgKS50cmlnZ2VyKCAnY2hhbmdlJyApO1xyXG5cdFx0fVxyXG5cdH0gKTtcclxufVxyXG5cclxuLyoqIEljb25zIFRyaWdnZXIgdG8gb3BlbiBjYWxlbmRhcnMsIGlmIGNsaWNrZWQgb24gQ2FsZW5kYXIgSWNvbnMgKi9cclxualF1ZXJ5KCAnLndwYmNfaWNuX2NoZWNrX2luJyApLm9uKCAnY2xpY2snLCBmdW5jdGlvbiAoIGV2ZW50ICl7XHJcblx0alF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19pbicgKS50cmlnZ2VyKCAnZm9jdXMnICk7XHJcbn0pO1xyXG5qUXVlcnkoICcud3BiY19pY25fY2hlY2tfb3V0JyApLm9uKCAnY2xpY2snLCBmdW5jdGlvbiAoIGV2ZW50ICl7XHJcblx0alF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19vdXQnICkudHJpZ2dlciggJ2ZvY3VzJyApO1xyXG59KTtcclxuXHJcblxyXG4vKipcclxuICogIERpc2FibGUgc2VhcmNoIGJ1dHRvblxyXG4gKi9cclxuZnVuY3Rpb24gd3BiY19zZWFyY2hfZm9ybV9fZGlzYWJsZV9zdWJtaXRfYnV0dG9uKCl7XHJcblxyXG5cdC8vIEZpeEluOiA5LjkuMC40NS5cclxuXHQvLyBqUXVlcnkoICcjYm9va2luZ19zZWFyY2hfZm9ybSAuc2VhcmNoX2Jvb2tpbmcnICkucHJvcCggJ2Rpc2FibGVkJywgdHJ1ZSApO1xyXG5cdGpRdWVyeSggJyNib29raW5nX3NlYXJjaF9mb3JtIC5zZWFyY2hfYm9va2luZycgKS5hdHRyKCAnc2F2ZWQtYnV0dG9uLWNvbG9yJywgalF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmNzcyggJ2NvbG9yJyApICk7XHJcblx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmNzcyggJ2NvbG9yJywgJyNjY2MnICk7XHJcblx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmNzcyggJ2N1cnNvcicsICdub3QtYWxsb3dlZCcgKTtcclxufVxyXG5cclxuLyoqXHJcbiAqIEVuYWJsZSBzZWFyY2ggYnV0dG9uXHJcbiAqL1xyXG5mdW5jdGlvbiB3cGJjX3NlYXJjaF9mb3JtX19lbmFibGVfc3VibWl0X2J1dHRvbigpe1xyXG5cclxuXHQvLyBGaXhJbjogOS45LjAuNDUuXHJcblx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLnByb3AoICdkaXNhYmxlZCcsIGZhbHNlICk7XHJcblx0aWYgKCB1bmRlZmluZWQgIT0galF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmF0dHIoICdzYXZlZC1idXR0b24tY29sb3InICkgKXsgICAgIC8vIEZpeEluOiA5LjUuMS4yLlxyXG5cdFx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmNzcyggJ2NvbG9yJywgalF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmF0dHIoICdzYXZlZC1idXR0b24tY29sb3InICkgKTtcclxuXHR9XHJcblx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX2Zvcm0gLnNlYXJjaF9ib29raW5nJyApLmNzcyggJ2N1cnNvcicsICdwb2ludGVyJyApO1xyXG59XHJcblxyXG5cclxuLyoqXHJcbiAqIEdldCBhcyBTdHJpbmcgdGhlIGFsbCBWYWx1ZXMgZnJvbSBIVE1MIFNlYXJjaCBGb3JtIGZpZWxkcy4gXHRcdEUuZy46ICdzZWxlY3Rec2VhcmNoX3F1YW50aXR5XjJ+Li4uLidcclxuICpcclxuICogQHBhcmFtIHNlYXJjaF9mb3JtXHRcdC0gSFRNTCBEb20gRm9ybSBlbGVtZW50OiB0aGlzLmZvcm1cclxuICogQHJldHVybnMge3N0cmluZ31cdFx0LSAnc2VsZWN0XnNlYXJjaF9xdWFudGl0eV4yfi4uLi4nXHJcbiAqL1xyXG5mdW5jdGlvbiB3cGJjX3NlYXJjaF9mb3JtX19nZXRfYWxsX2lucHV0X2ZpZWxkc19kYXRhKCBzZWFyY2hfZm9ybSApe1x0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8vIEZpeEluOiA3LjEuMi45LlxyXG5cclxuXHR2YXIgYWxsX3BhcmFtYXMgPSAnJztcclxuXHR2YXIgaW5wX2VsO1xyXG5cdHZhciBpbnBfdmFsO1xyXG5cclxuXHRmb3IgKCB2YXIgaSA9IDA7IGkgPCBzZWFyY2hfZm9ybS5sZW5ndGg7IGkrKyApe1xyXG5cclxuXHRcdGlmICggKHNlYXJjaF9mb3JtWyBpIF0udHlwZSA9PSAnY2hlY2tib3gnKSAmJiAoIXNlYXJjaF9mb3JtWyBpIF0uY2hlY2tlZCkgKXtcclxuXHRcdFx0Y29udGludWU7XHJcblx0XHR9XHJcblxyXG5cdFx0aW5wX2VsID0gc2VhcmNoX2Zvcm1bIGkgXS50eXBlICsgXCJeXCIgKyBzZWFyY2hfZm9ybVsgaSBdLm5hbWUgKyBcIl5cIjtcclxuXHJcblx0XHRpbnBfdmFsID0galF1ZXJ5KCBzZWFyY2hfZm9ybVsgaSBdICkudmFsKCk7XHJcblxyXG5cdFx0aWYgKCBBcnJheS5pc0FycmF5KCBpbnBfdmFsICkgKXtcclxuXHRcdFx0alF1ZXJ5LmVhY2goIGlucF92YWwsIGZ1bmN0aW9uICggaW5kZXggKXtcclxuXHRcdFx0XHRhbGxfcGFyYW1hcyArPSBpbnBfZWwgKyBpbnBfdmFsWyBpbmRleCBdICsgXCJ+XCI7XHJcblx0XHRcdH0gKTtcclxuXHRcdH0gZWxzZSB7XHJcblx0XHRcdGFsbF9wYXJhbWFzICs9IGlucF9lbCArIGlucF92YWwgKyBcIn5cIjtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdHJldHVybiBhbGxfcGFyYW1hcztcclxufVxyXG5cclxuLyoqXHJcbiAqIEdldCBEYXRlIHZhbHVlIFBhcnNlZCBmcm9tICBTZWFyY2ggRGF0ZSBmb3JtYXQgIHRvICAnMjAyNC0wNS0wNicgZm9ybWF0XHJcbiAqXHJcbiAqIEBwYXJhbSBodG1sX2lkXHRcdCcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyB8ICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX291dCdcclxuICovXHJcbmZ1bmN0aW9uIHdwYmNfc2VhcmNoX2Zvcm1fX2dldF9wYXJzZWRfc2VhcmNoX2RhdGVfX2FzX3ltZCggaHRtbF9pZCApe1xyXG5cclxuXHR2YXIgYm9va2luZ19zZWFyY2hfZGF0ZSA9ICcnO1xyXG5cdGlmICggalF1ZXJ5KCBodG1sX2lkICkubGVuZ3RoICl7XHJcblx0XHRib29raW5nX3NlYXJjaF9kYXRlID0galF1ZXJ5KCBodG1sX2lkICkudmFsKCk7XHJcblx0fVxyXG5cclxuXHQvLyBTZXQgSlMgIGRhdGUgdG8gIHNvbWUgRnV0dXJlIGRhdGUsICB0aGF0IHdpbGwgYmUgYXZhaWxhYmxlIGZvciBzdXJlXHJcblx0dmFyIHNlYXJjaF9qc19kYXRlID0gbmV3IERhdGUoICcyMTAwLTAxLTAxJyApO1xyXG5cclxuXHQvLyBQYXJzZSBhIHN0cmluZyB2YWx1ZSBpbnRvIGEgZGF0ZSBvYmplY3RcclxuXHRpZiAoICcnICE9PSBib29raW5nX3NlYXJjaF9kYXRlICl7XHJcblxyXG5cdFx0c2VhcmNoX2pzX2RhdGUgPSBqUXVlcnkuZGF0ZXBpY2sucGFyc2VEYXRlKCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X19kYXRlc19mb3JtYXQnICksIGJvb2tpbmdfc2VhcmNoX2RhdGUgKTtcclxuXHJcblx0XHQvLyBGb3JtYXQgYSBkYXRlIG9iamVjdCBpbnRvIGEgc3RyaW5nIHZhbHVlLlxyXG5cdFx0dmFyIHNlYXJjaF9zdHJpbmdfZGF0ZSA9IGpRdWVyeS5kYXRlcGljay5mb3JtYXREYXRlKCAneXktbW0tZGQnLCBzZWFyY2hfanNfZGF0ZSApO1xyXG5cclxuXHRcdHJldHVybiBzZWFyY2hfc3RyaW5nX2RhdGU7XHJcblxyXG5cdH0gZWxzZSB7XHJcblx0XHRyZXR1cm4gJzIxMDAtMDEtMDEnOyBcdFx0XHRcdC8vIEZpeEluOiAxMC4yLjIuMS5cclxuXHR9XHJcbn1cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuLy8gU2VhcmNoIFN1Ym1pdCAgLSAgTmV3IFBhZ2VcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblxyXG4vKipcclxuICogUHJlcGFyZSBmb3Igc3VibWl0IFNlYXJjaCBGb3JtICB0byBOZXcgUGFnZVxyXG4gKlxyXG4gKiBAcGFyYW0gc2VhcmNoX2Zvcm1cdFx0XHRIVE1MIERvbSAgZm9ybTogIHRoaXMuZm9ybVxyXG4gKiBAcGFyYW0gd3BkYmNfYWN0aXZlX2xvY2FsZVx0c3RyaW5nIGxvY2FsZTogXHQnZXNfRVMnXHJcbiAqIEByZXR1cm5zIHtib29sZWFufVxyXG4gKi9cclxuZnVuY3Rpb24gd3BiY19zZWFyY2hfZm9ybV9jbGlja19uZXdfcGFnZSggc2VhcmNoX2Zvcm0sIHdwZGJjX2FjdGl2ZV9sb2NhbGUgKXtcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdC8vIEZpeEluOiA4LjYuMS4yMS5cclxuXHJcblx0aWYgKCAnT2ZmJyAhPSBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X193YXJuaW5nX19kYXRlc19yZXF1aXJlZF9lbmFibGVkJyApICl7XHJcblx0XHRpZiAoICgnJyA9PSBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLnZhbCgpKSB8fCAoJycgPT0galF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fZGlzcGxheV9jaGVja19vdXQnICkudmFsKCkpICl7XHJcblx0XHRcdGFsZXJ0KCBfd3BiYy5nZXRfb3RoZXJfcGFyYW0oICdzZWFyY2hfYXZ5X193YXJuaW5nX19kYXRlc19yZXF1aXJlZF93YXJuaW5nJyApICk7XHJcblx0XHRcdHJldHVybiBmYWxzZTtcclxuXHRcdH1cclxuXHR9XHJcblx0d3BiY19zZWFyY2hfZm9ybV9fZGlzYWJsZV9zdWJtaXRfYnV0dG9uKCk7XHJcblxyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHQvLyBHZXQgU2VhcmNoIEZpZWxkczpcclxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblx0dmFyIHBhcmFtX19jaGVja19pbl95bWQgPSB3cGJjX3NlYXJjaF9mb3JtX19nZXRfcGFyc2VkX3NlYXJjaF9kYXRlX19hc195bWQoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApO1x0XHRcdC8vIEZpeEluOiA5LjUuMy40LlxyXG5cdGpRdWVyeSggJ1tuYW1lPVwic2VhcmNoX2dldF9fY2hlY2tfaW5feW1kXCJdJyApLnZhbCggcGFyYW1fX2NoZWNrX2luX3ltZCApOyAgICAgICAgICBcdC8vIGluIGZvcm1hdCAgMjAyNC0wNS0wNlxyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHR2YXIgcGFyYW1fX2NoZWNrX291dF95bWQgPSB3cGJjX3NlYXJjaF9mb3JtX19nZXRfcGFyc2VkX3NlYXJjaF9kYXRlX19hc195bWQoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX291dCcgKTtcclxuXHRqUXVlcnkoICdbbmFtZT1cInNlYXJjaF9nZXRfX2NoZWNrX291dF95bWRcIl0nICkudmFsKCBwYXJhbV9fY2hlY2tfb3V0X3ltZCApOyAgICAgICAgXHQvLyBpbiBmb3JtYXQgIDIwMjQtMDUtMDZcclxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblx0dmFyIHBhcmFtX19zZWFyY2hfcXVhbnRpdHkgPSAoalF1ZXJ5KCBcIltuYW1lPSdzZWFyY2hfcXVhbnRpdHknXVwiICkubGVuZ3RoID4gMClcclxuXHRcdFx0XHRcdFx0XHRcdD8galF1ZXJ5KCBcIltuYW1lPSdzZWFyY2hfcXVhbnRpdHknXVwiICkudmFsKClcclxuXHRcdFx0XHRcdFx0XHRcdDogMTtcclxuXHRqUXVlcnkoICdbbmFtZT1cInNlYXJjaF9nZXRfX3F1YW50aXR5XCJdJyApLnZhbCggcGFyYW1fX3NlYXJjaF9xdWFudGl0eSApO1xyXG5cdHZhciBwYXJhbV9fc2VhcmNoX3RpbWUgPSAoalF1ZXJ5KCBcIltuYW1lPSdzZWFyY2hfdGltZSddXCIgKS5sZW5ndGggPiAwKVxyXG5cdFx0XHRcdFx0XHRcdFx0PyBqUXVlcnkoIFwiW25hbWU9J3NlYXJjaF90aW1lJ11cIiApLnZhbCgpXHJcblx0XHRcdFx0XHRcdFx0XHQ6ICcnO1xyXG5cdGpRdWVyeSggJ1tuYW1lPVwic2VhcmNoX2dldF9fdGltZVwiXScgKS52YWwoIHBhcmFtX19zZWFyY2hfdGltZSApO1xyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHR2YXIgcGFyYW1fX3VzZXJzX2lkID0gKGpRdWVyeSggJyNzZWFyY2hfZmllbGRfX3VzZXJzX2lkJyApLmxlbmd0aClcclxuXHRcdFx0XHRcdFx0XHRcdFx0ID8galF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fdXNlcnNfaWQnICkudmFsKClcclxuXHRcdFx0XHRcdFx0XHRcdFx0IDogJyc7XHJcblx0alF1ZXJ5KCAnW25hbWU9XCJzZWFyY2hfZ2V0X191c2Vyc19pZFwiXScgKS52YWwoIHBhcmFtX191c2Vyc19pZCApO1xyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHR2YXIgcGFyYW1fX2V4dGVuZGVkX2RheXMgPSAoalF1ZXJ5KCBcImlucHV0W25hbWU9J3NlYXJjaF9maWVsZF9fZXh0ZW5kX3NlYXJjaF9kYXlzJ106Y2hlY2tlZFwiICkubGVuZ3RoID4gMClcclxuXHRcdFx0XHRcdFx0XHRcdD8galF1ZXJ5KCBcImlucHV0W25hbWU9J3NlYXJjaF9maWVsZF9fZXh0ZW5kX3NlYXJjaF9kYXlzJ11cIiApLnZhbCgpXHJcblx0XHRcdFx0XHRcdFx0XHQ6IDA7XHJcblx0alF1ZXJ5KCAnW25hbWU9XCJzZWFyY2hfZ2V0X19leHRlbmRcIl0nICkudmFsKCBwYXJhbV9fZXh0ZW5kZWRfZGF5cyApO1xyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHQvLyBHZXQgYXMgU3RyaW5nIHRoZSBhbGwgVmFsdWVzIGZyb20gSFRNTCBTZWFyY2ggRm9ybSBmaWVsZHMuIFx0XHRFLmcuOiAnc2VsZWN0XnNlYXJjaF9xdWFudGl0eV4yfi4uLi4nXHJcblx0dmFyIHBhcmFtX19hbGxfYXNfc3RyID0gd3BiY19zZWFyY2hfZm9ybV9fZ2V0X2FsbF9pbnB1dF9maWVsZHNfZGF0YSggc2VhcmNoX2Zvcm0gKTtcclxuXHRwYXJhbV9fYWxsX2FzX3N0ciA9IHBhcmFtX19hbGxfYXNfc3RyLnJlcGxhY2VBbGwoICd+JywgJ19eXycgKTtcdFx0Ly8gU29tZSBzeXN0ZW1zIGRvIG5vdCBsaWtlIHN5bWJvbCAnficgaW4gVVJMLCBzbyAgd2UgbmVlZCB0byByZXBsYWNlIHRvICBzb21lIG90aGVyIHN5bWJvbHNcclxuXHJcblx0alF1ZXJ5KCAnW25hbWU9XCJzZWFyY2hfZ2V0X19jdXN0b21fcGFyYW1zXCJdJyApLnZhbCggcGFyYW1fX2FsbF9hc19zdHIgKTsgICAgICAgICAgXHRcdFx0Ly8gaW4gZm9ybWF0ICAnc2VsZWN0XnNlYXJjaF9xdWFudGl0eV4yfi4uLi4nXHJcblx0Ly8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuXHRyZXR1cm4gIHRydWU7XHJcbn1cclxuXHJcblxyXG4vLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcbi8vIFNlYXJjaCBTdWJtaXQgIC0gIEFqYXhcclxuLy8gLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cclxuLyoqXHJcbiAqIFN1Ym1pdCBTZWFyY2ggQWpheCByZXF1ZXN0LCAgYW5kIHNob3cgTG9hZGluZyBzcGlubmVyXHJcbiAqXHJcbiAqIEBwYXJhbSBzZWFyY2hfZm9ybSAgICAgICAgICAgRE9NIEZvcm0gLT4gdGhpcy5mb3JtXHJcbiAqIEBwYXJhbSB3cGRldl9hY3RpdmVfbG9jYWxlICAgTG9jYWxlICAgLT4gJ2VzX0VTJ1xyXG4gKi9cclxuZnVuY3Rpb24gd3BiY19zZWFyY2hfZm9ybV9jbGlja19hamF4KCBzZWFyY2hfZm9ybSwgd3BkZXZfYWN0aXZlX2xvY2FsZSApe1xyXG5cclxuXHRpZiAoICdPZmYnICE9IF93cGJjLmdldF9vdGhlcl9wYXJhbSggJ3NlYXJjaF9hdnlfX3dhcm5pbmdfX2RhdGVzX3JlcXVpcmVkX2VuYWJsZWQnICkgKXtcclxuXHRcdGlmICggKCcnID09PSBqUXVlcnkoICcjc2VhcmNoX2ZpZWxkX19kaXNwbGF5X2NoZWNrX2luJyApLnZhbCgpKSB8fCAoJycgPT09IGpRdWVyeSggJyNzZWFyY2hfZmllbGRfX2Rpc3BsYXlfY2hlY2tfb3V0JyApLnZhbCgpKSApe1xyXG5cdFx0XHRhbGVydCggX3dwYmMuZ2V0X290aGVyX3BhcmFtKCAnc2VhcmNoX2F2eV9fd2FybmluZ19fZGF0ZXNfcmVxdWlyZWRfd2FybmluZycgKSApO1xyXG5cdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHR9XHJcblx0fVxyXG5cclxuXHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHQvLyBTaG93IExvYWRpbmcgU3Bpbm5lclxyXG5cdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLVxyXG5cdC8vLy8gOjogT2xkIDo6XHJcblx0Ly9kb2N1bWVudC5nZXRFbGVtZW50QnlJZCgnYm9va2luZ19zZWFyY2hfcmVzdWx0cycgKS5pbm5lckhUTUwgPSAnPGRpdiBzdHlsZT1cImhlaWdodDoyMHB4O3dpZHRoOjEwMCU7dGV4dC1hbGlnbjpjZW50ZXI7bWFyZ2luOjE1cHggYXV0bztcIj48aW1nICBzdHlsZT1cInZlcnRpY2FsLWFsaWduOm1pZGRsZTtib3gtc2hhZG93Om5vbmU7d2lkdGg6MTRweDtcIiBzcmM9XCInK193cGJjLmdldF9vdGhlcl9wYXJhbSggJ3VybF9wbHVnaW4nICkrJy9hc3NldHMvaW1nL2FqYXgtbG9hZGVyLmdpZlwiPjwvL2Rpdj4nO1xyXG5cdC8vLy86OiBCaWcgTG9hZGluZyBDaXJjbGUgOjpcclxuXHQvL2pRdWVyeSggJyNib29raW5nX3NlYXJjaF9yZXN1bHRzJyApLmh0bWwoICc8ZGl2IGNsYXNzPVwid3BiY19ib29raW5nX2Zvcm1fc3Bpbl9sb2FkZXJcIiBzdHlsZT1cInBvc2l0aW9uOiByZWxhdGl2ZTttYXJnaW4tdG9wOiA3MHB4O1wiPjxkaXYgY2xhc3M9XCJ3cGJjX3NwaW5zX2xvYWRlcl93cmFwcGVyXCI+PGRpdiBjbGFzcz1cIndwYmNfc3BpbnNfbG9hZGVyXCI+PC9kaXY+PC9kaXY+PC9kaXY+JyApO1xyXG5cclxuXHQvLy8vOjogTWluaSBMb2FkaW5nIENpcmNsZSA6OiAgICAgICAvLyBGaXhJbjogMTAuMC4wLjM4LlxyXG5cdGpRdWVyeSggJyNib29raW5nX3NlYXJjaF9yZXN1bHRzJyApLmh0bWwoICc8ZGl2IGNsYXNzPVwid3BiY19ib29raW5nX2Zvcm1fc3Bpbl9sb2FkZXJcIiBzdHlsZT1cInBvc2l0aW9uOiByZWxhdGl2ZTttYXJnaW4tdG9wOiA1MHB4O1wiPjxkaXYgY2xhc3M9XCJ3cGJjX3NwaW5zX2xvYWRlcl93cmFwcGVyXCI+PGRpdiBjbGFzcz1cIndwYmNfc3Bpbl9sb2FkZXJfb25lX25ld1wiPjwvZGl2PjwvZGl2PjwvZGl2PicgKTtcclxuXHJcblx0d3BiY19hamF4X3NlYXJjaF9zdWJtaXQoIHNlYXJjaF9mb3JtLCB3cGRldl9hY3RpdmVfbG9jYWxlICk7XHJcbn1cclxuXHJcblxyXG5cdC8qKlxyXG5cdCAqIFNlbmQgQWpheCBTZWFyY2ggQXZhaWxhYmlsaXR5IFJlcXVlc3RcclxuXHQgKlxyXG5cdCAqIEBwYXJhbSBzZWFyY2hfZm9ybVx0XHRcdEhUTUwgRG9tICBmb3JtOiAgdGhpcy5mb3JtXHJcblx0ICogQHBhcmFtIHdwZGJjX2FjdGl2ZV9sb2NhbGVcdHN0cmluZyBsb2NhbGU6IFx0J2VzX0VTJ1xyXG5cdCAqL1xyXG4gICAgZnVuY3Rpb24gd3BiY19hamF4X3NlYXJjaF9zdWJtaXQoIHNlYXJjaF9mb3JtLCB3cGRiY19hY3RpdmVfbG9jYWxlICkgeyAgICAgICAgICAgXHQvLyBGaXhJbjogNi4wLjEuMS5cclxuXHJcblx0XHQvLyBEaXNhYmxlIFN1Ym1pdCBidXR0b25cclxuXHRcdHdwYmNfc2VhcmNoX2Zvcm1fX2Rpc2FibGVfc3VibWl0X2J1dHRvbigpO1x0XHRcdFx0XHRcdFx0XHRcdFx0Ly8gRml4SW46IDkuOS4wLjQ1LlxyXG4gICAgICAgIGpRdWVyeSggJyNib29raW5nX3NlYXJjaF9mb3JtIC5zZWFyY2hfYm9va2luZycgKS5wcm9wKCAnZGlzYWJsZWQnLCB0cnVlICk7XHJcblxyXG5cdFx0Ly8gQ2xlYXIgc2VhcmNoIHJlc3VsdHNcclxuXHRcdGpRdWVyeSggJy5ib29raW5nX3NlYXJjaF9hamF4X2NvbnRhaW5lcicgKS5yZW1vdmUoKTtcclxuXHJcblx0XHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblx0XHQvLyBHZXQgU2VhcmNoIEZpZWxkczpcclxuXHRcdC8vIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS1cclxuXHJcblx0XHQvLyBHZXQgYXMgU3RyaW5nIHRoZSBhbGwgVmFsdWVzIGZyb20gSFRNTCBTZWFyY2ggRm9ybSBmaWVsZHMuIFx0XHRFLmcuOiAnc2VsZWN0XnNlYXJjaF9xdWFudGl0eV4yfi4uLi4nXHJcblx0XHR2YXIgcGFyYW1fX2FsbF9hc19zdHIgICAgPSB3cGJjX3NlYXJjaF9mb3JtX19nZXRfYWxsX2lucHV0X2ZpZWxkc19kYXRhKCBzZWFyY2hfZm9ybSApO1xyXG5cclxuXHRcdHZhciBwYXJhbV9fY2hlY2tfaW5feW1kICA9IHdwYmNfc2VhcmNoX2Zvcm1fX2dldF9wYXJzZWRfc2VhcmNoX2RhdGVfX2FzX3ltZCggJyNzZWFyY2hfZmllbGRfX2Rpc3BsYXlfY2hlY2tfaW4nICk7XHRcdC8vIEZpeEluOiA4LjYuMS4yMS5cclxuXHRcdHZhciBwYXJhbV9fY2hlY2tfb3V0X3ltZCA9IHdwYmNfc2VhcmNoX2Zvcm1fX2dldF9wYXJzZWRfc2VhcmNoX2RhdGVfX2FzX3ltZCggJyNzZWFyY2hfZmllbGRfX2Rpc3BsYXlfY2hlY2tfb3V0JyApO1xyXG5cclxuXHRcdHZhciBwYXJhbV9fdXNlcnNfaWQgPSAoalF1ZXJ5KCAnI3NlYXJjaF9maWVsZF9fdXNlcnNfaWQnICkubGVuZ3RoKVxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdCA/IGpRdWVyeSggJyNzZWFyY2hfZmllbGRfX3VzZXJzX2lkJyApLnZhbCgpXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0IDogJyc7XHJcblx0XHR2YXIgcGFyYW1fX2V4dGVuZGVkX2RheXMgPSAoalF1ZXJ5KCBcImlucHV0W25hbWU9J3NlYXJjaF9maWVsZF9fZXh0ZW5kX3NlYXJjaF9kYXlzJ106Y2hlY2tlZFwiICkubGVuZ3RoID4gMClcclxuXHRcdFx0XHRcdFx0XHRcdFx0PyBqUXVlcnkoIFwiaW5wdXRbbmFtZT0nc2VhcmNoX2ZpZWxkX19leHRlbmRfc2VhcmNoX2RheXMnXVwiICkudmFsKClcclxuXHRcdFx0XHRcdFx0XHRcdFx0OiAwO1xyXG5cdFx0dmFyIHBhcmFtX19zZWFyY2hfcXVhbnRpdHkgPSAoalF1ZXJ5KCBcIltuYW1lPSdzZWFyY2hfcXVhbnRpdHknXVwiICkubGVuZ3RoID4gMClcclxuXHRcdFx0XHRcdFx0XHRcdFx0PyBqUXVlcnkoIFwiW25hbWU9J3NlYXJjaF9xdWFudGl0eSddXCIgKS52YWwoKVxyXG5cdFx0XHRcdFx0XHRcdFx0XHQ6IDE7XHJcblx0XHR2YXIgcGFyYW1fX3NlYXJjaF90aW1lID0gKGpRdWVyeSggXCJbbmFtZT0nc2VhcmNoX3RpbWUnXVwiICkubGVuZ3RoID4gMClcclxuXHRcdFx0XHRcdFx0XHRcdFx0PyBqUXVlcnkoIFwiW25hbWU9J3NlYXJjaF90aW1lJ11cIiApLnZhbCgpXHJcblx0XHRcdFx0XHRcdFx0XHRcdDogJyc7XHJcblx0XHQvLyAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXHJcblx0XHRqUXVlcnkuYWpheCh7XHJcblx0XHRcdHVybCAgICA6IHdwYmNfdXJsX2FqYXgsXHJcblx0XHRcdHR5cGUgICA6J1BPU1QnLFxyXG5cdFx0XHRzdWNjZXNzOiBmdW5jdGlvbiAoIGRhdGEsIHRleHRTdGF0dXMgKXtcclxuXHRcdFx0XHRpZiAoIHRleHRTdGF0dXMgPT0gJ3N1Y2Nlc3MnICl7XHJcblxyXG5cdFx0XHRcdFx0aWYgKFxyXG5cdFx0XHRcdFx0XHQgICAgKCAndW5kZWZpbmVkJyAhPT0gdHlwZW9mIChkYXRhKSApXHJcblx0XHRcdFx0XHQgICAgICYmICggJ3VuZGVmaW5lZCcgIT09IHR5cGVvZiAoZGF0YS5hanhfZGF0YV9zZWFyY2hfY29udGVudCkgKVxyXG5cdFx0XHRcdFx0KXtcclxuXHRcdFx0XHRcdFx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX3Jlc3VsdHMnICkuaHRtbCggZGF0YS5hanhfZGF0YV9zZWFyY2hfY29udGVudCApOy8vICc8ZGl2IGNsYXNzPVwid3BiY19ib29raW5nX2Zvcm1fc3Bpbl9sb2FkZXJcIlxyXG5cdFx0XHRcdFx0XHQvLyBqUXVlcnkoICcjYm9va2luZ19zZWFyY2hfYWpheCcgKS5odG1sKCBkYXRhLmFqeF9kYXRhX3NlYXJjaF9jb250ZW50ICk7XHJcblx0XHRcdFx0XHRcdC8vIGpRdWVyeSggXCIjYm9va2luZ19zZWFyY2hfYWpheFwiICkuYWZ0ZXIoIGpRdWVyeSggXCIjYm9va2luZ19zZWFyY2hfYWpheCAuYm9va2luZ19zZWFyY2hfYWpheF9jb250YWluZXJcIiApICk7XHJcblx0XHRcdFx0XHRcdC8vIGpRdWVyeSggXCIjYm9va2luZ19zZWFyY2hfYWpheFwiICkuaGlkZSgpO1xyXG5cdFx0XHRcdFx0fSBlbHNlIHtcclxuXHRcdFx0XHRcdFx0Y29uc29sZS5sb2coICcgOjogU0VBUkNIIFJFU1BPTlNFIEVSUk9SIDo6ICcsIGRhdGEgKTtcclxuXHRcdFx0XHRcdFx0dmFyIGpxX25vZGUgPSBqUXVlcnkoICcjYm9va2luZ19zZWFyY2hfcmVzdWx0cycgKTtcclxuXHRcdFx0XHRcdFx0Ly8gU2hvdyBNZXNzYWdlXHJcblx0XHRcdFx0XHRcdHdwYmNfZnJvbnRfZW5kX19zaG93X21lc3NhZ2UoICcgOjogU0VBUkNIIFJFU1BPTlNFIEVSUk9SIDo6IDxicj4nICsgSlNPTi5zdHJpbmdpZnkoIGRhdGEgKS5yZXBsYWNlKCAvXFxuL2csIFwiPGJyIC8+XCIgKSxcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdHsgICAndHlwZScgICAgIDogJ3dhcm5pbmcnLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQnc2hvd19oZXJlJzogeydqcV9ub2RlJzoganFfbm9kZSwgJ3doZXJlJzogJ2FmdGVyJ30sXHJcblx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdCdpc19hcHBlbmQnOiB0cnVlLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQnc3R5bGUnICAgIDogJ3RleHQtYWxpZ246bGVmdDsnLFxyXG5cdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHQnZGVsYXknICAgIDogMzAwMDBcclxuXHRcdFx0XHRcdFx0XHRcdFx0XHRcdFx0XHRcdH0gKTtcclxuXHRcdFx0XHRcdFx0alF1ZXJ5KCAnI2Jvb2tpbmdfc2VhcmNoX3Jlc3VsdHMgLndwYmNfYm9va2luZ19mb3JtX3NwaW5fbG9hZGVyJykucmVtb3ZlKCk7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0XHR3cGJjX3NlYXJjaF9mb3JtX19lbmFibGVfc3VibWl0X2J1dHRvbigpO1xyXG5cdFx0XHRcdH1cclxuXHRcdFx0fSxcclxuXHRcdFx0ZXJyb3I6IGZ1bmN0aW9uICggWE1MSHR0cFJlcXVlc3QsIHRleHRTdGF0dXMsIGVycm9yVGhyb3duICl7IGNvbnNvbGUubG9nKCAgJ1dQQkMgRXJyb3IgOjogQWpheCBzZWFyY2ggRXJyb3Igc3RhdHVzOicgKyB0ZXh0U3RhdHVzICwgWE1MSHR0cFJlcXVlc3QgKTsgYWxlcnQoIFhNTEh0dHBSZXF1ZXN0LnN0YXR1cyArICcgJyArIFhNTEh0dHBSZXF1ZXN0LnN0YXR1c1RleHQgKTsgaWYgKCBYTUxIdHRwUmVxdWVzdC5zdGF0dXMgPT0gNTAwICl7ICBhbGVydCggJ1BsZWFzZSBjaGVjayBhdCB0aGlzIHBhZ2UgYWNjb3JkaW5nIHRoaXMgZXJyb3I6JyArICcgaHR0cHM6Ly93cGJvb2tpbmdjYWxlbmRhci5jb20vZmFxLyNhamF4LXNlbmRpbmctZXJyb3InICk7ICB9IH0sXHJcblx0XHRcdGRhdGE6IHtcclxuXHRcdFx0XHRhY3Rpb24gICAgICAgICAgICAgICAgICAgIDogJ0JPT0tJTkdfU0VBUkNIJyxcclxuXHJcblx0XHRcdFx0c2VhcmNoX2FqeF9fY2hlY2tfaW5feW1kICA6IHBhcmFtX19jaGVja19pbl95bWQsXHJcblx0XHRcdFx0c2VhcmNoX2FqeF9fY2hlY2tfb3V0X3ltZCA6IHBhcmFtX19jaGVja19vdXRfeW1kLFxyXG5cdFx0XHRcdHNlYXJjaF9hanhfX3F1YW50aXR5ICAgICAgOiBwYXJhbV9fc2VhcmNoX3F1YW50aXR5LFxyXG5cdFx0XHRcdHNlYXJjaF9hanhfX3RpbWUgICAgICBcdCAgOiBwYXJhbV9fc2VhcmNoX3RpbWUsXHJcblxyXG5cdFx0XHRcdHNlYXJjaF9hanhfX2N1c3RvbV9wYXJhbXMgOiBwYXJhbV9fYWxsX2FzX3N0cixcclxuXHRcdFx0XHRzZWFyY2hfYWp4X19leHRlbmQgICAgICAgIDogcGFyYW1fX2V4dGVuZGVkX2RheXMsXHJcblx0XHRcdFx0c2VhcmNoX2FqeF9fdXNlcnNfaWQgICAgICA6IHBhcmFtX191c2Vyc19pZCxcclxuXHJcblx0XHRcdFx0d3BkZXZfYWN0aXZlX2xvY2FsZSAgICAgICA6IHdwZGJjX2FjdGl2ZV9sb2NhbGUsXHJcblx0XHRcdFx0d3BiY19ub25jZSAgICAgICAgICAgICAgICA6IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKCAnd3BiY19zZWFyY2hfbm9uY2UnICkudmFsdWVcclxuXHRcdFx0fVxyXG5cdFx0fSk7XHJcblx0fVxyXG5cclxuIl0sIm1hcHBpbmdzIjoiOztBQUFBO0FBQ0E7QUFDQTtBQUNBLFNBQVNBLG1DQUFtQ0EsQ0FBQSxFQUFFO0VBRTdDLElBQUlDLGVBQWUsR0FBRztJQUNyQkMsUUFBUSxFQUFRQyw2QkFBNkI7SUFDN0NDLGFBQWEsRUFBR0MsMENBQTBDO0lBQzFEQyxNQUFNLEVBQVUsT0FBTztJQUN2QkMsV0FBVyxFQUFLLENBQUM7SUFDakJDLGNBQWMsRUFBRSxDQUFDO0lBQ2pCQyxVQUFVLEVBQU0sQ0FBQztJQUNqQkMsUUFBUSxFQUFRLFVBQVU7SUFDMUJDLFFBQVEsRUFBUSxVQUFVO0lBQzFCQyxVQUFVLEVBQU1DLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDBCQUEyQixDQUFDO0lBQ25FQyxXQUFXLEVBQUssS0FBSztJQUNyQkMsVUFBVSxFQUFNLEtBQUs7SUFDckJDLE9BQU8sRUFBUyxDQUFDO0lBQ2pCQyxPQUFPLEVBQVNMLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLG9DQUFxQyxDQUFDO0lBQUk7SUFDakY7SUFDQUssVUFBVSxFQUFRLEtBQUs7SUFDdkJDLGNBQWMsRUFBSSxJQUFJO0lBQ3RCQyxVQUFVLEVBQVEsS0FBSztJQUN2QkMsUUFBUSxFQUFVVCxLQUFLLENBQUNDLGVBQWUsQ0FBRSxzQkFBdUIsQ0FBQztJQUNqRVMsV0FBVyxFQUFPLEtBQUs7SUFDdkJDLGdCQUFnQixFQUFFLElBQUk7SUFDdEJDLGNBQWMsRUFBSSxLQUFLO0lBQ3ZCQyxTQUFTLEVBQVMsSUFBSTtJQUN0QkMsVUFBVSxFQUFRLENBQUMsY0FBYyxFQUFFLG1CQUFtQixFQUFFLHNCQUFzQjtFQUMvRSxDQUFDO0VBRUQsSUFBSUMsb0JBQW9CLEdBQUcsRUFBRTtFQUU3QixJQUFJQyxVQUFVLEdBQUdDLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxLQUFLLENBQUUsR0FBSSxDQUFDO0VBQzNDLElBQUtILFVBQVUsQ0FBQ0ksTUFBTSxHQUFHLENBQUMsRUFBRTtJQUMzQkosVUFBVSxHQUFHQSxVQUFVLENBQUUsQ0FBQyxDQUFFLENBQUNHLEtBQUssQ0FBRSxHQUFJLENBQUM7SUFDekMsS0FBTSxJQUFJRSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdMLFVBQVUsQ0FBQ0ksTUFBTSxFQUFFQyxDQUFDLEVBQUUsRUFBRTtNQUM1QyxJQUFJQyxTQUFTLEdBQUdOLFVBQVUsQ0FBRUssQ0FBQyxDQUFFLENBQUNGLEtBQUssQ0FBRSxHQUFJLENBQUM7TUFDNUMsSUFBTUcsU0FBUyxDQUFFLENBQUMsQ0FBRSxLQUFLLGdDQUFnQyxJQUFNLEVBQUUsS0FBS1Asb0JBQXFCLEVBQUU7UUFDNUZBLG9CQUFvQixHQUFHTyxTQUFTLENBQUUsQ0FBQyxDQUFFO01BQ3RDO01BQ0EsSUFBS0EsU0FBUyxDQUFFLENBQUMsQ0FBRSxLQUFLLDBCQUEwQixFQUFFO1FBQ25EUCxvQkFBb0IsR0FBR08sU0FBUyxDQUFFLENBQUMsQ0FBRTtNQUN0QztJQUNEO0VBQ0Q7RUFDQSxJQUFNLEVBQUUsS0FBS1Asb0JBQW9CLElBQU0sWUFBWSxLQUFLQSxvQkFBcUIsRUFBRTtJQUM5RTNCLGVBQWUsQ0FBRSxhQUFhLENBQUUsR0FBR21DLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxVQUFVLENBQzdDekIsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUMsRUFDbERzQixNQUFNLENBQUNDLFFBQVEsQ0FBQ0UsU0FBUyxDQUFFLFVBQVUsRUFBRVgsb0JBQXFCLENBQzlELENBQUM7SUFDaEIzQixlQUFlLENBQUUsYUFBYSxDQUFFLEdBQUcsSUFBSTtFQUN4QztFQUVBbUMsTUFBTSxDQUFFLGlDQUFrQyxDQUFDLENBQUNDLFFBQVEsQ0FBRXBDLGVBQWdCLENBQUM7QUFDeEU7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU3VDLG9DQUFvQ0EsQ0FBQSxFQUFFO0VBRTlDLElBQUl2QyxlQUFlLEdBQUc7SUFDckJHLGFBQWEsRUFBR3FDLDJDQUEyQztJQUMzRG5DLE1BQU0sRUFBVSxPQUFPO0lBQ3ZCQyxXQUFXLEVBQUssQ0FBQztJQUNqQkMsY0FBYyxFQUFFLENBQUM7SUFDakJDLFVBQVUsRUFBTSxDQUFDO0lBQ2pCQyxRQUFRLEVBQVEsVUFBVTtJQUMxQkMsUUFBUSxFQUFRLFVBQVU7SUFDMUJDLFVBQVUsRUFBTUMsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUM7SUFDbkVDLFdBQVcsRUFBSyxLQUFLO0lBQ3JCQyxVQUFVLEVBQU0sS0FBSztJQUNyQkMsT0FBTyxFQUFTLENBQUM7SUFDakJDLE9BQU8sRUFBU0wsS0FBSyxDQUFDQyxlQUFlLENBQUUsb0NBQXFDLENBQUM7SUFBSTtJQUNqRjtJQUNBSyxVQUFVLEVBQVEsS0FBSztJQUN2QkMsY0FBYyxFQUFJLElBQUk7SUFDdEJDLFVBQVUsRUFBUSxLQUFLO0lBQ3ZCQyxRQUFRLEVBQVVULEtBQUssQ0FBQ0MsZUFBZSxDQUFFLHNCQUF1QixDQUFDO0lBQ2pFUyxXQUFXLEVBQU8sS0FBSztJQUN2QkMsZ0JBQWdCLEVBQUUsSUFBSTtJQUN0QkMsY0FBYyxFQUFJLEtBQUs7SUFDdkJDLFNBQVMsRUFBUyxJQUFJO0lBQ3RCQyxVQUFVLEVBQVEsQ0FBQyxjQUFjLEVBQUUsbUJBQW1CLEVBQUUsc0JBQXNCO0VBQy9FLENBQUM7RUFFRCxJQUFJZSxxQkFBcUIsR0FBRyxFQUFFO0VBRTlCLElBQUliLFVBQVUsR0FBR0MsUUFBUSxDQUFDQyxJQUFJLENBQUNDLEtBQUssQ0FBRSxHQUFJLENBQUM7RUFDM0MsSUFBS0gsVUFBVSxDQUFDSSxNQUFNLEdBQUcsQ0FBQyxFQUFFO0lBQzNCSixVQUFVLEdBQUdBLFVBQVUsQ0FBRSxDQUFDLENBQUUsQ0FBQ0csS0FBSyxDQUFFLEdBQUksQ0FBQztJQUN6QyxLQUFNLElBQUlFLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR0wsVUFBVSxDQUFDSSxNQUFNLEVBQUVDLENBQUMsRUFBRSxFQUFFO01BQzVDLElBQUlDLFNBQVMsR0FBR04sVUFBVSxDQUFFSyxDQUFDLENBQUUsQ0FBQ0YsS0FBSyxDQUFFLEdBQUksQ0FBQztNQUM1QyxJQUFNRyxTQUFTLENBQUUsQ0FBQyxDQUFFLEtBQUssaUNBQWlDLElBQU0sRUFBRSxLQUFLTyxxQkFBc0IsRUFBRTtRQUM5RkEscUJBQXFCLEdBQUdQLFNBQVMsQ0FBRSxDQUFDLENBQUU7TUFDdkM7TUFDQSxJQUFLQSxTQUFTLENBQUUsQ0FBQyxDQUFFLEtBQUssMkJBQTJCLEVBQUU7UUFDcERPLHFCQUFxQixHQUFHUCxTQUFTLENBQUUsQ0FBQyxDQUFFO01BQ3ZDO0lBQ0Q7RUFDRDtFQUNBLElBQU0sRUFBRSxLQUFLTyxxQkFBcUIsSUFBTSxZQUFZLEtBQUtBLHFCQUFzQixFQUFFO0lBQ2hGekMsZUFBZSxDQUFFLGFBQWEsQ0FBRSxHQUFHbUMsTUFBTSxDQUFDQyxRQUFRLENBQUNDLFVBQVUsQ0FDN0N6QixLQUFLLENBQUNDLGVBQWUsQ0FBRSwwQkFBMkIsQ0FBQyxFQUNsRHNCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDRSxTQUFTLENBQUUsVUFBVSxFQUFFRyxxQkFBc0IsQ0FDL0QsQ0FBQztJQUNoQnpDLGVBQWUsQ0FBRSxhQUFhLENBQUUsR0FBRyxJQUFJO0VBQ3hDO0VBRUFtQyxNQUFNLENBQUUsa0NBQW1DLENBQUMsQ0FBQ0MsUUFBUSxDQUFFcEMsZUFBZ0IsQ0FBQztBQUN6RTs7QUFFQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0MsU0FBU0ksMENBQTBDQSxDQUFFc0MsSUFBSSxFQUFFO0VBRTFELElBQUlDLFVBQVUsR0FBRyxJQUFJQyxJQUFJLENBQUVoQyxLQUFLLENBQUNDLGVBQWUsQ0FBRSxXQUFZLENBQUMsQ0FBRSxDQUFDLENBQUUsRUFBR2dDLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLFdBQVksQ0FBQyxDQUFFLENBQUMsQ0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFHRCxLQUFLLENBQUNDLGVBQWUsQ0FBRSxXQUFZLENBQUMsQ0FBRSxDQUFDLENBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUUsQ0FBQyxDQUFDLENBQVE7RUFDaE0sSUFBSWlDLFNBQVMsR0FBR0Msd0JBQXdCLENBQUVMLElBQUssQ0FBQyxDQUFDLENBQWlCOztFQUVsRTtFQUNBLEtBQU0sSUFBSVQsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHckIsS0FBSyxDQUFDQyxlQUFlLENBQUUscUNBQXNDLENBQUMsQ0FBQ21CLE1BQU0sRUFBRUMsQ0FBQyxFQUFFLEVBQUU7SUFDaEcsSUFBS1MsSUFBSSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxJQUFJcEMsS0FBSyxDQUFDQyxlQUFlLENBQUUscUNBQXNDLENBQUMsQ0FBRW9CLENBQUMsQ0FBRSxFQUFFO01BQzFGLE9BQU8sQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHYSxTQUFTLEdBQUcsd0JBQXdCLENBQUM7SUFDbkU7RUFDRDtFQUNBO0VBQ0EsSUFDTUcsd0JBQXdCLENBQUVQLElBQUksRUFBRUMsVUFBVyxDQUFDLEdBQUdFLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLHNDQUF1QyxDQUFFLENBQUMsSUFFekhnQyxRQUFRLENBQUUsR0FBRyxHQUFHQSxRQUFRLENBQUVqQyxLQUFLLENBQUNDLGVBQWUsQ0FBRSxvQ0FBcUMsQ0FBRSxDQUFFLENBQUMsR0FBRyxDQUFDLElBQy9Gb0Msd0JBQXdCLENBQUVQLElBQUksRUFBRUMsVUFBVyxDQUFDLEdBQUdFLFFBQVEsQ0FBRSxHQUFHLEdBQUdBLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLG9DQUFxQyxDQUFFLENBQUUsQ0FDOUksRUFDRDtJQUNBLE9BQU8sQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHaUMsU0FBUyxHQUFHLHdCQUF3QixDQUFDO0VBQ25FOztFQUVBO0VBQ0EsT0FBTyxDQUFDLElBQUksRUFBRSxXQUFXLEdBQUdBLFNBQVMsR0FBRyxrQkFBa0IsQ0FBQztBQUM1RDs7QUFFQTtBQUNEO0FBQ0E7QUFDQTtBQUNDLFNBQVM1Qyw2QkFBNkJBLENBQUV3QyxJQUFJLEVBQUc7RUFFeEM7RUFDQSxJQUFJZixvQkFBb0IsR0FBR1EsTUFBTSxDQUFDQyxRQUFRLENBQUNFLFNBQVMsQ0FBRTFCLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDBCQUEyQixDQUFDLEVBQUdzQixNQUFNLENBQUUsaUNBQWtDLENBQUMsQ0FBQ2UsR0FBRyxDQUFDLENBQUUsQ0FBQztFQUUvSixJQUFJQyxhQUFhLEdBQUcsSUFBSVAsSUFBSSxDQUFDLENBQUM7RUFDOUJPLGFBQWEsQ0FBQ0MsV0FBVyxDQUFFekIsb0JBQW9CLENBQUMwQixXQUFXLENBQUMsQ0FBQyxFQUFFMUIsb0JBQW9CLENBQUMyQixRQUFRLENBQUMsQ0FBQyxFQUFFM0Isb0JBQW9CLENBQUM0QixPQUFPLENBQUMsQ0FBRSxDQUFDO0VBRXRJLElBQUlDLFFBQVE7RUFDWixJQUFJQyxXQUFXO0VBRVQsSUFDQSxPQUFPLElBQUk3QyxLQUFLLENBQUNDLGVBQWUsQ0FBRSw2QkFBOEIsQ0FBQyxJQUM1RCxDQUFDLENBQUMsSUFBSUQsS0FBSyxDQUFDQyxlQUFlLENBQUUsb0NBQXFDLENBQUcsRUFDL0U7SUFFUzJDLFFBQVEsR0FBR0UsaUNBQWlDLENBQUVQLGFBQWEsQ0FBQ0gsTUFBTSxDQUFDLENBQUMsRUFBRXBDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLG9DQUFxQyxDQUFFLENBQUM7SUFDcklzQyxhQUFhLENBQUNRLE9BQU8sQ0FBRVIsYUFBYSxDQUFDSSxPQUFPLENBQUMsQ0FBQyxJQUFJSixhQUFhLENBQUNILE1BQU0sQ0FBQyxDQUFDLEdBQUdRLFFBQVEsQ0FBRSxDQUFDO0lBRXRGQyxXQUFXLEdBQUd0QixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsVUFBVSxDQUFFekIsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUMsRUFBRXNDLGFBQWMsQ0FBQyxDQUFDLENBQVE7O0lBRXZIaEIsTUFBTSxDQUFFLGlDQUFrQyxDQUFDLENBQUNlLEdBQUcsQ0FBRU8sV0FBWSxDQUFDO0VBQ2xFO0VBQ0EsSUFBUzdDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDZCQUE4QixDQUFDLElBQUksU0FBUyxJQUFRRCxLQUFLLENBQUNDLGVBQWUsQ0FBRSxzQ0FBdUMsQ0FBQyxJQUFJLENBQUMsQ0FBRyxFQUFHO0lBRTFKMkMsUUFBUSxHQUFHRSxpQ0FBaUMsQ0FBRVAsYUFBYSxDQUFDSCxNQUFNLENBQUMsQ0FBQyxFQUFFcEMsS0FBSyxDQUFDQyxlQUFlLENBQUUsc0NBQXVDLENBQUUsQ0FBQztJQUN2SXNDLGFBQWEsQ0FBQ1EsT0FBTyxDQUFFUixhQUFhLENBQUNJLE9BQU8sQ0FBQyxDQUFDLElBQUlKLGFBQWEsQ0FBQ0gsTUFBTSxDQUFDLENBQUMsR0FBR1EsUUFBUSxDQUFFLENBQUM7SUFFdEZDLFdBQVcsR0FBR3RCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxVQUFVLENBQUV6QixLQUFLLENBQUNDLGVBQWUsQ0FBRSwwQkFBMkIsQ0FBQyxFQUFFc0MsYUFBYyxDQUFDLENBQUMsQ0FBUTtJQUN2SGhCLE1BQU0sQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDZSxHQUFHLENBQUVPLFdBQVksQ0FBQztFQUNsRTtFQUVBLElBQUtHLFFBQVEsQ0FBQ0MsY0FBYyxDQUFFLGlDQUFrQyxDQUFDLEtBQUssSUFBSSxFQUFFO0lBRXhFLElBQUlDLDBCQUEwQixHQUFHM0IsTUFBTSxDQUFDQyxRQUFRLENBQUNFLFNBQVMsQ0FBRTFCLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDBCQUEyQixDQUFDLEVBQUVzQixNQUFNLENBQUUsaUNBQWtDLENBQUMsQ0FBQ2UsR0FBRyxDQUFDLENBQUUsQ0FBQztJQUNwSyxJQUFJYSxNQUFNLEdBQUcsSUFBSW5CLElBQUksQ0FBQyxDQUFDO0lBQ3ZCbUIsTUFBTSxDQUFDWCxXQUFXLENBQUVVLDBCQUEwQixDQUFDVCxXQUFXLENBQUMsQ0FBQyxFQUFFUywwQkFBMEIsQ0FBQ1IsUUFBUSxDQUFDLENBQUMsRUFBRVEsMEJBQTBCLENBQUNQLE9BQU8sQ0FBQyxDQUFFLENBQUM7SUFFM0ksSUFBSVMsYUFBYSxHQUFHQywyQkFBMkIsQ0FBQyxDQUFDO0lBQ2pELElBQUtELGFBQWEsR0FBRyxDQUFDLEVBQUdBLGFBQWEsRUFBRTtJQUN4Q0QsTUFBTSxDQUFDSixPQUFPLENBQUVJLE1BQU0sQ0FBQ1IsT0FBTyxDQUFDLENBQUMsR0FBR1MsYUFBYyxDQUFDO0lBRWxEUCxXQUFXLEdBQUd0QixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsVUFBVSxDQUFFekIsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUMsRUFBRWtELE1BQU8sQ0FBQyxDQUFDLENBQVE7SUFDaEg1QixNQUFNLENBQUUsa0NBQW1DLENBQUMsQ0FBQ2UsR0FBRyxDQUFFTyxXQUFZLENBQUM7O0lBRS9EO0lBQ0EsSUFBSyxJQUFJLEtBQUs3QyxLQUFLLENBQUNDLGVBQWUsQ0FBRSxnQ0FBaUMsQ0FBQyxFQUFFO01BQ3JFcUQsVUFBVSxDQUFDLFlBQVU7UUFDakIvQixNQUFNLENBQUUsa0NBQW1DLENBQUMsQ0FBQ2dDLE9BQU8sQ0FBRSxPQUFRLENBQUM7TUFDbkUsQ0FBQyxFQUFFLEdBQUcsQ0FBQztJQUNYO0VBQ0o7QUFDSjs7QUFFSDtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0ksU0FBUzNCLDJDQUEyQ0EsQ0FBQ0UsSUFBSSxFQUFDO0VBRTVELElBQUlDLFVBQVUsR0FBRyxJQUFJQyxJQUFJLENBQUVoQyxLQUFLLENBQUNDLGVBQWUsQ0FBRSxXQUFZLENBQUMsQ0FBRSxDQUFDLENBQUUsRUFBR2dDLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLFdBQVksQ0FBQyxDQUFFLENBQUMsQ0FBRyxDQUFDLEdBQUcsQ0FBQyxFQUFHRCxLQUFLLENBQUNDLGVBQWUsQ0FBRSxXQUFZLENBQUMsQ0FBRSxDQUFDLENBQUUsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUUsQ0FBQyxDQUFDLENBQVE7RUFDaE0sSUFBSWlDLFNBQVMsR0FBR0Msd0JBQXdCLENBQUVMLElBQUssQ0FBQyxDQUFDLENBQWlCOztFQUVsRTtFQUNBLEtBQU0sSUFBSVQsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHckIsS0FBSyxDQUFDQyxlQUFlLENBQUUscUNBQXNDLENBQUMsQ0FBQ21CLE1BQU0sRUFBRUMsQ0FBQyxFQUFFLEVBQUU7SUFDaEcsSUFBS1MsSUFBSSxDQUFDTSxNQUFNLENBQUMsQ0FBQyxJQUFJcEMsS0FBSyxDQUFDQyxlQUFlLENBQUUscUNBQXNDLENBQUMsQ0FBRW9CLENBQUMsQ0FBRSxFQUFFO01BQzFGLE9BQU8sQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHYSxTQUFTLEdBQUcsd0JBQXdCLENBQUM7SUFDbkU7RUFDRDtFQUNBO0VBQ0EsSUFDTUcsd0JBQXdCLENBQUVQLElBQUksRUFBRUMsVUFBVyxDQUFDLEdBQUdFLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLHNDQUF1QyxDQUFFLENBQUMsSUFFekhnQyxRQUFRLENBQUUsR0FBRyxHQUFHQSxRQUFRLENBQUVqQyxLQUFLLENBQUNDLGVBQWUsQ0FBRSxvQ0FBcUMsQ0FBRSxDQUFFLENBQUMsR0FBRyxDQUFDLElBQy9Gb0Msd0JBQXdCLENBQUVQLElBQUksRUFBRUMsVUFBVyxDQUFDLEdBQUdFLFFBQVEsQ0FBRSxHQUFHLEdBQUdBLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLG9DQUFxQyxDQUFFLENBQUUsQ0FDOUksRUFDRDtJQUNBLE9BQU8sQ0FBQyxLQUFLLEVBQUUsV0FBVyxHQUFHaUMsU0FBUyxHQUFHLHdCQUF3QixDQUFDO0VBQ25FO0VBQ0E7O0VBRUEsSUFBSXNCLGdCQUFnQixHQUFHLGlCQUFpQjtFQUNsQyxJQUNTUixRQUFRLENBQUNDLGNBQWMsQ0FBRSxnQ0FBaUMsQ0FBQyxJQUFJLElBQUksSUFDbkVELFFBQVEsQ0FBQ0MsY0FBYyxDQUFFLGdDQUFpQyxDQUFDLENBQUNRLEtBQUssSUFBSSxFQUFJLEVBQ2pGO0lBRU47SUFDQSxJQUFJQyxXQUFXLEdBQUduQyxNQUFNLENBQUNDLFFBQVEsQ0FBQ0UsU0FBUyxDQUFFMUIsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUMsRUFBRXNCLE1BQU0sQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDZSxHQUFHLENBQUMsQ0FBRSxDQUFDO0lBRXJKLElBQUljLGFBQWEsR0FBR0MsMkJBQTJCLENBQUMsQ0FBQztJQUNqRCxJQUFLRCxhQUFhLEdBQUcsQ0FBQyxFQUFHQSxhQUFhLEVBQUU7SUFDeENNLFdBQVcsQ0FBQ1gsT0FBTyxDQUFFVyxXQUFXLENBQUNmLE9BQU8sQ0FBQyxDQUFDLEdBQUdTLGFBQWMsQ0FBQztJQUU1RCxJQUFJTyxZQUFZLEdBQUdwQyxNQUFNLENBQUNDLFFBQVEsQ0FBQ0UsU0FBUyxDQUFFMUIsS0FBSyxDQUFDQyxlQUFlLENBQUUsMEJBQTJCLENBQUMsRUFBRXNCLE1BQU0sQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDZSxHQUFHLENBQUMsQ0FBRSxDQUFDO0lBQ3RKLElBQUlzQixpQkFBaUIsR0FBR0MsMkJBQTJCLENBQUMsQ0FBQztJQUNyRCxJQUFLRCxpQkFBaUIsR0FBRyxDQUFDLEVBQUdBLGlCQUFpQixFQUFFO0lBQ2hERCxZQUFZLENBQUNaLE9BQU8sQ0FBRVksWUFBWSxDQUFDaEIsT0FBTyxDQUFDLENBQUMsR0FBR2lCLGlCQUFrQixDQUFDO0lBRWxFLElBQU1GLFdBQVcsSUFBSTVCLElBQUksSUFBTTZCLFlBQVksSUFBSTdCLElBQUssRUFBRTtNQUNyRCxPQUFPLENBQUMsSUFBSSxFQUFFLFdBQVcsR0FBR0ksU0FBUyxHQUFHLEdBQUcsR0FBR3NCLGdCQUFnQixHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUM7SUFDeEUsQ0FBQyxNQUFNO01BQ04sT0FBTyxDQUFDLEtBQUssRUFBRSxXQUFXLEdBQUd0QixTQUFTLEdBQUcsd0JBQXdCLENBQUMsQ0FBQyxDQUFVO0lBQzlFO0VBRUssQ0FBQyxNQUFNO0lBQ0gsT0FBTyxDQUFDLElBQUksRUFBRSxXQUFXLEdBQUdBLFNBQVMsR0FBRyxHQUFHLEdBQUdzQixnQkFBZ0IsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFNO0VBQ2hGO0FBQ0o7O0FBRUY7QUFDRjtBQUNBO0FBQ0E7QUFDRSxTQUFTSCwyQkFBMkJBLENBQUEsRUFBRTtFQUFvQjs7RUFFekQsSUFBSyxTQUFTLEtBQUtyRCxLQUFLLENBQUNDLGVBQWUsQ0FBRSw2QkFBOEIsQ0FBQyxFQUFFO0lBQzFFLE9BQU9nQyxRQUFRLENBQUVqQyxLQUFLLENBQUNDLGVBQWUsQ0FBRSw4QkFBK0IsQ0FBRSxDQUFDO0VBQzNFO0VBQ0EsSUFBSyxPQUFPLEtBQUtELEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDZCQUE4QixDQUFDLEVBQUU7SUFDeEUsT0FBT2dDLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDRCQUE2QixDQUFFLENBQUM7RUFDekU7RUFDQSxPQUFPLENBQUM7QUFDVDs7QUFFQTtBQUNGO0FBQ0E7QUFDQTtBQUNFLFNBQVM0RCwyQkFBMkJBLENBQUEsRUFBRTtFQUFvQjtFQUN6RCxJQUFLLFNBQVMsS0FBSzdELEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDZCQUE4QixDQUFDLEVBQUU7SUFDMUUsT0FBT2dDLFFBQVEsQ0FBRWpDLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDhCQUErQixDQUFFLENBQUM7RUFDM0U7RUFDQSxJQUFLLE9BQU8sS0FBS0QsS0FBSyxDQUFDQyxlQUFlLENBQUUsNkJBQThCLENBQUMsRUFBRTtJQUN4RSxPQUFPZ0MsUUFBUSxDQUFFakMsS0FBSyxDQUFDQyxlQUFlLENBQUUsNEJBQTZCLENBQUUsQ0FBQztFQUN6RTtFQUNBLE9BQU8sR0FBRztBQUNYOztBQUVGOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzZELG9FQUFvRUEsQ0FBQSxFQUFFO0VBRTlFLElBQUk5QyxVQUFVLEdBQUcsSUFBSStDLGVBQWUsQ0FBRUMsTUFBTSxDQUFDL0MsUUFBUSxDQUFDZ0QsTUFBTyxDQUFDO0VBRTlELElBQ0dqRCxVQUFVLENBQUNrRCxHQUFHLENBQUUsMkJBQTRCLENBQUMsRUFDL0M7SUFFQSxJQUFJQyx5QkFBeUIsR0FBSW5ELFVBQVUsQ0FBQ29ELEdBQUcsQ0FBRSwyQkFBNEIsQ0FBQzs7SUFFOUU7SUFDQUQseUJBQXlCLEdBQUdBLHlCQUF5QixDQUFDRSxVQUFVLENBQUUsS0FBSyxFQUFFLEdBQUksQ0FBQztJQUU5RSxJQUFJQyxpQkFBaUIsR0FBR0MsbUNBQW1DLENBQUVKLHlCQUEwQixDQUFDO0lBRXhGLEtBQU0sSUFBSTlDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2lELGlCQUFpQixDQUFDbEQsTUFBTSxFQUFFQyxDQUFDLEVBQUUsRUFBRTtNQUVuRCxJQUNLbUQsYUFBYSxDQUFFLENBQUMsTUFBTSxFQUFFLFlBQVksRUFBQyxlQUFlLEVBQUUsaUJBQWlCLEVBQUMsb0JBQW9CLEVBQUUsT0FBTyxFQUFFLFVBQVUsQ0FBQyxFQUFJRixpQkFBaUIsQ0FBRWpELENBQUMsQ0FBRSxDQUFFLE1BQU0sQ0FBRyxDQUFDLElBQ3ZKLENBQUVtRCxhQUFhLENBQUUsQ0FBQyxnQ0FBZ0MsRUFBRSxpQ0FBaUMsRUFBRSxzQkFBdUIsa0NBQWtDLENBQUUsRUFBR0YsaUJBQWlCLENBQUVqRCxDQUFDLENBQUUsQ0FBQyxNQUFNLENBQUUsQ0FBRyxFQUM1TDtRQUNBLElBQUlvRCxZQUFZLEdBQUtILGlCQUFpQixDQUFFakQsQ0FBQyxDQUFFLENBQUMsTUFBTSxDQUFDO1FBQ25ELElBQUlxRCxhQUFhLEdBQUlKLGlCQUFpQixDQUFFakQsQ0FBQyxDQUFFLENBQUMsT0FBTyxDQUFDO1FBRXBERSxNQUFNLENBQUUsU0FBUyxHQUFHa0QsWUFBWSxHQUFHLElBQUssQ0FBQyxDQUFDbkMsR0FBRyxDQUFFb0MsYUFBYyxDQUFDLENBQUNuQixPQUFPLENBQUUsUUFBUyxDQUFDO01BQ25GO0lBQ0Q7RUFDRDtFQUVBdkMsVUFBVSxDQUFDMkQsT0FBTyxDQUFFLENBQUVsQixLQUFLLEVBQUVtQixHQUFHLEtBQU07SUFDckMsSUFBS0EsR0FBRyxDQUFDQyxVQUFVLENBQUUsVUFBVyxDQUFDLEVBQUU7TUFDbEN0RCxNQUFNLENBQUUsU0FBUyxHQUFHcUQsR0FBRyxHQUFHLElBQUssQ0FBQyxDQUFDdEMsR0FBRyxDQUFFbUIsS0FBTSxDQUFDLENBQUNGLE9BQU8sQ0FBRSxRQUFTLENBQUM7SUFDbEU7RUFDRCxDQUFFLENBQUM7QUFDSjs7QUFFQTtBQUNBaEMsTUFBTSxDQUFFLG9CQUFxQixDQUFDLENBQUN1RCxFQUFFLENBQUUsT0FBTyxFQUFFLFVBQVdDLEtBQUssRUFBRTtFQUM3RHhELE1BQU0sQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDZ0MsT0FBTyxDQUFFLE9BQVEsQ0FBQztBQUMvRCxDQUFDLENBQUM7QUFDRmhDLE1BQU0sQ0FBRSxxQkFBc0IsQ0FBQyxDQUFDdUQsRUFBRSxDQUFFLE9BQU8sRUFBRSxVQUFXQyxLQUFLLEVBQUU7RUFDOUR4RCxNQUFNLENBQUUsa0NBQW1DLENBQUMsQ0FBQ2dDLE9BQU8sQ0FBRSxPQUFRLENBQUM7QUFDaEUsQ0FBQyxDQUFDOztBQUdGO0FBQ0E7QUFDQTtBQUNBLFNBQVN5Qix1Q0FBdUNBLENBQUEsRUFBRTtFQUVqRDtFQUNBO0VBQ0F6RCxNQUFNLENBQUUsc0NBQXVDLENBQUMsQ0FBQzBELElBQUksQ0FBRSxvQkFBb0IsRUFBRTFELE1BQU0sQ0FBRSxzQ0FBdUMsQ0FBQyxDQUFDMkQsR0FBRyxDQUFFLE9BQVEsQ0FBRSxDQUFDO0VBQzlJM0QsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUMyRCxHQUFHLENBQUUsT0FBTyxFQUFFLE1BQU8sQ0FBQztFQUN2RTNELE1BQU0sQ0FBRSxzQ0FBdUMsQ0FBQyxDQUFDMkQsR0FBRyxDQUFFLFFBQVEsRUFBRSxhQUFjLENBQUM7QUFDaEY7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsU0FBU0Msc0NBQXNDQSxDQUFBLEVBQUU7RUFFaEQ7RUFDQTVELE1BQU0sQ0FBRSxzQ0FBdUMsQ0FBQyxDQUFDNkQsSUFBSSxDQUFFLFVBQVUsRUFBRSxLQUFNLENBQUM7RUFDMUUsSUFBS0MsU0FBUyxJQUFJOUQsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUMwRCxJQUFJLENBQUUsb0JBQXFCLENBQUMsRUFBRTtJQUFNO0lBQ3RHMUQsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUMyRCxHQUFHLENBQUUsT0FBTyxFQUFFM0QsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUMwRCxJQUFJLENBQUUsb0JBQXFCLENBQUUsQ0FBQztFQUMvSTtFQUNBMUQsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUMyRCxHQUFHLENBQUUsUUFBUSxFQUFFLFNBQVUsQ0FBQztBQUM1RTs7QUFHQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTSSwyQ0FBMkNBLENBQUVDLFdBQVcsRUFBRTtFQUFhOztFQUUvRSxJQUFJQyxXQUFXLEdBQUcsRUFBRTtFQUNwQixJQUFJQyxNQUFNO0VBQ1YsSUFBSUMsT0FBTztFQUVYLEtBQU0sSUFBSXJFLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2tFLFdBQVcsQ0FBQ25FLE1BQU0sRUFBRUMsQ0FBQyxFQUFFLEVBQUU7SUFFN0MsSUFBTWtFLFdBQVcsQ0FBRWxFLENBQUMsQ0FBRSxDQUFDc0UsSUFBSSxJQUFJLFVBQVUsSUFBTSxDQUFDSixXQUFXLENBQUVsRSxDQUFDLENBQUUsQ0FBQ3VFLE9BQVEsRUFBRTtNQUMxRTtJQUNEO0lBRUFILE1BQU0sR0FBR0YsV0FBVyxDQUFFbEUsQ0FBQyxDQUFFLENBQUNzRSxJQUFJLEdBQUcsR0FBRyxHQUFHSixXQUFXLENBQUVsRSxDQUFDLENBQUUsQ0FBQ3dFLElBQUksR0FBRyxHQUFHO0lBRWxFSCxPQUFPLEdBQUduRSxNQUFNLENBQUVnRSxXQUFXLENBQUVsRSxDQUFDLENBQUcsQ0FBQyxDQUFDaUIsR0FBRyxDQUFDLENBQUM7SUFFMUMsSUFBS3dELEtBQUssQ0FBQ0MsT0FBTyxDQUFFTCxPQUFRLENBQUMsRUFBRTtNQUM5Qm5FLE1BQU0sQ0FBQ3lFLElBQUksQ0FBRU4sT0FBTyxFQUFFLFVBQVdPLEtBQUssRUFBRTtRQUN2Q1QsV0FBVyxJQUFJQyxNQUFNLEdBQUdDLE9BQU8sQ0FBRU8sS0FBSyxDQUFFLEdBQUcsR0FBRztNQUMvQyxDQUFFLENBQUM7SUFDSixDQUFDLE1BQU07TUFDTlQsV0FBVyxJQUFJQyxNQUFNLEdBQUdDLE9BQU8sR0FBRyxHQUFHO0lBQ3RDO0VBQ0Q7RUFFQSxPQUFPRixXQUFXO0FBQ25COztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTVSxnREFBZ0RBLENBQUVDLE9BQU8sRUFBRTtFQUVuRSxJQUFJQyxtQkFBbUIsR0FBRyxFQUFFO0VBQzVCLElBQUs3RSxNQUFNLENBQUU0RSxPQUFRLENBQUMsQ0FBQy9FLE1BQU0sRUFBRTtJQUM5QmdGLG1CQUFtQixHQUFHN0UsTUFBTSxDQUFFNEUsT0FBUSxDQUFDLENBQUM3RCxHQUFHLENBQUMsQ0FBQztFQUM5Qzs7RUFFQTtFQUNBLElBQUkrRCxjQUFjLEdBQUcsSUFBSXJFLElBQUksQ0FBRSxZQUFhLENBQUM7O0VBRTdDO0VBQ0EsSUFBSyxFQUFFLEtBQUtvRSxtQkFBbUIsRUFBRTtJQUVoQ0MsY0FBYyxHQUFHOUUsTUFBTSxDQUFDQyxRQUFRLENBQUNFLFNBQVMsQ0FBRTFCLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDBCQUEyQixDQUFDLEVBQUVtRyxtQkFBb0IsQ0FBQzs7SUFFdEg7SUFDQSxJQUFJRSxrQkFBa0IsR0FBRy9FLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxVQUFVLENBQUUsVUFBVSxFQUFFNEUsY0FBZSxDQUFDO0lBRWpGLE9BQU9DLGtCQUFrQjtFQUUxQixDQUFDLE1BQU07SUFDTixPQUFPLFlBQVksQ0FBQyxDQUFLO0VBQzFCO0FBQ0Q7O0FBR0E7QUFDQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsK0JBQStCQSxDQUFFaEIsV0FBVyxFQUFFaUIsbUJBQW1CLEVBQUU7RUFBaUI7O0VBRTVGLElBQUssS0FBSyxJQUFJeEcsS0FBSyxDQUFDQyxlQUFlLENBQUUsNkNBQThDLENBQUMsRUFBRTtJQUNyRixJQUFNLEVBQUUsSUFBSXNCLE1BQU0sQ0FBRSxpQ0FBa0MsQ0FBQyxDQUFDZSxHQUFHLENBQUMsQ0FBQyxJQUFNLEVBQUUsSUFBSWYsTUFBTSxDQUFFLGtDQUFtQyxDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFFLEVBQUU7TUFDN0htRSxLQUFLLENBQUV6RyxLQUFLLENBQUNDLGVBQWUsQ0FBRSw2Q0FBOEMsQ0FBRSxDQUFDO01BQy9FLE9BQU8sS0FBSztJQUNiO0VBQ0Q7RUFDQStFLHVDQUF1QyxDQUFDLENBQUM7O0VBRXpDO0VBQ0E7RUFDQTtFQUNBLElBQUkwQixtQkFBbUIsR0FBR1IsZ0RBQWdELENBQUUsaUNBQWtDLENBQUMsQ0FBQyxDQUFHO0VBQ25IM0UsTUFBTSxDQUFFLG1DQUFvQyxDQUFDLENBQUNlLEdBQUcsQ0FBRW9FLG1CQUFvQixDQUFDLENBQUMsQ0FBVztFQUNwRjtFQUNBLElBQUlDLG9CQUFvQixHQUFHVCxnREFBZ0QsQ0FBRSxrQ0FBbUMsQ0FBQztFQUNqSDNFLE1BQU0sQ0FBRSxvQ0FBcUMsQ0FBQyxDQUFDZSxHQUFHLENBQUVxRSxvQkFBcUIsQ0FBQyxDQUFDLENBQVM7RUFDcEY7RUFDQSxJQUFJQyxzQkFBc0IsR0FBSXJGLE1BQU0sQ0FBRSwwQkFBMkIsQ0FBQyxDQUFDSCxNQUFNLEdBQUcsQ0FBQyxHQUNwRUcsTUFBTSxDQUFFLDBCQUEyQixDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFDLEdBQzFDLENBQUM7RUFDVmYsTUFBTSxDQUFFLCtCQUFnQyxDQUFDLENBQUNlLEdBQUcsQ0FBRXNFLHNCQUF1QixDQUFDO0VBQ3ZFLElBQUlDLGtCQUFrQixHQUFJdEYsTUFBTSxDQUFFLHNCQUF1QixDQUFDLENBQUNILE1BQU0sR0FBRyxDQUFDLEdBQzVERyxNQUFNLENBQUUsc0JBQXVCLENBQUMsQ0FBQ2UsR0FBRyxDQUFDLENBQUMsR0FDdEMsRUFBRTtFQUNYZixNQUFNLENBQUUsMkJBQTRCLENBQUMsQ0FBQ2UsR0FBRyxDQUFFdUUsa0JBQW1CLENBQUM7RUFDL0Q7RUFDQSxJQUFJQyxlQUFlLEdBQUl2RixNQUFNLENBQUUseUJBQTBCLENBQUMsQ0FBQ0gsTUFBTSxHQUN0REcsTUFBTSxDQUFFLHlCQUEwQixDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFDLEdBQ3pDLEVBQUU7RUFDYmYsTUFBTSxDQUFFLCtCQUFnQyxDQUFDLENBQUNlLEdBQUcsQ0FBRXdFLGVBQWdCLENBQUM7RUFDaEU7RUFDQSxJQUFJQyxvQkFBb0IsR0FBSXhGLE1BQU0sQ0FBRSx3REFBeUQsQ0FBQyxDQUFDSCxNQUFNLEdBQUcsQ0FBQyxHQUNoR0csTUFBTSxDQUFFLGdEQUFpRCxDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFDLEdBQ2hFLENBQUM7RUFDVmYsTUFBTSxDQUFFLDZCQUE4QixDQUFDLENBQUNlLEdBQUcsQ0FBRXlFLG9CQUFxQixDQUFDO0VBQ25FO0VBQ0E7RUFDQSxJQUFJQyxpQkFBaUIsR0FBRzFCLDJDQUEyQyxDQUFFQyxXQUFZLENBQUM7RUFDbEZ5QixpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUMzQyxVQUFVLENBQUUsR0FBRyxFQUFFLEtBQU0sQ0FBQyxDQUFDLENBQUU7O0VBRWpFOUMsTUFBTSxDQUFFLG9DQUFxQyxDQUFDLENBQUNlLEdBQUcsQ0FBRTBFLGlCQUFrQixDQUFDLENBQUMsQ0FBYTtFQUNyRjs7RUFFQSxPQUFRLElBQUk7QUFDYjs7QUFHQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsMkJBQTJCQSxDQUFFMUIsV0FBVyxFQUFFMkIsbUJBQW1CLEVBQUU7RUFFdkUsSUFBSyxLQUFLLElBQUlsSCxLQUFLLENBQUNDLGVBQWUsQ0FBRSw2Q0FBOEMsQ0FBQyxFQUFFO0lBQ3JGLElBQU0sRUFBRSxLQUFLc0IsTUFBTSxDQUFFLGlDQUFrQyxDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFDLElBQU0sRUFBRSxLQUFLZixNQUFNLENBQUUsa0NBQW1DLENBQUMsQ0FBQ2UsR0FBRyxDQUFDLENBQUUsRUFBRTtNQUMvSG1FLEtBQUssQ0FBRXpHLEtBQUssQ0FBQ0MsZUFBZSxDQUFFLDZDQUE4QyxDQUFFLENBQUM7TUFDL0UsT0FBTyxLQUFLO0lBQ2I7RUFDRDs7RUFFQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTs7RUFFQTtFQUNBc0IsTUFBTSxDQUFFLHlCQUEwQixDQUFDLENBQUM0RixJQUFJLENBQUUseUxBQTBMLENBQUM7RUFFck9DLHVCQUF1QixDQUFFN0IsV0FBVyxFQUFFMkIsbUJBQW9CLENBQUM7QUFDNUQ7O0FBR0M7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0ksU0FBU0UsdUJBQXVCQSxDQUFFN0IsV0FBVyxFQUFFaUIsbUJBQW1CLEVBQUc7RUFBYTs7RUFFcEY7RUFDQXhCLHVDQUF1QyxDQUFDLENBQUMsQ0FBQyxDQUFVO0VBQzlDekQsTUFBTSxDQUFFLHNDQUF1QyxDQUFDLENBQUM2RCxJQUFJLENBQUUsVUFBVSxFQUFFLElBQUssQ0FBQzs7RUFFL0U7RUFDQTdELE1BQU0sQ0FBRSxnQ0FBaUMsQ0FBQyxDQUFDOEYsTUFBTSxDQUFDLENBQUM7O0VBRW5EO0VBQ0E7RUFDQTs7RUFFQTtFQUNBLElBQUlMLGlCQUFpQixHQUFNMUIsMkNBQTJDLENBQUVDLFdBQVksQ0FBQztFQUVyRixJQUFJbUIsbUJBQW1CLEdBQUlSLGdEQUFnRCxDQUFFLGlDQUFrQyxDQUFDLENBQUMsQ0FBRTtFQUNuSCxJQUFJUyxvQkFBb0IsR0FBR1QsZ0RBQWdELENBQUUsa0NBQW1DLENBQUM7RUFFakgsSUFBSVksZUFBZSxHQUFJdkYsTUFBTSxDQUFFLHlCQUEwQixDQUFDLENBQUNILE1BQU0sR0FDdERHLE1BQU0sQ0FBRSx5QkFBMEIsQ0FBQyxDQUFDZSxHQUFHLENBQUMsQ0FBQyxHQUN6QyxFQUFFO0VBQ2IsSUFBSXlFLG9CQUFvQixHQUFJeEYsTUFBTSxDQUFFLHdEQUF5RCxDQUFDLENBQUNILE1BQU0sR0FBRyxDQUFDLEdBQ2hHRyxNQUFNLENBQUUsZ0RBQWlELENBQUMsQ0FBQ2UsR0FBRyxDQUFDLENBQUMsR0FDaEUsQ0FBQztFQUNWLElBQUlzRSxzQkFBc0IsR0FBSXJGLE1BQU0sQ0FBRSwwQkFBMkIsQ0FBQyxDQUFDSCxNQUFNLEdBQUcsQ0FBQyxHQUNwRUcsTUFBTSxDQUFFLDBCQUEyQixDQUFDLENBQUNlLEdBQUcsQ0FBQyxDQUFDLEdBQzFDLENBQUM7RUFDVixJQUFJdUUsa0JBQWtCLEdBQUl0RixNQUFNLENBQUUsc0JBQXVCLENBQUMsQ0FBQ0gsTUFBTSxHQUFHLENBQUMsR0FDNURHLE1BQU0sQ0FBRSxzQkFBdUIsQ0FBQyxDQUFDZSxHQUFHLENBQUMsQ0FBQyxHQUN0QyxFQUFFO0VBQ1g7RUFDQWYsTUFBTSxDQUFDK0YsSUFBSSxDQUFDO0lBQ1hDLEdBQUcsRUFBTUMsYUFBYTtJQUN0QjdCLElBQUksRUFBSSxNQUFNO0lBQ2Q4QixPQUFPLEVBQUUsU0FBQUEsQ0FBV0MsSUFBSSxFQUFFQyxVQUFVLEVBQUU7TUFDckMsSUFBS0EsVUFBVSxJQUFJLFNBQVMsRUFBRTtRQUU3QixJQUNPLFdBQVcsS0FBSyxPQUFRRCxJQUFLLElBQzFCLFdBQVcsS0FBSyxPQUFRQSxJQUFJLENBQUNFLHVCQUEwQixFQUNoRTtVQUNBckcsTUFBTSxDQUFFLHlCQUEwQixDQUFDLENBQUM0RixJQUFJLENBQUVPLElBQUksQ0FBQ0UsdUJBQXdCLENBQUMsQ0FBQztVQUN6RTtVQUNBO1VBQ0E7UUFDRCxDQUFDLE1BQU07VUFDTkMsT0FBTyxDQUFDQyxHQUFHLENBQUUsK0JBQStCLEVBQUVKLElBQUssQ0FBQztVQUNwRCxJQUFJSyxPQUFPLEdBQUd4RyxNQUFNLENBQUUseUJBQTBCLENBQUM7VUFDakQ7VUFDQXlHLDRCQUE0QixDQUFFLG1DQUFtQyxHQUFHQyxJQUFJLENBQUNDLFNBQVMsQ0FBRVIsSUFBSyxDQUFDLENBQUNTLE9BQU8sQ0FBRSxLQUFLLEVBQUUsUUFBUyxDQUFDLEVBQzdHO1lBQUksTUFBTSxFQUFPLFNBQVM7WUFDekIsV0FBVyxFQUFFO2NBQUMsU0FBUyxFQUFFSixPQUFPO2NBQUUsT0FBTyxFQUFFO1lBQU8sQ0FBQztZQUNuRCxXQUFXLEVBQUUsSUFBSTtZQUNqQixPQUFPLEVBQU0sa0JBQWtCO1lBQy9CLE9BQU8sRUFBTTtVQUNkLENBQUUsQ0FBQztVQUNYeEcsTUFBTSxDQUFFLHdEQUF3RCxDQUFDLENBQUM4RixNQUFNLENBQUMsQ0FBQztRQUMzRTtRQUNBbEMsc0NBQXNDLENBQUMsQ0FBQztNQUN6QztJQUNELENBQUM7SUFDRGlELEtBQUssRUFBRSxTQUFBQSxDQUFXQyxjQUFjLEVBQUVWLFVBQVUsRUFBRVcsV0FBVyxFQUFFO01BQUVULE9BQU8sQ0FBQ0MsR0FBRyxDQUFHLHlDQUF5QyxHQUFHSCxVQUFVLEVBQUdVLGNBQWUsQ0FBQztNQUFFNUIsS0FBSyxDQUFFNEIsY0FBYyxDQUFDRSxNQUFNLEdBQUcsR0FBRyxHQUFHRixjQUFjLENBQUNHLFVBQVcsQ0FBQztNQUFFLElBQUtILGNBQWMsQ0FBQ0UsTUFBTSxJQUFJLEdBQUcsRUFBRTtRQUFHOUIsS0FBSyxDQUFFLGlEQUFpRCxHQUFHLHdEQUF5RCxDQUFDO01BQUc7SUFBRSxDQUFDO0lBQ3pYaUIsSUFBSSxFQUFFO01BQ0xlLE1BQU0sRUFBc0IsZ0JBQWdCO01BRTVDQyx3QkFBd0IsRUFBSWhDLG1CQUFtQjtNQUMvQ2lDLHlCQUF5QixFQUFHaEMsb0JBQW9CO01BQ2hEaUMsb0JBQW9CLEVBQVFoQyxzQkFBc0I7TUFDbERpQyxnQkFBZ0IsRUFBV2hDLGtCQUFrQjtNQUU3Q2lDLHlCQUF5QixFQUFHOUIsaUJBQWlCO01BQzdDK0Isa0JBQWtCLEVBQVVoQyxvQkFBb0I7TUFDaERpQyxvQkFBb0IsRUFBUWxDLGVBQWU7TUFFM0NJLG1CQUFtQixFQUFTVixtQkFBbUI7TUFDL0N5QyxVQUFVLEVBQWtCakcsUUFBUSxDQUFDQyxjQUFjLENBQUUsbUJBQW9CLENBQUMsQ0FBQ1E7SUFDNUU7RUFDRCxDQUFDLENBQUM7QUFDSCIsImlnbm9yZUxpc3QiOltdfQ==
