<?php
/**
 * @version 1.0
 * @package WP Booking Calendar > Resources > Search Options page
 * @category Settings Resource page
 * @author wpdevelop
 *
 * @web-site https://wpbookingcalendar.com/
 * @email info@wpbookingcalendar.com
 *
 * @modified 2024-04-02
 *
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

// FixIn: 10.0.0.18.

/**
 *  Show Content
 *  Update Content
 *  Define Slug
 *  Define where to show
 */
class WPBC_Page_Settings__searchable_resources extends WPBC_Page_Structure {

    const SUBMIT_FORM = 'wpbc_searchable_resources';                                   // Main Form Name

	/**
	 * Array of all searchable options from 		get_bk_option( 'booking_resources_search_options' );
	 * Example: [
	 *										 220 = [
	 *												  is_searchable = "On"
	 *												  url = "http://beta/booking-calendar-custom-days-selection/"
	 *												  title = "[:en]Eng booking resource #13 test  languages[:fr]France booking resource #13 test  languages[:]"
	 *												  description = "Bla Bla ...."
	 *												  picture = "https://serer.com/..image.png"
	 *												  options = "pets^=^yes~tv^contain^sony~tv^&gt;^40~max_visitors^&lt;=^3"
	 *      												  category = [  [category = "Uncategorized", slug = "uncategorized-en", ID = {int} 31], ... ]       // Deprecated
	 *		        										  tags = {array[0]}                                                                                 // Deprecated
	 *										 2 = [ ... ]
	 *                                  ]
	 */
	private $search_options_arr;

    public function in_page() {
        return 'wpbc-resources';
    }

    public function tabs() {

        $tabs = array();

		$tabs['searchable_resources'] = array(
			'title'      => __( 'Search Availability', 'booking' ),         // . '<span class="wpbc_new_label" style="position:absolute;margin:-5px 0 0 5px;">New</span>&nbsp;' // Title of TAB.
			'hint'       => __( 'Searchable Resource Setup', 'booking' ),   // Hint.
			'page_title' => __( 'Searchable Resource Setup', 'booking' ),   // Title of Page.
			// 'link'      => '',                               // Can be skiped,  then generated link based on Page and Tab tags. Or can  be extenral link.
			// 'css_classes'=> '',                              // CSS class(es).
			'font_icon'  => 'wpbc_icn_search',                  // CSS definition  of forn Icon.
			'default'    => false,                              // Is this tab activated by default or not: true || false. //FixIn: 9.8.15.2.4.
			'hided'      => false,
			'subtabs'    => array(),
		);

		$subtabs['searchable_resources_options'] = array(
			  'is_show_top_path'                   => true,                                  // true | false.  By default value is: false.
			  'left_navigation__default_view_mode' => 'compact',                             // '' | 'min' | 'compact' | 'max' | 'none'.  By default value is: ''.
			'type'            => 'subtab',                                        // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'.
			'title'           => __( 'Searchable Resources', 'booking' ),
			'page_title'      => __( 'Searchable Resource Setup', 'booking' ),    // Title of Page.
			'hint'            => __( 'Define which booking resources can appear in search results.', 'booking' ),
			'link'            => '',
			'css_classes'     => '',
			'font_icon'       => 'wpbc-bi-files',
			'font_icon_right' => 'wpbc-bi-question-circle',
			'default'         => true,                                            // Is this sub tab activated by default or not: true || false.
			'content'         => 'content',
		);

        $tabs[ 'searchable_resources' ]['subtabs'] = $subtabs;
        return $tabs;
    }

    /** Show Content of Settings page */
    public function content() {

        // Checking
        do_action( 'wpbc_hook_settings_page_header', 'searchable_resources');              	// Define Notices Section and show some static messages, if needed

        if ( ! wpbc_is_mu_user_can_be_here('activated_user') ) 		return false;    		// Check if MU user activated, otherwise show Warning message.
        // if ( ! wpbc_is_mu_user_can_be_here('only_super_admin') ) return false;  			// User is not Super admin, so exit.  Basically its was already checked at the bottom of the PHP file, just in case.


		// Make reimport, if the old Cache Search still exist, if it does not exist, then it do nothing. //TODO: maybe comment it ?
		// wpbc_searchable_resources__import_in_version_10();

        //  S u b m i t   Main Form
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
        if ( isset( $_POST['is_form_sbmitted_'. self::SUBMIT_FORM ] ) ) {
																						// Nonce checking    {Return false if invalid, 1 if generated between, 0-12 hours ago, 2 if generated between 12-24 hours ago. }
            $nonce_gen_time = check_admin_referer( 'wpbc_settings_page_' . self::SUBMIT_FORM );  						// It stops show anything on submitting, if it not refers to the original page

            $this->update();															// Save Changes
        }

		?><div class="clear" style="height:20px;"></div><?php

        echo '<span class="wpdevelop">';

			// JavaScript: Tooltips, Popover, Datepick (js & css)
			wpbc_js_for_bookings_page();

			// Toolbar
			wpbc_searchable_resources_page__toolbar();

        echo '</span>';

	    do_action( 'wpbc_hook_settings_page_before_content_table', 'searchable_resources' );      							// Define Notices Section and show some static messages, if needed

        // -------------------------------------------------------------------------------------------------------------
        // Content		of		Main Form		Resource Table
		// -------------------------------------------------------------------------------------------------------------
        ?><div class="clear" ></div><?php

		?><span class="metabox-holder"><?php

            ?><form  name="<?php echo esc_attr( self::SUBMIT_FORM); ?>" id="<?php echo esc_attr( self::SUBMIT_FORM); ?>" action="" method="post" autocomplete="off"><?php

			   // N o n c e   field, and key for checking   S u b m i t
			   wp_nonce_field( 'wpbc_settings_page_' . self::SUBMIT_FORM );

				// Add hidden input SEARCH KEY field into  main form, if previously was searching by ID or Title
				wpbc_hidden_search_by_id_field_in_main_form( array( 'search_get_key' => 'wh_resource_id' ) );			// FixIn: 8.0.1.12.

                ?><input type="hidden" name="is_form_sbmitted_<?php echo esc_attr( self::SUBMIT_FORM); ?>" id="is_form_sbmitted_<?php echo esc_attr( self::SUBMIT_FORM); ?>" value="1" /><?php

				?><div  class="wpbc_searchable_resources_table"><?php

					// Get search options  for all booking resources
					$search_options_arr = wpbc_searchable_resources__get_all_options();

					$this->search_options_arr = $search_options_arr;

					$this->wpbc_resources_table__show();

				?></div><?php

				?><div class="clear"></div><?php

				?><a class="button button-primary wpbc_button_save wpbc_button_action"
					 href="javascript:void(0);"
					 onclick="javascript: jQuery('#<?php echo esc_attr( self::SUBMIT_FORM ); ?>').trigger( 'submit' );" ><?php esc_html_e( 'Save Changes', 'booking' ); ?></a><?php

			?></form><?php

		?></span><?php

        do_action( 'wpbc_hook_settings_page_footer', 'searchable_resources' );
    }

	/**
	 * Show booking resources table    -    H E A D E R
	 */
	public function wpbc_resources_table__show() {

		// echo ( ( wpbc_is_this_demo() ) ? wpbc_get_warning_text_in_demo_mode() . '<div class="clear" style="height:20px;"></div>' : '' );

		$columns = array();
		// $columns[ 'check' ] = array( 'title' => '<input type="checkbox" value="" id="br-select-all" name="resource_id_all" />' , 'class' => 'wpbc_flextable_col_check check-column' );

		$columns[ 'on_off' ] = array( 	  'title' => wpbc_searchable_resources_page__get_on_off()
										, 'style' => ''
										, 'class' => 'check-column wpbc_searchable_on_off'
									);
		$columns[ 'title' ]  = array(     'title' => __( 'Resource Name', 'booking' )
										, 'style' => ''
										, 'sortable' => true
										, 'class' => 'wpbc_flextable_col_title'
									);
		$columns[ 'other' ] = array(      'title' => wpbc_searchable_resources_page__get_dropdown_menu_view()
										, 'style' => ''
										, 'sortable' => false
										, 'class' => 'wpbc_flextable_col_other'
									);
		$columns[ 'id' ] 	= array(      'title' =>__( 'ID', 'booking' )
										, 'style' => ''
										, 'sortable' => true
										, 'class' => 'wpbc_flextable_col_id'
									);
		$wpbc_br_table = new WPBC_BR_FlexTable( 'resources',
												array(
														'rows_func' => array( $this, 'wpbc_resources_table__show_rows' ),
														'columns'   => $columns,
														'url_sufix' => '#wpbc_resources_link'							// It's only for scrolling to specific section in pagination. We have no anchor at the content.
												)
							);
		$wpbc_br_table->display();
	}

    /**
	 * Show booking resources table    -    R O W S
     *
     * @param int $row_num
     * @param array $resource
     */
    public function wpbc_resources_table__show_rows( $row_num, $resource ) {

        $css_class = ' wpbc_resource_row';
        if ( class_exists( 'wpdev_bk_biz_l' ) ) {

                if ( intval($resource['count'] ) > 1 ) {
                    $css_class .= ' wpbc_resource_parent wpbc_resource_capacity' . $resource['count'] ;
                } else {

                    if ( empty( $resource['parent'] ) ) {
                        $css_class .= ' wpbc_resource_single';
                    } else {
                        $css_class .= ' wpbc_resource_child';

						// Show only 'Single' | 'Parent' resources. 	Hide Child resources.
						return;
                    }
                }
        }


 	    // Get  search option for specific booking resource,  or generate default value,  if not defined
	    $all_search_options_arr = $this->search_options_arr;
	    if ( ! isset( $all_search_options_arr[ $resource['id'] ] ) ) {
		    $search_options_arr = array();
	    } else {
		    $search_options_arr = $all_search_options_arr[ $resource['id'] ];
	    }

	    $search_options_default = array(
											'is_searchable' => 'Off',            // 'On' | 'Off'
											'url'           => '',
											'picture'       => '',
											'title'         => '',
											'description'   => '',
											'options'       => array()
										);
	    $search_options_arr = wp_parse_args( $search_options_arr, $search_options_default );


		// FixIn: 9.9.0.6.
        ?><div class="wpbc_flextable_row wpbc_resource_row_main wpbc_list_row wpbc_row<?php echo esc_attr( $css_class ); ?>" id="resource_<?php echo esc_attr( $resource['id'] ); ?>"><?php

			if(0){
				// =========================================================================================================
				// Checkbox
				// =========================================================================================================
				?><div class="wpbc_flextable_col wpbc_flextable_col_check check-column">
						<label class="screen-reader-text" for="br-select-<?php echo esc_attr( $resource['id' ] ); ?>"><?php echo esc_js(__('Select Booking Resource', 'booking')); ?></label>
						<input type="checkbox"  style="margin-top: 1px;"
									   id="br-select-<?php echo esc_attr( $resource['id' ] ); ?>"
									   name="br-select-<?php echo esc_attr( $resource['id' ] ); ?>"
									   value="resource_<?php echo esc_attr( $resource['id' ] ); ?>"
							/>
				</div><?php
			}

			// =========================================================================================================
			// On | Off
			// =========================================================================================================
			?><div class="wpbc_flextable_col wpbc_searchable_on_off check-column"><?php

					$is_checked = ( 'On' === $search_options_arr['is_searchable'] );

					$field_id    = 'wpbc_on_off_' . 'select_' . $resource['id' ];
					$field_name  = 'wpbc_on_off_' . 'select_' . $resource['id' ];
					$field_value = 'wpbc_on_off_' . 'id_' 	  . $resource['id' ];
					$params_checkbox = array(
											  'id'       => $field_id 										// HTML ID  of element
											, 'name'     => $field_name
											, 'label'    => array( 'title' => '', 'position' => 'right' )
											, 'toggle_style' => '' 												// CSS of select element
											, 'class'    => 'wpbc_visible_but_out_screen wpbc_searchable_checkbox_on_off' 													// CSS Class of select element
											, 'disabled' => ''
											, 'attr'     => array() 											// Any  additional attributes, if this radio | checkbox element
											, 'legend'   => ''//wp_kses_post( $field_title )						// aria-label parameter
											, 'value'    => $field_value 										// Some Value from optins array that selected by default
											, 'selected' => $is_checked											// Selected or not
											, 'onchange' 	=> "jQuery( this ).parents('.wpbc_searchable_on_off').find('.wpbc_label_on_off').hide();jQuery( this ).parents('.wpbc_searchable_on_off').find( jQuery( this ).is(':checked') ? '.wpbc_label_on' : '.wpbc_label_off' ).show();"					// JavaScript code
											//, 'onfocus' 	=>  "console.log( 'ON FOCUS:',  jQuery( this ).is(':checked') , 'in element:' , jQuery( this ) );"					// JavaScript code
											//, 'hint' 		=> array( 'title' => __('Send email notification to customer about this operation' ,'booking') , 'position' => 'top' )
										);
					wpbc_flex_toggle( $params_checkbox );

					?><div class="wpbc_flextable_labels">
						<a  class="wpbc_label wpbc_label_resource_parent  wpbc_label_on_off wpbc_label_off"
							style="<?php if ( $is_checked ) { echo 'display:none;'; } ?>"
							onclick="javascript:jQuery( this ).parents('.wpbc_searchable_on_off').find('.wpbc_searchable_checkbox_on_off').trigger('click');"
							href="javascript:void(0)"
						><?php esc_html_e( 'Disabled', 'booking' ); ?></a>
						<a class="wpbc_label wpbc_label_cost wpbc_label_on_off wpbc_label_on"
						   style="<?php if ( ! $is_checked ) { echo 'display:none;'; } ?>"
						   onclick="javascript:jQuery( this ).parents('.wpbc_searchable_on_off').find('.wpbc_searchable_checkbox_on_off').trigger('click');"
						   href="javascript:void(0)"
						><strong><?php esc_html_e( 'Searchable', 'booking' ); ?></strong></a>
					</div><?php

			?></div><?php


			// =========================================================================================================
			// Resource Title field
			// =========================================================================================================
			?><div class="wpbc_flextable_col wpbc_resource_name"><?php
				?><div class="wpbc_flextable_resource_title"><?php
					// =====================================================================================================
					// Folders
					// =====================================================================================================
					$resource_capacity   = ( ! empty( $resource['count'] ) ) ? $resource['count'] : 1;
					$resource_parent     = ( ! empty( $resource['parent'] ) ) ? $resource['parent'] : 0;
					$resource_last_child = ( ! empty( $resource['last_child'] ) ) ? $resource['last_child'] : 0;
					wpbc_flextable_reused_ui__folders_icons( $resource_parent, $resource_capacity, $resource_last_child );

					?><div class="wpbc_flextable_resource_title_text"><?php
				 		echo esc_html( $resource['title'] );
					?></div><?php

					wpbc_flextable_reused_ui__label_capacity_number( $resource_capacity );

				?></div><?php
			?></div><?php


			// =========================================================================================================
			// Different Data	-	Search Fields
			// =========================================================================================================
		    ?><div class="wpbc_flextable_col wpbc_flextable_col_other wpbc_other_resource_fields"><?php

					// =================================================================================================
					// Search URL
					// =================================================================================================
					?><div class="wpbc_resource_field__switchable wpbc_extra__search_url">
						<div class="wpbc_ajx_toolbar">
							<div class="ui_container ui_container_small">
								<div class="ui_group ui_group__search_url">
									<div class="ui_element ui_element__search_url">
										<input type="text"
											   value="<?php echo esc_attr( $search_options_arr['url'] ); ?>"
											   id="booking_resource_search_url_<?php echo intval( $resource['id' ] ); ?>"
											   name="booking_resource_search_url_<?php echo intval( $resource['id' ] ); ?>"
											   class="ui_text_field_100"
											   placeholder="<?php echo esc_attr( __( 'Specify booking form URL','booking')); ?>"
											   />
									</div>
									<?php
									$search_options__url = ( ! empty( $search_options_arr['url'] ) ) ? wpbc_lang( $search_options_arr['url'] ) : '';

									if ( ! empty( esc_attr( $search_options__url ) ) ) { ?>
										<div class="ui_element ui_element__search_url_link">
										   <a href="<?php echo esc_url( $search_options__url ); ?>" target="_blank"
											  class="tooltip_top wpbc-bi-arrow-up-right-square"
											  title="<?php echo esc_attr( __( 'Open in new window', 'booking' ) ); ?>"></a>
										</div>
									<?php } else { ?>
										<div class="ui_element ui_element__search_url_link">
										   <a  style="color:#ccc;"
											   title="<?php echo esc_attr( __( 'Specify booking form URL','booking')); ?>"
											   class="tooltip_top  wpbc-bi-question-circle"
											   ></a>
										</div>
									<?php } ?>
								</div>

							</div>
						</div>
					</div><?php


					// =================================================================================================
					//  Excerpt | Image
					// =================================================================================================
					?><div class="wpbc_resource_field__switchable wpbc_extra__excerpt_img">
						<div class="wpbc_ajx_toolbar">
							<div class="ui_container ui_container_small">
								<div class="ui_group ui_group__thumbnail">
									<div class="ui_element">
										<?php
										$thumbnail_url = ( ! empty( $search_options_arr['picture'] ) )
															? wpbc_lang( $search_options_arr['picture'] )
															: '';
										if ( ! empty( $thumbnail_url ) ) {
											?><a href="javascript:void(0)"
												 class="wpbc_media_upload_button"
													data-modal_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-btn_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-url_field="booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
											><?php
											// phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
											?><img src="<?php echo esc_url( $thumbnail_url ); ?>" class="search_thumbnail_img" /></a><?php
										}  else {
											?><div class="search_thumbnail_img" >
												<a 	href="javascript:void(0)"
													class="wpbc_media_upload_button"
													data-modal_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-btn_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-url_field="booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
												><?php
													esc_html_e('No Image','booking');
											?></a></div> <?php
										}
										?>
									</div>
								</div>
								<div class="ui_group ui_group__excerpt">
									<div class="ui_group ui_group__size_100">
										<div class="ui_element ui_element_text">
											<input type="text"
												   value="<?php echo esc_attr( $search_options_arr['title'] ); ?>"
												   id="booking_resource_search_title_<?php echo intval( $resource['id' ] ); ?>"
												   name="booking_resource_search_title_<?php echo intval( $resource['id' ] ); ?>"
												   class="ui_text_field_100 ui_field_title"
												   placeholder="<?php echo esc_attr( __( 'Customize the title displayed in search results','booking')); ?>"
												   />
										</div>
										<div class="ui_element ui_element_icon">
										   <a href="https://wpbookingcalendar.com/faq/search-availability-setup"
											  class="tooltip_top wpbc-bi-question-circle"
											  title="<?php echo esc_attr( __( 'Customize the title displayed in search results', 'booking' ) ); ?>"></a>
										</div>
									</div>
									<div class="ui_group ui_group__size_100">
										<div class="ui_element ui_element_text">
											<textarea name="booking_resource_search_excerpt_<?php echo intval( $resource['id'] ); ?>"
													  placeholder="<?php echo esc_attr( __( 'Specify an excerpt description for display in search results','booking')); ?>"
											><?php echo esc_textarea( $search_options_arr['description']  ); ?></textarea>
										</div>
										<div class="ui_element ui_element_icon">
										   <a href="https://wpbookingcalendar.com/faq/search-availability-setup"
											  class="tooltip_top wpbc-bi-question-circle"
											  title="<?php echo esc_attr( __( 'Specify an excerpt description for display in search results', 'booking' ) ); ?>"></a>
										</div>
									</div>
									<div class="ui_group ui_group__size_100">
										<div class="ui_element ui_element_text">
											<input type="text"
												   value="<?php echo esc_attr( $search_options_arr['picture'] ); ?>"
												   id="booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
												   name="booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
												   class="ui_text_field_100 booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
												   placeholder="<?php echo esc_attr( __( 'Set the thumbnail URL for item shown in search results','booking')); ?>"
												   />
											<script type="text/javascript">
												jQuery(document).ready(function(){
													jQuery( '#booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>').on( 'wpbc_media_upload_url_set', function(){
														<?php // phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage ?>
														jQuery( '#booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>').parents( '.wpbc_extra__excerpt_img' ).find( '.ui_group__thumbnail .wpbc_media_upload_button' ).html( '<img src="' + jQuery( '#booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>').val() + '" class="search_thumbnail_img" />' );
													});
												});
											</script>
										</div>
										<div class="ui_element ui_element_button">
										   <a href="javascript:void(0)"
											  title="<?php echo esc_attr( __( 'Set the thumbnail URL for item shown in search results', 'booking' ) ); ?>"
											  class="wpbc_media_upload_button tooltip_top wpbc_ui_control wpbc_ui_button wpbc_upload_img_<?php echo intval( $resource['id' ] ); ?>"
													data-modal_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-btn_title="<?php echo esc_attr( __( 'Select Image', 'booking' ) ); ?>"
													data-url_field="booking_resource_search_img_url_<?php echo intval( $resource['id' ] ); ?>"
										   >
											   <i class="menu_icon icon-1x wpbc_icn_tune"></i>
										   </a>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div><?php

					// =================================================================================================
					// Search Parameters
					// =================================================================================================
					?><div class="wpbc_resource_field__switchable wpbc_extra__search_filters">
						<div class="wpbc_ajx_toolbar">
							<div class="ui_container ui_container_small">

								<div class="ui_group ui_group__size_100 ui_group__search_options">
									<div class="ui_element ui_element_text">
										<?php
										$search_optons_html = '';
										if ( ! empty( $search_options_arr['options'] ) ) {

											$search_options_arr['options'] = wpbc_searchable_resources__filters__get_as_arr( $search_options_arr['options'] );

											foreach ( $search_options_arr['options'] as $option_name => $option_value_arr ) {

												$search_optons_html .= '<div class="search_filter__row">';
												$search_optons_html .= '  <div class="search_filter__col__name">';
												$search_optons_html .=       $option_name;
												$search_optons_html .= '  </div>';
												$search_optons_html .= '  <div class="search_filter__col__values">';
												foreach ( $option_value_arr as $option_op_value_arr ) {
													$search_optons_html .= '  <div class="search_filter__value_pairs">';
													$search_optons_html .= '    <div class="search_filter__operation">';
													$search_optons_html .=         $option_op_value_arr[0];
													$search_optons_html .= '    </div>';
													$search_optons_html .= '    <div class="search_filter__value">';
													$search_optons_html .=         $option_op_value_arr[1];
													$search_optons_html .= '    </div>';
													$search_optons_html .= '  </div>';
												}
												$search_optons_html .= '  </div>';
												$search_optons_html .= '</div>';
											}
										}
										?>
										<div  id="div_booking_resource_search_options_<?php echo intval( $resource['id' ] ); ?>"
												   name="div_booking_resource_search_options_<?php echo intval( $resource['id' ] ); ?>"
												   class="ui_text_field_100 put-in shortcode_text_field search_filters__display"
										><?php
											echo empty( $search_optons_html )
												? '<div class="in_shortcode_help_text">' . esc_html__( 'Define specific search filter parameters that can be used to refine search results', 'booking' ) . ' &nbsp; -&gt; </div>'
												: wp_kses_post( $search_optons_html ); ?></div>
										<textarea  name="booking_resource_options_<?php echo intval( $resource['id'] ); ?>"
												   id="booking_resource_options_<?php echo intval( $resource['id'] ); ?>"
										><?php echo esc_textarea(  wpbc_searchable_resources__filters__get_as_str( $search_options_arr['options'] )  ); ?></textarea>
									</div>

									<div class="ui_element ui_element_button">
										<a href="javascript:void(0)" onclick="javascript:wpbc_modal_search_options__open(<?php echo intval( $resource['id'] ); ?>);"
										   id="ui_btn_erase_availability" class="wpbc_ui_control wpbc_ui_button wpbc_ui_button_danger0 tooltip_top "
										   title="<?php esc_attr_e( 'Define specific search filter parameters that can be used to refine search results','booking'); ?>."  >
												<span style="display: none;"><?php esc_html_e('Customize','booking'); ?>&nbsp;&nbsp;&nbsp;</span>
												<i class="menu_icon icon-1x wpbc_icn_tune"></i>
										</a>
									</div>
								</div>

							</div>
						</div>
					</div><?php

					// =================================================================================================
					// Labels
					// =================================================================================================
					?><div class="wpbc_resource_field__switchable wpbc_resource_field__extra__labels 		wpbc_flextable_labels">
						<div class="wpbc_ajx_toolbar">
							<div class="ui_container ui_container_small">
								<div class="ui_group ui_group__labels">
								<?php

									// Cost Label
									wpbc_flextable_reused_ui__label_cost( $resource['id'], $resource['cost'] );

									// Default Form
									$resource_default_form = ( ! empty( $resource['default_form'] ) ) ? $resource['default_form'] : '';
									wpbc_flextable_reused_ui__label_default_form( $resource_default_form );

									// Parent | Child | Single
									$resource_capacity = ( ! empty( $resource['count'] ) )  ? $resource['count']  : 1;
									$resource_parent   = ( ! empty( $resource['parent'] ) ) ? $resource['parent'] : 0;
									wpbc_flextable_reused_ui__label_parent_child( $resource_parent, $resource_capacity );

									// User Owner Label
									$resource_user_id = ( ! empty( $resource['users'] ) ) ? $resource['users'] : 0;
									wpbc_flextable_reused_ui__label_user_owner( $resource_user_id );
								?>
								</div>
							</div>
						</div>
					</div>

			</div><?php

			// =========================================================================================================
			// ID
			// =========================================================================================================
			?><div class="wpbc_flextable_col wpbc_flextable_col_id">
				<div class="wpbc_listing_col wpbc_col_booking_labels wpbc_col_labels wpbc_label_resource_id_container">
					<span class="wpbc_label wpbc_label_booking_id wpbc_label_resource_id">
						<?php echo esc_attr( $resource['id' ] ); ?>
					</span>
				</div>
			</div>

		</div>
        <?php
    }


	/**
	 * Save Changes
	 *
	 * @return void
	 */
    public function update() {

		// if (  ( wpbc_is_this_demo() ) ||  ( ! class_exists( 'wpdev_bk_personal' ) )  ) { return; }
		global $wpdb;

		// -------------------------------------------------------------------------------------------------------------
		// "Num Per Page" -- Update number of booking resources per page							  // FixIn: 9.9.0.22.
		// -------------------------------------------------------------------------------------------------------------
	    // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
	    if (   ( ! empty( $_POST['booking_resourses_num_per_page'] ) ) ) {
			$booking_resourses_num_per_page = intval( $_POST['booking_resourses_num_per_page'] );  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			if ( ( $booking_resourses_num_per_page > 0 ) && ( $booking_resourses_num_per_page < 501 ) ) {
				update_bk_option( 'booking_resourses_num_per_page', $booking_resourses_num_per_page );
			}
		}

		// Get search options  for all booking resources
		$search_options_arr = wpbc_searchable_resources__get_all_options();

		// -------------------------------------------------------------------------------------------------------------
		// Get All resources from the cache
		// -------------------------------------------------------------------------------------------------------------
	    make_bk_action( 'wpbc_reinit_booking_resource_cache' );

	    $resources_cache   = wpbc_br_cache();
	    $all_resource_list = $resources_cache->get_resources();
	    foreach ( $all_resource_list as $resource_id => $resource_param_arr ) {
			// Set to all Child booking resources as not searchable - it is needed in case admin set some single booking resources as child previously at Booking > Resources page.
			if ( ! empty( $resource_param_arr['parent'] ) ){
				$search_options_arr[ $resource_id ]['is_searchable'] = 'Off';
			}
		}

		// Now we get only booking resources relative to our one SELECTED page in Resource Table.
	    $wpbc_br_table = new WPBC_BR_Table( 'resources_submit' );
	    $linear_resources_for_one_page = $wpbc_br_table->get_linear_data_for_one_page();

        foreach ( $linear_resources_for_one_page as $resource_id => $resource ) {

			/*
			// Parent
			if ( intval($resource['count'] ) > 1 ) {

			}
			// Single
			if ( intval($resource['count'] ) <= 1 ) {

			}
			*/

			// ---------------------------------------------------------------------------------------------------------
			// Check updated fields in booking resources
			// ---------------------------------------------------------------------------------------------------------
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
            if ( isset( $_POST['booking_resource_search_url_' . $resource_id ] ) ) {

				// Search Params
	            if ( ! isset( $search_options_arr[ $resource_id ] ) ) {
		            $search_options_arr[ $resource_id ] = array(
																'is_searchable' => 'Off',            // 'On' | 'Off'
																'url'           => '',
																'picture'       => '',
																'description'   => '',
																'title' 		=> '',
																'options'       => array()
															);
	            }

				// -----------------------------------------------------------------------------------------
				// On | Off
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'wpbc_on_off_' . 'select_' . $resource_id ] ) ) {
					$search_options_arr[ $resource_id ]['is_searchable'] = 'On';
				} else {
					$search_options_arr[ $resource_id ]['is_searchable'] = 'Off';
				}

				// -----------------------------------------------------------------------------------------
				// URL
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'booking_resource_search_url_' . $resource_id ] ) ) {

					if (
						   ( ( wpbc_is_this_demo() ) && ( $resource_id < 13 ) && ( ! class_exists( 'wpdev_bk_multiuser' ) )  )
						|| ( ( wpbc_is_this_demo() ) && ( $resource_id < 18 ) && (   class_exists( 'wpdev_bk_multiuser' ) )  )
					){
						// Do Not Save for Demo booking resources !
					} else {
						$validated_url = WPBC_Settings_API::validate_text_post_static( 'booking_resource_search_url_' . $resource_id );
						// $validated_url = sanitize_url( $validated_url );													// We not validate it as URL, because here can be configuration in several lang.
						$search_options_arr[ $resource_id ]['url'] = $validated_url;
					}
				}
				// Filter Options param - it sent already  as converted into  the String params:
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'booking_resource_options_' . $resource_id ] ) ) {
					$validated_text = WPBC_Settings_API::validate_textarea_post_static( 'booking_resource_options_' . $resource_id );
					$search_options_arr[ $resource_id ]['options'] =  $validated_text ;
					//	$search_options_arr[ $resource_id ]['options'] = maybe_unserialize( $validated_text );
					//	if ( empty( $search_options_arr[ $resource_id ]['options'] ) ) {
					//		$search_options_arr[ $resource_id ]['options'] = array();
					//	}
				}
				// Default image
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'booking_resource_search_img_url_' . $resource_id ] ) ) {

					// -----------------------------------------------------------------------------------------------------------------
					// Not Demo only
					// -----------------------------------------------------------------------------------------------------------------
					// $is_beta = (  $_SERVER['HTTP_HOST'] === 'beta'  );
					if ( ! wpbc_is_this_demo() ) {
						$validated_url = WPBC_Settings_API::validate_text_post_static( 'booking_resource_search_img_url_' . $resource_id );
						// $validated_url = sanitize_url( $validated_url );													// We not validate it as URL, because here can be configuration in several lang.
						$search_options_arr[ $resource_id ]['picture'] = $validated_url;
					}
				}
				// Excerpt
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'booking_resource_search_excerpt_' . $resource_id ] ) ) {
					$validated_text = WPBC_Settings_API::validate_textarea_post_static( 'booking_resource_search_excerpt_' . $resource_id );
					$search_options_arr[ $resource_id ]['description'] = $validated_text;
				}
				// Title
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( isset( $_POST[ 'booking_resource_search_title_' . $resource_id ] ) ) {
					$validated_text = WPBC_Settings_API::validate_textarea_post_static( 'booking_resource_search_title_' . $resource_id );
					$search_options_arr[ $resource_id ]['title'] = $validated_text;
				}
            }
        }

		// -------------------------------------------------------------------------------------------------------------
		// Save search options  for all booking resources
		// -------------------------------------------------------------------------------------------------------------
	    wpbc_searchable_resources__save_all_options( $search_options_arr );

		wpbc_show_changes_saved_message();

        make_bk_action( 'wpbc_reinit_booking_resource_cache' );
    }

}
add_action('wpbc_menu_created', array( new WPBC_Page_Settings__searchable_resources() , '__construct') );    // Executed after creation of Menu



// ---------------------------------------------------------------------------------------------------------------------
// Some UI elements
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Flex Table   -  H e a d e r    -  On | Off  Selector
 */
function wpbc_searchable_resources_page__get_on_off() {

	ob_start();

	$params_checkbox = array(
						  'id'       => 'wpbc_on_off_' . 'select_all' 											// HTML ID  of element
						, 'name'     => 'wpbc_on_off_' . 'select_id_all'
						, 'label'    => array( 'title' => '', 'position' => 'right' )		// 'title' => wp_kses_post( '' )
						, 'toggle_style' => '' 																	// CSS of select element
						, 'class'    => 'wpbc_visible_but_out_screen' 											// CSS Class of select element
						, 'disabled' => ''
						, 'attr'     => array() 																// Any  additional attributes, if this radio | checkbox element
						, 'legend'   => ''			 															// aria-label parameter
						, 'value'    => '' 																		// Some Value from options array that selected by default
						, 'selected' => false																	// Selected or not
						//, 'onfocus' 	=>  "console.log( 'ON FOCUS:',  jQuery( this ).is(':checked') , 'in element:' , jQuery( this ) );"					// JavaScript code
						//, 'onchange' 	=> "wpbc_ajx_booking_send_search_request_with_params( {'ui_usr__send_emails': (jQuery( this ).is(':checked') ? 'send' : 'not_send') } );"					// JavaScript code
						//, 'hint' 		=> array( 'title' => __('Send email notification to customer about this operation' ,'booking') , 'position' => 'top' )
					);
	wpbc_flex_toggle( $params_checkbox );		//echo '<span>' . esc_html__('Enable / Disable', 'booking') . '</span>';

	?><a href="https://wpbookingcalendar.com/faq/search-availability-setup" class="tooltip_top wpbc-bi-question-circle" title="<?php echo esc_attr( __( 'Enable / Disable', 'booking' ) ); ?>"></a><?php

	$toggle_box_html = ob_get_clean();

	return $toggle_box_html;
}

/**
 * Flex Table   -  H e a d e r    T a b s
 */
function wpbc_searchable_resources_page__get_dropdown_menu_view() {

	ob_start();
	ob_clean();

	// Class 'wpdevelop' here required for correct  showing dropdown menu in this Tabs
	?><span class="wpbc_flextable_header_tabs__resources wpdevelop"><?php

	wpbc_flextable_header_tabs_html_container_start();

		?><div style="margin:auto;"> <?php
			wpbc_bs_display_tab(   array(
												  'title'       => __('URL', 'booking')
												, 'font_icon'   => 'wpbc_icn_link'
												, 'hint' 		=> array( 'title' => __('Redirect URL from Search Results to Booking Page' ,'booking') , 'position' => 'top' )
												, 'onclick'     =>  "jQuery('.wpbc_other_resource_fields.wpbc_flextable_col_other').show();"
																	. "jQuery('.wpbc_resource_field__switchable').hide();"
																	. "jQuery('.wpbc_extra__search_url').show();"
																	. "jQuery('.wpbc_flextable_header_tabs__resources .nav-tab').removeClass('nav-tab-active');"
																	. "jQuery(this).addClass('nav-tab-active');"
																	. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																	. "jQuery('.nav-tab-active i').addClass('icon-white');"
												, 'default'     => true
												, 'attr'  => array( 'id' => 'flextable_header_tab__search_url' )
								) );
			wpbc_bs_display_tab(   array(
												  'title'       => __('Excerpt / Image', 'booking')
												, 'font_icon'   => 'wpbc_icn_image'
												, 'hint' 		=> array( 'title' => __('Set small text description and thumbnail for booking resources shown in search results.' ,'booking') , 'position' => 'top' )
												, 'onclick'     =>  "jQuery('.wpbc_other_resource_fields.wpbc_flextable_col_other').show();"
																	. "jQuery('.wpbc_resource_field__switchable').hide();"
																	. "jQuery('.wpbc_extra__excerpt_img').show();"
																	. "jQuery('.wpbc_flextable_header_tabs__resources .nav-tab').removeClass('nav-tab-active');"
																	. "jQuery(this).addClass('nav-tab-active');"
																	. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																	. "jQuery('.nav-tab-active i').addClass('icon-white');"
												, 'default'     => false
												, 'attr'  => array( 'id' => 'flextable_header_tab__search_excerpt' )
								) );

			wpbc_bs_display_tab(   array(
												  'title'       => __('Search Filters', 'booking')
												, 'font_icon'   => 'wpbc_icn_tune'
												, 'hint' 		=> array( 'title' => __('Define specific search filter parameters that can be used to refine search results' ,'booking') , 'position' => 'top' )
												, 'onclick'     =>  "jQuery('.wpbc_other_resource_fields.wpbc_flextable_col_other').show();"
																	. "jQuery('.wpbc_resource_field__switchable').hide();"
																	. "jQuery('.wpbc_extra__search_filters').show();"
																	. "jQuery('.wpbc_flextable_header_tabs__resources .nav-tab').removeClass('nav-tab-active');"
																	. "jQuery(this).addClass('nav-tab-active');"
																	. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																	. "jQuery('.nav-tab-active i').addClass('icon-white');"
												, 'default'     => false
												, 'attr'  => array( 'id' => 'flextable_header_tab__search_filters' )
								) );

			wpbc_bs_display_tab(   array(
											'title'         => ''//__('Labels', 'booking')
											, 'font_icon'   => 'wpbc-bi-tags'
											, 'hint' 		=> array( 'title' => __('Show Labels' ,'booking') , 'position' => 'top' )
											, 'onclick'     =>  "jQuery('.wpbc_other_resource_fields.wpbc_flextable_col_other').show();"
																. "jQuery('.wpbc_resource_field__switchable').hide();"
																. "jQuery('.wpbc_resource_field__extra__labels').show();"
																. "jQuery('.wpbc_flextable_header_tabs__resources .nav-tab').removeClass('nav-tab-active');"
																. "jQuery(this).addClass('nav-tab-active');"
																. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																. "jQuery('.nav-tab-active i').addClass('icon-white');"
											, 'default'     => false
											, 'attr'  => array( 'id' => 'flextable_header_tab__labels' )
							) );

			wpbc_bs_display_tab(   array(
											'title'         => ''//__('Hide', 'booking')
											, 'font_icon'   => 'wpbc-bi-eye-slash'
											, 'hint' 		=> array( 'title' => __('Hide Column' ,'booking') , 'position' => 'top' )
											, 'onclick'     =>  "jQuery('.wpbc_other_resource_fields.wpbc_flextable_col_other').hide();"
																. "jQuery('.wpbc_flextable_header_tabs__resources .nav-tab').removeClass('nav-tab-active');"
																. "jQuery(this).addClass('nav-tab-active');"
																. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																. "jQuery('.nav-tab-active i').addClass('icon-white');"
											, 'default'     => false
											, 'attr'  => array( 'id' => 'flextable_header_tab__hide' )
							) );
		?></div><?php


	// <editor-fold     defaultstate="collapsed"                        desc="  ==  S o r t i n g     D r o p d o w n     L i st   ==  "  >
		// -------------------------------------------------------------------------------------------------------------

		$page_url = wpbc_get_resources_url( true, false ) . '&tab=searchable_resources';

		$sort_order_items_arr = array();
		$sort_font_icon = 'wpbc_icn_swap_vert';

		// Priority
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( class_exists( 'wpdev_bk_biz_l' ) ){
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			if ( empty( $_GET['orderby'] ) ){
				$_GET['orderby'] = 'prioritet';
				$_GET['order'] = 'asc';
			}
			$sort_url =  $page_url .  '&orderby=prioritet'
							   . ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) ) ? '&order=desc' : '&order=asc' )  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
							   . '#wpbc_resources_link';

			$sort_icn = '';
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			if ( ( ! empty( $_GET['orderby'] ) ) && ( 'prioritet' === $_GET['orderby'] ) ) {
			 	 // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				$sort_icn	= ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) )
									? ' <span aria-hidden="true" class=" wpbc_icn_vertical_align_top"></span>'
									: ' <span aria-hidden="true" class=" wpbc_icn_vertical_align_bottom"></span>'
								);
			  	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				$sort_font_icon = ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) ) ? 'wpbc_icn_vertical_align_top' : 'wpbc_icn_vertical_align_bottom' );
			}

			$sort_order_items_arr[] = array(
				'type'  => 'link',
				'title' => __( 'Priority', 'booking' ) . $sort_icn,
				'url'   => $sort_url
			);
		}

		// Users
		if ( class_exists( 'wpdev_bk_multiuser' ) ) {

			$is_can = apply_bk_filter( 'multiuser_is_user_can_be_here', true, 'only_super_admin' );
			if ( $is_can ) {

				$sort_url =  $page_url .  '&orderby=users'
								   . ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) ) ? '&order=desc' : '&order=asc' )  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
								   . '#wpbc_resources_link';

				$sort_icn = '';
				// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
				if ( ( ! empty( $_GET['orderby'] ) ) && ( 'users' === $_GET['orderby'] ) ) {
				 	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
					$sort_icn	= ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) )
										? ' <span aria-hidden="true" class="wpbc_icn_vertical_align_top"></span>'
										: ' <span aria-hidden="true" class="wpbc_icn_vertical_align_bottom"></span>'
									);
				  	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
					$sort_font_icon = ( ( ( ! empty( $_GET['order'] ) ) && ( 'asc' === $_GET['order'] ) ) ? 'wpbc_icn_vertical_align_top' : 'wpbc_icn_vertical_align_bottom' );
				}

				$sort_order_items_arr[] = array(
					'type'  => 'link',
					'title' => __( 'Users', 'booking' ) . $sort_icn,
					'url'   => $sort_url
				);
			}
		}

		if ( ! empty( $sort_order_items_arr ) ) {

				wpbc_bs_dropdown_menu( array(
											'title'     => '',										//__( 'Options', 'booking' ) . '&nbsp;',
											'font_icon' => $sort_font_icon, 						//'wpbc_icn_more_vert0 wpbc_icn_swap_vert',
											'position'  => 'right',
											'style'   => 'margin-left: auto;',        				// Right align
											'items'     => $sort_order_items_arr
								));
		}
	// </editor-fold>

	wpbc_flextable_header_tabs_html_container_end();

	?></span><?php

	$content = ob_get_contents();
	ob_end_clean();

	return $content;
}

/**
 * Show   Toolbar   at   Searchable Resource Setup page
 *
 * @return void
 */
function wpbc_searchable_resources_page__toolbar() {

	wpbc_clear_div();

	//  Toolbar --------------------------------------------------------------------------------------------------------

	?><div id="toolbar_booking_resources" style="position:relative;display: none;display: block;"><?php

		wpbc_bs_toolbar_tabs_html_container_start();

			wpbc_bs_display_tab(   array(
												'title'         => __('Options', 'booking')
												// , 'hint' => array( 'title' => __('Manage bookings' ,'booking') , 'position' => 'top' )
												, 'onclick'     =>    "jQuery('.ui_container_toolbar').hide();"
																	. "jQuery('.ui_container_options').show();"
																	. "jQuery('#toolbar_booking_resources .nav-tab').removeClass('nav-tab-active');"
																	. "jQuery(this).addClass('nav-tab-active');"
																	. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
																	. "jQuery('.nav-tab-active i').addClass('icon-white');"
												, 'font_icon'   => 'wpbc_icn_tune'
												, 'default'     => true

								) );


			wpbc_bs_dropdown_menu_help();

		wpbc_bs_toolbar_tabs_html_container_end();

		$submit_form_name = 'wpbc_form_add_new_booking_resources';
		?><form  name="<?php echo esc_attr( $submit_form_name); ?>" id="<?php echo esc_attr( $submit_form_name); ?>" action="" method="post" autocomplete="off"><?php

			// N o n c e   field, and key for checking   S u b m i t
			wp_nonce_field( 'wpbc_settings_page_' . $submit_form_name );
			?><input type="hidden" name="is_form_sbmitted_<?php echo esc_attr( $submit_form_name); ?>" id="is_form_sbmitted_<?php echo esc_attr( $submit_form_name); ?>" value="1" /><?php


			////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			// New toolbar
			////////////////////////////////////////////////////////////////////////////////////////////////////////////////
			?><div id="booking_resources_toolbar_container" class="wpbc_ajx_toolbar"><?php

				$selected_tab = 'add_resource_options';

				// Options
				?><div class="ui_container    ui_container_toolbar		ui_container_small    ui_container_options    ui_container_options_row_1" style="<?php echo ( 'add_resource_options' == $selected_tab ) ? 'display: flex' : 'display: none' ?>;"><?php

					?><div class="ui_group"><?php

						wpbc_br__ui__toolbar_search_resource_by_keyword( array(
																				'url' => wpbc_get_resources_url() . '&tab=searchable_resources'
																			) );
					?></div><?php

				?></div><?php

			?></div><?php

		?></form><?php

		?><div class="clear" style="height:10px;"></div><?php

	?></div><?php

	wpbc_clear_div();
}

/**
 * Show / Hide toolbar options -  at  top Header line
 *
 * @param $page_tag
 * @param $active_page_tab
 * @param $active_page_subtab
 *
 * @return false|void
 */
function wpbc_show_searchable_resources__search_dropdown_menu( $page_tag, $active_page_tab, $active_page_subtab ) {

	if ( ( 'wpbc-resources' !== $page_tag ) || ( 'searchable_resources' !== $active_page_tab ) ) {
		return false;
	}

	$sort_order_items_arr   = array();
	$sort_order_items_arr[] = array(
										'type'  => 'link',
										'title' => '<i class="menu_icon icon-1x wpbc-bi-eye"></i> &nbsp; &nbsp; ' . __( 'Show Toolbar', 'booking' ),
										'url'   => 'javascript:void(0);',
										'attr' => array( 'class'   => 'wpbc_toggle_toolbar_options',
														 'onclick' => "javascript: jQuery( '#toolbar_booking_resources' ).toggle();jQuery( '.wpbc_toggle_toolbar_options').toggle(); "
										)
									);
	$sort_order_items_arr[] = array(
										'type'  => 'link',
										'title' => '<i class="menu_icon icon-1x wpbc-bi-eye-slash"></i> &nbsp; &nbsp; ' .__( 'Hide Toolbar', 'booking' ),
										'url'   => 'javascript:void(0);',
										'attr' => array( 'class'   => 'wpbc_toggle_toolbar_options',
														 'style'   => 'display:none;',
														 'onclick' => "javascript: jQuery( '#toolbar_booking_resources' ).toggle();jQuery( '.wpbc_toggle_toolbar_options').toggle(); "
										)
									);
	?><span class="wpdevelop" style="align-self: flex-end;"><?php
		wpbc_bs_dropdown_menu( array(
									'title'     => '',                                        //__( 'Options', 'booking' ) . '&nbsp;',
									'font_icon' => 'wpbc_icn_more_vert',                        //'wpbc_icn_more_vert0 wpbc_icn_swap_vert',
									'position'  => 'right',
									//'style'   => 'margin-left: auto;',        			// Right align
									'items'     => $sort_order_items_arr
								) );
	?></span><?php
}
// add_bk_action('wpbc_h1_header_content_end', 'wpbc_show_searchable_resources__search_dropdown_menu');


// ---------------------------------------------------------------------------------------------------------------------
// Settings   R e d i r e c t i o n   :: 	'Search Form / Results'  ->   Settings > Search page
// ---------------------------------------------------------------------------------------------------------------------

class WPBC_Page_SettingsSearch_duplicate extends WPBC_Page_Structure {

	public function in_page() {
		if (
				  ( ! wpbc_is_mu_user_can_be_here( 'only_super_admin' ) )
			// && ( ! wpbc_is_current_user_have_this_role('contributor') )
		){
			return (string) wp_rand( 100000, 1000000 );        // If this User not "super admin",  then  do  not load this page at all
		}

		return 'wpbc-resources';
	}

	public function tabs() {

		$tabs = array();

		// -------------------------------------------------------------------------------------------------------------
		// Search  Shortcuts
		// -------------------------------------------------------------------------------------------------------------
		$separator_i = 0;
		$subtab_default = array(
			'type'            => 'subtab',                        // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'.
			'title'           => '',                              // Example: __( 'Dashboard'                                                                   // Title of TAB.
			'page_title'      => '',                              // __( 'Search Availability'                                                                  // Title of Page.
			'hint'            => '',                              // __( 'Configure the layout and functionality of both the search form and search results.'   // Hint.
			'link'            => '',                              // wpbc_get_settings_url() . '&scroll_to_section=wpbc_general_settings_dashboard_tab',        // Link.
			'css_classes'     => '',                              // cls CSS .
			'font_icon'       => 'wpbc_icn_dashboard',
			'font_icon_right' => 'wpbc-bi-question-circle',                              // 'wpbc-bi-question-circle' .
			'default'         => false,                           // Is this sub tab activated by default or not: true || false.
		);

		$subtabs = array();

		// FixIn: 10.12.4.7.  $subtabs[ 'searchable_resources_hr' . ( ++ $separator_i ) ] = array_merge( $subtab_default, array( 'type' => 'separator', 'folder_style' => '' ) );

		$subtabs['search_form'] = array(
			'type'            => 'subtab',     // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'.
			'title'           => __( 'Search Form / Results', 'booking' ),       // Title of TAB.
			// , 'title'     => __( 'Search Form Layout', 'booking')             // Title of TAB.
			'page_title'      => __( 'Search Availability', 'booking' ),         // Title of Page.
			'hint'            => __( 'Configure the layout and functionality of both the search form and search results.', 'booking' ),
			'link'            => wpbc_get_settings_url() . '&tab=search#wpbc-settings-admin-page',
			'css_classes'     => '',
			'default'         => false,                                          // Is this sub tab activated by default or not: true || false.
			'content'         => 'content',
			'font_icon'       => 'wpbc_icn_search',
			'font_icon_right' => 'wpbc-bi-question-circle',
			//, 'checked_data' 			=> WPBC_EMAIL_NEW_ADMIN_PREFIX . WPBC_EMAIL_NEW_ADMIN_ID		// This is where we get content
			//, 'hint' => array( 'title' => __('Customization of email template, which is sending to Admin after new booking' ,'booking') , 'position' => 'right' )
		);

//        $subtabs['search_results'] = array(
//                              'type' => 'subtab'                                  // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'
//                            , 'title'       => __('Search Results Layout' ,'booking')        // Title of TAB
//											  . '<span class="wpbc-bi-arrow-up-short" style="margin-left: auto;"></span>'
//                            , 'page_title'  => __('Search Availability', 'booking')  // Title of Page
//                            , 'hint'        => __( 'Configure the layout and functionality of both the search form and search results.', 'booking')               // Hint
//                            , 'css_classes' => 'wpbc_navigation_sub_item'                               // CSS class(es)
//							, 'attr' => array( 'style' => 'display:flex;' )
//                            , 'font_icon' => 'wpbc-bi-file-text'                                                           // CSS definition of Font Icon
//						  	, 'font_icon_right' => ''
//                            , 'link' => wpbc_get_settings_url(). '&tab=search#wpbc_settings_search_results_form_metabox'                                      // link
//                            , 'default' =>  false                                // Is this sub tab activated by default or not: true || false.
//                            , 'content' => 'content'                            // Function to load as conten of this TAB
//                        );
//
//		$subtabs['search_options']                    = $subtabs['search_results'];
//		$subtabs['search_options']['title']           = __( 'Search Options', 'booking' ) . '<span class="wpbc-bi-arrow-up-short" style="margin-left: auto;"></span>';
//		$subtabs['search_options']['hint']            = __( 'Configure the layout and functionality of both the search form and search results.', 'booking' );
//		$subtabs['search_options']['link']            = wpbc_get_settings_url() . '&tab=search#wpbc_settings_search_advanced_metabox';
//		$subtabs['search_options']['font_icon']       = 'wpbc_icn_manage_search';
//		$subtabs['search_options']['font_icon_right'] = '';


		$tabs['searchable_resources']['subtabs'] = $subtabs;

		return $tabs;
	}

	public function content() {
	}
}
add_action('wpbc_menu_created', array( new WPBC_Page_SettingsSearch_duplicate() , '__construct') );    					// Executed after creation of Menu
