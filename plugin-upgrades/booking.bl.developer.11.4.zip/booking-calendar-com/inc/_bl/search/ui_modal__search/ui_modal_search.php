<?php
/**
 * @version 1.0
 * @package     Modal UI - Search Options
 * @subpackage  Template Loader
 * @category    Templates
 *
 * @author wpdevelop
 * @link https://wpbookingcalendar.com/
 * @email info@wpbookingcalendar.com
 *
 * @modified 2024-04-09
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly			// FixIn: 9.9.0.15.

//INFO: KEY_FOR_REPLACE:        'modal_search_options'

	// =====================================================================================================================
	//  Load JS files at  specific pages only
	// =====================================================================================================================

	/**
	 * Load JS files.
	 *
	 * @param $hook		'post.php' | 'wp-booking-calendar3_page_wpbc-resources'
	 *
	 * @return void
	 */
	function wpbc_register_js__modal_search_options( $hook ) {

		if ( wpbc_can_i_load_on_this_page__modal_search_options() ) {

			wpbc_load_js__required_for_modals();
			wpbc_load_js__required_for_media_upload();

			wp_enqueue_script( 'wpbc_ui__modal_search_options', WPBC_PRO_PLUGIN_URL . '/inc/_bl/search/ui_modal__search/_out/ui_modal_search.js' , 	array( 'jquery' ), WPBC_PRO_VERSION_NUM, array( 'in_footer' => WPBC_PRO_JS_IN_FOOTER ) );      // FixIn: 9.8.6.1.
			wp_enqueue_script( 'wpbc-admin-support', 			wpbc_plugin_url( '/core/any/js/admin-support.js' ), 							array( 'jquery' ), WPBC_PRO_VERSION_NUM, array( 'in_footer' => WPBC_PRO_JS_IN_FOOTER ) );		// Required for sending dismiss requests	// FixIn: 9.9.0.42.
		}
	}
	add_action( 'admin_enqueue_scripts', 'wpbc_register_js__modal_search_options'  );


	// =====================================================================================================================
	//  Load wp Templates
	// =====================================================================================================================

	/**
	 * On WordPress Init, define load of  "WP Util,  that  support wp.template"  and define Templates at Footer
	 *
	 * @return void
	 */
	function wpbc_templates__init_hook__modal_search_options(){

		if ( wpbc_can_i_load_on_this_page__modal_search_options() ) {

			// Load: WP Util,  that  support wp.template,  based on underscore _.template system
			wp_enqueue_script( 'wp-util' );

			// Load: Templates
			add_action( 'admin_footer', 'wpbc_templates__modal_search_options__write_templates', 10, 2 );
			add_action( 'admin_footer', 'wpbc_templates__modal_search_options__for_resource_table__write_templates', 10, 2 );
		}
	}
	add_action( 'init', 'wpbc_templates__init_hook__modal_search_options' );   								// Define init hooks


	/**
	 * Write Templates at the footer
	 *
	 * // ==============================================================================================================
	 *  Info:  E X A M P L E   of   Template Usage
	 *
	 *  Template(s), that loaded        in Footer        defined in        wpbc_templates__init_hook__shortcode_config()
	 *
	 *       add_action( 'admin_footer', 'wpbc__template__shortcode_config_booking__EXAMPLE', 10, 2 );
	 *
	 *  Help doc for use templates:
	 *     1.  JavaScript:                <# console.log( 'JS from  template' ); #>
	 *     2.  Escaped data:            {{ data.shortcode_config_2 }}
	 *     2.  Not escaped - HTML data:    {{{ data.shortcode_config_2 }}}
	 */
	function wpbc_templates__modal_search_options__write_templates(){

		// Templates here
		?><script type="text/html" id="tmpl-wpbc_modal_search_options__filters">
			<# _.each( data.filter_options, function ( p_val, p_id, p_data_arr ){ #>
			<div class="ui_group  	ui_group__modal_search_options__filter">
				<div class="ui_element">
					<input type="text" autocomplete="off"
						   name="modal_search_options__field_name"
						   value="{{ p_val.filter_name }}" placeholder="filter_name"
						   class="regular-text wpbc_dates_conditions_value_weekday" style="font-weight:600;">
				</div>
				<div class="ui_element">
					<select autocomplete="off"
							name="modal_search_options__field_operation" >
						<option value="=" <# if ( '=' === p_val.filter_operation ){ #> selected="selected" <# } #>  >=</option>
						<option value=">" <# if ( '>' === p_val.filter_operation ){ #> selected="selected" <# } #>  >&gt;</option>
						<option value="<" <# if ( '<' === p_val.filter_operation ){ #> selected="selected" <# } #>  >&lt;</option>
						<option value=">=" <# if ( '>=' === p_val.filter_operation ){ #> selected="selected" <# } #>  >&gt;=</option>
						<option value="<=" <# if ( '<=' === p_val.filter_operation ){ #> selected="selected" <# } #>  >&lt;=</option>
						<option value="contain" <# if ( 'contain' === p_val.filter_operation ){ #> selected="selected" <# } #>  ><?php echo esc_html( __( 'Contain', 'booking' ) ); ?></option>
					</select>
				</div>
				<div class="ui_element">
					<input type="text" autocomplete="off"
						   name="modal_search_options__field_value"
						   value="{{ p_val.filter_value }}" placeholder="10"
						   class="regular-text wpbc_dates_conditions_value_weekday" style="font-weight:400;">
				</div>
				<div class="ui_element">
					<a href="javascript:void(0);" onclick="javascript:wpbc_modal_search_options__delete_current( this );"
					   class="wpbc_ui_control wpbc_ui_button wpbc_ui_button_danger tooltip_top button-secondary button wpbc_vd_delete_button"
					   data-original-title="Delete"><i class="wpbc_icn_close"></i></a>
				</div>
			</div>
			<# } ); #>
		</script><?php

		// JS to Load template into page DOM  - HTML
		?>
		<script type="text/javascript">
			jQuery( document ).ready( function (){
				wpbc_modal_search_options__show_fields_with_data( { 'filter_options': [] } );
			});
		</script>
		<?php
	}


	function wpbc_templates__modal_search_options__for_resource_table__write_templates(){

		// Templates here
		?><script type="text/html" id="tmpl-wpbc_resource_table_search_options__filters">
			<# _.each( data.filter_arr, function ( p_val, p_id, p_data_arr ){ #>
				<div class="search_filter__row">
					<div class="search_filter__col__name">{{p_val.filter_name}}</div>
					<div class="search_filter__col__values">
						<div class="search_filter__value_pairs">
							<div class="search_filter__operation">{{p_val.filter_operation}}</div>
							<div class="search_filter__value">{{p_val.filter_value}}</div>
						</div>
					</div>
				</div>
			<# } ); #>
		</script><?php
	}

// =====================================================================================================================
//  M o d a l    C o n t e n t
// =====================================================================================================================
/**
 * Structure of Modal Content  - by  default echo  at  footer
 * @return false|void
 */
function wpbc_modal_search_options__content() {

	if ( ! wpbc_can_i_load_on_this_page__modal_search_options() ) {
		return  false;
	}

    ?><span class="wpdevelop wpbc_page"><div class="visibility_container clearfix-height" style="display:block;"><?php
    ?><div id="wpbc_modal__search_options" class="modal wpbc_popup_modal wpbc_modal__search_options" tabindex="-1" role="dialog">
          <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">
						<span>WP Booking Calendar</span>
						<span style="padding: 0 1em;"> / </span>
						<span> <?php esc_html_e( 'Search Filters', 'booking' ); ?></span></h4>
                </div>
                <div class="modal-body">

					<div class="wpbc_settings_flex_container">

						<div class="wpbc_settings_flex_container_left" style="flex: 1 1 150px;">
							<?php
								wpbc_modal_search_options__navigation_panel();
							?>
						</div>
						<div class="wpbc_settings_flex_container_right">
							<div class="wpbc_sc_container__all_shortcodes">
								<input name="wpbc_shortcode_type" id="wpbc_shortcode_type" value="booking" autocomplete="off" type="hidden" />
								<?php

								// Search Filter Options ---------------------------------------------------------------
								wpbc_modal_search_options__content__filters();

								?>
							</div>
							<input name="wpbc_text_gettenberg_section_id" id="wpbc_text_gettenberg_section_id" type="text" style="display: none;" />
						</div>
					</div>

                </div>
                <div class="modal-footer" style="text-align:center;">
					<div class="wpbc_shortcode_config_content_toolbar__container">
						<div class="wpbc_shortcode_config_content_toolbar__insert" style="border-left: 0px solid #ccc;margin-left: auto;">
							<a href="javascript:void(0)" class="button button-primary"
							   onclick="javascript:wpbc_modal_search__send_to_resource( wpbc_get__modal_search_options__implode() );wpbc_modal_search__hide();" ><?php esc_html_e( 'Ok', 'booking' ); ?></a>
						</div>
						<div class="wpbc_shortcode_config_content_toolbar__reset" style="margin-left: 10px;">
							<a href="javascript:void(0)" class="button button-secondary"
							   onclick="javascript:wpbc_modal_search__hide();"  ><?php esc_html_e( 'Cancel', 'booking' ); ?></a>
						</div>
						<input type="hidden" id="wpbc_modal_search__resource_id"  name="wpbc_modal_search__resource_id" value="" />
					</div>
               </div>
            </div><!-- /.modal-content -->
          </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <?php
    ?></div></span><?php

}

add_action( 'admin_footer', 'wpbc_modal_search_options__content' );            // Modal Content



// =====================================================================================================================
//  Left Navigation Panel
// =====================================================================================================================

/**
 * Left Vertical Navigation panel
 * @return void
 */
function wpbc_modal_search_options__navigation_panel(){

	?>
	<div class="wpbc_settings_navigation_column wpbc_shortcode_config_navigation_column">
		<div id="wpbc_modal_search_options__nav_tab__search_filters" class="wpbc_settings_navigation_item wpbc_settings_navigation_item_active">
			<a onclick="javascript:wpbc_shortcode_config_click_show_section(this,'#wpbc_sc_container__shortcode_search_filters', 'booking' );" href="javascript:void(0);">
				<span><?php esc_html_e( 'Search Filters', 'booking' ) ?></span>
			</a>
		</div>
		<div id="wpbc_modal_search_options__nav_tab__search_help" class="wpbc_settings_navigation_item wpbc_navigation_sub_item wpbc_navigation_top_border">
			<a href="https://wpbookingcalendar.com/faq/search-availability-setup" target="_blank" style="text-decoration: underline;text-decoration-style: dotted;text-underline-offset: 4px;text-decoration-thickness: 1px;">
				<span><?php esc_html_e( 'Help', 'booking' ) ?></span>
				<span class="tooltip_top wpbc-bi-question-circle0 wpbc-bi-arrow-up-right-square" style="margin-left: auto;"></span>
			</a>
		</div>
	</div>
	<?php
}

// =====================================================================================================================
//  Content
// =====================================================================================================================

/**
 * Content for Modal of Search Options
 *
 * @return void
 */
function wpbc_modal_search_options__content__filters() {

	$shortcode_name = 'search_filters';

	?><div id="wpbc_sc_container__shortcode_<?php echo esc_attr( $shortcode_name ); ?>" class="wpbc_sc_container__shortcode wpbc_sc_container__shortcode_<?php echo esc_attr( $shortcode_name ); ?>"><?php

		wpbc_modal_search_options__filters__top_tabs();

		// 'Conditional Days Selection' --------------------------------------------------------------------------------
		?><div class="wpbc_sc_container__shortcode_section wpbc_sc_container__shortcode_section__<?php echo esc_attr( $shortcode_name ); ?>"><?php

			?><div class="clear" style="height:15px;"></div><?php

			//wpbc_shortcode_config_fields__dates_conditions_toolbar();						// TOOLBAR

			?><div class="wpbc_sc_container__shortcode_subsection wpbc_sc_container__shortcode_subsection__weekdays_conditions">
				<?php
					wpbc_modal_search_options__content__filters_config( $shortcode_name . 'wpbc_select_day_weekday', $shortcode_name );
				?>
			</div><?php

		?></div><?php

	?></div><?php

	wpbc_clear_div();
}


	/**
	 * Top Tabs for Modal of Search Options
	 * @return void
	 */
	function wpbc_modal_search_options__filters__top_tabs(){

		$shortcode_name = 'search_filters';

		wpbc_bs_toolbar_tabs_html_container_start();

			$js = "jQuery(this).parents( '.wpbc_sc_container__shortcode' ).find( '.nav-tab' ).removeClass('nav-tab-active');"
				. "jQuery(this).addClass('nav-tab-active');"
				. "jQuery('.nav-tab i.icon-white').removeClass('icon-white');"
				. "jQuery('.nav-tab-active i').addClass('icon-white');"
				. "jQuery('.wpbc_sc_container__shortcode_" . $shortcode_name . " .wpbc_sc_container__shortcode_section').hide();";

			wpbc_bs_display_tab(   array(
							'title'         => __('Search Filter Options', 'booking')
							// , 'hint' => array( 'title' => __('Manage bookings' ,'booking') , 'position' => 'top' )
							, 'onclick'     =>  $js . "jQuery('.wpbc_sc_container__shortcode_" . $shortcode_name . " .wpbc_sc_container__shortcode_section__search_filters').show();"
							, 'font_icon'   => 'wpbc_icn_search'
							, 'default'     => true
			) );
//			wpbc_bs_display_tab(   array(
//							'title'         => __('Advanced', 'booking')
//							// , 'hint' => array( 'title' => __('Manage bookings' ,'booking') , 'position' => 'top' )
//							, 'onclick'     =>  $js . "jQuery('.wpbc_sc_container__shortcode_" . $shortcode_name . " .wpbc_sc_container__shortcode_section__other').show();"
//							, 'font_icon'   => 'wpbc_icn_tune'
//							, 'default'     => false
//
//			) );

		wpbc_bs_toolbar_tabs_html_container_end();
	}


	/**
	 * Week Days - Condition fields for 'option' parameter.
	 *
	 * @param $id
	 * @param $group_key
	 *
	 * @return void
	 */
	function wpbc_modal_search_options__content__filters_config( $id , $group_key ){

		//--------------------------------------------------------------------------------------------------------------
		// 'Upgrade to Pro' widget
		//--------------------------------------------------------------------------------------------------------------
		$upgrade_content_arr = wpbc_get_upgrade_widget( array(
								'id'                 => $id . '_' . 'conditional_days_weekdays',
								'dismiss_css_class'  => '.wpbc_dismiss__conditional_days',
								'blured_in_versions' => array( 'free', 'ps', 'bs' ),
								'feature_link'       => array( 'title' => 'feature', 'relative_url' => 'overview/#advanced-days-selection' ),
								'upgrade_link'       => array( 'title' => 'Upgrade to Pro', 'relative_url' => 'features/#bk_news_section' ),
								'versions'           => 'Business Medium / Large, MultiUser versions',
								'css'                => 'transform: translate(0) translateY(120px);'
							) );
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $upgrade_content_arr['content'];

		//--------------------------------------------------------------------------------------------------------------
		// Conditions for Weekdays selection
		//--------------------------------------------------------------------------------------------------------------
		?><div class="wpbc_shortcode_config__rules_container wpbc_dismiss__conditional_days <?php echo esc_attr( $upgrade_content_arr['maybe_blur_css_class'] ); ?>">

			<div class="wpbc_shortcode_config__rules__params_section 		wpbc_select_day_weekday">

				<div class="wpbc_ajx_toolbar wpbc_no_background wpbc_buttons_row">
					<div class="ui_container ui_container_mini 		ui_container_weekdays"><?php

						// For templates
						?><div id="wpbc_modal_search_options__run_template"></div><?php

					?></div>
				</div>

				<div class="wpbc_ajx_toolbar wpbc_no_background wpbc_buttons_row">
					<div class="ui_container ui_container_mini">
						<div class="ui_group"><?php

							?><div class="ui_element">
								<a href="javascript:void(0)"
								   onclick="javascript:wpbc_modal_search_options__add_new( this );"
								   class="button button-secondary"><i class="menu_icon icon-1x wpbc_icn_add"></i> <?php esc_html_e( 'Add New', 'booking' ); ?></a>
							</div><?php

						?>
						</div>
					</div>
				</div>

			</div>

			<div class="wpbc_shortcode_config__rules__help_section">
				<div class="wpbc-settings-notice notice-info notice-header">
					<span><?php esc_html_e( 'Customize specific criteria to refine search results', 'booking' ); ?></span>
				</div>
				<div class="wpbc-settings-notice notice-info notice-list">
					<ol>
						<li>
							<?php esc_html_e( "Define search filter parameters, allowing users to easily find relevant booking resources based on their preferences.", 'booking' ); ?>
						</li>
						<li>
							<?php
							echo '<strong>' . esc_html__( 'Example', 'booking' ) . ': </strong>'
											. '<br><code>max_capacity <= 3</code>'
											. '<br><code>location = Spain</code>'
											. '<br><code>category_type = apartment</code>'
											. '<br><code>amenity = parking</code>';
							?>
						</li>
						<li>
							<?php
							/* translators: 1: ... */
							echo wp_kses_post( sprintf(	__( 'Check the FAQ for details on %1$ssearch form configuration%2$s.' , 'booking' )
									, '<a href="https://wpbookingcalendar.com/faq/search-availability-setup" target="_blank">', '</a>'
								  ) );
							?>
						</li>
					</ol>
				</div>
			</div>
		</div><?php

	}
