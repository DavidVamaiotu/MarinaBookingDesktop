    /**
     * RESOURCES PAGE: Open TinyMCE Modal */
    function wpbc_modal_search_options__open( resource_id ) {

        // FixIn: 9.0.1.5.
        jQuery('#wpbc_modal__search_options').wpbc_my_modal({
            keyboard: false
          , backdrop: true
          , show: true
        });

        var data_arr = wpbc_get__modal_search_options__parse( jQuery( '#booking_resource_options_' + resource_id ).val() );

        wpbc_modal_search_options__show_fields_with_data( {'filter_options': data_arr} );

        jQuery( '#wpbc_modal_search__resource_id' ).val( resource_id );
    }

    function wpbc_modal_search__hide(){
        // Close modal
        if ( 'function' === typeof( jQuery('#wpbc_modal__search_options').wpbc_my_modal ) ){
            jQuery( '#wpbc_modal__search_options' ).wpbc_my_modal( 'hide' );
            jQuery( '#wpbc_modal_search__resource_id' ).val( '' );
        }
    }


    /**
     * Parse data from  TEXTAREA into array  of Objects
     *
     * @param data_str      =   'booking_tv^=^"yes"~booking_tv^=^Sony\'~booking_pets^=^false';
     * @returns {*}
     */
    function wpbc_get__modal_search_options__parse( data_str ){

        var filter_options_arr = [];

        var data_arr = data_str.split( '~' );
        for ( var j = 0; j < data_arr.length; j++ ){

            var my_form_field = data_arr[ j ].split( '^' );

            var filter_name = ('undefined' !== typeof (my_form_field[ 0 ])) ? my_form_field[ 0 ] : '';
            var filter_operation = ('undefined' !== typeof (my_form_field[ 1 ])) ? my_form_field[ 1 ] : '='
            var filter_value = ('undefined' !== typeof (my_form_field[ 2 ])) ? my_form_field[ 2 ] : ''

            filter_options_arr.push(
                                        {
                                            'filter_name'     : filter_name,
                                            'filter_operation': filter_operation.replaceAll('&gt;','>').replaceAll('&lt;','<'),
                                            'filter_value'    : filter_value
                                        }
                                   );
        }

        return filter_options_arr;
    }

    /**
     * Get array data from Modal configuration
     * @returns {*[]}  array
     */
    function wpbc_get__modal_search_options__get_filters_in_modal_as_arr(){

        var j_options_arr = jQuery( '#wpbc_modal_search_options__run_template').find('.ui_group__modal_search_options__filter');

        var filter_options_arr = [];

        j_options_arr.each(function( index ) {

            var filter_name = jQuery( this ).find( 'input[name^="modal_search_options__field_name"]' ).val().replaceAll( '~', '' ).replaceAll( '^', '' );
            var filter_operation = jQuery( this ).find( 'select[name^="modal_search_options__field_operation"]' ).val().replaceAll( '~', '' ).replaceAll( '^', '' );
            var filter_value = jQuery( this ).find( 'input[name^="modal_search_options__field_value"]' ).val().replaceAll( '~', '' ).replaceAll( '^', '' );

            if ( ('' !== filter_name) && ('' !== filter_value) ){

                filter_options_arr.push(
                                            {
                                                'filter_name'     : filter_name,
                                                'filter_operation': filter_operation,
                                                'filter_value'    : filter_value
                                            }
                                       );
            }

        });

        return filter_options_arr;
    }


    /**
     * Implode all data from Modal configuration  into the String
     *
     * @returns {*}   =   'booking_tv^=^"yes"~booking_tv^=^Sony\'~booking_pets^=^false';
     */
    function wpbc_get__modal_search_options__implode(){

        var filter_options_arr = wpbc_get__modal_search_options__get_filters_in_modal_as_arr();

        var filter_options_str=[];
        for ( var j = 0; j < filter_options_arr.length; j++ ){

            filter_options_str.push( filter_options_arr[ j ][ 'filter_name' ] + '^' +
                                     filter_options_arr[ j ][ 'filter_operation' ] + '^' +
                                     filter_options_arr[ j ][ 'filter_value' ]
                                    );
        }
        filter_options_str = filter_options_str.join( '~' );

        return filter_options_str;
    }

    /**
     * Move configured STR parameters from  Modal  to  TEXTAREA in  Resource Table
     * @param data_str
     */
    function wpbc_modal_search__send_to_resource( data_str ){
        var resource_id = jQuery( '#wpbc_modal_search__resource_id' ).val();
        resource_id = parseInt( resource_id );
        jQuery( '#booking_resource_options_' + resource_id ).val( data_str );


        var template__wpbc_resource_table_search_options__filters = wp.template( 'wpbc_resource_table_search_options__filters' );
        jQuery( '#div_booking_resource_search_options_' + resource_id ).html(
                                                                                template__wpbc_resource_table_search_options__filters(
                                                                                    { 'filter_arr': wpbc_get__modal_search_options__get_filters_in_modal_as_arr() }
                                                                                )
                                                                            );
    }

    /**
     * Show Generated Template "Search Option Filters" with filled data
     * @param data_arr
     */
    function wpbc_modal_search_options__show_fields_with_data( data_arr ){

        var template__wpbc_modal_search_options__filters = wp.template( 'wpbc_modal_search_options__filters' );

        jQuery( '#wpbc_modal_search_options__run_template' ).html( template__wpbc_modal_search_options__filters( data_arr ) );
    }

    /**
     * Add New filter option
     */
    function wpbc_modal_search_options__add_new(){

        var template__wpbc_modal_search_options__filters = wp.template( 'wpbc_modal_search_options__filters' );

        jQuery( '#wpbc_modal_search_options__run_template' ).append(
                                                                    template__wpbc_modal_search_options__filters( {
                                                                                                                    'filter_options': [
                                                                                                                                        {
                                                                                                                                            'filter_name'     : '',
                                                                                                                                            'filter_operation': '=',
                                                                                                                                            'filter_value'    : ''
                                                                                                                                        }
                                                                                                                                      ]
                                                                                                                } )
                                                                   );

    }


    /**
     * Delete ONE current filter option
     */
    function wpbc_modal_search_options__delete_current( _this ){

        jQuery( _this ).parents('.ui_group__modal_search_options__filter').remove();
    }