<?php
/**
 * @version     1.0
 * @package     New Search Availability Engine
 * @category    Search Availability
 * @author      wpdevelop
 *
 * @web-site    https://wpbookingcalendar.com/
 * @email       info@wpbookingcalendar.com
 * @modified    2024-05-01
 *
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

// KEY: 'wpbc_search_avy'                                                       // FixIn: 10.0.0.37.

/**
 *  == Ajax & GET ==  Search Request:
 * Ajax:
 *
 * Get:
 *
 */

// ---------------------------------------------------------------------------------------------------------------------
// Ajax request to Start Searching
// ---------------------------------------------------------------------------------------------------------------------
function wpbc_ajax_start_searching(){

	ob_start();

	wpbc_search_avy__show_search_results();                                                                             // FixIn: 10.0.0.37.

	$search_results_to_show = ob_get_clean();

	wp_send_json( array(
		'ajx_data_search_content' => $search_results_to_show,
		'ajx_search_params'       => $_REQUEST,  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
	) );
}


// ---------------------------------------------------------------------------------------------------------------------
// Search Availability Engine
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Get Filtered Sanitized       Search Request parameters       from $_GET  or  $_REQUEST
 *
 * @return array - $filtered_search_request = [
 *                                                [search__check_in_ymd]  => 2024-05-10
 *                                                [search__check_out_ymd] => 2024-05-16
 *                                                [search__quantity]      => 1
 *                                                [search__time]          => ''
 *                                                [search__extend]        => 0
 *                                                [search__users_id]      => ''
 *                                                [search__custom_params] =>  [
 *                                                                                [booking_location] => ''
 *                                                                                [max_visitors]     => ''
 *                                                                            ]
 *                                            ]
 */
function wpbc_search_avy__get_search_params(){

	$filtered_search_request_params = array(
											'search__check_in_ymd'  => '',
											'search__check_out_ymd' => '',
											'search__quantity'      => 1,
											'search__time'          => '',
											'search__extend'        => 0,
											'search__users_id'      => '',
											'search__custom_params' => array()
										);
	if (  is_admin() && ( defined( 'DOING_AJAX' ) ) && ( DOING_AJAX )  ) {
		/**
		 * AJX $_REQUEST = [
		 *                    action    "BOOKING_SEARCH"
		 *                    wpdev_active_locale    "en_US"
		 *                    wpbc_nonce    "44f6a2d34a"
		 *
		 *                    search_ajx__check_in_ymd    "2024-05-10"
		 *                    search_ajx__check_out_ymd   "2024-05-12"
		 *                    search_ajx__quantity        "2"
		 *                    search_ajx__time            ""
		 *                    search_ajx__custom_params   "text^search_field__display_check_in^10.05.2024~text^search_field__display_check_out^12.05.2024~selectbox-one^search_quantity^2~selectbox-one^booking_location^London~selectbox-one^booking_max_visitors^~checkbox^search_field__extend_search_days^3~button^^Search~hidden^wpbc_search_nonce^44f6a2d34a~hidden^_wp_http_referer^/search-availability-ajax/~"
		 *                    search_ajx__extend          "3"
		 *                    search_ajx__users_id        ""
		 *             ]
		 */
		$prefix = 'search_ajx__';
	} else {
		/**
		 * $_GET = [
		 *            search_field__display_check_in  = "10.05.2024"
		 *            search_field__display_check_out = "12.05.2024"
		 *            search_quantity                 = "2"
		 *            search_time                     = ""
		 *            booking_location                = "London"
		 *            booking_max_visitors            = ""
		 *            search_field__extend_search_days = "3"
		 *
		 *            search_get__check_in_ymd            = "2024-05-10"
		 *            search_get__check_out_ymd           = "2024-05-12"
		 *            search_get__quantity                = "2"
		 *            search_get__time                    = ""
		 *            search_get__extend                  = "3"
		 *            search_get__users_id                = ""
		 *            search_get__custom_params           = "text^search_field__display_check_in^10.05.2024~text^search_field__display_check_out^12.05.2024~selectbox-one^search_quantity^2~selectbox-one^booking_location^London~selectbox-one^booking_max_visitors^~checkbox^search_field__extend_search_days^3~submit^^Search~hidden^search_get__check_in_ymd^2024-05-10~hidden^search_get__check_out_ymd^2024-05-12~hidden^search_get__time~hidden^search_get__quantity^2~hidden^search_get__extend^3~hidden^search_get__users_id^~hidden^search_get__custom_params^~"
		 *         ]
		 */
		$prefix = 'search_get__';
	}

	if ( 1 ) {

		// -------------------------------------------------------------------------------------------------------------
		// Dates
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'check_in_ymd'] ) ){
			$filtered_search_request_params['search__check_in_ymd'] = wpbc_clean_date( $_REQUEST[ $prefix . 'check_in_ymd'] );  // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'check_out_ymd'] ) ){
			$filtered_search_request_params['search__check_out_ymd'] = wpbc_clean_date( $_REQUEST[ $prefix . 'check_out_ymd'] );  // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		}
		// Fix Date(s) if some or both was missed.
		if( 1 ){
			// If 'Check In' & 'Check Out'  not set,         then we define future date, for showing search  results for all  booking resources!
			if ( ( empty( $filtered_search_request_params['search__check_in_ymd'] ) ) && ( empty( $filtered_search_request_params['search__check_out_ymd'] ) ) ) {
				$filtered_search_request_params['search__check_in_ymd']  = '2100-01-01';
				$filtered_search_request_params['search__check_out_ymd'] = '2100-01-01';
			}
			// If 'Check In'   not set
			if (
					( ( empty( $filtered_search_request_params['search__check_in_ymd'] ) ) ||  ( '2100-01-01' === $filtered_search_request_params['search__check_in_ymd'] ) )
			     && ( ! empty( $filtered_search_request_params['search__check_out_ymd'] ) )
			){
				$filtered_search_request_params['search__check_in_ymd'] = $filtered_search_request_params['search__check_out_ymd'];
			}
			// If 'Check Out'   not set
			if (
				   ( ! empty( $filtered_search_request_params['search__check_in_ymd'] ) )
				&& ( ( empty( $filtered_search_request_params['search__check_out_ymd'] ) ) || ( '2100-01-01' === $filtered_search_request_params['search__check_out_ymd'] ) )
			){
				$filtered_search_request_params['search__check_out_ymd'] = $filtered_search_request_params['search__check_in_ymd'];
			}
		}

		// -------------------------------------------------------------------------------------------------------------
		// Quantity
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'quantity'] ) ) {
			$filtered_search_request_params['search__quantity'] = intval( $_REQUEST[ $prefix . 'quantity'] );  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			$filtered_search_request_params['search__quantity'] = empty( $filtered_search_request_params['search__quantity'] ) ? 1 : $filtered_search_request_params['search__quantity'];
		}
		// -------------------------------------------------------------------------------------------------------------
		// Search Time
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'time'] ) ) {
			$filtered_search_request_params['search__time'] = wpbc_clean_text_value( $_REQUEST[ $prefix . 'time'] );  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$filtered_search_request_params['search__time'] = empty( $filtered_search_request_params['search__time'] ) ? '' : $filtered_search_request_params['search__time'];
		} else {
			// No search  time, so  we will  check  about check in/out
			if( wpbc_is_booking_used_check_in_out_time() ) {
				$filtered_search_request_params['search__time'] = esc_attr( get_bk_option( 'booking_range_selection_start_time' ) );
				$filtered_search_request_params['search__time'] .= ' - ';
				$filtered_search_request_params['search__time'] .= esc_attr( get_bk_option( 'booking_range_selection_end_time' ) );
			}
		}
		// -------------------------------------------------------------------------------------------------------------
		// EXTENDED DAYS
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'extend'] ) ) {
			$filtered_search_request_params['search__extend'] = intval( $_REQUEST[ $prefix . 'extend'] );  // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
			$filtered_search_request_params['search__extend'] = empty( $filtered_search_request_params['search__extend'] ) ? 0 : $filtered_search_request_params['search__extend'];
		}
		// -------------------------------------------------------------------------------------------------------------
		// USERS
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( ! empty( $_REQUEST[ $prefix . 'users_id'] ) ) {
			$filtered_search_request_params['search__users_id'] = wpbc_clean_digit_or_csd( $_REQUEST[ $prefix . 'users_id'] );  // phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$filtered_search_request_params['search__users_id'] = empty( $filtered_search_request_params['search__users_id'] ) ? '' : $filtered_search_request_params['search__users_id'];
		}

		// -------------------------------------------------------------------------------------------------------------
		// Custom Params
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( isset( $_REQUEST[ $prefix . 'custom_params'] ) ) {

			// Support types:   'text' | 'selectbox-one' | 'selectbox-multiple'| 'select-multiple' | 'radio' | 'checkbox' .      Note: values for several selected options in 'select-multiple' separated by ', '
			// FixIn: 10.2.0.2.

			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$search_get__custom_params = str_replace( '_^_', '~', $_REQUEST[ $prefix . 'custom_params' ] );
			$search_request_params     = wpbc_get_parsed_booking_data_arr( $search_get__custom_params, '_DATA_TO_SKIP' );

			foreach ( $search_request_params as $search_param_arr ) {
				// Filter only visible input fields:      Only  such TYPES used for search request:
				if (
					   (   in_array( $search_param_arr['type'], array( 'text', 'select-one', 'selectbox-one', 'select-multiple', 'selectbox-multiple', 'radio', 'checkbox') ) )
					&& ( ! in_array( $search_param_arr['name'], array( 'search_field__display_check_in', 'search_field__display_check_out', 'search_quantity', 'search_time', 'search_field__extend_search_days' ) ) )
				){

					// Sanitize part value of $_REQUEST[ $prefix . 'custom_params']
					$cleaned_name  = wpbc_clean_text_value( $search_param_arr['name'] );
					$cleaned_value = wpbc_clean_text_value( $search_param_arr['value'] );

					// Set not empty names
					if ( ! empty( $cleaned_name ) ) {
						$filtered_search_request_params['search__custom_params'][ $cleaned_name ] = $cleaned_value;
					}
				}
			}
		}
    }

	return $filtered_search_request_params;
}


/**
 * Check  search  availability  based on  Ajax or $_GET request - parameters comes from  $_REQUEST | $_GET
 *
 * @param $local_params array   (Optional)   array( 'time_as_seconds_arr' => array( 0, 24 * 60 * 60 ) )
 *
 * @return array                             [    [dates_arr, resources_arr],     [dates_arr2, resources_arr2],   ...  ]
 *
 * Request:
 *
 * GET: ?search_get__check_in_ymd=2024-10-14
 *      &search_get__check_out_ymd=2024-10-17
 *      &search_get__quantity=1
 *      &search_get__time=
 *      &search_get__extend=5
 *      &search_get__users_id=
 *      &search_get__custom_params=text^search_field__display_check_in^14.10.2024~text^search_field__display_check_out^17.10.2024~selectbox-one^search_quantity^1~selectbox-one^location^~selectbox-one^max_capacity^~selectbox-one^amenity^~checkbox^search_field__extend_search_days^5~submit^^Search~hidden^search_get__check_in_ymd^2024-10-14~hidden^search_get__check_out_ymd^2024-10-17~hidden^search_get__time~hidden^search_get__quantity^1~hidden^search_get__extend^5~hidden^search_get__users_id^~hidden^search_get__custom_params^~
 *      &search_field__display_check_in=14.10.2024&search_field__display_check_out=17.10.2024&search_quantity=1&location=&max_capacity=&amenity=&search_field__extend_search_days=5
 *
 *
 * OR Ajax:       action:                        "BOOKING_SEARCH"
 *                search_ajx__check_in_ymd:      "2024-10-14"
 *                search_ajx__check_out_ymd:     "2024-10-17"
 *                search_ajx__quantity:          "1"
 *                search_ajx__time:               ""
 *                search_ajx__custom_params:     "text^search_field__display_check_in^14.10.2024~text^search_field__display_check_out^17.10.2024~selectbox-one^search_quantity^1~selectbox-one^location^~selectbox-one^max_capacity^~selectbox-one^amenity^~checkbox^search_field__extend_search_days^5~button^^Search~hidden^wpbc_search_nonce^1735821361~hidden^_wp_http_referer^/search-availability-ajax/~"
 *                search_ajx__extend:            "5"
 *                search_ajx__users_id:          ""
 *                wpdev_active_locale:           "en_US"
 *                wpbc_nonce:                    "1735821361"
 *
 * Return:             [
 *                        [
 *                          'dates_only_sql_arr' => ["2024-10-14","2024-10-15","2024-10-16","2024-10-17"],              <- main dates interval
 *                          'resource_id_arr'    => [ 2, 3, 14, 15]                                                     <- available resources for main dates
 *                          'max_availability'   => [ 2 => 1, 3 => 5, 14 => 1, 15 => 2 ]                                <- max availability per resource for these dates
 *                          'time_as_seconds_arr' => [ 0, 24 * 60 * 60]
 *                        ],
 *                        [
 *                          'dates_only_sql_arr' => ["2024-10-19","2024-10-20","2024-10-21","2024-10-22"],              <- advanced dates interval
 *                          'resource_id_arr'    => [ 4 ]                                                               <- available resources for advanced dates
 *                          'max_availability'   => [ 4 => 2 ]                                                          <- max availability per resource for these dates
 *                          'time_as_seconds_arr' => [ 0, 24 * 60 * 60]
 *                        ]
 *                     ]
 */
function wpbc_search_avy__do_search( $local_params = array() ) {

	$defaults = array(
						'time_as_seconds_arr' => array( 0, 24 * 60 * 60 )                                               //  array(  0 * 60 * 60   ,   14 * 60 * 60  );
					);
	$local_params = wp_parse_args( $local_params, $defaults );

	// -----------------------------------------------------------------------------------------------------------------
	// Get Search Params
	// -----------------------------------------------------------------------------------------------------------------
	/**
	 * Get Filtered Sanitized       Search Request parameters       from $_GET  or  $_REQUEST
	 * $search_request_params = [
	 *                    [search__check_in_ymd]  => 2024-05-10
	 *                    [search__check_out_ymd] => 2024-05-16
	 *                    [search__quantity]      => 1
	 *                    [search__time]          => ''
	 *                    [search__extend]        => 0
	 *                    [search__users_id]      => ''
	 *                    [search__custom_params] =>  [
	 *                                                    [booking_location] => ''
	 *                                                    [max_visitors]     => ''
	 *                                                 ]
	 *                  ]
	 */
	$search_request_params = wpbc_search_avy__get_search_params();


	// Searching for specific time slot
	if ( ! empty( $search_request_params['search__time'] ) ) {
		//$local_params['time_as_seconds_arr'] =
		$time_range_in_seconds     = wpbc_convert__readable_time_slot__to__time_range_in_seconds( $search_request_params['search__time'] );
		$time_range_in_seconds_arr = explode( ' - ', $time_range_in_seconds );
		$local_params['time_as_seconds_arr'][0] = intval( $time_range_in_seconds_arr[0] );
		$local_params['time_as_seconds_arr'][1] = intval( $time_range_in_seconds_arr[1] );
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Resources
	// -----------------------------------------------------------------------------------------------------------------

	//TODO: '2024-05-24 14:25'  Filter results relative to  the             $search_request_params['search__time']      ->      '10:00 - 14:00'

	// Check  if booking resources exist
	wpbc_searchable_resources_option_update__if_resource_not_exist();

	/**
	 *  Get array of searchable booking resources:
	 *
	 * [      228 => [    [is_searchable] => 'On'
	 *                    [url]           => 'http://beta/?p=4613'
	 *                    [title]         => 'Post  for Test  search  resource ID = 228'
	 *                    [description]   => 'Small - description  in excerpt  Post  for Test  search  resource ID = 228'
	 *                    [picture]       => 'http://beta/wp-content/uploads/2024/04/a5718ad.jpg'
	 *                    [options]       => 'booking_tv^=^"yes"~booking_tv^=^Sony'~booking_pets^=^false'
	 *                    [category]      => [ 0 => [
	 *                                                [category] => Uncategorized
	 *                                                [slug] => uncategorized-en
	 *                                                [ID] => 31
	 *                                            ], ...
	 *                                       ]
	 *                    [tags] => []
	 *        ], ...
	 * ]
	 */
	$saved_search_filters_arr = wpbc_searchable_resources__get_all_options();

	//----------------------------------------------------------------------------------
	// Filter SEARCHABLE ON  resources, which fit  to  custom params            ->  [231, 237]
	//----------------------------------------------------------------------------------
	$local_params['resource_id'] = array();
	foreach ( $saved_search_filters_arr as $resource_id => $search_arr ) {

		if ( 'On' === $saved_search_filters_arr[ $resource_id ]['is_searchable'] ) {

			// Check Custom Params
			$is_fit_resource = wpbc_search_avy__is_fit_resource___to_custom_params( $saved_search_filters_arr[ $resource_id ]['options'], $search_request_params['search__custom_params'] );
			if ( $is_fit_resource ) {
				$local_params['resource_id'][] = $resource_id;
			}
		}
	}

	//----------------------------------------------------------------------------------
	// Filter  booking resources  by user ID                                    ->  [231, 237]
	//----------------------------------------------------------------------------------
	if ( ! empty($search_request_params['search__users_id']) ){
		$local_params['resource_id'] = wpbc_search_avy__filter_resource___by_user_id( $local_params['resource_id'], $search_request_params['search__users_id'] );
	}



	// -----------------------------------------------------------------------------------------------------------------
	// Array  of Date(s)  (extended).
	// -----------------------------------------------------------------------------------------------------------------
	$search__check_in_ymd               = $search_request_params['search__check_in_ymd'];
	$search__check_out_ymd              = $search_request_params['search__check_out_ymd'];
	$local_params['dates_only_sql_arr'] = wpbc_get_dates_array_from_start_end_days( $search__check_in_ymd, $search__check_out_ymd );

	// -----------------------------------------------------------------------------------------------------------------
	// Original Dates Search
	// -----------------------------------------------------------------------------------------------------------------
	// Get filtered available booking resources for specific:  dates | times | quantity     ->    [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
	$resources_fit_quantity = wpbc_search_avy__search_available_in(
																$local_params['resource_id'],                           // [230, 237]
																$local_params['dates_only_sql_arr'],                    // ['2024-05-11','2024-05-12','2024-05-13']
																$search_request_params['search__quantity'],             // 1
																$local_params['time_as_seconds_arr']                    // array(0, 24 * 60 * 60 )
															);
	$resources_fit_quantity_extended_arr = array();
	$resources_fit_quantity_id_arr = array_keys( $resources_fit_quantity );
	$resources_fit_quantity_extended_arr[] =  array(
													'dates_only_sql_arr'  => $local_params['dates_only_sql_arr'],
													'resource_id_arr'     => $resources_fit_quantity_id_arr,
													'max_availability'    => $resources_fit_quantity,
													'time_as_seconds_arr' => $local_params['time_as_seconds_arr']
												);


	// -----------------------------------------------------------------------------------------------------------------
	// Extended Days:
	// -----------------------------------------------------------------------------------------------------------------
	$extended_days_intervals_arr = ( ! empty( $search_request_params['search__extend'] ) )
									? wpbc_search_avy__get_extended_days_intervals( $search_request_params['search__extend'], $search__check_in_ymd, $search__check_out_ymd )
									: array();
	$new_resources_to_search_in__arr = array_diff( $local_params['resource_id'], $resources_fit_quantity_id_arr );

	if (! empty($new_resources_to_search_in__arr)){
		foreach ( $extended_days_intervals_arr as $ext_days_intervals_arr ) {

			// Get filtered available booking resources for specific:  dates | times | quantity     ->    [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
			$resources_fit_quantity_ext = wpbc_search_avy__search_available_in(
																		$new_resources_to_search_in__arr,                       // [230, 237]
																		$ext_days_intervals_arr,                                // ['2024-05-11','2024-05-12','2024-05-13']
																		$search_request_params['search__quantity'],             // 1
																		$local_params['time_as_seconds_arr']                    // array(0, 24 * 60 * 60 )
																	);
			$resources_fit_quantity_ext_id_arr = array_keys( $resources_fit_quantity_ext );

			if ( ! empty( $resources_fit_quantity_ext_id_arr ) ){
				$resources_fit_quantity_extended_arr[] = array(
																'dates_only_sql_arr'  => $ext_days_intervals_arr,
																'resource_id_arr'     => $resources_fit_quantity_ext_id_arr,
																'max_availability'    => $resources_fit_quantity_ext,
																'time_as_seconds_arr' => $local_params['time_as_seconds_arr']
															);
				$new_resources_to_search_in__arr = array_diff( $new_resources_to_search_in__arr, $resources_fit_quantity_ext_id_arr );
			}
			if ( empty( $new_resources_to_search_in__arr ) ) {
				break;
			}
		}
	}
	// -----------------------------------------------------------------------------------------------------------------

	return $resources_fit_quantity_extended_arr;
}


/**
 * Get filtered available booking resources for specific:  dates | times | quantity
 *
 * @param $resource_id_arr          [230, 237]
 * @param $dates_only_sql_arr       ['2024-05-11','2024-05-12','2024-05-13']
 * @param $search__quantity         =   1
 * @param $time_as_seconds_arr      =   array(0, 24 * 60 * 60 )   ||  array(0, 86400 )
 *
 * @return array                -> [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
 */
function wpbc_search_avy__search_available_in( $resource_id_arr, $dates_only_sql_arr, $search__quantity = 1, $time_as_seconds_arr = array( 0, 86400 ) ){

    // -----------------------------------------------------------------------------------------------------------------
	// Get for each resource array  of child booking resources,  if it parents booking resources:       [  231 => [ 232, 233, 234, 235 ], 237 => [],  238 => []  ]
	// -----------------------------------------------------------------------------------------------------------------
	$support_child_arr__for_resources = wpbc_get_children_arr_for_resources( $resource_id_arr );


	// -----------------------------------------------------------------------------------------------------------------
	// DO AVAILABILITY SEARCH
	// -----------------------------------------------------------------------------------------------------------------
	$maybe_extended__dates_to_check_arr = $dates_only_sql_arr;
	if ( function_exists( 'wpbc__extend_checking_dates_range__if_used__extra_seconds__before_after' ) ) {
		// If we are using the unavailable before/after booking dates,  then we need to extend "$dates_only_sql_arr" to such  dates.
		$maybe_extended__dates_to_check_arr = wpbc__extend_checking_dates_range__if_used__extra_seconds__before_after( $dates_only_sql_arr );
	}
	//// [ "dates": [ "2023-11-05": [ "day_availability":4, ... "2": [ "is_day_unavailable":false, ...]], '2023-11-06':[...] ] ,"resources_id_arr__in_dates":[2,12,10,11]}
	$server_request_uri = ( ( isset( $_SERVER['REQUEST_URI'] ) ) ? sanitize_text_field( $_SERVER['REQUEST_URI'] ) : '' );  /* phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.MissingUnslash */ /* FixIn: sanitize_unslash */
	$server_http_referer_uri = ( ( isset( $_SERVER['HTTP_REFERER'] ) ) ? sanitize_text_field( $_SERVER['HTTP_REFERER'] ) : '' );  /* phpcs:ignore WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.MissingUnslash */ /* FixIn: sanitize_unslash */
	$availability_per_days = wpbc_get_availability_per_days_arr( array(
																		'resource_id'         => $resource_id_arr,
																		'skip_booking_id'     => '',
																		'dates_to_check'      => $maybe_extended__dates_to_check_arr,
																		'request_uri'         => ( ( ( defined( 'DOING_AJAX' ) ) && ( DOING_AJAX ) ) ? $server_http_referer_uri : $server_request_uri ), //  front-end: $server_request_uri | ajax: $server_http_referer_uri                      // It different in Ajax requests. It's used for change-over days to detect for exception at specific pages
																		'as_single_resource'  => false,     // default FALSE  ::  get dates as for 'single resource' or 'parent' resource including bookings in all 'child booking resources'
																		'additional_bk_types' => array(),
																		//'aggregate_type'      => $local_params['aggregate_type'],
																	    'custom_form'         => ''                     //FixIn: 10.0.0.10       // Required for checking all available time-slots and compare with  booked time slots
																	) );

	// -----------------------------------------------------------------------------------------------------------------
	// Unset additional  dates,  if was used option: 'extra_seconds__before_after'
	// -----------------------------------------------------------------------------------------------------------------
	if ( $maybe_extended__dates_to_check_arr != $dates_only_sql_arr ) {

		$dates_to_unset = array_diff( $maybe_extended__dates_to_check_arr, $dates_only_sql_arr );

		foreach ( $dates_to_unset as $date_ymd ) {
			if ( isset( $availability_per_days['dates'][ $date_ymd ] ) ) {
				unset( $availability_per_days['dates'][ $date_ymd ] );
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Get Max Availability by  Dates                           ->       [ 231 => [   2024-05-10 => [ 231=1, 232=1, 233=1, 234=1, 235=1 ], ... ] ,... ]
	// -----------------------------------------------------------------------------------------------------------------
	/**
	 *    $resources_availability_in_dates -> [
	 *                                      231 = [
	 *                                              2024-05-10 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                              2024-05-11 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                      237 = [
	 *                                              2024-05-10 = [ 237 = 1  ]
	 *                                              2024-05-11 = [ 237 = 1  ]
	 *                                            ]
	 *                                   ]
	 */
	$resources_availability_in_dates  = wpbc_search_avy__get_resources__availability( $availability_per_days , $support_child_arr__for_resources, $time_as_seconds_arr );

	// -----------------------------------------------------------------------------------------------------------------
	// Get value of how many  booking resources to  book        ->       [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
	// -----------------------------------------------------------------------------------------------------------------
	$resources_fit_quantity = wpbc_search_avy__filter_resources_on_quantity( $resources_availability_in_dates, $search__quantity );

	return $resources_fit_quantity;
}

	// -----------------------------------------------------------------------------------------------------------------
	// SUPPORT (Search encapsulated functions)
	// -----------------------------------------------------------------------------------------------------------------

	/**
	 * Get resources availability  by  dates  in each single/child resources
	 *
	 * @param $availability_per_days  ->                   [
     *														    [aggregate_resource_id_arr] => []
	 *														    [dates] => [
	 *																            [2024-05-10] => [
	 *																							                    [day_availability]  => 5
	 *																							                    [max_capacity]      => 5
	 *																							                    [statuses]          => [ ... ]
	 *																							                    [summary]           => [ ... ]
	 *																                    [237] => stdClass Object (
	 *																                            [is_day_unavailable]    =>
	 *																                            [_day_status]           => available
	 *																                            [pending_approved]      => []
	 *																                            [tooltips]              => [ ... ]
	 *																                            [booked_time_slots]     => [
	 *																					                                    [in_seconds] => []
	 *																					                                    [readable24h] => []
	 *																					                                    [merged_seconds] => []
	 *																					                                    [merged_readable] => []
	 *																					                                ]
	 *																                            [date_cost_rate] => 0
	 *																                        )
	 *																                   [238] => stdClass Object(...)
	 *																            [2024-05-11] => [ ... ]
	 *																            , ....
	 *																	   ],
	 *														    [resources_id_arr__in_dates] => [ 237, 238, 231, 232, 233, 234, 235 ]
	 *														]
	 *
	 * @param $support_child_arr__for_resources ->  [  231 => [ 232, 233, 234, 235 ], 237 => [],  238 => []  ]      Array of children resources
	 *
	 * @return array
	 *    $resources_max_availability -> [
	 *                                      231 = [
	 *                                              2024-05-10 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                              2024-05-11 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                      237 = [
	 *                                              2024-05-10 = [ 237 = 1  ]
	 *                                              2024-05-11 = [ 237 = 1  ]
	 *                                            ]
	 *                                   ]
	 */
	function wpbc_search_avy__get_resources__availability( $availability_per_days , $support_child_arr__for_resources , $time_as_seconds_arr = array( 0, 86400 ) ){

        // Shift time interval  in 30 seconds
		$shift__30sec = array( 30, 30 );
        $time_as_seconds_arr[ 0 ] = $time_as_seconds_arr[ 0 ] + $shift__30sec[0];
        $time_as_seconds_arr[ 1 ] = $time_as_seconds_arr[ 1 ] - $shift__30sec[1];

		$resources_max_availability = array();

		foreach ( $support_child_arr__for_resources as $single_or_parent_res_id => $children__res_id_arr ) {

			$resources_max_availability[ $single_or_parent_res_id ] = array();

			$sql_class_day_number = -1;

			foreach ( $availability_per_days['dates'] as $date_ymd => $this_date_availability_arr ) {

				// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				// Duplicated part of code, as in where_to_save.php     //FixIn: 2024-05-12_11:58
				// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
				$sql_class_day_number++;

				$this_date_time_as_seconds_arr = $time_as_seconds_arr;
				if (
					   ( ! ( 'On' === get_bk_option( 'booking_recurrent_time' ) ) )
					&& ( count( $availability_per_days['dates'] ) > 1 )
				){
					if ( 0 == $sql_class_day_number ) {                                                                 // check in
						$this_date_time_as_seconds_arr[1] = 24 * 60 * 60;
						$date_shift__30sec[1]             = 0;
					} else if ( ( count( $availability_per_days['dates'] ) - 1 ) == $sql_class_day_number ) {           // check out
						$this_date_time_as_seconds_arr[0] = 0;
						$date_shift__30sec[0]             = 0;
					} else {
						$this_date_time_as_seconds_arr = array( 0, 24 * 60 * 60 );
						$date_shift__30sec             = array( 0, 0 );
					}
				}
				// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

				$resources_max_availability[ $single_or_parent_res_id ][ $date_ymd ] = array();


				$merged_seconds_arr = wpbc_get__booking_obj__merged_seconds_arr( $this_date_availability_arr[ $single_or_parent_res_id ] );

				$is_intersect = wpbc_is_intersect__merged_seconds_arr__and__seconds_arr( $merged_seconds_arr['merged_seconds'], $this_date_time_as_seconds_arr );

				$resources_max_availability[ $single_or_parent_res_id ][ $date_ymd ][ $single_or_parent_res_id ] = ( ( $is_intersect ) ? 0 : 1 );       // 0 | 1

				// Check  for all  child booking resources
				foreach ( $support_child_arr__for_resources[$single_or_parent_res_id] as $child_res_id ) {

					$merged_seconds_arr = wpbc_get__booking_obj__merged_seconds_arr( $this_date_availability_arr[ $child_res_id ] );

					$is_intersect = wpbc_is_intersect__merged_seconds_arr__and__seconds_arr( $merged_seconds_arr['merged_seconds'], $this_date_time_as_seconds_arr );

					$resources_max_availability[ $single_or_parent_res_id ][ $date_ymd ][ $child_res_id ] = ( ( $is_intersect ) ? 0 : 1 );              // 0 | 1
				}
			}
		}

		return $resources_max_availability;
	}


	/**
	 * Get only   booking resources that  have enough available capacity
	 *
	 * @param $resources_availability_in_dates      -> [
	 *                                          231 = [
	 *                                              2024-05-10 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                              2024-05-11 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
	 *                                          237 = [
	 *                                              2024-05-10 = [ 237 = 1  ]
	 *                                              2024-05-11 = [ 237 = 1  ]
	 *                                            ]
	 *                                        ]
	 * @param $how_many_items_to_book               -> 2
	 *
	 * @return array         [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
	 */
	function wpbc_search_avy__filter_resources_on_quantity( $resources_availability_in_dates, $how_many_items_to_book ) {

		/*
			$max_availability =  [
									[231] => 5
									[237] => 0
									[238] => 1
								]
		*/
		$max_availability = wpbc_search_avy__get_max_availability__per_resource( $resources_availability_in_dates );

		$resources_fit_quantity = array();
		foreach ( $max_availability as $resource_id => $max_availability ) {
			if ( $max_availability >= $how_many_items_to_book ) {

				//TODO: we need to trasfer aslo MAX_Availability ,s o need to do this:
				$resources_fit_quantity[ $resource_id ] = $max_availability;
				//$resources_fit_quantity[] = $resource_id;
			}
		}

		return $resources_fit_quantity;     // [ 231 => 1, 238 =>5 ],  where [ resource_ID => max_availability ]
	}

		/**
		 * Get Maximum availability  per resource for these dates range. Check situation, where all dates must be in one child resource  -  while enabled:
		 * 'Disable bookings in different booking resources'
		 *
		 * @param $resources_availability_in_dates               -> [
		 *                                              231 = [
		 *                                                       2024-05-10 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
		 *                                                       2024-05-11 = [ 231 = 1, 232 = 1, 233 = 1, 234 = 1, 235 = 1 ]
		 *                                              237 = [
		 *                                                       2024-05-10 = [ 237 = 1  ]
		 *                                                       2024-05-11 = [ 237 = 1  ]
		 *                                              ]
		 *                                         ]
		 *
		 * @return array = $max_availability =  [
		 *                                            [231] => 5
		 *                                            [237] => 0
		 *                                            [238] => 1
		 *                                        ]
		 *
		 *
		 */
		function wpbc_search_avy__get_max_availability__per_resource( $resources_availability_in_dates  ){

			//TODO: maybe re-update this func,  or test it more.

			$resources_fit_quantity = array();

			// == In      SAME      'child' booking resources   ============================================================
			if ( 'On' === get_bk_option( 'booking_is_dissbale_booking_for_different_sub_resources' ) ) {

				$days_count = 0;

				foreach ( $resources_availability_in_dates as $resource_id => $days_availability ) {
					$resources_fit_quantity[ $resource_id ] = array();
					$days_count = count( $days_availability );
					foreach ( $days_availability as $date_ymd => $resource_availability_arr ) {

						foreach ( $resource_availability_arr as $child_res_id => $is_available ) {
							if ( ! isset( $resources_fit_quantity[ $resource_id ][ $child_res_id ] ) ) {
								$resources_fit_quantity[ $resource_id ][ $child_res_id ] = array();
							}
							if ( $is_available ) {
								$resources_fit_quantity[ $resource_id ][ $child_res_id ][] = $date_ymd;
							}
						}

					}
				}

				$child_resources_availability = array();
				foreach ( $resources_fit_quantity as $resource_id => $days_availability_child ) {
					$child_resources_availability[$resource_id] = array();
					foreach ( $days_availability_child as $child_id => $days_available_arr ) {
						if (count($days_available_arr) == $days_count){
							$child_resources_availability[ $resource_id ][ $child_id ] = 1;
						} else {
							$child_resources_availability[ $resource_id ][ $child_id ] = 0;
						}
					}
				}
				/**
				 * $child_resources_availability = [ 231 => [         231 => 1,
				 *                                                    232 => 1,
				 *                                                    233 => 1,
				 *                                                    234 => 1,
				 *                                                    235 => 1,
				 *                                             ],
				 *                                      237 => [
				 *                                                    237 => 0,
				 *                                              ],
				 *                                      238 => [
				 *                                                   238 => 1,
				 *                                              ],
				 *                                    ]
				 */

				$child_resources_availability_max_availability = array();
				foreach ( $child_resources_availability as $resource_id => $child_res_arr_availability ) {
					$child_resources_availability_max_availability[$resource_id] = 0;
					foreach ( $child_res_arr_availability as $child_id => $is_available  ) {
						if ( $is_available ) {
							$child_resources_availability_max_availability[$resource_id]++;
						}
					}
				}

				/**
					[
					    [231] => 5
					    [237] => 0
					    [238] => 1
					]
				 */

			} else {

				foreach ( $resources_availability_in_dates as $resource_id => $days_availability ) {

					$resources_fit_quantity[ $resource_id ] = array();

					foreach ( $days_availability as $date_ymd => $resource_availability_arr ) {

						$resources_fit_quantity[ $resource_id ][ $date_ymd ] = 0;

						foreach ( $resource_availability_arr as $child_res_id => $is_available ) {

							if ( $is_available ) {
								$resources_fit_quantity[ $resource_id ][ $date_ymd ]++;
							}
						}
					}
				}
				/**
				 * [    231 => [  '2024-05-10' => 5,
				 *                '2024-05-11' => 5,
				 *                '2024-05-12' => 5
				 *              ],
				 *      237 => [
				 *                '2024-05-10' => 1,
				 *                '2024-05-11' => 1,
				 *                '2024-05-12' => 0
				 *              ],
				 *      238 => [
				 *                '2024-05-10' => 1,
				 *                '2024-05-11' => 1,
				 *                '2024-05-12' => 1
				 *              ]
				 *   ]
				 *
				 */
				$child_resources_availability_max_availability = array();
				foreach ( $resources_fit_quantity as $resource_id => $days_availability ) {
					$child_resources_availability_max_availability[ $resource_id ] = 900000000000000;
					foreach ( $days_availability as $date_ymd => $availability_count ) {
						$child_resources_availability_max_availability[ $resource_id ] = min($child_resources_availability_max_availability[ $resource_id ], $availability_count);
					}
				}
				/*
				    $child_resources_availability_max_availability =    [
																    [231] => 5
																    [237] => 0
																    [238] => 1
																]
				*/
			}


			return $child_resources_availability_max_availability;
		}


// ---------------------------------------------------------------------------------------------------------------------
// Resources Filtering
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Get array  of children booking resources for each resource in source arr,  if this resource parent booking resource.
 *
 * @param $resources_arr    [231, 237, 238 ]
 *
 * @return array            [  231 => [ 232, 233, 234, 235 ], 237 => [],  238 => []  ]
 */
function wpbc_get_children_arr_for_resources($resources_arr){

	$resources_children_arr = array();
	if ( ! empty( $resources_arr ) ) {

        // Get here Obj. of booking resource (which can include CHILD booking resources)
		$resources_obj = new WPBC_RESOURCE_SUPPORT( array( 'resource_id' => $resources_arr ) );
		// Resource ID arr (Can be Parent and Child resource ID)
		$resource_obj__with_children__arr = $resources_obj->get_resources_obj_arr();

		// Get array  of child booking resources
		foreach ( $resources_arr as $resource_id ) {

			$resources_children_arr[ $resource_id ] = array();

			foreach ( $resource_obj__with_children__arr as $res_id => $resource_obj ) {
				if ($resource_obj->parent == $resource_id) {
					$resources_children_arr[ $resource_id ][] = $res_id;
				}
			}
		}
	}

	return $resources_children_arr;
}

/**
 * Filter  booking resources by  user ID from  the search availability  shortcode.
 *
 * @param $local_params_resource_id     [230, 231, 237]
 * @param $search__users_id             '2,3' | ''
 *
 * @return array|mixed                  [230, 231, 237]
 */
function wpbc_search_avy__filter_resource___by_user_id(  $local_params_resource_id, $search__users_id ){

	$search__users_id_arr = str_replace( ';', ',', $search__users_id );
	$search__users_id_arr = explode( ',', $search__users_id_arr );

	if (
			( empty( $search__users_id_arr ) )
	     || ( ! class_exists( 'wpdev_bk_multiuser' ) )
	){
		return $local_params_resource_id;
	}

	$filtered_resources = array();
	if ( ! empty( $local_params_resource_id ) ) {

		// 'resource_id' : CSD | D | array          // 'as_single_resource' : If true,  then  skip child booking resources
		$resources_obj = new WPBC_RESOURCE_SUPPORT( array( 'resource_id' => $local_params_resource_id ) );
		$all_resource_obj__arr = $resources_obj->get_resources_obj_arr();

		$resources_obj_arr = array();
		foreach ( $local_params_resource_id as $res_id ) {
			$resources_obj_arr[ $res_id ] = $all_resource_obj__arr[ $res_id ];
		}


		foreach ( $resources_obj_arr as $resource_id => $resource_obj ) {
			if ( in_array( $resource_obj->users, $search__users_id_arr ) ) {
				$filtered_resources[] = $resource_id;
			}
		}
	}

	return $filtered_resources;
}

/**
 * Check  if booking resource fit to  custom  parameters of search  request
 *
 * @param $resource_option_string         = 'pets^contain^on~cost^&gt;^100'
 * @param $search__custom_params_arr      = [
 *                                            [booking_location] => London
 *                                            [booking_max_visitors] =>
 *                                          ]
 *
 *
 * @return true
 */
function wpbc_search_avy__is_fit_resource___to_custom_params( $resource_option_string, $search__custom_params_arr ) {

	$resource_option_arr = wpbc_searchable_resources__filters__get_as_arr( $resource_option_string );


	foreach ( $search__custom_params_arr as $search_key_name => $search_value ) {

		// If custom search field '', then  it is means any values
		if ( '' === $search_value ) { continue; }

		$is_fit_resource = false;

		// Check  if at least one parameter  $resource_option_arr   in Resources Options fit to  this specific Search Parameter:   $search_key_name => $search_value
		foreach ( $resource_option_arr as $resource_field_name => $field_condition_arr ) {
			if ( $resource_field_name === $search_key_name ) {
				foreach ( $field_condition_arr as $condition_arr ) {
					list( $operator, $field_value ) = $condition_arr;

					$operator = html_entity_decode($operator);

					switch ( $operator ) {

						case '=':
							if ($field_value === $search_value){
								$is_fit_resource = true;
							}
							break;

						case '>':
							if ( floatval( $field_value ) < floatval( $search_value ) ) {
								$is_fit_resource = true;
							}
							break;

						case '>=':
							if ( floatval( $field_value ) <= floatval( $search_value ) ) {
								$is_fit_resource = true;
							}
							break;

						case '<':
							if ( floatval( $field_value ) > floatval( $search_value ) ) {
								$is_fit_resource = true;
							}
							break;

						case '<=':
							if ( floatval( $field_value ) >= floatval( $search_value ) ) {
								$is_fit_resource = true;
							}
							break;

						case 'contain':
							if ( false !== strpos( $search_value, $field_value ) ) {
								$is_fit_resource = true;
							}
							break;

						default:
					}
				}
			}
		}

		// We did not find the 'resource field option' with  names of 'search custom request field'
		if ( ! $is_fit_resource ) {
			return false;
		}
	}

	return true;
}


// ---------------------------------------------------------------------------------------------------------------------
// Get Extended Days Intervals for       [search_extend "5"]
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Get extended dates intervals arr.
 *
 * @param $search__extend_num           -     number of days to  extend.        Example: 2
 * @param $search__check_in_ymd         -     check  in                         '2024-05-11'
 * @param $search__check_out_ymd        -     check  out                        '2024-05-15'
 *
 * @return array
 */
function wpbc_search_avy__get_extended_days_intervals( $search__extend_num, $search__check_in_ymd, $search__check_out_ymd ) {

	$extended_days_intervals_arr = array();

	if ( $search__extend_num > 0 ) {
		$check_dates_intervals = array();
		for ( $i = 1; $i <= $search__extend_num; $i ++ ) {
			$check_dates_intervals[] = $i;
			$check_dates_intervals[] = - $i;
		}

		$min_date_check = strtotime( $search__check_in_ymd );
		$max_date_check = strtotime( $search__check_out_ymd );

		foreach ( $check_dates_intervals as $day_shift ) {
			if ( $day_shift > 0 ) {
				$day_shift_text = ' +' . $day_shift . ' day';
			} else {
				$day_shift_text = ' -' . abs( $day_shift ) . ' day';
			}

			if ( abs( $day_shift ) > 1 ) {
				$day_shift_text .= 's';
			}

			$search__check_in_ymd_ext  = gmdate( 'Y-m-d', strtotime( $day_shift_text, $min_date_check ) );
			$search__check_out_ymd_ext = gmdate( 'Y-m-d', strtotime( $day_shift_text, $max_date_check ) );
			$dates_only_sql_arr_ext    = wpbc_get_dates_array_from_start_end_days( $search__check_in_ymd_ext, $search__check_out_ymd_ext );

			$extended_days_intervals_arr[] = $dates_only_sql_arr_ext;
		}
	}

	return $extended_days_intervals_arr;
}




// ======================================================================================================================================================================================
//   S E A R C H A B L E    R E S O U R C E S     -     O P T I O N S
// ======================================================================================================================================================================================


// =====================================================================================================================
//   Get / Save     Search Options      for all booking resources       into    'booking_resources_search_options'
// =====================================================================================================================

/**
 * Get array of all Search  Options for booking resources
 *
 * @return array|false|mixed|null   [
 *										 220 = [
 *													is_searchable = "On"
 *													url = "http://beta/premium-suite/#bklnk230"
 *													picture = "http://beta/wp-content/uploads/2024/04/69121b41-536c-4e7b-bbf8-fbe9e413e8b5.jpg"
 *													description = "Enjoy luxury and comfort in our premium suite, where every detail is designed for your relaxation. Relax in style with modern furnishings, including a plush king-sized bed, a lavish en-suite bathroom, and exclusive access to our premium services. Create unforgettable memories in our Premium Suite."
 *													options = "max_capacity^&lt;=^3~amenity^=^parking"
 *													title = "Premium Suite"*												  is_searchable = "On"
 *      												  category = [  [category = "Uncategorized", slug = "uncategorized-en", ID = {int} 31], ... ]       // Deprecated
 *		        										  tags = {array[0]}                                                                                 // Deprecated
 *										 2 = [ ... ]
 *                                  ]
 *
 */
function wpbc_searchable_resources__get_all_options() {

	$booking_resources_search_options = get_bk_option( 'booking_resources_search_options' );

	$booking_resources_search_options = ( ! empty( $booking_resources_search_options ) )
										? maybe_unserialize( $booking_resources_search_options )
										: array();

	return $booking_resources_search_options;
}

/**
 * Set  Search  Options for ALL booking resources
 *
 * @return array|false|mixed|null
 */
function wpbc_searchable_resources__save_all_options( $search_options_arr ) {

	update_bk_option( 'booking_resources_search_options', $search_options_arr );

	return $search_options_arr;
}

		/**
		 * Get search option for specific booking resource
		 *
		 * @param $resource_id
		 * @param $option_name
		 *
		 * @return false|mixed
		 */
		function wpbc_searchable__get_resource_option( $resource_id, $option_name ) {

			$search_options_arr = wpbc_searchable_resources__get_all_options();

			if (
					( ! isset( $search_options_arr[ $resource_id ] ) )
			     || ( ! isset( $search_options_arr[ $resource_id ][ $option_name ] ) )
			) {
				return false;
			}

			return $search_options_arr[ $resource_id ][ $option_name ];
		}

		/**
		 * Set search option for specific booking resource
		 *
		 * @param $resource_id  integer
		 * @param $option_name string
		 * @param $option_value
		 *
		 * @return void
		 */
		function wpbc_searchable__set_resource_option( $resource_id , $option_name, $option_value) {

			$search_options_arr = wpbc_searchable_resources__get_all_options();

			if ( ! isset( $search_options_arr[ $resource_id ] ) ) {
				$search_options_arr[ $resource_id ] = array();
			}

			$search_options_arr[ $resource_id ][ $option_name ] = $option_value;

			update_bk_option( 'booking_resources_search_options' , $search_options_arr );
		}


// =====================================================================================================================
// Import from older versions       from        'booking_cache_content'
// =====================================================================================================================

/**
 * Import Search Cache settings in previos versions 10.0 and older  and then delete cache
 *
 * @return void
 *
 *   Format: [
               ... ,
               [228] => stdClass Object (
				            [ID] => 4613
				            [post_title] => Post  for Test  search  resource ID = 228
				            [guid] => http://beta/?p=4613
				            [post_content] =>
				            [post_excerpt] => Small - description  in excerpt  Post  for Test  search  resource ID = 228
				            [custom_fields] => [
							                      [booking_tv] => [
									                                 [0] => 'yes'
											                      ]
									           ]
				            [booking] => [
						                    [resource_id] => 228
						                    [nummonths] => 2
						                    [type] => 228
								        ]
				            [booking_resource] => 228
				            [picture] => 0
				            [user] => 1
				            [category] => [
				                             [0] => [
							                            [category] => Uncategorized
							                            [slug] => uncategorized-en
							                            [ID] => 31
									               ]
							              ]
				            [tags] => []
				        ),
			  ...
 *          ]
 *
 */
function wpbc_searchable_resources__import_in_version_10() {

	// Get old cache content
	$booking_cache_content = get_bk_option( 'booking_cache_content' );

	$booking_cache_content_arr = ( ! empty( $booking_cache_content ) ) ? maybe_unserialize( $booking_cache_content ) : array();
	if ( empty( $booking_cache_content_arr ) ) {
		return;
	}

//debuge($booking_cache_content);

	$search_options_arr = wpbc_searchable_resources__get_all_options();
	/**
	 * [
	 *   3 -> [
				ID = "1541"
				post_title = "ID=3 | Apart. 2 | capacity=1"
				guid = "http://beta/?page_id=1541"
				post_content = ""
				post_excerpt = ""
				custom_fields = {array[0]}
				booking = {array[9]}
				booking_resource = {int} 3
				picture = {int} 0
				user = "1"
				category = {array[0]}
				tags = {array[0]}
	 *    ],...
	 * ]
	 */
	foreach ( $booking_cache_content_arr as $resource_id => $search_cache_resource_arr ) {

		$search_options_arr[ $resource_id ]['is_searchable'] = 'On';
		$search_options_arr[ $resource_id ]['url']           = ( ! empty( $search_cache_resource_arr->guid ) ) ? $search_cache_resource_arr->guid : '';

		// Deprecated
		$search_options_arr[ $resource_id ]['title'] = ( ! empty( $search_cache_resource_arr->post_title ) ) ? $search_cache_resource_arr->post_title : '';

		$search_options_arr[ $resource_id ]['description'] = ( ! empty( $search_cache_resource_arr->post_excerpt ) ) ? $search_cache_resource_arr->post_excerpt : '';
		$search_options_arr[ $resource_id ]['picture'] = '';
		if ( ( ! empty( $search_cache_resource_arr->picture ) ) && ( is_array( $search_cache_resource_arr->picture ) ) ) {
			$image_src = $search_cache_resource_arr->picture[0];
			$image_w   = $search_cache_resource_arr->picture[1];
			$image_h   = $search_cache_resource_arr->picture[2];
			$search_options_arr[ $resource_id ]['picture'] = $image_src;
		}
		/**
			...->custom_fields = [
									 booking_tv = [
													  0 = ""yes""
													  1 = "Sony'"
					                              ]
									 booking_pets = [
													  0 = "false "
						                            ]
				                ]
		 */
		$search_filters_arr = ( ! empty( $search_cache_resource_arr->custom_fields ) ) ? $search_cache_resource_arr->custom_fields : array();
		$search_options_arr[ $resource_id ]['options'] = wpbc_searchable_resources__filters__get_as_str( $search_filters_arr );

		// Deprecated
		$search_options_arr[ $resource_id ]['category'] = ( ! empty( $search_cache_resource_arr->category ) ) ? $search_cache_resource_arr->category : array();
		$search_options_arr[ $resource_id ]['tags']     = ( ! empty( $search_cache_resource_arr->tags ) ) ? $search_cache_resource_arr->tags : array();
	}

	wpbc_searchable_resources__save_all_options( $search_options_arr );

	// Erase Old Search Cache
	delete_bk_option( 'booking_cache_content' );
}


// =====================================================================================================================
// Search Filters - Criteria for searching
// =====================================================================================================================
/**
 * Transform searchable options array to  string
 *
 * @param $options_arr
 * @param $separator_row       =   '~'
 * @param $separator_col       =   '^'
 *
 * @return string
 *
 * Example:
 *
 *                     booking_visitors^<=^2 ~ booking_pets^=^cats ~ booking_pets^=^dogs ~ booking_eats^=^breakfast
 *                 <=>
 *                     [
 *                        booking_visitors => [ ['<=' , 2 ] ]
 *                        booking_pets     => [ ['=' , 'cats'], ['=' , 'dogs'] ]
 *                        booking_eats     => [ ['=' , 'breakfast'] ]
 *                     ]
 *
 */
function wpbc_searchable_resources__filters__get_as_str( $options_arr, $separator_row = '~', $separator_col = '^' ) {

	$options_rows_str = array();
	if ( is_array( $options_arr ) ) {
		foreach ( $options_arr as $custom_field_name => $field_options_arr ) {

			//        $field_options_arr  :  [ ['=' , 'cats'], ['=' , 'dogs'] ]      OR    [ 'cats', 'dogs' ]
			foreach ( $field_options_arr as $option_value ) {

				$option_operator = '=';

				if ( is_array( $option_value ) ) {
					$option_operator = array_shift( $option_value );
					$option_value = implode( '||', $option_value );
				}

				$options_rows_str[] =   $custom_field_name . $separator_col
				                      . $option_operator   . $separator_col
				                      . $option_value;
			}
		}
	}

	$options_str = implode( $separator_row, $options_rows_str );

	return $options_str;
}


/**
 * Transform searchable options string into array
 *
 * @param $options_str
 * @param $separator_row       =   '~'
 * @param $separator_col       =   '^'
 *
 * @return array
 *
 * Example:
 *
 *                     booking_visitors^<=^2 ~ booking_pets^=^cats ~ booking_pets^=^dogs ~ booking_eats^=^breakfast
 *                 <=>
 *                     [
 *                        booking_visitors => [ ['<=' , 2 ] ]
 *                        booking_pets     => [ ['=' , 'cats'], ['=' , 'dogs'] ]
 *                        booking_eats     => [ ['=' , 'breakfast'] ]
 *                     ]
 */
function wpbc_searchable_resources__filters__get_as_arr( $options_str, $separator_row = '~', $separator_col = '^' ) {

    $options_arr = array();

	if ( ! empty( $options_str ) ) {

		$options_rows_str = explode( $separator_row, $options_str );

		foreach ( $options_rows_str as $option_row_arr ) {
			   // $options_rows_str =   booking_pets^=^cats

			$option_attributes = explode( $separator_col, $option_row_arr );

			if ( ! empty( $option_attributes ) ) {

				$options_operator     = '=';
				$option_name          = ( isset( $option_attributes[0] ) ) ? $option_attributes[0] : 'unknown';

				if ( ! isset( $option_attributes[2] ) ) {
					$option_value     = ( isset( $option_attributes[1] ) ) ? $option_attributes[1] : 'unknown';
				} else {
					$options_operator = ( isset( $option_attributes[1] ) ) ? $option_attributes[1] : $options_operator;
					$option_value     = ( isset( $option_attributes[2] ) ) ? $option_attributes[2] : 'unknown';
				}

				if ( ! isset( $options_arr[ $option_name ] ) ) {
					$options_arr[ $option_name ] = array();
				}

				$options_arr[ $option_name ][] = array( $options_operator, $option_value );
			}
		}
	}
	return $options_arr;
}



/**
 * Remove the booking resource 'searchable_resources' option parameter, if booking resource deleted at the Booking > Resources page or in other settings page
 *
 *
 * @param $resources_id_str  ID of booking resources. Example:   '9'  or      '4,7,8'
 *
 * @return void
 */
function wpbc_searchable_resources_option_update__on_resource_delete( $resources_id_str ){

	$booking_resources_search_options = wpbc_searchable_resources__get_all_options();

	$resources_id_arr = explode( ',', $resources_id_str );
	foreach ( $resources_id_arr as $resource_key => $resource_id ) {
		unset( $booking_resources_search_options[ $resource_id ] );
	}
	wpbc_searchable_resources__save_all_options( $booking_resources_search_options );

}
add_action( 'wpbc_deleted_booking_resources', 'wpbc_searchable_resources_option_update__on_resource_delete' );


/**
 * Check  all exist  booking resources and update searchable booking resources
 *
 * @return void
 */
function wpbc_searchable_resources_option_update__if_resource_not_exist(){

	$booking_resources_search_options = wpbc_searchable_resources__get_all_options();

	global $wpdb;
	$sql= "SELECT booking_type_id as id  FROM {$wpdb->prefix}bookingtypes ";

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	$bookings_sql_obj = $wpdb->get_results( $sql );

	$exist_booking_resources = array();
	foreach ( $bookings_sql_obj as $resource_obj) {
		$exist_booking_resources[]= $resource_obj->id;
	}

	$is_re_update = false;
	foreach ( $booking_resources_search_options as $resource_id => $params ) {
		if ( ! in_array( $resource_id, $exist_booking_resources ) ) {
			unset( $booking_resources_search_options[ $resource_id ] );
			$is_re_update = true;
		}
	}

	if ( $is_re_update ) {
		wpbc_searchable_resources__save_all_options( $booking_resources_search_options );
	}

}