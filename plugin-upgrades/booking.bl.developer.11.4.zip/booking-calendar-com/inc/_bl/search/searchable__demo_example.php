<?php
/**
 * @version 1.0
 * @package Booking Calendar  - Search Examples
 * @subpackage Search Functions
 * @category Support Functions
 *
 * @author wpdevelop
 * @link https://wpbookingcalendar.com/
 * @email info@wpbookingcalendar.com
 *
 * @modified 2024-04-07
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

	/**
	 * Get description | Titles | Images | Filter options as Examples for Live Demo websites
	 * @return array
	 */
	function wpbc_searchable_resources__get_demo_examples(){

		$demo_props = array();
		//TODO:
		//  create a new page
		// 						https://multiuser.wpbookingcalendar.com/demo/penthouse/
		// Maybe rename?:
		// 						https://multiuser.wpbookingcalendar.com/demo/appartments/ 		-> https://multiuser.wpbookingcalendar.com/demo/rooms/
		//						https://multiuser.wpbookingcalendar.com/demo/royal-villa/		-> https://multiuser.wpbookingcalendar.com/demo/urban-villa/
		//						https://multiuser.wpbookingcalendar.com/demo/presidential-suit/ -> https://multiuser.wpbookingcalendar.com/demo/premium-suit/
		// .
		// 1. Update configuration  of the custom search  fields for the Live demos and update Search Form/ Results for live demos
		// 2. Update content of the live demos at  the  https://multiuser.wpbookingcalendar.com/
		// 4. Create GIFs for WN
		// 5. Create a new FAQ Guide for configuration  of the Search  Form functionality

		//$admin_uri = ltrim( str_replace( get_site_url( null, '', 'admin' ), '', admin_url('admin.php?') ), '/' ) ;		// FixIn: 8.8.1.2.
		$site_url = get_site_url();

		if ( class_exists( 'wpdev_bk_multiuser' ) ) {

			$id = 13;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url']           = $site_url . '/demo/service-a/#main';
			$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-a.jpg';
			$demo_props[ $id ]['description']   = '<div><b>Description:</b> Book a consultation session with our experts for personalized advice.</div>' . "\n"
												. '<div>Suitable for legal consultations, financial planning, health consultations, and more.</div>' . "\n"
												. '<div><br><b>Example:</b> Legal consultation, financial planning session, health and wellness advice.</div>';
			$demo_props[ $id ]['options']       = 'Service^=^Financial~Service^=^Legal~Service^=^Health~Location^=^In-person~Location^=^Online';
			$demo_props[ $id ]['title']         = 'General Consultation';

			$id = 14;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url']           = $site_url . '/demo/service-b/#main';
			$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-b.jpg';
			$demo_props[ $id ]['description']   = '<div><b>Description:</b> Arrange a dedicated support session with our customer service team to resolve issues and answer questions.</div>' . "\n"
												. '<div>Perfect for technical support, product troubleshooting, or account management.</div>' . "\n"
												. '<div><br><b>Example:</b> Technical support session, product troubleshooting, account management.</div>';
			$demo_props[ $id ]['options']       = 'Service^=^Technical Support~Service^=^Product Troubleshooting~Service^=^Account Management~Location^=^Phone~Location^=^Email~Location^=^Live Chat';
			$demo_props[ $id ]['title']         = 'Customer Support';

			$id = 15;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url']           = $site_url . '/demo/service-c/#main';
			$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-c.jpg';
			$demo_props[ $id ]['description']   = '<div><b>Description:</b> Book a session to take care of your physical and mental well-being.</div>' . "\n"
												. '<div>Choose from various wellness activities.</div>' . "\n"
												. '<div><br><b>Example:</b> Massage therapy, yoga class, nutritional counseling.</div>';
			$demo_props[ $id ]['options']       = 'Service^=^Massage Therapy~Service^=^Yoga Class~Service^=^Nutritional Counseling~Location^=^In-person~Location^=^Online';
			$demo_props[ $id ]['title']         = 'Wellness Session';

			$id = 16;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url']           = $site_url . '/demo/service-d/#main';
			$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-d.jpg';
			$demo_props[ $id ]['description']   = '<div><b>Description:</b> Arrange a technical support appointment with our IT specialists to troubleshoot and resolve technical issues.</div>' . "\n"
												. '<div>Suitable for software troubleshooting, hardware repairs, or network setup.</div>' . "\n"
												. '<div><br><b>Example:</b> Software troubleshooting session, hardware repair, network setup.</div>';
			$demo_props[ $id ]['options']       = 'Service^=^Software Troubleshooting~Service^=^Hardware Repair~Service^=^Network Setup~Location^=^Phone~Location^=^Email~Location^=^Live Chat';
			$demo_props[ $id ]['title']         = 'Technical Support';

			$id = 17;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url']           = $site_url . '/demo/service-e/#main';
			$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-e.jpg';
			$demo_props[ $id ]['description']   = '<div><b>Description:</b> Schedule a creative consultation to discuss project ideas and get expert design advice.</div>' . "\n"
												. '<div>Ideal for graphic design projects, interior decorating, or event planning.</div>' . "\n"
												. '<div><br><b>Example:</b> Graphic design consultation, interior decorating advice, event planning session.</div>';
			$demo_props[ $id ]['options']       = 'Service^=^Graphic Design~Service^=^Interior Decorating~Service^=^Event Planning~Location^=^In-person~Location^=^Online';
			$demo_props[ $id ]['title']         = 'Creative Consultation';

		} else {
			$id = 1;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url'] 		  = $site_url . '/demo/standard-rooms/#main';
			$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/standard-room.jpg';
			$demo_props[ $id ]['description'] = 'Enjoy comfortable and convenient accommodation in our standard room, perfect for a relaxing stay. With its inviting ambiance and essential amenities, including a comfortable bed and modern bathroom, it provides everything you need for a restful stay. Enjoy a restful nights sleep in a cozy atmosphere, ensuring a rejuvenating stay for all guests.';
			$demo_props[ $id ]['options']     = 'max_adults^<=^2~max_children^<=^1~location^=^Spain~amenity^=^wifi~amenity^=^spa';
			$demo_props[ $id ]['title']       = 'Standard Room';

			$id = 2;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url'] 		  = $site_url . '/demo/double-room/#main';
			$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/double-room.jpg';
			$demo_props[ $id ]['description'] = 'Relax in our cozy double room, ideal for couples or small families. Thoughtfully furnished with modern amenities our Double Room offers a peaceful sanctuary for rest and relaxation. Whether you are traveling for business or leisure, enjoy a comfortable stay and personalized service at our property.';
			$demo_props[ $id ]['options']     = 'max_adults^<=^3~max_children^<=^2~location^=^France~amenity^=^wifi~amenity^=^spa';
			$demo_props[ $id ]['title']       = 'Double Room';

			$id = 3;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url'] 		  = $site_url . '/demo/penthouse/#main';
			$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/penthouse.jpg';
			$demo_props[ $id ]['description'] = 'Experience luxury living with breathtaking views from our exclusive penthouse suite. Our luxurious Penthouse offers unparalleled sophistication and comfort in the heart of the city. With expansive floor-to-ceiling windows providing panoramic views, this exclusive retreat features lavish amenities, including a private terrace, deluxe furnishings, and personalized concierge service you will  have an unforgettable stay.';
			$demo_props[ $id ]['options']     = 'max_adults^<=^4~max_children^<=^2~location^=^USA~amenity^=^wifi~amenity^=^parking';
			$demo_props[ $id ]['title']       = 'Penthouse';

			$id = 4;
			$demo_props[ $id ] = array();
			$demo_props[ $id ]['is_searchable'] = 'On';
			$demo_props[ $id ]['url'] 		  = $site_url . '/demo/urban-villa/#main';
			$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/urban-villa.jpg';
			$demo_props[ $id ]['description'] = 'Our stylish Urban Villa, featuring sleek interiors and contemporary design elements. Enjoy the convenience of modern amenities and a welcoming atmosphere for your next vacation.  Perfect for families or groups, our Urban Villa provides the ideal setting for memorable gatherings and relaxation.';
			$demo_props[ $id ]['options']     = 'max_adults^<=^4~max_children^<=^4~location^=^Australia~amenity^=^wifi~amenity^=^parking';
			$demo_props[ $id ]['title']       = 'Urban Villa';

//			$id = 238;
//			$demo_props[ $id ] = array();
//			$demo_props[ $id ]['is_searchable'] = 'On';
//			$demo_props[ $id ]['url'] =   '';
//			$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/premium-suite.jpg';
//			$demo_props[ $id ]['description'] = 'Enjoy luxury and comfort in our premium suite, where every detail is designed for your relaxation. Relax in style with modern furnishings, including a plush king-sized bed, a lavish en-suite bathroom, and exclusive access to our premium services. Create unforgettable memories in our Premium Suite.';
//			$demo_props[ $id ]['options']     = 'max_capacity^<=^3~location^=^France~category_type^=^house~amenity^=^wifi~amenity^=^parking';
//			$demo_props[ $id ]['title']       = 'Premium Suite';
		}


		// <editor-fold     defaultstate="collapsed"                        desc="  ==  BETA  Examples  ==  "  >
		// -----------------------------------------------------------------------------------------------------------------
		// BETA  Examples:
		// -----------------------------------------------------------------------------------------------------------------
		if ( ( ( isset( $_SERVER['HTTP_HOST'] ) ) && ( 'beta' === $_SERVER['HTTP_HOST'] ) ) && ( class_exists( 'wpdev_bk_multiuser' ) ) ) {
			$demo_props = array();
			if ( ( defined( 'WP_BK_BETA_DATA_FILL_AS' ) ) && ( 'MU' === WP_BK_BETA_DATA_FILL_AS ) ) {

				$id = 1;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url']           = $site_url . '/demo/service-a/#main';
				$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-a.jpg';
				$demo_props[ $id ]['description']   = '<div><b>Description:</b> Book a consultation session with our experts for personalized advice.</div>' . "\n"
													. '<div>Suitable for legal consultations, financial planning, health consultations, and more.</div>' . "\n"
													. '<div><br><b>Example:</b> Legal consultation, financial planning session, health and wellness advice.</div>';
				$demo_props[ $id ]['options']       = 'Service^=^Financial~Service^=^Legal~Service^=^Health~Location^=^In-person~Location^=^Online';
				$demo_props[ $id ]['title']         = 'General Consultation';

				$id = 2;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url']           = $site_url . '/demo/service-b/#main';
				$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-b.jpg';
				$demo_props[ $id ]['description']   = '<div><b>Description:</b> Arrange a dedicated support session with our customer service team to resolve issues and answer questions.</div>' . "\n"
													. '<div>Perfect for technical support, product troubleshooting, or account management.</div>' . "\n"
													. '<div><br><b>Example:</b> Technical support session, product troubleshooting, account management.</div>';
				$demo_props[ $id ]['options']       = 'Service^=^Technical Support~Service^=^Product Troubleshooting~Service^=^Account Management~Location^=^Phone~Location^=^Email~Location^=^Live Chat';
				$demo_props[ $id ]['title']         = 'Customer Support';

				$id = 3;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url']           = $site_url . '/demo/service-c/#main';
				$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-c.jpg';
				$demo_props[ $id ]['description']   = '<div><b>Description:</b> Book a session to take care of your physical and mental well-being.</div>' . "\n"
													. '<div>Choose from various wellness activities.</div>' . "\n"
													. '<div><br><b>Example:</b> Massage therapy, yoga class, nutritional counseling.</div>';
				$demo_props[ $id ]['options']       = 'Service^=^Massage Therapy~Service^=^Yoga Class~Service^=^Nutritional Counseling~Location^=^In-person~Location^=^Online';
				$demo_props[ $id ]['title']         = 'Wellness Session';

				$id = 4;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url']           = $site_url . '/demo/service-d/#main';
				$demo_props[ $id ]['picture']       = $site_url . '/demo_assets/service-d.jpg';
				$demo_props[ $id ]['description']   = '<div><b>Description:</b> Arrange a technical support appointment with our IT specialists to troubleshoot and resolve technical issues.</div>' . "\n"
													. '<div>Suitable for software troubleshooting, hardware repairs, or network setup.</div>' . "\n"
													. '<div><br><b>Example:</b> Software troubleshooting session, hardware repair, network setup.</div>';
				$demo_props[ $id ]['options']       = 'Service^=^Software Troubleshooting~Service^=^Hardware Repair~Service^=^Network Setup~Location^=^Phone~Location^=^Email~Location^=^Live Chat';
				$demo_props[ $id ]['title']         = 'Technical Support';

			} else {

				$id = 1;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url'] 		  = $site_url . '/demo/standard-rooms/#main';
				$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/standard-room.jpg';
				$demo_props[ $id ]['description'] = 'Enjoy comfortable and convenient accommodation in our standard room, perfect for a relaxing stay. With its inviting ambiance and essential amenities, including a comfortable bed and modern bathroom, it provides everything you need for a restful stay. Enjoy a restful nights sleep in a cozy atmosphere, ensuring a rejuvenating stay for all guests.';
				$demo_props[ $id ]['options']     = 'max_adults^<=^2~max_children^<=^1~location^=^Spain~amenity^=^wifi~amenity^=^spa';
				$demo_props[ $id ]['title']       = 'Standard Room';

				$id = 2;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url'] 		  = $site_url . '/demo/double-room/#main';
				$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/double-room.jpg';
				$demo_props[ $id ]['description'] = 'Relax in our cozy double room, ideal for couples or small families. Thoughtfully furnished with modern amenities our Double Room offers a peaceful sanctuary for rest and relaxation. Whether you are traveling for business or leisure, enjoy a comfortable stay and personalized service at our property.';
				$demo_props[ $id ]['options']     = 'max_adults^<=^3~max_children^<=^2~location^=^France~amenity^=^wifi~amenity^=^spa';
				$demo_props[ $id ]['title']       = 'Double Room';

				$id = 3;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url'] 		  = $site_url . '/demo/penthouse/#main';
				$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/penthouse.jpg';
				$demo_props[ $id ]['description'] = 'Experience luxury living with breathtaking views from our exclusive penthouse suite. Our luxurious Penthouse offers unparalleled sophistication and comfort in the heart of the city. With expansive floor-to-ceiling windows providing panoramic views, this exclusive retreat features lavish amenities, including a private terrace, deluxe furnishings, and personalized concierge service you will  have an unforgettable stay.';
				$demo_props[ $id ]['options']     = 'max_adults^<=^4~max_children^<=^2~location^=^USA~amenity^=^wifi~amenity^=^parking';
				$demo_props[ $id ]['title']       = 'Penthouse';

				$id = 4;
				$demo_props[ $id ] = array();
				$demo_props[ $id ]['is_searchable'] = 'On';
				$demo_props[ $id ]['url'] 		  = $site_url . '/demo/urban-villa/#main';
				$demo_props[ $id ]['picture']     = $site_url . '/demo_assets/urban-villa.jpg';
				$demo_props[ $id ]['description'] = 'Our stylish Urban Villa, featuring sleek interiors and contemporary design elements. Enjoy the convenience of modern amenities and a welcoming atmosphere for your next vacation.  Perfect for families or groups, our Urban Villa provides the ideal setting for memorable gatherings and relaxation.';
				$demo_props[ $id ]['options']     = 'max_adults^<=^4~max_children^<=^4~location^=^Australia~amenity^=^wifi~amenity^=^parking';
				$demo_props[ $id ]['title']       = 'Urban Villa';
			}
		}

		// </editor-fold>


		return $demo_props;
	}


function wpbc_booking_activate_l___searchable_resources(){

	$is_update_in_beta_also = ( ( isset( $_SERVER['HTTP_HOST'] ) ) && ( 'beta' === $_SERVER['HTTP_HOST'] ) );
    // -----------------------------------------------------------------------------------------------------------------
    // Demo
    // -----------------------------------------------------------------------------------------------------------------
    if (    ( wpbc_is_this_demo() )
         || ( $is_update_in_beta_also )
    ) {

		// Get search options  for all booking resources
		$search_options_arr = wpbc_searchable_resources__get_all_options();

		// Booking Calendar Business Large version
		$demo_examples = wpbc_searchable_resources__get_demo_examples();
		foreach ( $demo_examples as $res_id => $res_options ) {
			$search_options_arr[ $res_id ] = $res_options;
		}
		wpbc_searchable_resources__save_all_options( $search_options_arr );


//TODO: add for live demos on activation
//TODO: 2024-04-20 15:23
//      delete from activation  of the plugin,  creation  of the 'booking_cache_content'
//      because now all search  options saved in 'booking_resources_search_options'
    }
}
add_bk_action( 'wpbc_other_versions_activation',   'wpbc_booking_activate_l___searchable_resources'   );



/**
 * Generate NEW booking search cache        -   TEST function. TODO: delete it later.
 * @return void
 */
function wpbc__test_regenerate_booking_search_cache() {

	// wp_cache_flush(); // FixIn: 5.4.5.10.
	$available_booking_resources = array();
	global $wpdb;
	$sql    = "SELECT ID, post_title, guid, post_content, post_excerpt 
						FROM {$wpdb->posts}  
						WHERE post_status = 'publish' AND ( post_type != 'revision' ) AND post_content LIKE '%[booking %'";

	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
	$postss = $wpdb->get_results( $sql );

	$look_4_shortcode = '[booking ';            // FixIn: 9.1.2.5.

	if ( empty( $postss ) ) {

		$sql    = "SELECT ID, post_title, guid, post_content, post_excerpt 
							FROM {$wpdb->posts}  
							WHERE post_status = 'publish' AND ( post_type != 'revision' ) AND post_content LIKE '%[bookinglooking %'";

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.NotPrepared
		$postss = $wpdb->get_results( $sql );

		$look_4_shortcode = '[bookinglooking ';
	}

	if ( ! empty( $postss ) ) {
		foreach ( $postss as $value ) {

			$post_id = $value->ID;

			$post_custom_fields = array();
			$post_meta          = get_post_meta( $post_id, '', false );

			foreach ( $post_meta as $meta_key => $meta_value ) {
				if ( strpos( $meta_key, 'booking_' ) === 0 ) {
					$post_custom_fields[ $meta_key ] = $meta_value;
				}
			}
			$value->custom_fields = $post_custom_fields;
			//debuge($value );
			$image_src = false;
			if ( $post_id &&
			     function_exists( 'has_post_thumbnail' ) &&
			     has_post_thumbnail( $post_id ) &&
			     ( $image = wp_get_attachment_image_src( get_post_thumbnail_id( $post_id ), 'post-thumbnail' ) )
			) {
				if ( count( $image ) > 2 ) {
					$image_src = $image[0];
					$image_w   = $image[1];
					$image_h   = $image[2];
				}
			}


			$shortcode_start   = strpos( $value->post_content, $look_4_shortcode );    //    '[booking ');	// FixIn: 9.1.2.5.
			$shortcode_end     = strpos( $value->post_content, ']', $shortcode_start );
			$shortcode_content = substr( $value->post_content, $shortcode_start + strlen( $look_4_shortcode ), $shortcode_end - $shortcode_start - 9 );

			$shortcode_content_attr = explode( ' ', $shortcode_content );
			$shortcode_attributes   = array();

			foreach ( $shortcode_content_attr as $attr ) {
				$attr_key_value = explode( '=', $attr );
				if ( count( $attr_key_value ) > 1 ) {
					$shortcode_attributes[ $attr_key_value[0] ] = $attr_key_value[1];
				}
			}

			if ( ! isset( $shortcode_attributes['type'] ) ) {
				$shortcode_attributes['type'] = 1;
			} else {
				$shortcode_attributes['type'] = intval( $shortcode_attributes['type'] );
			}
			// FixIn: 9.9.0.26.
			if ( ! empty( $shortcode_attributes['resource_id'] ) ) {
				$shortcode_attributes['type'] = intval( $shortcode_attributes['resource_id'] );
			}


			$value->booking          = $shortcode_attributes;
			$value->booking_resource = $shortcode_attributes['type'];

			if ( $image_src !== false ) {
				$value->picture = array( $image_src, $image_w, $image_h );
			} else {
				$value->picture = 0;
			}


			$us_id = apply_bk_filter( 'get_user_of_this_bk_resource', false, $value->booking_resource );
			if ( $us_id !== false ) {
				$value->user = $us_id;
			}

			$categories = get_the_terms( $post_id, 'category' );
			$post_cats  = array();
			if ( ! empty( $categories ) ) {
				foreach ( $categories as $cat ) {
					$post_cats[] = array( 'category' => $cat->name, 'slug' => $cat->slug, 'ID' => $cat->term_id );
				}
			}
			$value->category = $post_cats;

			$tags      = get_the_terms( $post_id, 'post_tag' );
			$post_tags = array();
			if ( ! empty( $tags ) ) {
				foreach ( $tags as $cat ) {
					$post_tags[] = array( 'tag' => $cat->name, 'slug' => $cat->slug, 'ID' => $cat->term_id );
				}
			}
			$value->tags = $post_tags;

			$value->post_title   = htmlspecialchars( $value->post_title, ENT_QUOTES );
			$value->post_content = '';   // htmlspecialchars($value->post_content, ENT_QUOTES);      // FixIn: 5.4.5.10.
			$value->post_excerpt = htmlspecialchars( $value->post_excerpt, ENT_QUOTES );

			if ( ! isset( $available_booking_resources[ $shortcode_attributes['type'] ] ) ) {
				$available_booking_resources[ $shortcode_attributes['type'] ] = $value;
			}


		}
	}

	$available_booking_resources_serilized = serialize( $available_booking_resources );
	update_bk_option( 'booking_cache_content', $available_booking_resources_serilized );
	update_bk_option( 'booking_cache_created', wpbc_datetime_localized( gmdate( 'Y-m-d H:i:s' ), 'Y-m-d H:i:s' ) );
}

    /** Show Time of cache Expiring and Found Pages with  booking forms */
     function wpbc__test_show_info_search_cache_and_pages_with_booking_forms() {

        ?>
        <div class="clear"></div>
        <p class="wpbc-settings-notice notice-info" style="text-align:left;">
            <span class="description"><?php echo wp_kses_post( sprintf( __( 'Cache will expire:' ,'booking')) ); ?> </span><?php

                $period = get_bk_option( 'booking_cache_expiration' );
                if ( substr( $period, -1, 1 ) == 'd' ) {
                    $period = substr( $period, 0, -1 );
                    $period = $period * 24 * 60 * 60;
                }
                if ( substr( $period, -1, 1 ) == 'h' ) {
                    $period = substr( $period, 0, -1 );
                    $period = $period * 60 * 60;
                }
                $previos = get_bk_option( 'booking_cache_created' );
                $previos = explode( ' ', $previos );
                $previos_time = explode( ':', $previos[1] );
                $previos_date = explode( '-', $previos[0] );
                $previos_sec = mktime( intval($previos_time[0]), intval($previos_time[1]), intval($previos_time[2]), intval($previos_date[1]), intval($previos_date[2]), intval($previos_date[0]) );

                $expire_sec = ($previos_sec + $period);
                $cache_epire_on = wpbc_datetime_localized( gmdate( 'Y-m-d H:i:s T', $expire_sec ), 'Y-m-d H:i:s' );

                echo '<code>' . wp_kses_post( $cache_epire_on ) . '</code>';

                $found_records = get_bk_option( 'booking_cache_content' );      // FixIn: 6.0.1.15.
                if ( !empty( $found_records ) ) {
                    if ( is_serialized( $found_records ) )
                        $found_records = @unserialize( $found_records );
                    $found_records_num = count( $found_records );
                } else {
	                $found_records_num = 0;
					$found_records = array();
                }
                ?>
                <br/><span class="description"><?php
				/* translators: 1: ... */
				echo wp_kses_post( sprintf( __(  'Found: %s booking forms inside of posts or pages ', 'booking' ), '<code>' . $found_records_num . '</code>' ) ); ?>:</span>
                <?php
                foreach ( $found_records as $found_record ) {
                    echo '<br/><code>';
                    echo wp_kses_post( '[', __( 'Page', 'booking' ), ' ID=', $found_record->ID, '] '
                        . ' [', __( 'Resource', 'booking' ), ' ID=', $found_record->booking_resource, '] '
                        . $found_record->guid );
                    echo '</code>';
                }
                ?>
        </p>
        <div class="clear"></div>
        <?php
    }


    /** Button  for Search Cache reseting */
     function wpbc__test_show_reset_search_cache_button() {


        $link = wpbc_get_settings_url() . '&tab=search';

        ?>
        <div class="clear" style="height:20px;"></div>
        <input class="button-primary0 button"
               style="float:left;font-weight:600;"
               type="button"
               value="<?php esc_attr_e('Reset Search Cache' ,'booking'); ?>"
               onclick="javascript:window.location.href='<?php
			   // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			   echo  $link;?>&cache_reset=1';"
               name="reset_form" />
        <div class="clear"></div>
        <?php
    }
