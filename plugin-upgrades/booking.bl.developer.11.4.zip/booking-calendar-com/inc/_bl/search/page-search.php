<?php
/**
 * @version     1.0
 * @package     Booking > Settings > Search page - Saving search availability  form
 * @category    Settings API
 * @author      wpdevelop
 *
 * @web-site    https://wpbookingcalendar.com/
 * @email       info@wpbookingcalendar.com 
 * @modified    2016-08-05
 * 
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly


/** API  for  Settings Page - Search Availability  */
class WPBC_API_SettingsSearchAvailability extends WPBC_Settings_API  {                             
    
    /**
	 * Settings API Constructor
     *  During creation,  system try to load values from DB, if exist.
     * 
     * @param type $id - "Pure Name"
     */
    public function __construct( $id,  $init_fields_values = array(), $options = array() ) {
        
        $default_options = array( 
                        'db_prefix_option' => '' 
                      , 'db_saving_type'   => 'separate'                 
            );                 
                                                                                // separate_prefix: update_bk_option( $this->options['db_prefix_option'] . $settings_id . '_' . $field_name , $value );
        $options = wp_parse_args( $options, $default_options );

        // add_bk_action( 'wpbc_other_versions_activation',   array( $this, 'activate'   ) );      // Activate
        // add_bk_action( 'wpbc_other_versions_deactivation', array( $this, 'deactivate' ) );      // Deactivate
        
        parent::__construct( $id, $options, $init_fields_values );              // Define ID of Setting page and options                
    }


		/**
		 * Get  help  text  for Simple HTML tags
		 * @return string
		 */
		private function support_get_simple_html_help_text(){

			return sprintf( __('Booking Calendar supercharged with new simple way to configure rows and several columns for you fields configuration.' ,'booking') , '<strong>' , '</strong>')
						. '<br><br>'
						. '<strong>'.esc_html__('Configuration' ,'booking') . '</strong>'
						. '<br/>' . esc_html__( 'Row: ', 'booking' ) . '<code>&lt;r&gt;...&lt;/r&gt;</code>'
						. '<br/>' . esc_html__( 'Columns: ', 'booking' ) . '<code>&lt;c&gt;...&lt;/c&gt;</code>'
						. '<br/>' . esc_html__( 'Labels: ', 'booking' ) . '<code>&lt;l&gt;...&lt;/l&gt;</code>'
						. '<br/>' . esc_html__( 'Spacer: ', 'booking' ) . '<code>&lt;spacer&gt;&lt;/spacer&gt;</code>'
						. '<p class="description">'
						. '<strong>'.__('Row with 1 column:' ,'booking') . '</strong><br>'
						. '<code>&lt;r&gt;  &lt;c&gt; ... &lt;/c&gt;  &lt;/r&gt;</code>'
						. '</p>'
						.'<p class="description">'
						. '<strong>'.__('Row with 2 columns:' ,'booking') . '</strong><br>'
						. '<code>&lt;r&gt;  &lt;c&gt;..&lt;/c&gt; &lt;c&gt;..&lt;/c&gt;  &lt;/r&gt;</code>'.'<br>'
									. '<strong>'.__('Horizontal Spacer:' ,'booking') . '</strong>'.'<br>'
									. '<code>&lt;spacer&gt;width:1em;&lt;/spacer&gt;</code>'.'<br>'
									. '<strong>'.__('Vertical Spacer:' ,'booking') . '</strong>'.'<br>'
									. '<code>&lt;spacer&gt;height:10px;&lt;/spacer&gt;</code>'

						. '</p>';
		}


    /** Define settings Fields  */
    public function init_settings_fields() {


		// FixIn: 8.4.7.18.
		if (
    		( function_exists( 'wpbc_codemirror') )
    		&& ( is_user_logged_in() && 'false' !== wp_get_current_user()->syntax_highlighting )
		) {
    		$is_use_code_mirror = true;
		} else {
    		$is_use_code_mirror = false;
		}


        $this->fields = array();
        
        $this->fields['booking_search_form_show'] = array(   
                                      'type'        => ( $is_use_code_mirror ? 'textarea' : 'wp_textarea' )				// FixIn: 8.4.7.18.
                                    , 'default'     => ''
                                    , 'placeholder' => ''
                                    , 'title'       => ''
                                    , 'description' => ''
                                    , 'description_tag' => ''
                                    , 'css'         => ''
                                    , 'group'       => 'general'
                                    , 'tr_class'    => ''
                                    , 'rows'        => 20
                                    , 'show_in_2_cols' => true            
                                    // Default options:    
                                    , 'class'           => ''                   // Any extra CSS Classes to append to the Editor textarea 
                                    , 'default_editor'  => 'html'               // 'tinymce' | 'html'       // 'html' is used for the "Text" editor tab.
                                    , 'show_visual_tabs'=> true                 // Remove Visual Mode from the Editor        
                                    , 'teeny'           => true                 // Whether to output the minimal editor configuration used in PressThis 
                                    , 'drag_drop_upload'=> false                // Enable Drag & Drop Upload Support (since WordPress 3.9) 
                            );
        
        $this->fields['booking_search_form_show_help'] = array(   
                                        'type' => 'help'                                        
                                        , 'value' => array()
                                        , 'cols' => 2
                                        , 'group' => 'search_form_help'
										, 'css' => 'padding-right: 10px !important;max-height: 581px;overflow: auto;'
										, 'only_field'  => true
                                );
        //$this->fields['booking_search_form_show_help']['value'][] = __('HTML tags is accepted.' ,'booking');
		/* translators: 1: ... */
		$this->fields['booking_search_form_show_help']['value'][] = sprintf(	__( 'Check the FAQ for details on %1$ssearch form configuration%2$s.' , 'booking' )
																		, '<a href="https://wpbookingcalendar.com/faq/search-availability-setup" target="_blank">', '</a>'
																	  );
		$this->fields['booking_search_form_show_help']['value'][] = '<div style="width:100%;border-bottom: 1px dashed #555;margin-top: 15px;"></div>';
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Standard Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_search_form_show_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Standard Shortcodes' ,'booking'),
																			'is_open' => true,
																			'params'  => array(
																								'container_attr' => array( 'style' => 'font-weight:600;' ),
																								'content_attr'   => array( 'style' => 'font-weight:400;display:block;padding: 0px 5px;margin: 0;background: #fff;' )
																		)));
		if (1){
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf(__( '%s - check-in date, ' ,'booking'), '<code>[search_check_in]</code>');
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf(__( '%s - check-out date, ' ,'booking'),'<code>[search_check_out]</code>');
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf(__( '%s - items count, ' ,'booking'),'<code>[search_quantity "1" "2" "3"]</code>');
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( '%s - +/- 2 ' . __('days' ,'booking') . ', ','<code>[search_extend "2"]</code>');
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf(__( '%s - search button, ' ,'booking'),'<code>[search_button "Search"]</code>');        // FixIn: 9.2.3.2.
			$this->fields['booking_search_form_show_help']['value'][] = '<div style="width:100%;border-bottom: 1px dashed #555;margin-top: 15px;"></div>';

			$this->fields['booking_search_form_show_help']['value'][] = '<div class="description">' .
																			sprintf( '%s - search  available times ' . ' ',
																						'<code>[search_time "Full Day@@" "10:00 - 14:00" "15:00 - 16:00"]</code>' )
			 														  		. '<div class="wpbc_container_open_or_closed wpbc_container_closed		wpbc_deprected_help_container" style="display:block;text-align:right;">
																				   <a class="wpbc_container_open_or_closed__link"  href="javascript:void(0)">' . esc_html__('Show More' ,'booking') .'</a>'
																	  			. '<div class="wpbc_container_open_or_closed__content" style="display:none;text-align:left;">'
																						. '<strong>' . esc_html__( 'AM / PM time titles and real time values:', 'booking' ) . '</strong>'
																						. ' <br><code>[search_time "Full Day@@"  "10:00 AM - 12:00 PM@@10:00 - 12:00" "12:00 PM - 02:00 PM@@12:00 - 14:00" "02:00 PM - 04:00 PM@@14:00 - 16:00" "04:00 PM - 06:00 PM@@16:00 - 18:00" "06:00 PM - 08:00 PM@@18:00 - 20:00"]</code>'
																					. '<br>'
																						/* translators: 1: ... */
																						. '<strong>' . sprintf( __( '%s minutes intervals:', 'booking' ), '30' ) . '</strong>'
																						. ' <br><code>[search_time "Full Day@@"  "06:00 - 06:30" "06:30 - 07:00" "07:00 - 07:30" "07:30 - 08:00" "08:00 - 08:30" "08:30 - 09:00" "09:00 - 09:30" "09:30 - 10:00" "10:00 - 10:30" "10:30 - 11:00" "11:00 - 11:30" "11:30 - 12:00" "12:00 - 12:30" "12:30 - 13:00" "13:00 - 13:30" "13:30 - 14:00" "14:00 - 14:30" "14:30 - 15:00" "15:00 - 15:30" "15:30 - 16:00" "16:00 - 16:30" "16:30 - 17:00" "17:00 - 17:30" "17:30 - 18:00" "18:00 - 18:30" "18:30 - 19:00" "19:00 - 19:30" "19:30 - 20:00" "20:00 - 20:30" "20:30 - 21:00" "21:00 - 21:30"]</code>'
																		    	. '</div>'
																		   . '</div>'
																	  . '</div>';



		}
		$this->fields['booking_search_form_show_help']['value'][] = wpbc_get_open_close_link__container_end_html();

		$this->fields['booking_search_form_show_help']['value'][] = '<hr/>';
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Search Filter Options 	-	Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_search_form_show_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																	'title'   => __('Search Filter Options' ,'booking'),
																	'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
															  ));
		if (1){
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( __('Define search filter parameters, allowing users to easily find relevant booking resources based on their preferences. ','booking') );
			$this->fields['booking_search_form_show_help']['value'][] =   '<strong>' . esc_html__( 'Example', 'booking' ) . ' #1:</strong><br>'
																		. '<code>'
																			.'[selectbox amenity "Any@@" "Parking" "WiFi"]'
																		  .'</code>';
			$this->fields['booking_search_form_show_help']['value'][] =   '<strong>' . esc_html__( 'Example', 'booking' ) . ' #2:</strong><br>'
																		. '<code>' .'[selectbox max_visitors "Any@@" "1" "2" "3"]' .'</code>';

			$this->fields['booking_search_form_show_help']['value'][] =   '<strong>' . esc_html__( 'Example', 'booking' ) . ' #3:</strong><br>'
																		. '<p class="description"><code>'
																	    	.'&lt;c&gt;&lt;l&gt;Location:&lt;/l&gt;' . '<br>'
																			.'[selectbox location "Any@@" "Spain" "France"]'
																		  	. '<br>'.'&lt;/c&gt;'
																		  .'</code></p>';
		}
        $this->fields['booking_search_form_show_help']['value'][] = wpbc_get_open_close_link__container_end_html();
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Simple HTML ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_search_form_show_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																	'title'   => __('Simple HTML' ,'booking'),
																	'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
															  ));
		if (1){
			$this->fields['booking_search_form_show_help']['value'][] = $this->support_get_simple_html_help_text();
		}
		$this->fields['booking_search_form_show_help']['value'][] = wpbc_get_open_close_link__container_end_html();
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Deprecated Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_search_form_show_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																	'title'   => __('Deprecated Shortcodes' ,'booking'),
																	'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
															  ));
		if (1){
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf(__( '%s - default selection number of items, ' ,'booking'),'<code>[search_visitors]</code>');
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( __( 'Example: %s - custom number of items selections"' ,'booking'),'<code>[search_visitors "1" "2" "3" "4" "5" "6" "7" "8" "9" "10"]</code>' );
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( '%s - +/- 2 ' . __('days' ,'booking') . ', ','<code>[additional_search "3"]</code>');
			$this->fields['booking_search_form_show_help']['value'][] = '<hr/>';
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( __( 'The %1$s shortcode is outdated and no longer supported. Find more details on %2$sthis page%3$s.', 'booking' ),
																		'<code>[search_category]</code>', '<a href="https://wpbookingcalendar.com/faq/search-availability-setup"> ', '</a>' );
			/* translators: 1: ... */
			$this->fields['booking_search_form_show_help']['value'][] = sprintf( __( 'The %1$s shortcode is outdated and no longer supported. Find more details on %2$sthis page%3$s.', 'booking' ),
																		'<code>[search_tag]</code>', '<a href="https://wpbookingcalendar.com/faq/search-availability-setup"> ', '</a>' );
		}
        $this->fields['booking_search_form_show_help']['value'][] = wpbc_get_open_close_link__container_end_html();
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------



        ////////////////////////////////////////////////////////////////////////
        
        $this->fields['booking_found_search_item'] = array(   
                                      'type'        => ( $is_use_code_mirror ? 'textarea' : 'wp_textarea' )				// FixIn: 8.4.7.18.
                                    , 'default'     => ''
                                    , 'placeholder' => ''
                                    , 'title'       => ''
                                    , 'description' => ''
                                    , 'description_tag' => ''
                                    , 'css'         => ''
                                    , 'group'       => 'search_results'
                                    , 'tr_class'    => ''
                                    , 'rows'        => 20
                                    , 'show_in_2_cols' => true            
                                    // Default options:    
                                    , 'class'           => ''                   // Any extra CSS Classes to append to the Editor textarea 
                                    , 'default_editor'  => 'html'               // 'tinymce' | 'html'       // 'html' is used for the "Text" editor tab.
                                    , 'show_visual_tabs'=> true                 // Remove Visual Mode from the Editor        
                                    , 'teeny'           => true                 // Whether to output the minimal editor configuration used in PressThis 
                                    , 'drag_drop_upload'=> false                // Enable Drag & Drop Upload Support (since WordPress 3.9) 
                            );
        
        $this->fields['booking_found_search_item_help'] = array(   
                                        'type' => 'help'                                        
                                        , 'value' => array()
                                        , 'cols' => 2
                                        , 'group' => 'search_results_help'
										, 'css' => 'padding-right: 10px !important;max-height: 709px;overflow: auto;'
										, 'only_field'  => true
                                );
		/* translators: 1: ... */
		$this->fields['booking_found_search_item_help']['value'][] = sprintf(	__( 'Check the FAQ for details on %1$ssearch form configuration%2$s.' , 'booking' )
																		, '<a href="https://wpbookingcalendar.com/faq/search-availability-setup" target="_blank">', '</a>'
																	  );
		$this->fields['booking_found_search_item_help']['value'][] = '<div style="width:100%;border-bottom: 1px dashed #555;margin-top: 15px;"></div>';
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Standard Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Standard Shortcodes' ,'booking'),
																			'is_open' => true,
																			'params'  => array(
																								'container_attr' => array( 'style' => 'font-weight:600;' ),
																								'content_attr'   => array( 'style' => 'font-weight:400;display:block;padding: 0px 5px;margin: 0;background: #fff;' )
																		)));
		if (1) {
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_title]</code> - ' 			 . __( 'search title', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_info]</code> - ' 			 . __( 'search excerpt description', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_image]</code> - ' 			 . __( 'image associated with search result', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_image_url]</code> - ' 		 . __( 'URL of image associated with search result', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_url]</code> - ' 				 . __( 'URL to the page with booking form', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_result_button "Book Now"]</code> - ' . __( 'button with link to the page with booking form', 'booking' ) . ', ';

			$this->fields['booking_found_search_item_help']['value'][] = '<code>[available_count]</code> - ' 			. __( 'number of available items for booking for searched date/time interval', 'booking' ) . ', ';
		}
		$this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();

        $this->fields['booking_found_search_item_help']['value'][] = '<hr/>';

		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Resources Hints 	==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Resources Hints' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[resource_capacity]</code> - ' 			. __( 'total resource capacity', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[resource_title]</code> - ' 			. __( 'resource title', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[resource_id]</code> - ' 			 	. __( 'resource ID', 'booking' ) . ', ';

			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf( __( '%s - ID of page with booking form, ', 'booking' ), '<code>[booking_resource_post_id]</code>' );
		}
        $this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();


		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Search Date / Time Hints 	==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Dates and Times Hints' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_check_in]</code> - ' 			. __( 'check-in date', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_check_out]</code> - ' 			. __( 'check-out date', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_check_out_plus1day]</code> - ' 	. __( 'plus one date after last searched date', 'booking' ) . ', ';

			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_time]</code> - ' 				. __( 'search time', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_time_check_in]</code> - ' 		. __( 'start time', 'booking' ) . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_time_check_out]</code> - ' 		. __( 'end time', 'booking' ) . ', ';

			// FixIn: 10.7.1.1.
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_days_number]</code> - ' 		. __('number of days' ,'booking') . ', ';
			$this->fields['booking_found_search_item_help']['value'][] = '<code>[search_nights_number]</code> - ' 		. __('number of nights' ,'booking');
		}
        $this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();


		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Search Cost Hints 	-	Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Cost Hints' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - cost of booking the resource, ' ,'booking'),'<code>[resource_cost]</code>');
			$this->fields['booking_found_search_item_help']['value'][] = '<code>'.'[cost_hint]'.'</code> - ' . __('Full cost of the booking.' ,'booking');
			$this->fields['booking_found_search_item_help']['value'][] = '<code>'.'[original_cost_hint]'.'</code> - ' . __('Cost of the booking for the selected dates only.' ,'booking');
			$this->fields['booking_found_search_item_help']['value'][] = '<code>'.'[additional_cost_hint]'.'</code> - ' . __('Additional cost, which depends on the fields selection in the form.' ,'booking');
			$this->fields['booking_found_search_item_help']['value'][] = '<code>'.'[deposit_hint]'.'</code> - ' . __('The deposit cost of the booking.' ,'booking');
			$this->fields['booking_found_search_item_help']['value'][] = '<code>'.'[balance_hint]'.'</code> - ' . __('Balance cost of the booking - difference between deposit and full cost.' ,'booking');
		}
        $this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();


		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Search Filter Options ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Search Filter Options' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			$this->fields['booking_found_search_item_help']['value'][] =  __('You can use the Search Filter options, which you defined at Searchable Resource page.' ,'booking');
			$this->fields['booking_found_search_item_help']['value'][] =  '<p class="description">'
																			. '<strong>'.__('if Search Filter defined as:' ,'booking') . '</strong><br>'
																			. '<code>location = Spain</code>'
																		  . '</p>'
																		  . '<p class="description">'
																			. '<strong>'.__('Use here:' ,'booking') . '</strong><br>'
																			. '<code>[location]</code>'
																		. '</p>';

		}
        $this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();


		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Simple HTML ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Simple HTML' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			$this->fields['booking_found_search_item_help']['value'][] = $this->support_get_simple_html_help_text();
		}
		$this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();

		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		// == Deprecated Shortcodes ==
		// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------
		$this->fields['booking_found_search_item_help']['value'][] =  wpbc_get_open_close_link__container_start_html( array(
																			'title'   => __('Deprecated Shortcodes' ,'booking'),
																			'params'  => array( 'container_class' => 'wpbc_deprected_help_container' )
																	  ));
		if (1){
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - resource title, ' ,'booking'),'<code>[booking_resource_title]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - link to the page with booking form, ' ,'booking'),'<code>[link_to_booking_resource "Book now"]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - link to the page with booking form, ' ,'booking'),'<code>[book_now_link]</code> (URL)');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - availability of booking resource, ' ,'booking'),'<code>[num_available_resources]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - featured image, taken from the featured image associated with the post, ' ,'booking'),'<code>[booking_featured_image]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - booking info, taken from the excerpt associated with the post, ' ,'booking'),'<code>[booking_info]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - ID of booking resource, ' ,'booking'),'<code>[booking_resource_id]</code>');
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf(__( '%s - cost of booking the resource, ' ,'booking'),'<code>[standard_cost]</code>');
			$this->fields['booking_found_search_item_help']['value'][] = '<hr/>';
			/* translators: 1: ... */
			$this->fields['booking_found_search_item_help']['value'][] = sprintf( __( 'The %1$s shortcode is outdated and no longer supported. Find more details on %2$sthis page%3$s.', 'booking' ),
																		'<code>[max_visitors]</code>', '<a href="https://wpbookingcalendar.com/faq/search-availability-setup"> ', '</a>' );
		}
        $this->fields['booking_found_search_item_help']['value'][] = wpbc_get_open_close_link__container_end_html();

        
        ////////////////////////////////////////////////////////////////////////


	    // FixIn: 8.4.7.8.
        $this->fields['booking_search_results_order'] = array(
                                    'type' => 'select'
                                    , 'default' => ''
                                    , 'title' => __('Sort search results by', 'booking')
                                    , 'description' => __('Select type of sorting search  results', 'booking')
                                    , 'description_tag' => 'span'
                                    , 'css' => ''
                                    , 'options' => array(
											'id_asc' 		=> __( 'ID of booking resource' , 'booking') 	 		  	. '&nbsp;(' . __( 'ASC', 'booking' ) . ')',
											'id' 		=> __( 'ID of booking resource' , 'booking') 	 		  		. '&nbsp;(' . __( 'DESC', 'booking' ) . ')',
											'title_asc' 	=> __( 'Title of booking resource' , 'booking') 		  	. '&nbsp;(' . __( 'ASC', 'booking' ) . ')',
											'title' 	=> __( 'Title of booking resource' , 'booking') 		  		. '&nbsp;(' . __( 'DESC', 'booking' ) . ')',
											'prioritet_asc' => __( 'Priority field of booking resource' , 'booking') 	. '&nbsp;(' . __( 'ASC', 'booking' ) . ')',
											'prioritet' => __( 'Priority field of booking resource' , 'booking') 		. '&nbsp;(' . __( 'DESC', 'booking' ) . ')',
											'cost_asc' 		=> __( 'Cost of booking resource' , 'booking') 				. '&nbsp;(' . __( 'ASC', 'booking' ) . ')',
											'cost' 		=> __( 'Cost of booking resource' , 'booking') 					. '&nbsp;(' . __( 'DESC', 'booking' ) . ')',
											'cost_booking_asc' 		=> __( 'Cost of booking' , 'booking') 				. '&nbsp;(' . __( 'ASC', 'booking' ) . ')',
											'cost_booking' 		=> __( 'Cost of booking' , 'booking') 					. '&nbsp;(' . __( 'DESC', 'booking' ) . ')',
											'shuffle' 		=> __( 'Shuffle' , 'booking') 					     		// FixIn: 8.7.3.1.

											//'parent' => 0
											//'visitors' => 2
											//'users' => 1
											//'is_booked' => 0
											//'items_count' => 5
                                    	)
                                    , 'group' => 'search_advanced'
                            );

	    // FixIn: 8.6.1.21.
		$field_options = array();
		$search_dates_formats = array(
										'yy-mm-dd',
										'dd-mm-yy',
										'mm-dd-yy',
										'dd/mm/yy',
										'mm/dd/yy',
										'yy/mm/dd',
										'dd.mm.yy',
										'mm.dd.yy',
										'yy.mm.dd',
										'yy.dd.mm'
		);
	    foreach ( $search_dates_formats as $search_date_format ) {
		    $field_options[ $search_date_format ] = array( 'title' => date_i18n( wpbc_get_php_dateformat_from_datepick_dateformat( $search_date_format ) ) );
		}
//		$field_options[ 'yy-mm-dd' ] = array( 'title' => date_i18n( 'Y-m-d' ) );

        $this->fields['booking_search_form_dates_format'] = array(
                                    'type' => 'select'
                                    , 'default' => ''
                                    , 'title' => __('Date Format', 'booking')
                                    , 'description' => __('Select date format for search form', 'booking')
                                    , 'description_tag' => 'span'
                                    , 'css' => ''
                                    , 'options' => $field_options
                                    , 'group' => 'search_advanced'
                            );

	    // FixIn: 8.8.2.3.
        $this->fields['booking_search_results_days_select'] = array(
                                      'type'    => 'checkbox'
                                    , 'default' => 'Off'
                                    , 'title' => __('Disable Days Auto Selection', 'booking')
                                    , 'label'       => sprintf(__('Check this box to prevent automatic selection of days in the calendar after redirection from search results.' ,'booking'),'<b>','</b>')
                                    //, 'description' => __('Check this box to prevent automatic selection of days in the calendar after redirection from search results.', 'booking')
                                    , 'description_tag' => 'span'
                                    , 'css' => ''
                                    , 'group' => 'search_advanced'
            );


		// FixIn: 10.0.0.39.
        $this->fields['booking_search_from_auto_open_checkout_cal'] = array(
                                      'type'    => 'checkbox'
                                    , 'default' => 'On'
                                    , 'title' => __('Auto-open Checkout Calendar', 'booking')
                                    , 'label'       => sprintf(__('Select this option to automatically open the checkout calendar after choosing a date in the check-in calendar on the search form.' ,'booking'),'<b>','</b>')
                                    , 'description' => ''
                                    , 'description_tag' => 'span'
                                    , 'css' => ''
                                    , 'group' => 'search_advanced'
            );

		$this->fields['hr_booking_search_form__no_dates_before'] = array( 'type' => 'hr', 'group' => 'search_advanced' );
		$this->fields['booking_search_form__dates_required_enabled'] = array(
									  'type'    	=> 'checkbox'
									, 'default' 	=> 'On'
									, 'title' 		=> __('Check-in/out Dates Required', 'booking')
									, 'label'       => sprintf(__('Enable this option to require users to select check-in and check-out dates in the search form. If disabled, searches will use other criteria, even if no dates are chosen.' ,'booking'),'<b>','</b>')
									, 'description' => ''
									, 'description_tag' => 'span'
									, 'css' => ''
									, 'group' => 'search_advanced'
			);
		$this->fields['booking_search_form__dates_required_warning'] = array(
									  'type'    	=> 'text'
									, 'default' 	=> __('Please select check-in and check-out dates to perform the search.','booking')
									, 'title' 		=> __( 'Warning for Missing Dates', 'booking' )
									, 'label'       => ''
									, 'description' => __( 'Set the warning message that appears when users try to search without selecting dates, if date selection is required.', 'booking' )
									, 'description_tag' => 'div'
									, 'css' 		=> 'width:100%;'
									, 'tr_class'    => 'wpbc_sub_settings_grayed'
									, 'group' => 'search_advanced'
			);
		$this->fields['hr_booking_search_form__no_dates_after'] = array( 'type' => 'hr', 'group' => 'search_advanced' );

        $this->fields['booking_search_from__search_header'] = array(
                                      'type'    => 'text'
                                    , 'default' 	=> '[result_count] ' . __('Result(s) Found','booking')
                                    , 'title' 		=> __( 'Search Results Title', 'booking' )
                                    , 'label'       => __( 'Type the title you want to appear above the search results. ', 'booking' )
                                    , 'description' => __( 'Type the title you want to appear above the search results. ', 'booking' ) . ' '
													   /* translators: 1: ... */
													   . sprintf( __( 'Use %s to display the number of search results.', 'booking' ), '<code>[result_count]</code>' )
                                    , 'description_tag' => 'div'
                                    , 'css' => 'width:100%;'
                                    , 'group' => 'search_advanced'
            );
        $this->fields['booking_search_from__search_nothing_found'] = array(
                                      'type'    => 'text'
                                    , 'default' 	=> __( 'Nothing Found','booking')
                                    , 'title' 		=> __( 'Nothing Found Message', 'booking' )
                                    , 'label'       => __( 'Enter the message to display when no search results are found.', 'booking' )
                                    , 'description' => __( 'Enter the message to display when no search results are found.', 'booking' )
                                    , 'description_tag' => 'div'
                                    , 'css' => 'width:100%;'
                                    , 'group' => 'search_advanced'
            );
        $this->fields['booking_search_from__search_header_advanced'] = array(
                                      'type'    => 'text'
                                    , 'default' 	=> __( 'Extended Search Results', 'booking' )
                                    , 'title' 		=> __( 'Extended Search Results Title', 'booking' )
                                    , 'label'       => __( 'Set the title for extra search results outside the selected dates in the search form, showing matches that are within a range of +/- N dates.', 'booking' )
                                    , 'description' => __( 'Set the title for extra search results outside the selected dates in the search form, showing matches that are within a range of +/- N dates.', 'booking' )
													  . ' '
													  /* translators: 1: ... */
													  . sprintf( __( 'Use %s to display the number of search results.', 'booking' ), '<code>[result_count]</code>' )
                                    , 'description_tag' => 'div'
                                    , 'css' => 'width:100%;'
                                    , 'group' => 'search_advanced'
            );

    }


    //                                                                              <editor-fold   defaultstate="collapsed"   desc=" Custom Validate $_POST " >    
    
    /**
	 * Custom Validate Textarea in POST request - escape data correctly.
     *  Primary  executed for element with ID: "validate_   ID    _post"        validate_   booking_search_form_show    _post
     *
     * @param string $post_key - key for POST 
     * @return string | false,  if no such POST
     */
    public function validate_booking_search_form_show_post( $post_key ) {
        return $this->validate_js_post( $post_key );
    }
    

    /**
	 * Custom Validate Textarea in POST request - escape data correctly.
     *  Primary  executed for element with ID: "validate_   ID    _post"        validate_   booking_found_search_item    _post
     *
     * @param string $post_key - key for POST 
     * @return string | false,  if no such POST
     */
    public function validate_booking_found_search_item_post( $post_key ) {
        return $this->validate_js_post( $post_key );
    }
    

    /**
	 * Custom Validate Textarea in POST request - escape data correctly. Allow JS.
     *
     * @param string $post_key - key for POST 
     * @return string | false,  if no such POST
     */
    public function validate_js_post( $post_key ) {

        $value = false;
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
        if ( isset( $_POST[ $post_key ] ) ) {
			// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
            $value = wp_kses(   trim( stripslashes( $_POST[ $post_key ] ) ),
                                array_merge(
                                                array(    'iframe' => array( 'src' => true, 'style' => true, 'id' => true, 'class' => true )
                                                        , 'script' => array( 'type' => true )       // Allow JS
                                                ),
                                                wp_kses_allowed_html( 'post' )
                                )
                    );
        }

        return $value;
    }

    //                                                                              </editor-fold>
}


// FixIn: 8.6.1.21.
/**
 * @param $datepick_format		'yy-mm-dd'
 *
 * @return string				'Y-m-d'
 */
function wpbc_get_php_dateformat_from_datepick_dateformat( $datepick_format ){
    /**
		$field_options[ 'yy-mm-dd' ] = array( 'title' => date_i18n( 'Y-m-d' ) );
		$field_options[ 'yy/mm/dd' ] = array( 'title' => date_i18n( 'Y/m/d' ) );
		$field_options[ 'mm/dd/yy' ] = array( 'title' => date_i18n( 'm/d/Y' ) );
		$field_options[ 'dd/mm/yy' ] = array( 'title' => date_i18n( 'd/m/Y' ) );
	 */

	$php_date_format = str_replace( 'yy', 'Y', $datepick_format );
	$php_date_format = str_replace( 'mm', 'm', $php_date_format );
	$php_date_format = str_replace( 'dd', 'd', $php_date_format );

	return $php_date_format;
}



/**
	 * Show Content
 *  Update Content
 *  Define Slug
 *  Define where to show
 */
class WPBC_Page_SettingsSearchAvailability extends WPBC_Page_Structure {
    

    public $gateway_api = false;
    
    /**
	 * API - for Fields of this Settings Page
     * 
     * @param array $init_fields_values - array of init form  fields data - this array  can  ovveride "default" fields and loaded data.
     * @return object API
     */
    public function get_api( $init_fields_values = array() ){
        
        if ( $this->gateway_api === false ) {
            $this->gateway_api = new WPBC_API_SettingsSearchAvailability( 'search_availability' , $init_fields_values );    
        }        
        return $this->gateway_api;
    }

    
    public function in_page() {
        
        if ( ! wpbc_is_mu_user_can_be_here( 'only_super_admin' ) ) {            // If this User not "super admin",  then  do  not load this page at all            
            return (string) wp_rand(100000, 1000000);
        }
        
        return 'wpbc-settings';
    }
    

    public function tabs() {
        

		$separator_i = 0;
		$subtab_default = array(
			'type'            => 'subtab',                        // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'.
			'title'           => '',                              // Example: __( 'Dashboard'                                                                   // Title of TAB.
			'page_title'      => '',                              // __( 'Search Availability'                                                                  // Title of Page.
			'hint'            => '',                              // __( 'Configure the layout and functionality of both the search form and search results.'   // Hint.
			'link'            => '',                              // wpbc_get_settings_url() . '&scroll_to_section=wpbc_general_settings_dashboard_tab',        // Link.
			'css_classes'     => '',                              // cls CSS .
			'font_icon'       => 'wpbc_icn_dashboard',
			'font_icon_right' => 'wpbc-bi-question-circle',                              // 'wpbc-bi-question-circle' .
			'default'         => false,                           // Is this sub tab activated by default or not: true || false.
		);

        $tabs = array();
		//$tabs[ 'search_availability_hr' . ( ++$separator_i ) ] = array_merge( $subtab_default, array( 'type' => 'separator' ,'folder_style' => '' ) );

        $tabs[ 'search' ] = array(
                              'title'     => __( 'Search Availability', 'booking')             // Title of TAB
                            , 'page_title'=> __( 'Search Availability', 'booking')      // Title of Page
                            , 'hint'      => __( 'Configure the layout and functionality of both the search form and search results.', 'booking')               // Hint
                            //, 'link'      => ''                                 // Can be skiped,  then generated link based on Page and Tab tags. Or can  be extenral link
                            //, 'position'  => ''                                 // 'left'  ||  'right'  ||  ''
                            //, 'css_classes'=> ''                                // CSS class(es)
                            //, 'icon'      => ''                                 // Icon - link to the real PNG img
                            , 'font_icon' => 'wpbc_icn_search'         // CSS definition  of forn Icon
                            //, 'default'   => false                               // Is this tab activated by default or not: true || false. 
                            //, 'disabled'  => false                              // Is this tab disbaled: true || false. 
                            //, 'hided'     => false                              // Is this tab hided: true || false. 
                            , 'subtabs'   => array()   
                    );

        $subtabs = array();
        $subtabs['search_form'] = array(
                              'type' => 'subtab'                                  // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'
                            , 'title'     => __( 'Search Form Layout', 'booking')             // Title of TAB
                            , 'page_title'=> __( 'Search Availability', 'booking')      // Title of Page
                            , 'hint'      => __( 'Configure the layout and functionality of both the search form and search results.', 'booking')               // Hint
                            , 'link' => wpbc_get_settings_url(). '&tab=search#wpbc-settings-admin-page'                                      // link
                            , 'css_classes' => ''                               // CSS class(es)
                            //, 'icon' => 'http://.../icon.png'                 // Icon - link to the real PNG img
							, 'default' 	=> true                                // Is this sub tab activated by default or not: true || false.
                            , 'content' 	=> 'content'                            // Function to load as conten of this TAB
							, 'font_icon' => 'wpbc_icn_search'         // CSS definition  of forn Icon
						  	, 'font_icon_right' => 'wpbc-bi-question-circle'
							//, 'checked_data' 			=> WPBC_EMAIL_NEW_ADMIN_PREFIX . WPBC_EMAIL_NEW_ADMIN_ID		// This is where we get content
							//, 'hint' => array( 'title' => __('Customization of email template, which is sending to Admin after new booking' ,'booking') , 'position' => 'right' )
                        );

        $subtabs['search_results'] = array(
                              'type' => 'subtab'                                  // Required| Possible values:  'subtab' | 'separator' | 'button' | 'goto-link' | 'html'
                            , 'title'       => __('Search Results Layout' ,'booking')        // Title of TAB
											  . '<span class="wpbc-bi-arrow-up-short" style="margin-left: auto;"></span>'
                            , 'page_title'  => __('Search Availability', 'booking')  // Title of Page
                            , 'hint'        => __( 'Configure the layout and functionality of both the search form and search results.', 'booking')               // Hint
                            , 'css_classes' => 'wpbc_navigation_sub_item'                               // CSS class(es)
							, 'attr' => array( 'style' => 'display:flex;' )
                            , 'font_icon' => 'wpbc-bi-file-text'                                                           // CSS definition of Font Icon
						  	, 'font_icon_right' => ''
                            , 'link' => wpbc_get_settings_url(). '&tab=search#wpbc_settings_search_results_form_metabox'                                      // link
                            , 'default' =>  false                                // Is this sub tab activated by default or not: true || false.
                            , 'content' => 'content'                            // Function to load as conten of this TAB
                        );

		$subtabs['search_options']                    = $subtabs['search_results'];
		$subtabs['search_options']['title']           = __( 'Search Options', 'booking' ) . '<span class="wpbc-bi-arrow-up-short" style="margin-left: auto;"></span>';
		$subtabs['search_options']['hint']            = __( 'Configure the layout and functionality of both the search form and search results.', 'booking' );
		$subtabs['search_options']['link']            = wpbc_get_settings_url() . '&tab=search#wpbc_settings_search_advanced_metabox';
		$subtabs['search_options']['font_icon']       = 'wpbc_icn_manage_search';
		$subtabs['search_options']['font_icon_right'] = '';

		// FixIn: 10.12.4.7.  $subtabs[ 'searchable_resources' . ( ++$separator_i ) ] = array_merge( $subtab_default, array( 'type' => 'separator' ,'folder_style' => '' ) );

		$subtabs['searchable_resources']                    = $subtabs['search_results'];
		$subtabs['searchable_resources']['title']           = __( 'Searchable Resources', 'booking' );
		$subtabs['searchable_resources']['hint']            = __( 'Define which booking resources can appear in search results.', 'booking' );
		$subtabs['searchable_resources']['link']            = wpbc_get_resources_url() . '&tab=searchable_resources&subtab=searchable_resources_options';
		$subtabs['searchable_resources']['font_icon']       = 'wpbc-bi-files';
		$subtabs['searchable_resources']['font_icon_right'] = 'wpbc-bi-question-circle';
		$subtabs['searchable_resources']['css_classes']     = 'wpbc_navigation_top_border';

		$tabs['search']['subtabs'] = $subtabs;

		return $tabs;
	}


    /** Show Content of Settings page */
    public function content() {

        $this->css();
        
        ////////////////////////////////////////////////////////////////////////
        // Checking 
        ////////////////////////////////////////////////////////////////////////

        do_action( 'wpbc_hook_settings_page_header', 'search_availability_settings');    // Define Notices Section and show some static messages, if needed
        
        if ( ! wpbc_is_mu_user_can_be_here('activated_user') ) return false;    // Check if MU user activated, otherwise show Warning message.
   
        if ( ! wpbc_is_mu_user_can_be_here('only_super_admin') ) return false;  // User is not Super admin, so exit.  Basically its was already checked at the bottom of the PHP file, just in case.
        
        
        ////////////////////////////////////////////////////////////////////////
        // Load Data 
        ////////////////////////////////////////////////////////////////////////
        
        $init_fields_values = array();               
        
        $this->get_api( $init_fields_values );

        ////////////////////////////////////////////////////////////////////////
        //  S u b m i t   Main Form  
        ////////////////////////////////////////////////////////////////////////
        
        $submit_form_name = 'wpbc_search_availability';                         // Define form name
        
        // $this->get_api()->validated_form_id = $submit_form_name;             // Define ID of Form for ability to  validate fields (like required field) before submit.
        
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
        if ( isset( $_POST['is_form_sbmitted_'. $submit_form_name ] ) ) {

            // Nonce checking    {Return false if invalid, 1 if generated between, 0-12 hours ago, 2 if generated between 12-24 hours ago. }
            $nonce_gen_time = check_admin_referer( 'wpbc_settings_page_' . $submit_form_name );  // Its stop show anything on submiting, if its not refear to the original page

            // Save Changes 
            $this->update();
        }   
        
        // Cache Reset 'deleted' 2024-05-18

        ////////////////////////////////////////////////////////////////////////
        // JavaScript: Tooltips, Popover, Datepick (js & css) 
        ////////////////////////////////////////////////////////////////////////
        
        echo '<span class="wpdevelop">';
        
        wpbc_js_for_bookings_page();                                        
        
        echo '</span>';

        ////////////////////////////////////////////////////////////////////////
        // Content  ////////////////////////////////////////////////////////////
        ?>
        <div class="clear" style="margin-top: -10px;"></div>
        <span class="metabox-holder">
            <form  name="<?php echo esc_attr( $submit_form_name ); ?>" id="<?php echo esc_attr( $submit_form_name ); ?>" action="" method="post" autocomplete="off">
                <?php 
                   // N o n c e   field, and key for checking   S u b m i t 
                   wp_nonce_field( 'wpbc_settings_page_' . $submit_form_name );
                ?><input type="hidden" name="is_form_sbmitted_<?php echo esc_attr( $submit_form_name ); ?>" id="is_form_sbmitted_<?php echo esc_attr( $submit_form_name ); ?>" value="1" /><?php

                ?><div class="clear" style="height:10px;"></div><?php

                ?><div class="wpbc_settings_row wpbc_settings_row_left"><?php
                
                    wpbc_open_meta_box_section( 'wpbc_settings_search_availability_form', __('Search Form Layout', 'booking') );
                        $this->toolbar_reset_to_default( 'search_form_show' );                                // Reset to Default Forms
                        $this->get_api()->show( 'general' );                               
                    wpbc_close_meta_box_section();
                ?>
                </div>  
                <div class="wpbc_settings_row wpbc_settings_row_right"><?php                
                
                    wpbc_open_meta_box_section( 'wpbc_settings_search_availability_form_help', __('Help', 'booking') );
                        $this->get_api()->show( 'search_form_help' );   
                    wpbc_close_meta_box_section();
                ?>
                </div>
                <div class="clear"></div>

                <div class="wpbc_settings_row wpbc_settings_row_left"><?php                
                
                    wpbc_open_meta_box_section( 'wpbc_settings_search_results_form', __('Search Results Layout' ,'booking') );
                        $this->toolbar_reset_to_default( 'found_search_item' );                                // Reset to Default Forms                    
                        $this->get_api()->show( 'search_results' );  
                        
                        echo  '<div class="clear" style="height:5px;"></div>';
//                            . '<div class="wpbc-settings-notice notice-info" style="text-align:left;">'
//                            .   '<strong>' . esc_html__('Note!' ,'booking') . '</strong> '
//                            .        __('CSS customization of search form and search results you can make at this file' ,'booking')
//                            .       ': <code>' . WPBC_PRO_PLUGIN_URL . '/inc/css/search-form.css</code>'
//                            . '</div>'
//                            . '<div class="clear"></div>';

                    wpbc_close_meta_box_section();
                
                ?>
                </div>  
                <div class="wpbc_settings_row wpbc_settings_row_right"><?php                
                
                    wpbc_open_meta_box_section( 'wpbc_settings_search_results_form_help', __('Help', 'booking') );                        
						$this->get_api()->show( 'search_results_help' );
                    wpbc_close_meta_box_section();
                ?>
                </div>
                <div class="clear"></div>
                
                <div class="wpbc_settings_row wpbc_settings_row_leftNO"><?php                

                    // FixIn: 8.4.7.8.
                    wpbc_open_meta_box_section( 'wpbc_settings_search_advanced', __('Search Options' ,'booking') );
					   $this->get_api()->show( 'search_advanced' );
					wpbc_close_meta_box_section();
                ?>
                </div>  
                <div class="clear"></div>
                <input type="submit" value="<?php esc_attr_e('Save Changes','booking'); ?>" class="button button-primary wpbc_submit_button" />
            </form>
        </span>
        <?php       


				// FixIn: 8.4.7.18.
		if (
    		( function_exists( 'wpbc_codemirror') )
    		&& ( is_user_logged_in() && 'false' !== wp_get_current_user()->syntax_highlighting )
		) {
    		$is_use_code_mirror = true;
		} else {
    		$is_use_code_mirror = false;
		}

    	if ( $is_use_code_mirror ) {

			wpbc_codemirror()->set_codemirror( array(
												'textarea_id' => '#search_availability_booking_search_form_show'
												// , 'preview_id'   => '#wpbc_add_form_html_preview'
			) );
			wpbc_codemirror()->set_codemirror( array(
												'textarea_id' => '#search_availability_booking_found_search_item'
												// , 'preview_id'   => '#wpbc_add_form_html_preview'
			) );

	    }

        do_action( 'wpbc_hook_settings_page_footer', 'search_availability_settings' );
    }


    /** Save Chanages */  
    public function update() {

        // Get Validated Email fields
        $validated_fields = $this->get_api()->validate_post();

        // Overwrite - allow HTML to  save

		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $validated_fields['booking_search_form_show']  =  trim( stripslashes( $_POST[ 'search_availability' . '_' . 'booking_search_form_show' ] ) );
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
        $validated_fields['booking_found_search_item'] =  trim( stripslashes( $_POST[ 'search_availability' . '_' . 'booking_found_search_item' ] ) );
        
        $validated_fields = apply_filters( 'wpbc_search_availability_validate_fields_before_saving', $validated_fields );   //Hook for validated fields.

        $this->get_api()->save_to_db( $validated_fields );
        
        wpbc_show_changes_saved_message();
    }


    // <editor-fold     defaultstate="collapsed"                        desc=" CSS  "  >
    
    /** CSS for this page */
    private function css() {
        ?>
        <style type="text/css">  
            .wpbc-help-message {
                border:none;
            }
            /* toolbar fix */
            .wpdevelop .visibility_container .control-group {
                margin: 2px 8px 3px 0;  /* margin: 0 8px 5px 0; */ /* FixIn:  9.5.4.8	*/
            }
            /* Selectbox element in toolbar */
            .visibility_container select optgroup{                            
                color:#999;
                vertical-align: middle;
                font-style: italic;
                font-weight: 400;
            }
            .visibility_container select option {
                padding:5px;
                font-weight: 400;
            }
            .visibility_container select optgroup option{
                padding: 5px 20px;       
                color:#555;
                font-weight: 600;
            }
            #wpbc_create_new_custom_form_name_fields {
                width: 360px;
                display:none;
            }
            @media (max-width: 399px) {
                #wpbc_create_new_custom_form_name_fields {
                    width: 100%;
                }                
            }
        </style>
        <?php
    }
    
    // </editor-fold>
    
    
    // <editor-fold     defaultstate="collapsed"                        desc="  S u p p o r t   "  >

		/** Selection  of default Template and Button for Reseting  */
		private function toolbar_reset_to_default( $template_type ) {

			?><div class="wpdevelop"><?php
			?><div class="visibility_container" style="display:block;"><?php


			$templates = array();

			if ( $template_type == 'search_form_show' ) {


				$templates['selector_hint'] = array(
														'title' => __('Select Template', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => 'font-weight: 400;border-bottom:1px dashed #ccc;color:#aaa;'
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'minimal_search_form' ] = array(
														'title' => __('Minimal', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);

				$templates[ 'standard_search_form' ] = array(
														'title' => __('Standard', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'single_day_search_form' ] = array(
														'title' => __('Single Day', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'timeslots_search_form' ] = array(
														'title' => __('Time-Slots', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'advanced_search_form' ] = array(
														'title' => __('Advanced', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'rooms_search_form' ] = array(
														'title' => __('Rooms', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);

			} else if ( $template_type == 'found_search_item' ) {

				$templates['selector_hint'] = array(
														'title' => __('Select Template', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => 'font-weight: 400;border-bottom:1px dashed #ccc;color:#aaa;'
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'standard_search_results' ] = array(
														'title' => __('Standard', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'simple_search_results' ] = array(
														  'title' => __('Simple', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'compact_search_results' ] = array(
														  'title' => __('Compact', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'advanced_search_results' ] = array(
														  'title' => __('Advanced', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => ''
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
				$templates[ 'old_search_results' ] = array(
														  'title' => __('Legacy', 'booking')
														, 'id' => ''
														, 'name' => ''
														, 'style' => 'font-weight: 400;border-top:1px dashed #ccc;color:#aaa;'
														, 'class' => ''
														, 'disabled' => false
														, 'selected' => false
														, 'attr' => array()
													);
			}

			$params = array(
							  'label_for' => $template_type                         // "For" parameter  of label element
							, 'label' => '' //__('Add New Field', 'booking')        // Label above the input group
							, 'style' => ''                                         // CSS Style of entire div element
							, 'items' => array(
	//                                array(
	//                                    'type' => 'addon'
	//                                    , 'element' => 'text'           // text | radio | checkbox
	//                                    , 'text' => __('Reset Search Availability Form', 'booking') . ':'
	//                                    , 'class' => ''                 // Any CSS class here
	//                                    , 'style' => 'font-weight:600;' // CSS Style of entire div element
	//                                )
									// Warning! Can be text or selectbox, not both  OR you need to define width
									 array(
										  'type' => 'select'
										, 'id'   => $template_type
										, 'name' => $template_type
										, 'style' => 'width:200px;'
										, 'class' => ''
										, 'multiple' => false
										, 'disabled' => false
										, 'disabled_options' => array()             // If some options disbaled,  then its must list  here
										, 'attr' => array()                         // Any  additional attributes, if this radio | checkbox element
										, 'options' => $templates                   // Associated array  of titles and values
										, 'value' => ''                             // Some Value from optins array that selected by default
										, 'onfocus' => ''
										//, 'onchange' => "wpbc_show_fields_generator( this.options[this.selectedIndex].value );"
									)
							)
						);




			?><div class="control-group wpbc-no-padding"><?php
					wpbc_bs_input_group( $params );
			?></div><?php


			$params = array(
						  'label_for' => $template_type                             // "For" parameter  of label element
						, 'label' => '' //__('Add New Field', 'booking')            // Label above the input group
						, 'style' => ''                                             // CSS Style of entire div element
						, 'items' => array(
											array(
												'type' => 'button'
												, 'title' => __('Reset', 'booking')  // __('Reset', 'booking')
												, 'hint' => array( 'title' => __('Reset current Form' ,'booking') , 'position' => 'top' )
												, 'class' => 'button tooltip_top'
												, 'font_icon' => 'wpbc_icn_rotate_left'
												, 'icon_position' => 'right'
												, 'action' => " var sel_res_val = document.getElementById('" . $template_type . "').options[ document.getElementById('" . $template_type . "').selectedIndex ].value;"
															. " if   ( sel_res_val == 'selector_hint') { "
															. "    wpbc_field_highlight( '#" . $template_type . "' ); return;"          //. "  jQuery('#wpbc_search_availability').trigger( 'submit' );"
															. " }"
															//. " if ( wpbc_are_you_sure('" . esc_js(__('Do you really want to do this ?' ,'booking')) . "') ) {"
															. "    wpbc_reset_form_to_template( 'search_availability_booking_" . $template_type . "', sel_res_val ); "          //. "  jQuery('#wpbc_search_availability').trigger( 'submit' );"
															//. " }"
											)
								)
						);

			?><div class="control-group wpbc-no-padding"><?php
					wpbc_bs_input_group( $params );
			?></div><?php


			?></div></div><?php
			?><div class="clear"></div><?php

			?>
			<script type="text/javascript">
				function wpbc_reset_form_to_template( form_id, template_name ) {
					var search_form_content = '';
					if ( form_id == 'search_availability_booking_search_form_show' ) {
						if ( template_name == 'standard_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('standard_search_form') ); ?>';	// FixIn: 8.5.2.11.
						}
						if ( template_name == 'single_day_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('single_day_search_form') ); ?>';
						}
						if ( template_name == 'timeslots_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('timeslots_search_form') ); ?>';
						}
						if ( template_name == 'minimal_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('minimal_search_form') ); ?>';
						}
						if ( template_name == 'advanced_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('advanced_search_form') ); ?>';
						}
						if ( template_name == 'rooms_search_form' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_form_template('rooms_search_form') ); ?>';
						}
					}
					if ( form_id == 'search_availability_booking_found_search_item' ) {
						if ( template_name == 'standard_search_results' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_results_template('standard_search_results') ); ?>';
						}
						if ( template_name == 'compact_search_results' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_results_template('compact_search_results') ); ?>';
						}
						if ( template_name == 'simple_search_results' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_results_template('simple_search_results') ); ?>';
						}
						if ( template_name == 'old_search_results' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_results_template('old_search_results') ); ?>';
						}
						if ( template_name == 'advanced_search_results' ) {
							search_form_content = '<?php
								// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
								echo str_replace( '\\n\\r', '\n', wpbc_get_default_search_results_template('advanced_search_results') ); ?>';
						}
					}
					wpbc_reset_wp_editor_content( form_id, search_form_content );
				}
				jQuery( document ).ready( function (){

					jQuery( '#search_availability_booking_search_form__dates_required_enabled' ).on( 'change', function (){
						if ( jQuery( '#search_availability_booking_search_form__dates_required_enabled' ).is( ':checked' ) ){
							jQuery( '.wpbc_tr_search_availability_booking_search_form__dates_required_warning' ).removeClass( 'hidden_items' );
						} else {
							jQuery( '.wpbc_tr_search_availability_booking_search_form__dates_required_warning' ).addClass( 'hidden_items' );
						}
					} );
					if ( jQuery( '#search_availability_booking_search_form__dates_required_enabled' ).is( ':checked' ) ){
						jQuery( '.wpbc_tr_search_availability_booking_search_form__dates_required_warning' ).removeClass( 'hidden_items' );
					} else {
						jQuery( '.wpbc_tr_search_availability_booking_search_form__dates_required_warning' ).addClass( 'hidden_items' );
					}
				} );
			</script>
			<?php
		}

    // </editor-fold>
    
}
add_action('wpbc_menu_created', array( new WPBC_Page_SettingsSearchAvailability() , '__construct') );    // Executed after creation of Menu