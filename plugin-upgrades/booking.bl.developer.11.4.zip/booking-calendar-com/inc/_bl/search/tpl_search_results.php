<?php
/**
 * @version     1.0
 * @package     New Search Results
 * @category    Search Availability
 * @author      wpdevelop
 *
 * @web-site    https://wpbookingcalendar.com/
 * @email       info@wpbookingcalendar.com
 * @modified    2024-05-03
 *
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

// KEY: 'wpbc_search_avy'                                                       // FixIn: 10.0.0.37.


/**
 * Do Search  and show Search Results
 *
 * @param $shortcode_attr
 *
 * @return void
 */
function wpbc_search_avy__show_search_results( $shortcode_attr  = array()) {

	$defaults = array( 'is_silent' => false );
	$shortcode_attr = wp_parse_args( $shortcode_attr, $defaults );


	// -----------------------------------------------------------------------------------------------------------------
    // Search available resources for specific dates  and other params                                                  // FixIn: 10.0.0.37.
	// -----------------------------------------------------------------------------------------------------------------
	$found_resources = wpbc_search_avy__do_search();
	/**
	 * Return:      [       [   [dates_only_sql_arr]    => [ '2024-05-14', '2024-05-15', '2024-05-16' ]
	 *                          [resource_id_arr]       => [ 230, 231, 236, 238 ]
	 *                          [max_availability]      => [ [230] => 1,   [231] => 5,  [236] => 1, [238] => 1  ]
	 *                          [time_as_seconds_arr]   => [ 0, 24 * 60 * 60]
	 *                      ],
	 *                      [
	 *                          [dates_only_sql_arr]    => [ '2024-05-15', '2024-05-16', '2024-05-17' ]
	 *                          [resource_id_arr]       => [ 237 ]
	 *                          [max_availability]      => [ [237] => 1 ]
	 *                          [time_as_seconds_arr]   => [ 0, 24 * 60 * 60]
	 *                      ]
	 *              ]
     */

	/**
	 *	// For Testing ::  49 seconds difference for intersections !!!
	    $found_resources = wpbc_search_avy__do_search(	array(
															'time_as_seconds_arr' => array( 12 * 60 * 60    - 49+1,
																							16 * 60 * 60 )
														)
													);
	 */

	$is_include_field_type = true;
	$form_for_cost = wpbc_search_avy__get_form_fields__from__search_request( $is_include_field_type );                                          //'selectbox-one^visitors[resource_id]^' . '1'
	$is_include_field_type = false;
	$form_for_auto_fill = wpbc_search_avy__get_form_fields__from__search_request( $is_include_field_type );                                     //'visitors[resource_id]^' . '1'

	$resources_sorted_details_arr = wpbc_search_avy__search_results__get_sort_details_arr( $found_resources, $form_for_cost );
	/**
	 *   Return:     [main_count]        => 13
	 *   [main_search_results_id]        => [ 2, 3, 4, 14, 15, 1, 227, 225, 230, 226, 231, 236, 238 ]
	 *   [main_search_results]           => [       [  [0] => [  '2024-05-14', '2024-05-15'  ],    [1] => [ 2, 3, 4, 14, 15, 1, 227, 225, 230, 226, 231, 236, 238 ]    ]    ]
	 *   [advanced_count]                => 3
	 *   [advanced_search_results_id_arr] => [13, 237, 228 ]
	 *   [advanced_search_results]       => [...]
	 *   [resources__check_in_out_arr]   => [...]
	 *   [all_resources_id_arr]          => [  2, 3, 4, 14, 15, 1 ..., 228 ]
	 *   [sorted_resources_id_arr]       => [ 13, 3, 2, 1, 4, 225 ..., 238 ]
	 *   [resource_obj__arr]             => [...]
	 */

	$search_time_arr = wpbc_search_avy__get_search_time__from__search_request();

	// -----------------------------------------------------------------------------------------------------------------
	// Templates
	// -----------------------------------------------------------------------------------------------------------------
	$found_item_tpl_content = get_bk_option( 'booking_found_search_item' );
	$found_item_tpl_content = wpbc_lang( $found_item_tpl_content );
	$found_item_tpl_content = wpbc_bf__replace_custom_html_shortcodes( $found_item_tpl_content );						// Replace "Simple HTML" shortcodes

	$booking_form_theme = get_bk_option( 'booking_form_theme' );
	$booking_form_is_using_bs_css = get_bk_option( 'booking_form_is_using_bs_css' );
	echo '<div class="booking_search_ajax_container wpbc_container wpbc_container_search wpbc_container_search_results '
																		. ( ( wpbc_is_this_demo() == 'On' ) ? 'wpbc_demo_site ' : '' )
	                            										. esc_attr( $booking_form_theme ) . ' '
	                            										. ( ( $booking_form_is_using_bs_css == 'On' ) ? 'wpdevelop ' : '' )
	                            . '">';

		// Title
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo wpbc_search_avy__search_results_tpl__header( $resources_sorted_details_arr['main_count'] );

		// Main search results
		foreach ( $resources_sorted_details_arr['sorted_resources_id_arr'] as $sorted_resources_id ) {
			if ( in_array( $sorted_resources_id, $resources_sorted_details_arr['main_search_results_id'] ) ) {

				// Show One Row
				wpbc_search_avy__search_results_tpl__item_row( array(
						'resource_obj'          => $resources_sorted_details_arr['resource_obj__arr'][ $sorted_resources_id ],
						'check_in_out_arr'      => $resources_sorted_details_arr['resources__check_in_out_arr'][ $sorted_resources_id ],
						'template'              => $found_item_tpl_content,
						'auto_fill_form_fields' => $form_for_auto_fill,
						'search_time_arr' 		=> $search_time_arr
					) );
			}
		}


		if ( ! empty( $resources_sorted_details_arr['advanced_count'] ) ) {

			// Advanced Title
			wpbc_search_avy__advanced_search_results_tpl__header( $resources_sorted_details_arr['advanced_count'] );

			// Advanced search  results
			foreach ( $resources_sorted_details_arr['sorted_resources_id_arr'] as $sorted_resources_id ) {
				if ( in_array( $sorted_resources_id, $resources_sorted_details_arr['advanced_search_results_id_arr'] ) ) {

					// Show One Row
					wpbc_search_avy__search_results_tpl__item_row( array(
							'resource_obj'          => $resources_sorted_details_arr['resource_obj__arr'][ $sorted_resources_id ],
							'check_in_out_arr'      => $resources_sorted_details_arr['resources__check_in_out_arr'][ $sorted_resources_id ],
							'template'              => $found_item_tpl_content,
							'auto_fill_form_fields' => $form_for_auto_fill,
							'search_time_arr' 		=> $search_time_arr
					) );
				}
			}
		}

	echo '</div>';
}


	/**
	 * Get Search Time Field  		from  Search Request
	 *
	 * @return array       e.g. ->  	[  0,   24 * 60 * 60  ]
	 */
	function wpbc_search_avy__get_search_time__from__search_request() {

		if ( is_admin() && ( defined( 'DOING_AJAX' ) ) && ( DOING_AJAX ) ) {
			$prefix = 'search_ajx__';
		} else {
			$prefix = 'search_get__';
		}

		// -------------------------------------------------------------------------------------------------------------
		// Custom Params
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( isset( $_REQUEST[ $prefix . 'custom_params'] ) ) {


			// Fix separator in URL from  '_^_' to '~'
			$search_get__custom_params = str_replace( '_^_', '~', $_REQUEST[ $prefix . 'custom_params' ] );	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			// // Support types:   'text' | 'selectbox-one' | 'select-multiple' | 'selectbox-one' | 'selectbox-multiple' | 'radio' | 'checkbox' .  Note: values for several selected options in 'select-multiple' separated by ', '
			$search_request_params = wpbc_get_parsed_booking_data_arr( $search_get__custom_params, '_DATA_TO_SKIP' );


			foreach ( $search_request_params as $search_param_arr ) {

				if ( 'search_time' == $search_param_arr['name'] ) {

					$cleaned_value = wpbc_clean_text_value( $search_param_arr['value'] );
					// Searching for specific time slot
					if ( ! empty( $cleaned_value ) ) {

						$time_range_in_seconds     = wpbc_convert__readable_time_slot__to__time_range_in_seconds( $cleaned_value );
						$time_range_in_seconds_arr = explode( ' - ', $time_range_in_seconds );

						$time_range_in_seconds_arr[0] = intval( $time_range_in_seconds_arr[0] ) - 10 - 1;
						$time_range_in_seconds_arr[1] = intval( $time_range_in_seconds_arr[1] ) + 10 - 2;

						$time_range_in_seconds_arr[0] = ( $time_range_in_seconds_arr[0] < 0 ) ? 0 : $time_range_in_seconds_arr[0];
						$time_range_in_seconds_arr[1] = ( $time_range_in_seconds_arr[1] > 24 * 60 * 60 ) ? 24 * 60 * 60 : $time_range_in_seconds_arr[1];

						return $time_range_in_seconds_arr;
					}

				}
			}

			// No search  time, so  we will  check  about check in/out
			if( wpbc_is_booking_used_check_in_out_time() ) {
				$cleaned_value = esc_attr( get_bk_option( 'booking_range_selection_start_time' ) );
				$cleaned_value .= ' - ';
				$cleaned_value .= esc_attr( get_bk_option( 'booking_range_selection_end_time' ) );
				if ( ! empty( $cleaned_value ) ) {

					$time_range_in_seconds     = wpbc_convert__readable_time_slot__to__time_range_in_seconds( $cleaned_value );
					$time_range_in_seconds_arr = explode( ' - ', $time_range_in_seconds );

					$time_range_in_seconds_arr[0] = intval( $time_range_in_seconds_arr[0] ) - 10 - 1;
					$time_range_in_seconds_arr[1] = intval( $time_range_in_seconds_arr[1] ) + 10 - 2;

					$time_range_in_seconds_arr[0] = ( $time_range_in_seconds_arr[0] < 0 ) ? 0 : $time_range_in_seconds_arr[0];
					$time_range_in_seconds_arr[1] = ( $time_range_in_seconds_arr[1] > 24 * 60 * 60 ) ? 24 * 60 * 60 : $time_range_in_seconds_arr[1];

					return $time_range_in_seconds_arr;
				}
			}


		}

		return array( 0, 24 * 60 * 60 );
	}



	/**
	 * Get Form Fields (as saved booking form data) from  Search Request,  for future calculation  of booking cost
	 *
	 * @return string       e.g. -> 'selectbox-one^visitors[resource_id]^' . '1'
	 */
	function wpbc_search_avy__get_form_fields__from__search_request( $is_include_field_type = true ) {

		if (  is_admin() && ( defined( 'DOING_AJAX' ) ) && ( DOING_AJAX )  ) {
			$prefix = 'search_ajx__';
		} else {
			$prefix = 'search_get__';
		}


		$booking_form_fields_arr = array();

		// -------------------------------------------------------------------------------------------------------------
		// Custom Params
		// -------------------------------------------------------------------------------------------------------------
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing
		if ( isset( $_REQUEST[ $prefix . 'custom_params'] ) ) {


			// Fix separator in URL from  '_^_' to '~'
			$search_get__custom_params = str_replace( '_^_', '~', $_REQUEST[ $prefix . 'custom_params' ] );	// phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.NonceVerification.Missing, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

			// // Support types:   'text' | 'selectbox-one' | 'select-multiple' | 'selectbox-one' | 'selectbox-multiple' | 'radio' | 'checkbox' .  Note: values for several selected options in 'select-multiple' separated by ', '
			$search_request_params = wpbc_get_parsed_booking_data_arr( $search_get__custom_params, '_DATA_TO_SKIP' );

			foreach ( $search_request_params as $search_param_arr ) {
				// Filter only visible input fields:      Only  such TYPES used for search request:
				if (
					   (   in_array( $search_param_arr['type'], array( 'text', 'select-one', 'selectbox-one', 'select-multiple', 'selectbox-multiple', 'radio', 'checkbox') ) )
					&& ( ! in_array( $search_param_arr['name'], array( 'search_field__display_check_in', 'search_field__display_check_out', 'search_time', 'search_quantity', 'search_field__extend_search_days' ) ) )
				){

					// Sanitize part value of $_REQUEST[ $prefix . 'custom_params']
					$cleaned_name  = wpbc_clean_text_value( $search_param_arr['name'] );
					$cleaned_value = wpbc_clean_text_value( $search_param_arr['value'] );

					// Set not empty names
					if ( ( ! empty( $cleaned_name ) ) && ( '' !== $cleaned_value ) ) {

						$booking_form_fields_arr[] = ( $is_include_field_type )
														? $search_param_arr['type'] . '^' . $cleaned_name . '[resource_id]^' . $cleaned_value
														: $cleaned_name . '[resource_id]^' . $cleaned_value;
					}
				}

				if ( 'search_quantity' == $search_param_arr['name'] ) {
					$capacity_field_name = wpbc_get__booking_capacity_field__name();
					if ( ! empty( $capacity_field_name ) ) {
						$cleaned_value             = wpbc_clean_text_value( $search_param_arr['value'] );
						if ( '' !== $cleaned_value ) {
							$booking_form_fields_arr[] = ( $is_include_field_type )
															? 'selectbox-one^' . $capacity_field_name . '[resource_id]^' . $cleaned_value
															: $capacity_field_name . '[resource_id]^' . $cleaned_value;
						}
					}
				}

				if ( 'search_time' == $search_param_arr['name'] ) {
					$time_field_name = 'rangetime';
					if ( ! empty( $time_field_name ) ) {
						$cleaned_value             = wpbc_clean_text_value( $search_param_arr['value'] );
						if ( '' !== $cleaned_value ) {
							$booking_form_fields_arr[] = ( $is_include_field_type )
															? 'selectbox-one^' . $time_field_name . '[resource_id]^' . $cleaned_value
															: $time_field_name . '[resource_id]^' . $cleaned_value;
						}
					}
				}



			}
		}

		$booking_form_fields_str = implode( '~', $booking_form_fields_arr );

	    return $booking_form_fields_str;    // 'selectbox-one^visitors[resource_id]^' . '1';
	}


	/**
	 * Get Sorted Search Results arr
	 *
	 * @param $found_resources                                    [ [   ["2024-10-14","2024-10-15","2024-10-16","2024-10-17"],
	 *                                                                  [2,3,14,15,13,1,227,220,225,228,230,226,231,237,236,238]
	 *                                                              ],
	 *                                                              [
	 *                                                                  ["2024-10-19","2024-10-20","2024-10-21","2024-10-22"],
	 *                                                                  [4]
	 *                                                              ]
	 *                                                            ]
	 * @param $form_for_cost string                               'selectbox-one^visitors[resource_id]^1'
	 *                                                            where '1' it's value selected in search form
	 *                                                            Required for correct  cost  calculation if defined cost at WP Booking Calendar > Prices > Form Options Costs page
	 *
	 * @return array        [
	 *                            [main_count]            => 13
	 *                            [main_search_results_id] => [ 2, 3, 4, 14, 15, 1, 227, 225, 230, 226, 231, 236, 238 ]
	 *                            [main_search_results]    => [  [0] => [  '2024-05-14', '2024-05-15'  ]
	 *                                                           [1] => [ 2, 3, 4, 14, 15, 1, 227, 225, 230, 226, 231, 236, 238 ]    ]
	 *                            [advanced_count]        => 3
	 *                            [advanced_search_results_id_arr] => [13, 237, 228 ]
	 *                            [advanced_search_results] => [
	 *                                                          [0] => [    [0] => [ '2024-05-15', '2024-05-16'  ]
	 *                                                                      [1] => [ 13, 237 ]    ]
	 *                                                          [1] => [    [0] => [ '2024-05-18', '2024-05-19' ]
	 *                                                                      [1] => [ 228 ]      ]
	 *                                                          ]
	 *                            [resources__check_in_out_arr] =>  [
	 *                                    [2] => [ [0] => 2024-05-14, [1] => 2024-05-15 ]
	 *                                    [3] => [ [0] => 2024-05-14, [1] => 2024-05-15 ]
	 *                                    [4] => [ [0] => 2024-05-14, [1] => 2024-05-15 ]
	 *                                    , ...
	 *                                    [13] => [ [0] => 2024-05-15, [1] => 2024-05-16 ]
	 *                                    , ...
	 *                                    [237] => [ [0] => 2024-05-15, [1] => 2024-05-16 ]
	 *                                    [228] => [ [0] => 2024-05-18, [1] => 2024-05-19 ]
	 *                                ]
	 *                            [all_resources_id_arr]     => [  2, 3, 4, 14, 15, 1 ..., 228 ]
	 *                            [sorted_resources_id_arr]  => [ 13, 3, 2, 1, 4, 225 ..., 238 ]
	 *                            [resource_obj__arr]        => [ [237] => stdClass Object (      [booking_type_id] => 237
	 *                                                                                            [title] => Double Room
	 *                                                                                            [users] => 1
	 *                                                                                            [import] =>
	 *                                                                                            [export] =>
	 *                                                                                            [cost] => 0
	 *                                                                                            [default_form] => standard
	 *                                                                                            [prioritet] => 0
	 *                                                                                            [parent] => 0
	 *                                                                                            [visitors] => 1
	 *                                                                                            [sort_key] => 0
	 *                                                                                            [capacity] => 1
	 *                                                                                            [booking_cost_arr] => [ [additional_description] => '...', [payment_cost] => 0.00, ...  ]
	 *                                                                                            [booking_cost] => 0.00
	 *                                                                                            ['search_options'] => [ ... ]
	 *                                                                                        ), ...
	 *                                                            ]
	 *                        ]
	 */
	function wpbc_search_avy__search_results__get_sort_details_arr( $found_resources , $form_for_cost = '' ) {

		$return_arr = array();

		// -----------------------------------------------------------------------------------------------------------------
		// Count Main  and Advanced search  results
		// -----------------------------------------------------------------------------------------------------------------
		$all_resources_id_arr        = array();
		$resources__check_in_out_arr = array();
		$resources__max_availability_arr = array();

		$main_search_results     = array();
		$main_search_results_id_arr = array();

		$advanced_search_results = array();
		$advanced_search_results_id_arr = array();
		$advanced_count = 0;
		foreach ( $found_resources as $search_dates_interval_index => $found_resource_arr ) {
			if ( 0 == $search_dates_interval_index ) {
				$main_search_results = $found_resource_arr;
				$main_search_results_id_arr = array_merge( $main_search_results_id_arr, $found_resource_arr['resource_id_arr'] );
			} else {
				if ( ! empty( $found_resource_arr['resource_id_arr'] ) ) {
					$advanced_count += count($found_resource_arr['resource_id_arr']);
					$advanced_search_results[] = $found_resource_arr;
					$advanced_search_results_id_arr = array_merge( $advanced_search_results_id_arr, $found_resource_arr['resource_id_arr'] );
				}
			}

			// Get check in/out for each booking resource,  and ID of all found booking resources
			foreach ( $found_resource_arr['resource_id_arr'] as $resource_id  ) {
				$dates_sql_arr = $found_resource_arr['dates_only_sql_arr'];
				$resources__check_in_out_arr[ $resource_id ] = array(   $dates_sql_arr[0],    $dates_sql_arr[ count( $dates_sql_arr ) - 1 ]	);
				$all_resources_id_arr[]= $resource_id;
				$resources__max_availability_arr[ $resource_id ] = $found_resource_arr['max_availability'][ $resource_id ];
			}
		}

		$return_arr['main_count']             = count( $main_search_results['resource_id_arr'] );
		$return_arr['main_search_results_id'] = $main_search_results_id_arr;
		$return_arr['main_search_results']    = $main_search_results;

		$return_arr['advanced_count']                 = $advanced_count;
		$return_arr['advanced_search_results_id_arr'] = $advanced_search_results_id_arr;
		$return_arr['advanced_search_results']        = $advanced_search_results;

		$return_arr['resources__check_in_out_arr'] = $resources__check_in_out_arr;
		$return_arr['all_resources_id_arr']        = $all_resources_id_arr;
		$return_arr['max_availability']            = $resources__max_availability_arr;


		// -----------------------------------------------------------------------------------------------------------------
		// Get resources Details        and         Sort Search Results
		// -----------------------------------------------------------------------------------------------------------------

	    // Get here Obj. of all found booking resources                                                                     // 'as_single_resource' => true   -->  skip child booking resources
		$resources_obj = new WPBC_RESOURCE_SUPPORT( array( 'resource_id' => $all_resources_id_arr ) );
		$all_resource_obj__arr = $resources_obj->get_resources_obj_arr();

		$resource_obj__arr = array();
		foreach ( $all_resources_id_arr as $res_id ) {
			$resource_obj__arr[ $res_id ] = $all_resource_obj__arr[ $res_id ];
		}

		// Sort Resources
		$sorted_resources_obj = wpbc_search_avy__sort_resources( $resource_obj__arr, $resources__check_in_out_arr, $form_for_cost );

		/**
		 *  Get array of searchable booking resources:
		 *
		 * [      228 => [    [is_searchable] => 'On'
		 *                    [url]           => 'http://beta/?p=4613'
		 *                    [title]         => 'Post  for Test  search  resource ID = 228'
		 *                    [description]   => 'Small - description  in excerpt  Post  for Test  search  resource ID = 228'
		 *                    [picture]       => 'http://beta/wp-content/uploads/2024/04/a5718ad.jpg'
		 *                    [options]       => 'booking_tv^=^"yes"~booking_tv^=^Sony'~booking_pets^=^false'
		 *                    [category]      => [ 0 => [
		 *                                                [category] => Uncategorized
		 *                                                [slug] => uncategorized-en
		 *                                                [ID] => 31
		 *                                            ], ...
		 *                                       ]
		 *                    [tags] => []
		 *        ], ...
		 * ]
		 */
		$saved_search_filters_arr = wpbc_searchable_resources__get_all_options();

		$sorted_resources_id_arr = array();
		foreach ( $sorted_resources_obj as $resource_obj ) {

			$sorted_resources_id_arr[] = intval( $resource_obj->booking_type_id );

			$resource_obj__arr[ $resource_obj->booking_type_id ]->booking_cost_arr = $resource_obj->booking_cost_arr;
			$resource_obj__arr[ $resource_obj->booking_type_id ]->booking_cost     = $resource_obj->booking_cost;
			$resource_obj__arr[ $resource_obj->booking_type_id ]->max_availability = $resources__max_availability_arr[ $resource_obj->booking_type_id ];

			if ( ! empty( $saved_search_filters_arr[ $resource_obj->booking_type_id ] ) ) {
				$resource_obj__arr[ $resource_obj->booking_type_id ]->search_options = $saved_search_filters_arr[ $resource_obj->booking_type_id ];
				$resource_obj__arr[ $resource_obj->booking_type_id ]->search_options['options_arr'] = wpbc_searchable_resources__filters__get_as_arr( $resource_obj__arr[ $resource_obj->booking_type_id ]->search_options['options'] );
			}
		}
		// -----------------------------------------------------------------------------------------------------------------

		$return_arr['sorted_resources_id_arr'] = $sorted_resources_id_arr;
		$return_arr['resource_obj__arr']       = $resource_obj__arr;

		return $return_arr;
	}


		/**
		 * Define Sorting   O R D E R   of booking resources (Search Results)       and       Calculate booking    C O S T
		 *
		 * @param $resource_obj__arr
		 * @param $resources__check_in_out_arr
		 * @param $form_for_cost
		 *
		 * @return array    $sorted_resource_obj__arr        Indexes Reseted !
		 */
		function wpbc_search_avy__sort_resources( $resource_obj__arr , $resources__check_in_out_arr, $form_for_cost = '' ) {

		    // Sort the booking resources array with priority descending ///////////
		    $sort_free_objects = array();

		    $booking_search_results_order = get_bk_option( 'booking_search_results_order' );                                // FixIn: 8.4.7.8.
			$sort_type = 'SORT_NUMERIC';
		    /**
		     *   [    stdClass Object -> (
		     *                                [booking_type_id] => 230
		     *                                [title] => Penthouse
		     *                                [users] => 1
		     *                                [import] =>
		     *                                [export] =>
		     *                                [cost] => 100
		     *                                [default_form] => standard
		     *                                [prioritet] => 0
		     *                                [parent] => 0
		     *                                [visitors] => 1
		     *                                [sort_key] => 1
		     *                                [capacity] => 1
		     *                            )
		     *      , ...
		     *   ]
		     */
		    foreach ( $resource_obj__arr as $key => $value ) {

				// Probably lost booking resource
		        if ( ! isset( $value->booking_type_id ) ) {    // FixIn: 9.7.1.2.
			        continue;
		        }

				// ---------------------------------------------------------------------------------------------------------
		        /**
		         * $total_cost_of_booking = [
		         *        [additional_description] =>
		         *        [payment_cost] => 0.00
		         *        [payment_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
		         *        [total_cost] => 400.00
		         *        [cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>400.00</span>
		         *        [total_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>400.00</span>
		         *        [deposit_cost] => 400.00
		         *        [deposit_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>400.00</span>
		         *        [deposit_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>400.00</span>
		         *        [balance_cost] => 0.00
		         *        [balance_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
		         *        [balance_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
		         *        [original_cost] => 400.00
		         *        [original_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>400.00</span>
		         *        [additional_cost] => 0.00
		         *        [additional_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
		         *        [coupon_discount] => 0.00
		         *        [coupon_discount_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
		         *    ]
		         */
		        $total_cost_of_booking = wpbc_get_costs_i_hints__based_on_cost_calc( array(
					        'form'              => str_replace( '[resource_id]', $value->booking_type_id, $form_for_cost ),         //'selectbox-one^visitors' . $value->booking_type_id . '^' . $this->search_param_visitors,
					        'days_input_format' => wpbc_get_comma_seprated_dates_from_to_day(
																							  date_i18n( "d.m.Y", strtotime( $resources__check_in_out_arr[$value->booking_type_id][0] ) ),
					                                                                          date_i18n( "d.m.Y", strtotime( $resources__check_in_out_arr[$value->booking_type_id][1] ) )
				                                                                            ),
					        'resource_id'       => $value->booking_type_id,
					        'booking_form_type' => apply_bk_filter( 'wpbc_get_default_custom_form', 'standard', $value->booking_type_id )
				        ) );
				// Set  here total  cost of the booking, which  possibly  will be used in search  results replacing [cost_hint] shortcodes
		        $resource_obj__arr[ $key ]->booking_cost_arr = $total_cost_of_booking;
				$resource_obj__arr[ $key ]->booking_cost     = $total_cost_of_booking['total_cost'];                        // Needs for sorting order
				// ---------------------------------------------------------------------------------------------------------

		        // Sort Search  results by booking cost
		        if (    	   ( 'cost_booking' == $booking_search_results_order )
					        || ( 'cost_booking_asc' == $booking_search_results_order ) ) {
							$sort_free_objects[] = $total_cost_of_booking['total_cost'];

		        } else if (    ( 'id' == $booking_search_results_order )
					        || ( 'id_asc' == $booking_search_results_order ) ) {
			        $sort_free_objects[] = $value->booking_type_id;

		        } else if (    ( 'title' == $booking_search_results_order )
					        || ( 'title_asc' == $booking_search_results_order ) ) {
			        $sort_free_objects[] = $value->title;

			        $sort_type = 'SORT_STRING';

		        } else if (    ( 'prioritet' == $booking_search_results_order )
					        || ( 'prioritet_asc' == $booking_search_results_order ) ) {
			        $sort_free_objects[] = $value->prioritet;

		        } else if (    ( 'cost' == $booking_search_results_order )
					        || ( 'cost_asc' == $booking_search_results_order ) ) {
			        $sort_free_objects[] = $value->cost;

		        } else {	// Otherwise default search  by  priority

		            $sort_free_objects[] = $value->prioritet;
				}
		    }

			array_multisort( $sort_free_objects
							, (  ( strpos( $booking_search_results_order, '_asc' ) ) ? SORT_ASC : SORT_DESC )
							, (  ( 'SORT_NUMERIC' == $sort_type )  ? SORT_NUMERIC : SORT_STRING  )
							, $resource_obj__arr );

		    ////////////////////////////////////////////////////////////////////////
			// FixIn: 8.7.3.1.
			if ( 'shuffle' == $booking_search_results_order ) {
				shuffle( $resource_obj__arr );
			}

			return $resource_obj__arr;
		}


// ---------------------------------------------------------------------------------------------------------------------
// Templates
// ---------------------------------------------------------------------------------------------------------------------
/**
 * Show Search Results Header   -   e.g.    'Search results: 10 items found.'
 *
 * @param $found_main_results_number   int
 *
 * @return void
 */
function wpbc_search_avy__search_results_tpl__header( $found_main_results_number ) {

	if ( ! empty( $found_main_results_number ) ) {
		// Found
		$text_found = get_bk_option( 'booking_search_from__search_header' );
		if ( empty( $text_found ) ) {
			$text_found = __( 'Search results', 'booking' );
		}

	} else {
		// Nothing
		$text_found = get_bk_option( 'booking_search_from__search_nothing_found' );
		if ( empty( $text_found ) ) {
			$text_found = __( 'Nothing Found', 'booking' );
		}
	}

	// Lang
	$text_found = wpbc_lang( $text_found );

	// Found Number
	$text_found = str_replace( array( '[result_count]', '[searchresults]', '{searchresults}' ), $found_main_results_number, $text_found );

	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<h2 class="wpbc_search_avy_header">' . $text_found . '</h2>';
}


function wpbc_search_avy__advanced_search_results_tpl__header( $found_advanced_results_number ) {

	if ( ! empty( $found_advanced_results_number ) ) {
		// Found
		$text_found = get_bk_option( 'booking_search_from__search_header_advanced' );
		if ( empty( $text_found ) ) {
			$text_found = __( 'Advanced', 'booking' ) . ' ' . strtolower( __( 'Search results', 'booking' ) );
		}

	} else {
		// Nothing
		$text_found = '';
	}

	// Lang
	$text_found = wpbc_lang( $text_found );

	// Found Number
	$text_found = str_replace( array( '[result_count]', '[searchresults]', '{searchresults}' ), $found_advanced_results_number, $text_found );

	if ( ! empty( $text_found ) ) {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo '<h2 class="wpbc_search_avy_header wpbc_search_avy_header_advanced">' . $text_found . '</h2>';
	}
}


/**
 * Show One Search Results Row
 *
 * @param $params  [
 *                    'resource_obj'  => object      stdClass Object(
 *                                                                [booking_type_id]  => 230
 *                                                                [title]            => Penthouse
 *                                                                [users]            => 1
 *                                                                [import]           =>
 *                                                                [export]           =>
 *                                                                [cost]             => 100                             <- std. resource cost
 *                                                                [default_form]     => standard
 *                                                                [prioritet]        => 0
 *                                                                [parent]           => 0
 *                                                                [visitors]         => 1
 *                                                                [sort_key]         => 2
 *                                                                [capacity]         => 5                               <- Total capacity
 *                                                                [max_availability] => 3                               <- Number of available child booking resources.
 *                                                                [booking_cost]     => 130.00
 *                                                                [booking_cost_arr] => [
 *                                                                                        [additional_description] =>
 *                                                                                        [payment_cost] => 0.00
 *                                                                                        [payment_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
 *                                                                                        [total_cost] => 130.00
 *                                                                                        [cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>130.00</span>
 *                                                                                        [total_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>130.00</span>
 *                                                                                        [deposit_cost] => 130.00
 *                                                                                        [deposit_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>130.00</span>
 *                                                                                        [deposit_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>130.00</span>
 *                                                                                        [balance_cost] => 0.00
 *                                                                                        [balance_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
 *                                                                                        [balance_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
 *                                                                                        [original_cost] => 130.00
 *                                                                                        [original_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>130.00</span>
 *                                                                                        [additional_cost] => 0.00
 *                                                                                        [additional_cost_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
 *                                                                                        [coupon_discount] => 0.00
 *                                                                                        [coupon_discount_hint] => <span class="wpbc-cost-amount"><span class="wpbc-currency-symbol">CURRENCY_SYMBOL</span>0.00</span>
 *                                                                                    ]
 *                                                                [search_options] => [
 *                                                                                        [is_searchable] => On
 *                                                                                        [url] => http://beta/penthouse/#bklnk230
 *                                                                                        [title] => Penthouse
 *                                                                                        [description] => Experience luxury living with breathtaking views from our exclusive penthouse suite. Our luxurious Penthouse offers unparalleled sophistication and comfort in the heart of the city. With expansive floor-to-ceiling windows providing panoramic views, this exclusive retreat features lavish amenities, including a private terrace, deluxe furnishings, and personalized concierge service you will  have an unforgettable stay.
 *                                                                                        [picture] => http://beta/wp-content/uploads/2024/04/7c174df0-8997-40aa-bf49-0044b4168952.jpg
 *                                                                                        [options] => pets_friendly^=^yes~max_capacity^&lt;=^7~location^=^Singapur
 *                                                                                        [category] => []
 *                                                                                        [tags] => []
 *                                                                                        [options_arr] =>[
 *                                                                                                            [pets_friendly] => [
 *                                                                                                                                    [0] => [
 *                                                                                                                                            [0] => =
 *                                                                                                                                            [1] => yes
 *                                                                                                                                        ]
 *                                                                                                                                ]
 *                                                                                                            [max_capacity] => [
 *                                                                                                                                    [0] => [
 *                                                                                                                                            [0] => &lt;=
 *                                                                                                                                            [1] => 7
 *                                                                                                                                        ]
 *                                                                                                                                ]
 *                                                                                                            [location]      => [
 *                                                                                                                                    [0] => [
 *                                                                                                                                            [0] => =
 *                                                                                                                                            [1] => Singapur
 *                                                                                                                                        ]
 *                                                                                                                                ]
 *                                                                                                        ]
 *                                                                                ]
 *                                                        )
 *                   'check_in_out_arr'  	 =>  [    [0] => 2024-05-14, [1] => 2024-05-15   ]
 *                   'template'          	 =>  "<div class=\"wpdevelop search_results_container\"> ..."
 *	                 'auto_fill_form_fields' => 'selectbox-one^visitors[resource_id]^1~selectbox-one^max_capacity[resource_id]^1'
 *                 	 'search_time_arr' 		 => [ 0 , 86400 ]
 *               ]
 * @return void
 */
function wpbc_search_avy__search_results_tpl__item_row( $params ) {

	$defaults = array(
						'resource_obj'          => '',
						'check_in_out_arr'      => array(),
						'template'              => '',
						'auto_fill_form_fields' => '',
						'search_time_arr' 		=> array( 0, 24 * 60 * 60 )
				);
	$params   = wp_parse_args( $params, $defaults );

	$resource_details_obj = $params['resource_obj'];
	$check_in_out_arr     = $params['check_in_out_arr'];
	$replaced_content     = $params['template'];

	/**
	 * Template shortcodes:
	 *
	 *							[booking_resource_title] 	- resource title,
	 *							[num_available_resources] 	- availability of booking resource,
	 *							[standard_cost] 			- cost of booking the resource,
	 *							[booking_featured_image] 	- featured image, taken from the featured image associated with the post,
	 *							[booking_info] 				- booking info, taken from the excerpt associated with the post,
	 *							[cost_hint] 				- Full cost of the booking.
	 *							[original_cost_hint] 		- Cost of the booking for the selected dates only.
	 *							[additional_cost_hint] 		- Additional cost, which depends on the fields selection in the form.
	 *							[deposit_hint] 				- The deposit cost of the booking.
	 *							[balance_hint] 				- Balance cost of the booking - difference between deposit and full cost.
	 *							[search_check_in] 			- check-in date,
	 *							[search_check_out] 			- check-out date,
	 *							[booking_resource_id] 		- ID of booking resource,
	 *					[booking_resource_post_id] 	- ID of page with booking form,
	 *					[link_to_booking_resource "Book"] - link to the page with booking form,
	 *					[book_now_link] 			(URL) - link to the page with booking form,
	 *
	 *			Object:
	 *                  [booking_type_id]  => 230
	 *                  [title]            => Penthouse
	 *                  [users]            => 1
	 *                  [import]           =>
	 *                  [export]           =>
	 *                  [cost]             => 100                             <- std. resource cost
	 *                  [default_form]     => standard
	 *                  [prioritet]        => 0
	 *                  [parent]           => 0
	 *                  [visitors]         => 1
	 *                  [sort_key]         => 2
	 *                  [capacity]         => 5                               <- Total capacity
	 *                  [max_availability] => 3                               <- Number of available child booking resources.
	 *                  [booking_cost]     => 130.00
	 *                  [booking_cost_arr] => [  .... ]
	 *                  [search_options]   => [
	 *                                          [is_searchable] => On
	 *                                          [url] 	=> http://beta/penthouse/#bklnk230
	 *                                          [title] 	=> Penthouse
	 *                                          [description] => Experience luxury living with breathtaking views from our exclusive penthouse suite. Our luxurious Penthouse offers unparalleled sophistication and comfort in the heart of the city. With expansive floor-to-ceiling windows providing panoramic views, this exclusive retreat features lavish amenities, including a private terrace, deluxe furnishings, and personalized concierge service you will  have an unforgettable stay.
	 *                                          [picture]  => http://beta/wp-content/uploads/2024/04/7c174df0-8997-40aa-bf49-0044b4168952.jpg
	 *                                          [options]  => pets_friendly^=^yes~max_capacity^&lt;=^7~location^=^Singapur
	 *                                          [category] => []
	 *                                          [tags] 	 => []
	 *                                          [options_arr] =>[
	 *                                                              [pets_friendly] => [  [ '=', 'yes' ]  ]
	 *                                                              [max_capacity]  => [  [ '&lt;=', '7' ]  ]
	 *                                                              [location]      => [  [ '=', 'Singapur' ]  ]
	 *                                                          ]
	 *                                  	    ]
	 */

	/**
	 * New Shortcodes:
	 * 									[search_result_title]
	 * 									[search_result_info]
	 * 									[search_result_image]
	 * 									[search_result_image_url]
	 * 									[search_result_url]
	 * 									[search_result_button "Book Now"]
	 *
	 *  New:							[resource_title], [resource_id], [resource_capacity], [available_count], [resource_cost]
	 * 									[search_time]
	 *  			Existing:    										[search_check_in] [search_check_out],
	 * New:								[search_check_out_plus1day]
	 *  			Existing:    										[booking_resource_post_id]
	 * 																	[cost_hint], [original_cost_hint], [additional_cost_hint], [deposit_hint], [balance_hint]
	 */
	/**
	 * Deprecated:						[booking_resource_title], [booking_resource_id],  [booking_info], [booking_featured_image], [num_available_resources], [check_out_plus1day_hint], [standard_cost], [book_now_link], [link_to_booking_resource]
	 * Removed: 						[max_visitors]
	 */

	// -----------------------------------------------------------------------------------------------------------------
	// Standard 	Search Results 		Shortcodes
	// -----------------------------------------------------------------------------------------------------------------
	$replaced_content = str_replace( 		'[search_result_title]', '<div class="wpbc_search_result__search_result_title booking_search_result_title">'
															  							. wpbc_lang( $resource_details_obj->search_options['title'] ) . '</div>', $replaced_content );
	$replaced_content = str_replace( array( '[search_result_info]', '[booking_info]' ),	  wpbc_lang( $resource_details_obj->search_options['description'] ), 		$replaced_content );
	// -----------------------------------------------------------------------------------------------------------------
	$replaced_content = str_replace( array( '[resource_title]', '[booking_resource_title]' ), '<div class="wpbc_search_result__resource_title booking_search_result_title">'
																							  	. wpbc_lang( $resource_details_obj->title ) . '</div>', $replaced_content );
	$replaced_content = str_replace( array( '[resource_id]', 	'[booking_resource_id]' ), 					 $resource_details_obj->booking_type_id, $replaced_content );

	// -----------------------------------------------------------------------------------------------------------------
	// Fav Img.
	// -----------------------------------------------------------------------------------------------------------------
	$featured_image_url = esc_url( wpbc_lang( $resource_details_obj->search_options['picture'] ) );
	$replaced_content   = str_replace( '[search_result_image_url]', $featured_image_url, $replaced_content );
	// phpcs:ignore PluginCheck.CodeAnalysis.ImageFunctions.NonEnqueuedImage
	$featured_image = ( empty( $featured_image_url ) ) ? '' : '<img class="booking_featured_image" src="' . $featured_image_url . '" />';
	$replaced_content = str_replace( array( '[search_result_image]', '[booking_featured_image]' ), $featured_image, $replaced_content );

	// -----------------------------------------------------------------------------------------------------------------
	// Availability | Capacity
	// -----------------------------------------------------------------------------------------------------------------
	$replaced_content = str_replace( array( '[available_count]', '[num_available_resources]' ), '<span class="wpbc_search_result__available_count">'   . $resource_details_obj->max_availability . '</span>', $replaced_content );
	$replaced_content = str_replace( 		'[resource_capacity]', 								'<span class="wpbc_search_result__resource_capacity">' . $resource_details_obj->capacity 		 . '</span>', $replaced_content );

	// -----------------------------------------------------------------------------------------------------------------
	// Search Time 	-	10:00 AM - 02:00 PM
	// -----------------------------------------------------------------------------------------------------------------
	$timeslots_maybe_in_am_pm = wpbc_transform_timerange__seconds_arr__in__formated_hours( $params['search_time_arr'] );
	$replaced_content         = str_replace( '[search_time]', $timeslots_maybe_in_am_pm, $replaced_content );

	$time_check_in                = $params['search_time_arr'][0];
	$time_check_in_maybe_in_am_pm = wpbc_transform__seconds__in__formated_hours( $time_check_in );
	$replaced_content = str_replace( '[search_time_check_in]', $time_check_in_maybe_in_am_pm, $replaced_content );

	$time_check_out                = $params['search_time_arr'][1];
	$time_check_out_maybe_in_am_pm = wpbc_transform__seconds__in__formated_hours( $time_check_out );
	$replaced_content = str_replace( '[search_time_check_out]', $time_check_out_maybe_in_am_pm, $replaced_content );


	// -----------------------------------------------------------------------------------------------------------------
	// Dates
	// -----------------------------------------------------------------------------------------------------------------
	$s_check_in  = '';
	$s_check_out = '';
	if ( ! empty( $check_in_out_arr ) ) {
		$s_check_in  = $check_in_out_arr[0];
		$s_check_out = $check_in_out_arr[ ( count( $check_in_out_arr ) - 1 ) ];
		if ( ( '1980-01-01' == $s_check_in ) || ( '2100-01-01' == $s_check_in ) ) {
			$replaced_content = str_replace( '[search_check_in]', '...', $replaced_content );
		};
		if ( ( '1980-01-01' == $s_check_out ) || ( '2100-01-01' == $s_check_out ) ) {
			$replaced_content = str_replace( array( '[search_check_out]', '[check_out_plus1day_hint]' ), '...', $replaced_content );
		}
		$replaced_content = str_replace( 		'[search_check_in]',  date_i18n( get_bk_option( 'booking_date_format' ), mysql2date( 'U', $s_check_in ) ), $replaced_content );
		$replaced_content = str_replace( 		'[search_check_out]', date_i18n( get_bk_option( 'booking_date_format' ), mysql2date( 'U', $s_check_out ) ), $replaced_content );
		$replaced_content = str_replace( array( '[search_check_out_plus1day]', '[check_out_plus1day_hint]'), wpbc_get_dates_comma_string_localized( gmdate( 'Y-m-d H:i:s', strtotime( '+1 day', strtotime( $s_check_out ) ) ) ), $replaced_content );

		// FixIn: 10.14.13.1.
		if ( ( ! empty( $s_check_in ) ) && ( ! empty( $s_check_out ) ) ) {
			$dates_only_sql_arr = wpbc_get_dates_array_from_start_end_days( $s_check_in, $s_check_out );
			$replaced_content   = str_replace( '[search_days_number]', count( $dates_only_sql_arr ), $replaced_content );
			$replaced_content   = str_replace( '[search_nights_number]', ( 1 === count( $dates_only_sql_arr ) ) ? 1 : ( count( $dates_only_sql_arr ) - 1 ), $replaced_content );
		}
	}


	// -----------------------------------------------------------------------------------------------------------------
	// Costs
	// -----------------------------------------------------------------------------------------------------------------
	$replaced_content = str_replace( array(   '[resource_cost]', '[standard_cost]' ),
												'<span class="booking_search_result_cost">' .
													wpbc_get_cost_with_currency_for_user( $resource_details_obj->cost, $resource_details_obj->booking_type_id ) .
	  							 				'</span>', $replaced_content );
	$replaced_content = str_replace( '[cost_hint]' , '<span class="booking_search_result_cost_hint">' .
									  					wpbc_get_cost_with_currency_for_user( $resource_details_obj->booking_cost, $resource_details_obj->booking_type_id ) .
									  				 '</span>' , $replaced_content );
	$replaced_content = str_replace( '[original_cost_hint]' , '<span class="booking_search_result_original_cost_hint">' .
									  					wpbc_get_cost_with_currency_for_user( $resource_details_obj->booking_cost_arr['original_cost'], $resource_details_obj->booking_type_id ) .
									  				 '</span>' , $replaced_content );
	$replaced_content = str_replace( '[additional_cost_hint]' , '<span class="booking_search_result_additional_cost_hint">' .
									  					wpbc_get_cost_with_currency_for_user( $resource_details_obj->booking_cost_arr['additional_cost'], $resource_details_obj->booking_type_id ) .
									  				 '</span>' , $replaced_content );
	$replaced_content = str_replace( '[deposit_hint]' , '<span class="booking_search_result_deposit_hint">' .
									  					wpbc_get_cost_with_currency_for_user( $resource_details_obj->booking_cost_arr['deposit_cost'], $resource_details_obj->booking_type_id ) .
									  				 '</span>' , $replaced_content );
	$replaced_content = str_replace( '[balance_hint]' , '<span class="booking_search_result_balance_hint">' .
									  					wpbc_get_cost_with_currency_for_user( $resource_details_obj->booking_cost_arr['balance_cost'], $resource_details_obj->booking_type_id ) .
									  				 '</span>' , $replaced_content );

	// -----------------------------------------------------------------------------------------------------------------
	// Links
	// -----------------------------------------------------------------------------------------------------------------
	$book_url = wpbc_lang( $resource_details_obj->search_options['url'] );
	if ( ! empty( $book_url ) ) {

		// Post ID -----------------------------------------------------------------------------------------------------
		$post_id = url_to_postid( $book_url );					// $post_obj = get_page_by_path( $book_url );
		if ( $post_id ) {
			$replaced_content = str_replace( '[booking_resource_post_id]', $post_id, $replaced_content );
		}

		// Define params for Auto-Selection:  dates,  fields,  etc...
		$full_link  = explode( '#', $book_url );
		$full_link[0] .= ( strpos( $full_link[0], '?' ) === false ) ? '?' : '&';

		$wpbc_auto_fill_value = str_replace( '[resource_id]', $resource_details_obj->booking_type_id, $params['auto_fill_form_fields'] );
		// Some systems do not like symbol '~' in URL, so  we need to replace to  some other symbols
		$wpbc_auto_fill_value = str_replace( '~', '_^_', $wpbc_auto_fill_value );
		$wpbc_auto_fill_value = ( '' === $wpbc_auto_fill_value ) ? '0' : $wpbc_auto_fill_value;        					// FixIn: 10.4.0.3.

		$full_link[0] .= http_build_query( array(
							'wpbc_auto_fill'          => $wpbc_auto_fill_value,
							'wpbc_select_check_in'    => $s_check_in,
							'wpbc_select_check_out'   => $s_check_out,
							'wpbc_select_calendar_id' => $resource_details_obj->booking_type_id
						) );
		$full_link  = implode( '#', $full_link );

		$replaced_content = str_replace( array( '[search_result_url]', '[book_now_link]' ), $full_link, $replaced_content );

		// -------------------------------------------------------------------------------------------------------------
		// 'Book Now' buttons:  [search_result_button "Book Now"]		   or Legacy:  [link_to_booking_resource "Book"]
		foreach ( array( 'search_result_button', 'link_to_booking_resource' ) as $book_now_btn_shortcode ) {

			$found_shortcode_arr = wpbc_shortcode_with_options__find( $replaced_content, $book_now_btn_shortcode );

			if ( ! empty( $found_shortcode_arr ) ) {

				$button_title = ( ! empty( $found_shortcode_arr[$book_now_btn_shortcode]['options'] ) )
									? $found_shortcode_arr[$book_now_btn_shortcode]['options'][0]						// Found options - title for 'Book Now'  button
									: __( 'Book now', 'booking' );														// No Options - no title for book  now button

				$replaced_content = str_replace( $found_shortcode_arr[ $book_now_btn_shortcode ]['replace'], '<a href="' . esc_url( $full_link ) . '"  class="wpbc_button_light" >'
																											 	. $button_title
																											 . '</a>', $replaced_content );
			}
		}
	}


	// -----------------------------------------------------------------------------------------------------------------
	// Search Option Filters  - tags
	// -----------------------------------------------------------------------------------------------------------------
	foreach ( $resource_details_obj->search_options['options_arr'] as $option_name => $option_value_arr ) {
		$op_replace_value = array();
		foreach ( $option_value_arr as $option_value_pair ) {
			list( $op_operation, $op_value ) = $option_value_pair;

			$op_operation = html_entity_decode($op_operation);

			switch ( $op_operation ) {
				case '=':
					$op_replace_value[] = $op_value;
					break;
				case '>':
					$op_replace_value[] = '> ' . $op_value;
					break;
				case '>=':
					$op_replace_value[] = '>= ' . $op_value;
					break;
				case '<':
					$op_replace_value[] = '< ' . $op_value;
					break;
				case '<=':
					$op_replace_value[] = '<= ' . $op_value;
					break;
				case 'contain':
					$op_replace_value[] = '[... ' . $op_value . ' ...]';
					break;
				default:
			}
		}

		$op_replace_value = implode( ', ', $op_replace_value );

		$replaced_content = str_replace( '[' . $option_name . ']', $op_replace_value, $replaced_content );
	}
	// -----------------------------------------------------------------------------------------------------------------


	// -----------------------------------------------------------------------------------------------------------------
	// Replace ALL unknown shortcodes to ''
	// -----------------------------------------------------------------------------------------------------------------
	$replaced_content = preg_replace( '/[\s]{0,}[\[\{]{1}[^\]]{0,}[\]\}]{1}[\s]{0,}/', '', $replaced_content );

	//	$replace_unknown_shortcodes = '';
	//	$replaced_content = wpbc_replace_booking_shortcodes( $replaced_content, array(), $replace_unknown_shortcodes );

	$replaced_content = apply_filters( 'wpbc_search_results_item', $replaced_content );

	?><div class="booking_search_result_item wpbc_container"><?php
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $replaced_content;
	?></div><?php
}
