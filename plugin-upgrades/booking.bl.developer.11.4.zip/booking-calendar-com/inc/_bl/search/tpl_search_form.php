<?php
/**
 * @version     1.0
 * @package     New Search Form
 * @category    Search Availability
 * @author      wpdevelop
 *
 * @web-site    https://wpbookingcalendar.com/
 * @email       info@wpbookingcalendar.com
 * @modified    2024-05-03
 *
 * This is COMMERCIAL SCRIPT
 * We are not guarantee correct work and support of Booking Calendar, if some file(s) was modified by someone else then wpdevelop.
 */

if ( ! defined( 'ABSPATH' ) ) exit;                                             // Exit if accessed directly

// KEY: 'wpbc_search_avy'                                                       // FixIn: 10.0.0.37.

/**
 * JavaScript File(s) Load
 *
 * @param $where_to_load
 *
 * @return void
 */
function wpbc_search_avy_js_load_files( $where_to_load ) {

	if  ( in_array( $where_to_load, array( /*'admin',*/ 'both', 'client' ) ) ) {
		$is_in_footer = true;
		wp_enqueue_script( 'wpbc_search_avy_form', WPBC_PRO_PLUGIN_URL . '/inc/_bl/search/_out/search_avy_form.js' , array( 'wpbc-datepick' ), WPBC_PRO_VERSION_NUM , $is_in_footer );
	}
}
add_action( 'wpbc_enqueue_js_files',  'wpbc_search_avy_js_load_files', 50 );

/**
 * CSS File(s) Load
 *
 * @param $where_to_load
 *
 * @return void
 */
function wpbc_search_avy_enqueue_css_files( $where_to_load ) {

	if ( in_array( $where_to_load, array( /*'admin',*/ 'both', 'client' ) ) ) {
		wp_enqueue_style( 'wpbc_search_avy_form_css', WPBC_PRO_PLUGIN_URL . '/inc/_bl/search/_out/search_avy_form.css' , array(), WPBC_PRO_VERSION_NUM );
	}
}
add_action( 'wpbc_enqueue_css_files', 'wpbc_search_avy_enqueue_css_files', 50 );


// ---------------------------------------------------------------------------------------------------------------------
// Search Form
// ---------------------------------------------------------------------------------------------------------------------

/**
 * Display Search Form
 *
 * @param $search_form
 * @param $shortcode_attr
 *
 * @return string
 */
function wpbc_search_avy__show_search_form( $shortcode_attr ) {

	// -----------------------------------------------------------------------------------------------------------------
	// Define  JavaScript  variables,  that  is required for Search  Form,  before echo  of search  form.
	$search_css_js = wpbc_search_avy__set_js_params__before_show();

	// -----------------------------------------------------------------------------------------------------------------
	// Parameters from Shortcode
	if ( ! empty( $shortcode_attr['searchresults'] ) ) {
		$searchresults = $shortcode_attr['searchresults'];
		$searchresults = wpbc_lang( $searchresults );
	} else {
		$searchresults = false;
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Search form
	$booking_search_form_show = get_bk_option( 'booking_search_form_show' );
	$booking_search_form_show = wpbc_lang( $booking_search_form_show );

	// Replace "Simple HTML" shortcodes
	$booking_search_form_show = wpbc_bf__replace_custom_html_shortcodes( $booking_search_form_show );

	$my_random_id = 'search_form_id_'. time() * wp_rand(0,1000);
	$booking_form_theme = get_bk_option( 'booking_form_theme' );
	$booking_form_is_using_bs_css = get_bk_option( 'booking_form_is_using_bs_css' );
	$booking_search_form_show = '<div id="' . $my_random_id . '"   class="wpbc_container wpbc_form wpbc_container_search wpbc_container_search_form '
																		. ( ( wpbc_is_this_demo() == 'On' ) ? 'wpbc_demo_site ' : '' )
	                            										. esc_attr( $booking_form_theme ) . ' '
	                            										. ( ( $booking_form_is_using_bs_css == 'On' ) ? 'wpdevelop ' : '' )
	                            . '" >'
	                            		. $booking_search_form_show
	                            . '</div>';

	/*
		[search_check_in] - check-in date,
		[search_check_out] - check-out date,
		[search_quantity] - default selection number of items, Example: [search_quantity "1" "2" "3" "4" "5" "6" "7" "8" "9" "10"] - custom number of items selections"
		[search_extend "3"] - +/- 2 days,
		[search_button "Search"] - search button,
	 */

	// -----------------------------------------------------------------------------------------------------------------
	// Replace Shortcodes
	// -----------------------------------------------------------------------------------------------------------------
	// Check In | Out																									//FixIn: 9.4.4.8 		//FixIn: 8.2.1.4		// FixIn: 8.6.1.21.
	$booking_search_form_show = str_replace( 	'[search_check_in]',
												'<input type="text" value="" size="10" inputmode="none" '
													.' name="search_field__display_check_in" '
													.'   id="search_field__display_check_in" '
													.' placeholder="' . esc_attr( date_i18n( wpbc_get_php_dateformat_from_datepick_dateformat( get_bk_option( 'booking_search_form_dates_format' ) ) ) ) . '"'
												.' />',
												$booking_search_form_show );
	$booking_search_form_show = str_replace( 	'[search_check_out]',
												'<input type="text" value="" size="10" inputmode="none" '
													.' name="search_field__display_check_out" '
													.'   id="search_field__display_check_out" '
													.' placeholder="' . esc_attr( date_i18n( wpbc_get_php_dateformat_from_datepick_dateformat(  get_bk_option( 'booking_search_form_dates_format' ) ) , strtotime( '+1 day' ) ) ) . '"'
												.' />',
												$booking_search_form_show );
	// Users
	$booking_search_form_show .= ( ! empty( $shortcode_attr['users'] ) )
								? '<input type="hidden"  name="search_field__users_id" id="search_field__users_id" value="' . esc_attr( $shortcode_attr['users'] ) . '" />'
								: '';

	if (1){
		// -----------------------------------------------------------------------------------------------------------------
		// Deprecated: Category | Tags - Legacy
		// -----------------------------------------------------------------------------------------------------------------
		$booking_search_form_show = str_replace( 	'[search_category]',
													/* translators: 1: ... */
													sprintf( __( 'The %1$s shortcode is outdated and no longer supported. Find more details on %2$sthis page%3$s.', 'booking' ),
															'<strong>[search_category]</strong>', '<a href="https://wpbookingcalendar.com/faq/search-availability-setup"> ', '</a>' ),
													$booking_search_form_show );
		$booking_search_form_show = str_replace( 	'[search_tag]',
													/* translators: 1: ... */
													sprintf( __( 'The %1$s shortcode is outdated and no longer supported. Find more details on %2$sthis page%3$s.', 'booking' ),
															'<strong>[search_tag]</strong>', '<a href="https://wpbookingcalendar.com/faq/search-availability-setup"> ', '</a>' ),
													$booking_search_form_show );
				//	$booking_search_form_show = str_replace( 	'[search_category]',
				//												'<input type="text" size="10" value="" name="category" id="booking_search_category" >',
				//												$booking_search_form_show );
				//	$booking_search_form_show = str_replace( 	'[search_tag]',
				//												'<input type="text" size="10" value="" name="tag" id="booking_search_tag" >',
				//												$booking_search_form_show );
		// -----------------------------------------------------------------------------------------------------------------
		//Deprecated shortcodes:
		// -----------------------------------------------------------------------------------------------------------------
		// Icons	in	 check in / out																						// FixIn: 9.1.3.1.
		$booking_search_form_show = str_replace( '[search_check_in_icon]',
												 '<a href="javascript:void(0)"  class="wpbc_icn_check_in wpbc_icn_check_in_out "></a>',
												 $booking_search_form_show );
		$booking_search_form_show = str_replace( '[search_check_out_icon]',
												 '<a href="javascript:void(0)"  class="wpbc_icn_check_out wpbc_icn_check_in_out "></a>',
												 $booking_search_form_show );
	}

	// -----------------------------------------------------------------------------------------------------------------
	// Search QUANTITY shortcodes		|		Search TIME shortcode			[search_time 'Full Day@@' "10 AM - 2PM@@10:00 - 14:00" '3 PM - 4PM@@15:00 - 16:00']
	// -----------------------------------------------------------------------------------------------------------------
	$search_quantity = array(
							  	'search_quantity' => 'search_quantity',						// [search_quantity "One@@1" '2 Rooms@@2' "3"]
							  	'search_how_many' => 'search_quantity',
							  	'search_visitors' => 'search_quantity', 					// Legacy,  previously  here was 'visitors' name for select	box

								'search_time' => 'search_time'								// [search_time 'Full Day@@' "10 AM - 2PM@@10:00 - 14:00" '3 PM - 4PM@@15:00 - 16:00']
							);
	foreach ( $search_quantity as $search_shortcode => $html_field_name ) {

		$found_shortcode = wpbc_shortcode_with_options__find( $booking_search_form_show, $search_shortcode );

		if ( ! empty( $found_shortcode[ $search_shortcode ] ) ) {

			$replace = $found_shortcode[ $search_shortcode ]['replace'];

			$options_arr = ( ! empty( $found_shortcode[ $search_shortcode ]['options'] ) ) ? $found_shortcode[ $search_shortcode ]['options'] :  range( 1, 6 );

			$code_to_insert = "<select  name='{$html_field_name}' class='wpbc_search_avy_field__{$search_shortcode}'>";

			foreach ( $options_arr as $option ) {

				list( $option_title, $option_value ) = wpbc_shortcode_option__get_tile_value( $option );				// '10 AM - 2PM@@10:00 - 14:00'   ->   [ '10 AM - 2PM', '10:00 - 14:00' ]
				$code_to_insert .= "<option value='{$option_value}'>{$option_title}</option>";
			}
			$code_to_insert .= "</select>";
			$booking_search_form_show = str_replace( $replace, $code_to_insert, $booking_search_form_show );
		}
	}


	// -----------------------------------------------------------------------------------------------------------------
	// 'Search Filter Options'
	// -----------------------------------------------------------------------------------------------------------------
//TODO: 2024-05-24 14:28   ->  Parse  'Search Filter Options'  here
	// SELECT
	$found_shortcodes_arr = wpbc_shortcode_with_name_and_options__find( $booking_search_form_show, 'select|selectbox' );
	/**
	 * 				[
	 *                    [search_time] =>  [
	 *                                        [replace]  => [selectbox search_time 'Any@@' "10 AM - 2PM@@10:00 - 14:00" '3 PM - 4PM@@15:00 - 16:00']
	 *                                        [type]     => selectbox
	 *                                        [name]     => search_time
	 *                                        [options]  => [
	 *                                                        [0] => Any@@
	 *                                                        [1] => 10 AM - 2PM@@10:00 - 14:00
	 *                                                        [2] => 3 PM - 4PM@@15:00 - 16:00
	 *                                                      ]
	 *                                      ],
	 *                    [othersearch_time] => [
	 *                                            [replace] => [selectbox othersearch_time]
	 *                                            [type]    => select
	 *                                            [name]    => othersearch_time
	 *                                            [options] => []
	 *                                        ]
	 *                    [location] => [
	 *                                    [replace] => [selectbox location "Any@@" "Spain Country@@Spain" "France" "Singapur" "Tirana"]
	 *                                    [type]    => select
	 *                                    [name]    => location
	 *                                    [options] => [
	 *                                                    [0] => Any@@
	 *                                                    [1] => Spain Country@@Spain
	 *                                                    [2] => France
	 *                                                    [3] => Singapur
	 *                                                    [4] => Tirana
	 *                                                ]
	 *                                ]
	 *                ]
	 */
	foreach ( $found_shortcodes_arr as $search_shortcode => $found_shortcode_params_arr ) {
		if ( ! empty( $found_shortcode_params_arr ) ) {

			$replace = $found_shortcode_params_arr['replace'];
			$shortcode_type = $found_shortcode_params_arr['type'];
			$shortcode_name = $found_shortcode_params_arr['name'];

			$options_arr = ( ! empty( $found_shortcode_params_arr['options'] ) ) ? $found_shortcode_params_arr['options'] :  array();

			$code_to_insert = "<select  name='{$shortcode_name}' class='wpbc_search_avy_field__{$shortcode_name}'>";

			foreach ( $options_arr as $option ) {

				list( $option_title, $option_value ) = wpbc_shortcode_option__get_tile_value( $option );				// '10 AM - 2PM@@10:00 - 14:00'   ->   [ '10 AM - 2PM', '10:00 - 14:00' ]
				$code_to_insert .= "<option value='{$option_value}'>{$option_title}</option>";
			}
			$code_to_insert .= "</select>";
			$booking_search_form_show = str_replace( $replace, $code_to_insert, $booking_search_form_show );
		}
	}


	// -----------------------------------------------------------------------------------------------------------------
	// [search_extend]																								// FixIn: 6.0.1.1.
	// -----------------------------------------------------------------------------------------------------------------
	$search_shortcode_arr = array( 'additional_search', 'search_extend' );
	foreach ( $search_shortcode_arr as $search_shortcode ) {

		$found_or_error   = preg_match_all( '/\[' . $search_shortcode . '[^\]]*\]/', $booking_search_form_show, $found_matches );

		if ( count( $found_matches ) > 0 ) {
			foreach ( $found_matches[0] as $key => $found_shortcode ) {

				$found_shortcode_param = trim( str_replace( array( '[' . $search_shortcode, ']' ), '', $found_shortcode ) );

				$found_shortcode_param = ( empty( $found_shortcode_param ) )
											? 2
											: str_replace( array( "'", '"' ), '', $found_shortcode_param );
				$found_shortcode_param = intval( $found_shortcode_param );

				$code_to_insert = "<input type='checkbox' "
								  	." id='search_extend' "
								  	." name='search_field__extend_search_days' "
								  	." value='{$found_shortcode_param}' "
								  	. checked( isset( $_GET['search_field__extend_search_days'] ) ? $_GET['search_field__extend_search_days'] : '', $found_shortcode_param, false ) // phpcs:ignore WordPress.Security.NonceVerification.Recommended, WordPress.Security.ValidatedSanitizedInput.InputNotValidated, WordPress.Security.ValidatedSanitizedInput.MissingUnslash, WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
								  . " />";

				$booking_search_form_show = str_replace( $found_shortcode, $code_to_insert, $booking_search_form_show );
			}
		}
	}

	// -----------------------------------------------------------------------------------------------------------------
	// [search_button]																									// FixIn: 9.2.3.2.
	// -----------------------------------------------------------------------------------------------------------------
	$search_shortcode = 'search_button';
	$pattern          = '/\[' . $search_shortcode . '\s*("[^"]*")?[^\]]*\]/';

	preg_match_all( $pattern, $booking_search_form_show, $matches );

	list( $search_button_shortcde_arr, $search_button_title_arr ) = $matches;

	$search_button_shortcode = '';
	$search_button_title     = '';
	if ( count( $search_button_shortcde_arr ) > 0 ) {
		$search_button_shortcode = $search_button_shortcde_arr[0];
		$search_button_title     = empty( $search_button_title_arr[0] ) ? __( 'Search', 'booking' ) : $search_button_title_arr[0];
		$search_button_title     = trim( $search_button_title, '"' );
	}


	// -----------------------------------------------------------------------------------------------------------------
	// FORM
	// -----------------------------------------------------------------------------------------------------------------
	if ( $searchresults === false ) {		// AJAX  - Search Form  ....................................................
		// '[search_button]'
		$booking_search_form_show = str_replace( $search_button_shortcode
				, '<input type="button" '
					  . ' class="search_booking wpbc_button_light" '
					  . ' onclick="wpbc_search_form_click_ajax( this.form, \'' . wpbc_get_maybe_reloaded_booking_locale() . '\' );" '
					  . ' value="' . esc_attr( $search_button_title ) . '" />'
				, $booking_search_form_show );

		$wpbc_ajax_search_nonce = wp_nonce_field( 'BOOKING_SEARCH', "wpbc_search_nonce", true, false );
		$booking_search_form_show .= $wpbc_ajax_search_nonce;

		$search_form = '<div  id="booking_search_form" class="booking_search_form wpbc_container"> ' .
							'<form name="booking_search_form" autocomplete="off" action="" method="post">' .
		               			$booking_search_form_show .
		               			'<div style="clear:both;"></div>' .
							'</form>' .
						'</div>' .
						'<div id="booking_search_ajax"></div>' .
						'<div id="booking_search_results"></div>';														// FixIn: 8.4.7.7.

	} else { 								// Search Form  on New Page ................................................

		// '[search_button]'																							// FixIn: 8.6.1.21.
		$booking_search_form_show = str_replace( $search_button_shortcode,
				'<input type="submit" '
					. ' class="search_booking wpbc_button_light"  '
					. ' value="' . esc_attr( $search_button_title ) . '" '
					. ' onclick="javascript:return wpbc_search_form_click_new_page( this.form, \'' . wpbc_get_maybe_reloaded_booking_locale() . '\' );" />'
				, $booking_search_form_show );

		$search_form = '<div  id="booking_search_form" class="booking_search_form wpbc_container"> ' .
							'<form name="booking_search_form" autocomplete="off" action="' . $searchresults . '"  method="get">' .
		               			$booking_search_form_show .
		               			'<input type="hidden" value="" name="search_get__check_in_ymd" />'  .                             // FixIn: 9.5.3.4.
		               			'<input type="hidden" value="" name="search_get__check_out_ymd" />' .
		               			'<input type="hidden" value="" name="search_get__quantity" />' .
		               			'<input type="hidden" value="" name="search_get__time" />' .
		               			'<input type="hidden" value="" name="search_get__extend" />' .
		               			'<input type="hidden" value="" name="search_get__users_id" />' .
		               			'<input type="hidden" value="" name="search_get__custom_params" />' .
		               			'<div style="clear:both;"></div> ' .
							'</form> ' .
						'</div>';
	}
	// -----------------------------------------------------------------------------------------------------------------

	$search_form = apply_filters( 'wpbc_search_form', $search_form );                                                	// FixIn: 8.1.2.1.

	return $search_css_js . $search_form;
}


	// -----------------------------------------------------------------------------------------------------------------
	// JavaScript Variables
	// -----------------------------------------------------------------------------------------------------------------

/**
 * Define  JavaScript  variables,  that  is required for Search  Form,  before echo  of search  form.
 *
 * @return false|string
 */
function wpbc_search_avy__set_js_params__before_show() {

	ob_start();
	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo '<script type="text/javascript"> ' . wpbc_jq_ready_start();                                                    // FixIn: 10.1.3.7.

	?> _wpbc.set_other_param( 'search_avy__dates_format', '<?php echo esc_attr( get_bk_option( 'booking_search_form_dates_format' ) ); ?>' ); <?php
	?> _wpbc.set_other_param( 'search_avy__auto_open_checkout', '<?php echo esc_attr( get_bk_option( 'booking_search_from_auto_open_checkout_cal' ) ); ?>' ); <?php

	?> _wpbc.set_other_param( 'search_avy__warning__dates_required_enabled', '<?php echo esc_attr( get_bk_option( 'booking_search_form__dates_required_enabled' ) ); ?>' ); <?php
	?> _wpbc.set_other_param( 'search_avy__warning__dates_required_warning', '<?php echo esc_js( wpbc_lang( get_bk_option( 'booking_search_form__dates_required_warning' ) ) ); ?>' ); <?php

	?> wpbc_init_datepick__search_check_in(); <?php

	?> wpbc_init_datepick__search_check_out(); <?php

	// Auto select  some fields in Search Form ( depend on $_GET['search_get__custom_params'] )
	?> wpbc_search_avy__auto_select_fields_in_search_form__if_params_in_url(); <?php

	// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	echo wpbc_jq_ready_end() . '</script>';                                                                             // FixIn: 10.1.3.7.

	$html = ob_get_clean();

	return $html;
}
