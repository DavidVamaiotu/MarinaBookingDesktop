<?php
/**
 * Advanced Mode sidebar bootstrap.
 *
 * @package Booking Calendar
 * @subpackage Form Builder
 * @since 11.0.0
 * @file ../wp-content/plugins/booking-calendar-com/inc/_ps/page-form-builder/advanced-mode/class-wpbc-bfb-advanced-mode-sidebar.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/class-wpbc-bfb-advanced-mode-data.php';
require_once dirname( __FILE__ ) . '/class-wpbc-bfb-advanced-mode-render.php';

/**
 * Register Advanced Mode sidebar tools.
 */
class WPBC_BFB_Advanced_Mode_Sidebar {

	/**
	 * Singleton instance.
	 *
	 * @var WPBC_BFB_Advanced_Mode_Sidebar|null
	 */
	private static $instance = null;

	/**
	 * Get instance.
	 *
	 * @return WPBC_BFB_Advanced_Mode_Sidebar
	 */
	public static function get_instance() {

		if ( null === self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {

		$this->register_section_hooks();

		add_action( 'wpbc_bfb_advanced_mode_sidebar_tools', array( $this, 'render_all_sections_fallback' ) );
		add_action( 'wpbc_bfb_advanced_mode_sidebar_generator', array( $this, 'render_all_sections_fallback' ) );
		add_action( 'wpbc_bfb_advanced_mode_sidebar_help', array( $this, 'render_all_sections_fallback' ) );

		add_action( 'wpbc_enqueue_css_files', array( $this, 'enqueue_styles' ) );
		add_action( 'wpbc_enqueue_js_files', array( $this, 'enqueue_scripts' ) );
	}

	/**
	 * Register hooks for all top-level Advanced Mode sections.
	 *
	 * @return void
	 */
	private function register_section_hooks() {

		$section_slugs = array(
			'booking_essentials',
			'fields',
			'time_services',
			'layouts',
			'hints',
			'conditional_rules',
			'simple_html_layout',
			'tips_and_tricks',
			'other_fields',
		);

		foreach ( $section_slugs as $section_slug ) {
			add_action( 'wpbc_bfb_advanced_mode_sidebar__' . $section_slug, array( $this, 'render_section_from_current_hook' ) );
		}
	}

	/**
	 * Check whether current admin page is BFB page.
	 *
	 * @return bool
	 */
	private function is_builder_page() {

		if ( ! is_admin() ) {
			return false;
		}

		if ( ! function_exists( 'wpbc_is_builder_booking_form_page' ) ) {
			return false;
		}

		if ( ! wpbc_is_builder_booking_form_page() ) {
			return false;
		}

		return true;
	}

	/**
	 * Get assets url.
	 *
	 * @return string
	 */
	private function get_assets_url() {
		return plugin_dir_url( __FILE__ ) . '_out/';
	}

	/**
	 * Get assets path.
	 *
	 * @return string
	 */
	private function get_assets_path() {
		return plugin_dir_path( __FILE__ ) . '_out/';
	}

	/**
	 * Enqueue styles.
	 *
	 * @return void
	 */
	public function enqueue_styles() {

		if ( ! $this->is_builder_page() ) {
			return;
		}

		$assets_url  = $this->get_assets_url();
		$assets_path = $this->get_assets_path();
		$style_file  = $assets_path . 'bfb-advanced-mode-sidebar.css';

		wp_enqueue_style(
			'wpbc-bfb-advanced-mode-sidebar',
			$assets_url . 'bfb-advanced-mode-sidebar.css',
			array(),
			file_exists( $style_file ) ? filemtime( $style_file ) : '1.0.0'
		);
	}

	/**
	 * Enqueue scripts.
	 *
	 * @return void
	 */
	public function enqueue_scripts() {

		if ( ! $this->is_builder_page() ) {
			return;
		}

		$shortcode_items = apply_filters(
			'wpbc_bfb_advanced_mode_shortcode_items',
			WPBC_BFB_Advanced_Mode_Data::get_shortcode_items()
		);

		$assets_url  = $this->get_assets_url();
		$assets_path = $this->get_assets_path();
		$script_file = $assets_path . 'bfb-advanced-mode-sidebar.js';

		wp_enqueue_script(
			'wpbc-bfb-advanced-mode-sidebar',
			$assets_url . 'bfb-advanced-mode-sidebar.js',
			array( 'jquery' ),
			file_exists( $script_file ) ? filemtime( $script_file ) : '1.0.0',
			true
		);

		wp_add_inline_script(
			'wpbc-bfb-advanced-mode-sidebar',
			'window.WPBC_BFB_Advanced_Mode_Sidebar_Data = ' . wp_json_encode(
				array(
					'items' => array_values( $shortcode_items ),
					'i18n'  => array(
						'copy'             => __( 'Copy', 'booking' ),
						'copied'           => __( 'Copied', 'booking' ),
						'no_item_selected' => __( 'Select a shortcode type to generate code.', 'booking' ),
					),
				)
			),
			'before'
		);
	}

	/**
	 * Render one section based on the current action hook name.
	 *
	 * @return void
	 */
	public function render_section_from_current_hook() {

		$current_hook = current_action();
		$section_slug = str_replace( 'wpbc_bfb_advanced_mode_sidebar__', '', $current_hook );
		$tool_section = WPBC_BFB_Advanced_Mode_Data::get_tool_section( $section_slug );

		if ( empty( $tool_section ) ) {
			return;
		}

		$shortcode_items = apply_filters(
			'wpbc_bfb_advanced_mode_shortcode_items',
			WPBC_BFB_Advanced_Mode_Data::get_shortcode_items()
		);

		WPBC_BFB_Advanced_Mode_Render::render_section( $tool_section, $shortcode_items );
	}

	/**
	 * Fallback renderer for old hooks.
	 *
	 * @return void
	 */
	public function render_all_sections_fallback() {

		$tool_sections = WPBC_BFB_Advanced_Mode_Data::get_tool_sections();
		$shortcode_items = apply_filters(
			'wpbc_bfb_advanced_mode_shortcode_items',
			WPBC_BFB_Advanced_Mode_Data::get_shortcode_items()
		);

		foreach ( $tool_sections as $tool_section ) {
			echo '<div class="wpbc_bfb__am_fallback_section">';
			WPBC_BFB_Advanced_Mode_Render::render_section( $tool_section, $shortcode_items );
			echo '</div>';
		}
	}
}
