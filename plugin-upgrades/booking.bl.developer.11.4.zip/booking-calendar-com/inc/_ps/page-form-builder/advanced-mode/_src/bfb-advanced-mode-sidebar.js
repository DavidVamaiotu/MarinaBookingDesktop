(function ( $, window_obj ) {
	'use strict';

	var sidebar_data = window_obj.WPBC_BFB_Advanced_Mode_Sidebar_Data || {};
	var shortcode_items = sidebar_data.items || get_empty_array();
	var i18n = sidebar_data.i18n || {};

	function get_empty_array() {
		return [];
	}

	function get_item_by_slug( item_slug ) {
		var found_item = null;

		$.each( shortcode_items, function( index, current_item ) {
			if ( current_item.slug === item_slug ) {
				found_item = current_item;
				return false;
			}
		} );

		return found_item;
	}

	function esc_html( value ) {
		return $( '<div />' ).text( value || '' ).html();
	}

	function esc_attr_value( value ) {
		return String( value || '' ).replace( /"/g, '&quot;' );
	}

	function sanitize_token( value ) {
		return String( value || '' ).replace( /[^A-Za-z0-9_-]/g, '' );
	}

	function sanitize_number( value ) {
		return String( value || '' ).replace( /[^0-9]/g, '' );
	}

	function sanitize_text_value( value ) {
		return String( value || '' )
			.replace( /[\[\]]/g, '' )
			.replace( /"/g, '&quot;' );
	}

	function sanitize_option_value( value ) {
		return sanitize_text_value( value ).replace( /@@/g, '@' );
	}

	function sanitize_placeholder( value ) {
		value = sanitize_text_value( value );
		value = value.replace( /\s+/g, '_' );
		value = value.replace( /[^A-Za-z0-9_-]/g, '_' );
		return value;
	}

	function get_sanitized_value( control, raw_value ) {
		var sanitize_type = control.sanitize || '';

		if ( 'token' === sanitize_type ) {
			return sanitize_token( raw_value );
		}

		if ( 'placeholder' === sanitize_type ) {
			return sanitize_placeholder( raw_value );
		}

		if ( 'number' === control.type ) {
			return sanitize_number( raw_value );
		}

		if ( 'digits' === sanitize_type ) {
			return sanitize_number( raw_value );
		}

		return raw_value;
	}

	function split_non_empty_lines( value ) {
		var lines = String( value || '' ).split( /\r?\n/ );
		var clean_lines = [];

		$.each( lines, function( index, line ) {
			line = $.trim( line );

			if ( '' !== line ) {
				clean_lines.push( line );
			}
		} );

		return clean_lines;
	}

	function build_size_and_maxlength_string( values ) {
		var size = sanitize_number( values.size || '' );
		var maxlength = sanitize_number( values.maxlength || '' );

		if ( '' === size && '' === maxlength ) {
			return '';
		}

		if ( '' !== size && '' !== maxlength ) {
			return ' ' + size + '/' + maxlength;
		}

		if ( '' !== size ) {
			return ' ' + size + '/';
		}

		return ' /' + maxlength;
	}

	function build_textarea_size_string( values ) {
		var cols = sanitize_number( values.cols || '' );
		var rows = sanitize_number( values.rows || '' );

		if ( '' === cols && '' === rows ) {
			return '';
		}

		if ( '' !== cols && '' !== rows ) {
			return ' ' + cols + 'x' + rows;
		}

		if ( '' !== cols ) {
			return ' ' + cols + 'x';
		}

		return ' x' + rows;
	}

	function build_attribute_string( value, prefix ) {
		value = String( value || '' );

		if ( '' === value ) {
			return '';
		}

		return ' ' + prefix + value;
	}

	function build_quoted_string( value ) {
		value = sanitize_text_value( value );

		if ( '' === value ) {
			return '';
		}

		return ' "' + value + '"';
	}

	function build_choice_options_string( values ) {
		var option_values = split_non_empty_lines( values.options || '' );
		var option_titles = split_non_empty_lines( values.titles || '' );
		var output = '';

		$.each( option_values, function( index, option_value ) {
			var clean_value = sanitize_option_value( option_value );
			var clean_title = '';

			if ( index < option_titles.length ) {
				clean_title = sanitize_option_value( option_titles[ index ] );
			}

			if ( '' !== clean_title ) {
				output += ' "' + clean_title + '@@' + clean_value + '"';
			} else {
				output += ' "' + clean_value + '"';
			}
		} );

		return output;
	}

	function collect_values( generator_root ) {
		var values = {};

		generator_root.find( '[data-role="dynamic-control"]' ).each( function() {
			var field = $( this );
			var field_key = field.attr( 'data-key' );
			var control_type = field.attr( 'data-control-type' );

			if ( 'checkbox' === control_type ) {
				values[ field_key ] = field.is( ':checked' );
			} else {
				values[ field_key ] = field.val();
			}
		} );

		return values;
	}

	function build_simple_shortcode( item ) {
		var form_shortcode = '[' + item.tag + ']';
		var content_shortcode = '';

		if ( item.supports_content_tag ) {
			content_shortcode = '[' + item.tag + ']';
		}

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: ''
		};
	}

	function build_simple_with_default_shortcode( item, values ) {
		var default_value = build_quoted_string( values.default || '' );
		var form_shortcode = '[' + item.tag + default_value + ']';
		var content_shortcode = '[' + item.tag + ']';

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: ''
		};
	}

	function build_named_field_shortcode( item, values ) {
		var name = sanitize_token( values.name || '' );
		var required = values.required ? '*' : '';
		var form_shortcode = '';
		var content_shortcode = '';
		var default_value = build_quoted_string( values.default || '' );
		var html_id = build_attribute_string( sanitize_token( values.html_id || '' ), 'id:' );
		var css_class = build_attribute_string( sanitize_token( values.css_class || '' ), 'class:' );
		var placeholder = build_attribute_string( sanitize_placeholder( values.placeholder || '' ), 'placeholder:' );
		var size_and_maxlength = build_size_and_maxlength_string( values );

		if ( '' === name ) {
			return {
				form: '',
				content: '',
				value: ''
			};
		}

		form_shortcode = '[' + item.tag + required + ' ' + name;
		form_shortcode += size_and_maxlength;
		form_shortcode += html_id;
		form_shortcode += css_class;
		form_shortcode += placeholder;
		form_shortcode += default_value;
		form_shortcode += ']';

		content_shortcode = '[' + name + ']';

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: ''
		};
	}

	function build_textarea_shortcode( item, values ) {
		var name = sanitize_token( values.name || '' );
		var required = values.required ? '*' : '';
		var form_shortcode = '';
		var content_shortcode = '';
		var default_value = build_quoted_string( values.default || '' );
		var html_id = build_attribute_string( sanitize_token( values.html_id || '' ), 'id:' );
		var css_class = build_attribute_string( sanitize_token( values.css_class || '' ), 'class:' );
		var size_string = build_textarea_size_string( values );

		if ( '' === name ) {
			return {
				form: '',
				content: '',
				value: ''
			};
		}

		form_shortcode = '[' + item.tag + required + ' ' + name;
		form_shortcode += size_string;
		form_shortcode += html_id;
		form_shortcode += css_class;
		form_shortcode += default_value;
		form_shortcode += ']';

		content_shortcode = '[' + name + ']';

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: ''
		};
	}

	function build_select_shortcode( item, values ) {
		var name = sanitize_token( values.name || '' );
		var required = values.required ? '*' : '';
		var multiple = values.multiple ? ' multiple' : '';
		var default_value = sanitize_option_value( values.default || '' );
		var html_id = build_attribute_string( sanitize_token( values.html_id || '' ), 'id:' );
		var css_class = build_attribute_string( sanitize_token( values.css_class || '' ), 'class:' );
		var options = build_choice_options_string( values );
		var form_shortcode = '';
		var content_shortcode = '';
		var value_shortcode = '';

		if ( '' === name || '' === options ) {
			return {
				form: '',
				content: '',
				value: ''
			};
		}

		form_shortcode = '[' + item.tag + required + ' ' + name;
		form_shortcode += html_id;
		form_shortcode += css_class;

		if ( '' !== default_value ) {
			form_shortcode += ' default:' + default_value;
		}

		form_shortcode += multiple;
		form_shortcode += options;
		form_shortcode += ']';

		content_shortcode = '[' + name + ']';
		value_shortcode = '[' + name + '_val]';

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: value_shortcode
		};
	}

	function build_choice_shortcode( item, values ) {
		var name = sanitize_token( values.name || '' );
		var required = values.required ? '*' : '';
		var default_value = sanitize_option_value( values.default || '' );
		var html_id = build_attribute_string( sanitize_token( values.html_id || '' ), 'id:' );
		var css_class = build_attribute_string( sanitize_token( values.css_class || '' ), 'class:' );
		var options = build_choice_options_string( values );
		var form_shortcode = '';
		var content_shortcode = '';
		var value_shortcode = '';
		var extra_flags = '';

		if ( values.use_label_element ) {
			extra_flags += ' use_label_element';
		}
		if ( values.label_wrap ) {
			extra_flags += ' label_wrap';
		}
		if ( values.label_first ) {
			extra_flags += ' label_first';
		}
		if ( values.exclusive ) {
			extra_flags += ' exclusive';
		}

		if ( '' === name || '' === options ) {
			return {
				form: '',
				content: '',
				value: ''
			};
		}

		form_shortcode = '[' + item.tag + required + ' ' + name;
		form_shortcode += html_id;
		form_shortcode += css_class;

		if ( '' !== default_value ) {
			form_shortcode += ' default:' + default_value;
		}

		form_shortcode += extra_flags;
		form_shortcode += options;
		form_shortcode += ']';

		content_shortcode = '[' + name + ']';
		value_shortcode = '[' + name + '_val]';

		return {
			form: form_shortcode,
			content: content_shortcode,
			value: value_shortcode
		};
	}

	function build_submit_shortcode( item, values ) {
		var label = build_quoted_string( values.label || '' );
		var html_id = build_attribute_string( sanitize_token( values.html_id || '' ), 'id:' );
		var css_class = build_attribute_string( sanitize_token( values.css_class || '' ), 'class:' );
		var form_shortcode = '[' + item.tag + html_id + css_class + label + ']';

		return {
			form: form_shortcode,
			content: '',
			value: ''
		};
	}

	function build_key_value_attrs_shortcode( item, values ) {
		var form_shortcode = '[' + item.tag;

		$.each( item.controls || [], function( index, control ) {
			var attr_name = control.attr_name || '';
			var value = values[ control.key ];

			if ( '' === attr_name ) {
				return;
			}

			if ( 'checkbox' === control.type ) {
				if ( value ) {
					form_shortcode += ' ' + attr_name + '="' + esc_attr_value( control.checked_val || '1' ) + '"';
				}
				return;
			}

			value = sanitize_text_value( value || '' );

			if ( '' !== value ) {
				form_shortcode += ' ' + attr_name + '="' + esc_attr_value( value ) + '"';
			}
		} );

		form_shortcode += ']';

		return {
			form: form_shortcode,
			content: '',
			value: ''
		};
	}

	function build_outputs( item, values ) {
		if ( ! item ) {
			return {
				form: '',
				content: '',
				value: ''
			};
		}

		if ( 'simple' === item.mode ) {
			return build_simple_shortcode( item );
		}

		if ( 'simple_with_default' === item.mode ) {
			return build_simple_with_default_shortcode( item, values );
		}

		if ( 'named_field' === item.mode ) {
			return build_named_field_shortcode( item, values );
		}

		if ( 'textarea_field' === item.mode ) {
			return build_textarea_shortcode( item, values );
		}

		if ( 'select_field' === item.mode ) {
			return build_select_shortcode( item, values );
		}

		if ( 'choice_field' === item.mode ) {
			return build_choice_shortcode( item, values );
		}

		if ( 'submit_button' === item.mode ) {
			return build_submit_shortcode( item, values );
		}

		if ( 'key_value_attrs' === item.mode ) {
			return build_key_value_attrs_shortcode( item, values );
		}

		return {
			form: '',
			content: '',
			value: ''
		};
	}

	function render_notes( generator_root, item ) {
		var notes_wrap = generator_root.find( '[data-role="item-notes"]' );
		var html = '';

		if ( ! item || ! item.notes || ! item.notes.length ) {
			notes_wrap.html( '' );
			return;
		}

		html += '<ul class="wpbc_bfb__amg__notes_list">';

		$.each( item.notes, function( index, note ) {
			html += '<li>' + esc_html( note ) + '</li>';
		} );

		html += '</ul>';

		notes_wrap.html( html );
	}

	function render_controls( generator_root, item ) {
		var controls_wrap = generator_root.find( '[data-role="item-controls"]' );
		var html = '';

		if ( ! item || ! item.controls || ! item.controls.length ) {
			controls_wrap.html( '' );
			return;
		}

		$.each( item.controls, function( index, control ) {
			var default_value = ( undefined !== control.default ) ? control.default : '';
			var readonly_attr = control.readonly ? ' readonly="readonly"' : '';
			var checked_attr = ( 'checkbox' === control.type && control.default ) ? ' checked="checked"' : '';
			var control_classes = 'wpbc_bfb__amg__control';

			if (
				'textarea' === control.type ||
				'checkbox' === control.type ||
				'placeholder' === control.key ||
				'options' === control.key ||
				'titles' === control.key
			) {
				control_classes += ' is-full-row';
			}

			html += '<div class="' + control_classes + '">';

			if ( 'checkbox' === control.type ) {
				html += '<label class="wpbc_bfb__amg__check_label">';
				html += '<input type="checkbox" data-role="dynamic-control" data-key="' + esc_html( control.key ) + '" data-control-type="checkbox"' + checked_attr + ' />';
				html += '<span>' + esc_html( control.label ) + '</span>';
				html += '</label>';

				if ( control.description ) {
					html += '<div class="description">' + esc_html( control.description ) + '</div>';
				}
			} else {
				html += '<label class="wpbc_bfb__amg__label">' + esc_html( control.label ) + '</label>';

				if ( 'textarea' === control.type ) {
					html += '<textarea class="widefat" rows="4" data-role="dynamic-control" data-key="' + esc_html( control.key ) + '" data-control-type="textarea"' + readonly_attr + '>' + esc_html( default_value ) + '</textarea>';
				} else {
					html += '<input class="widefat" type="' + esc_html( control.type ) + '" value="' + esc_html( default_value ) + '" data-role="dynamic-control" data-key="' + esc_html( control.key ) + '" data-control-type="' + esc_html( control.type ) + '"' + readonly_attr + ' />';
				}

				if ( control.description ) {
					html += '<div class="description">' + esc_html( control.description ) + '</div>';
				}
			}

			html += '</div>';
		} );

		controls_wrap.html( html );
	}

	function update_outputs( generator_root ) {
		var item_slug = generator_root.find( '[data-role="item-select"]' ).val();
		var item = get_item_by_slug( item_slug );
		var values = collect_values( generator_root );
		var outputs = build_outputs( item, values );
		var form_wrap = generator_root.find( '[data-role="output-form-wrap"]' );
		var content_wrap = generator_root.find( '[data-role="output-content-wrap"]' );
		var value_wrap = generator_root.find( '[data-role="output-value-wrap"]' );

		generator_root.find( '[data-role="output-form"]' ).val( outputs.form );
		generator_root.find( '[data-role="output-content"]' ).val( outputs.content );
		generator_root.find( '[data-role="output-value"]' ).val( outputs.value );

		form_wrap.show();

		if ( item && item.supports_content_tag ) {
			content_wrap.show();
		} else {
			content_wrap.hide();
		}

		if ( item && item.supports_value_tag ) {
			value_wrap.show();
		} else {
			value_wrap.hide();
		}
	}

	function render_item( generator_root ) {
		var item_slug = generator_root.find( '[data-role="item-select"]' ).val();
		var item = get_item_by_slug( item_slug );
		var description_wrap = generator_root.find( '[data-role="item-description"]' );

		if ( ! item ) {
			description_wrap.text( i18n.no_item_selected || '' );
			generator_root.find( '[data-role="item-controls"]' ).html( '' );
			generator_root.find( '[data-role="item-notes"]' ).html( '' );
			generator_root.find( '[data-role="output-form"]' ).val( '' );
			generator_root.find( '[data-role="output-content"]' ).val( '' );
			generator_root.find( '[data-role="output-value"]' ).val( '' );
			generator_root.find( '[data-role="output-form-wrap"]' ).hide();
			generator_root.find( '[data-role="output-content-wrap"]' ).hide();
			generator_root.find( '[data-role="output-value-wrap"]' ).hide();
			return;
		}

		description_wrap.text( item.description || '' );
		generator_root.find( '[data-role="output-form-wrap"]' ).show();

		render_notes( generator_root, item );
		render_controls( generator_root, item );
		update_outputs( generator_root );
	}

	function copy_text_to_clipboard( text, fallback_field ) {
		if (
			navigator.clipboard &&
			'function' === typeof navigator.clipboard.writeText
		) {
			navigator.clipboard.writeText( text ).catch( function() {
				if ( fallback_field.length ) {
					fallback_field.trigger( 'focus' );
					fallback_field.trigger( 'select' );

					try {
						document.execCommand( 'copy' );
					} catch ( err ) {
						/* noop */
					}
				}
			} );

			return;
		}

		if ( fallback_field.length ) {
			fallback_field.trigger( 'focus' );
			fallback_field.trigger( 'select' );

			try {
				document.execCommand( 'copy' );
			} catch ( err ) {
				/* noop */
			}
		}
	}

	function copy_text_from_target( generator_root, target_name ) {
		var selector = '[data-role="output-' + target_name + '"]';
		var field = generator_root.find( selector );

		if ( ! field.length ) {
			return;
		}

		copy_text_to_clipboard( field.val(), field );
	}

	function init_generator( root_node ) {
		var generator_root = $( root_node );

		generator_root.on( 'change', '[data-role="item-select"]', function() {
			render_item( generator_root );
		} );

		generator_root.on( 'input change', '[data-role="dynamic-control"]', function() {
			var field = $( this );
			var raw_value = field.val();
			var field_key = field.attr( 'data-key' );
			var item_slug = generator_root.find( '[data-role="item-select"]' ).val();
			var item = get_item_by_slug( item_slug );

			if ( item && item.controls ) {
				$.each( item.controls, function( index, control ) {
					if ( control.key === field_key && 'checkbox' !== control.type ) {
						field.val( get_sanitized_value( control, raw_value ) );
						return false;
					}
				} );
			}

			update_outputs( generator_root );
		} );

		generator_root.on( 'click', '[data-copy-target]', function( event ) {
			var target_name = $( this ).attr( 'data-copy-target' );

			event.preventDefault();
			copy_text_from_target( generator_root, target_name );
		} );

		render_item( generator_root );
	}

	$( function() {
		$( '[data-wpbc-bfb-advanced-mode-generator="1"]' ).each( function() {
			init_generator( this );
		} );
	} );

})( jQuery, window );