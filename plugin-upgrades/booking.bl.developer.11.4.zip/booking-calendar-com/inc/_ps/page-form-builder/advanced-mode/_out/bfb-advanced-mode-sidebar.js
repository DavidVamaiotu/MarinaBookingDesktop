"use strict";

(function ($, window_obj) {
  'use strict';

  var sidebar_data = window_obj.WPBC_BFB_Advanced_Mode_Sidebar_Data || {};
  var shortcode_items = sidebar_data.items || get_empty_array();
  var i18n = sidebar_data.i18n || {};
  function get_empty_array() {
    return [];
  }
  function get_item_by_slug(item_slug) {
    var found_item = null;
    $.each(shortcode_items, function (index, current_item) {
      if (current_item.slug === item_slug) {
        found_item = current_item;
        return false;
      }
    });
    return found_item;
  }
  function esc_html(value) {
    return $('<div />').text(value || '').html();
  }
  function esc_attr_value(value) {
    return String(value || '').replace(/"/g, '&quot;');
  }
  function sanitize_token(value) {
    return String(value || '').replace(/[^A-Za-z0-9_-]/g, '');
  }
  function sanitize_number(value) {
    return String(value || '').replace(/[^0-9]/g, '');
  }
  function sanitize_text_value(value) {
    return String(value || '').replace(/[\[\]]/g, '').replace(/"/g, '&quot;');
  }
  function sanitize_option_value(value) {
    return sanitize_text_value(value).replace(/@@/g, '@');
  }
  function sanitize_placeholder(value) {
    value = sanitize_text_value(value);
    value = value.replace(/\s+/g, '_');
    value = value.replace(/[^A-Za-z0-9_-]/g, '_');
    return value;
  }
  function get_sanitized_value(control, raw_value) {
    var sanitize_type = control.sanitize || '';
    if ('token' === sanitize_type) {
      return sanitize_token(raw_value);
    }
    if ('placeholder' === sanitize_type) {
      return sanitize_placeholder(raw_value);
    }
    if ('number' === control.type) {
      return sanitize_number(raw_value);
    }
    if ('digits' === sanitize_type) {
      return sanitize_number(raw_value);
    }
    return raw_value;
  }
  function split_non_empty_lines(value) {
    var lines = String(value || '').split(/\r?\n/);
    var clean_lines = [];
    $.each(lines, function (index, line) {
      line = $.trim(line);
      if ('' !== line) {
        clean_lines.push(line);
      }
    });
    return clean_lines;
  }
  function build_size_and_maxlength_string(values) {
    var size = sanitize_number(values.size || '');
    var maxlength = sanitize_number(values.maxlength || '');
    if ('' === size && '' === maxlength) {
      return '';
    }
    if ('' !== size && '' !== maxlength) {
      return ' ' + size + '/' + maxlength;
    }
    if ('' !== size) {
      return ' ' + size + '/';
    }
    return ' /' + maxlength;
  }
  function build_textarea_size_string(values) {
    var cols = sanitize_number(values.cols || '');
    var rows = sanitize_number(values.rows || '');
    if ('' === cols && '' === rows) {
      return '';
    }
    if ('' !== cols && '' !== rows) {
      return ' ' + cols + 'x' + rows;
    }
    if ('' !== cols) {
      return ' ' + cols + 'x';
    }
    return ' x' + rows;
  }
  function build_attribute_string(value, prefix) {
    value = String(value || '');
    if ('' === value) {
      return '';
    }
    return ' ' + prefix + value;
  }
  function build_quoted_string(value) {
    value = sanitize_text_value(value);
    if ('' === value) {
      return '';
    }
    return ' "' + value + '"';
  }
  function build_choice_options_string(values) {
    var option_values = split_non_empty_lines(values.options || '');
    var option_titles = split_non_empty_lines(values.titles || '');
    var output = '';
    $.each(option_values, function (index, option_value) {
      var clean_value = sanitize_option_value(option_value);
      var clean_title = '';
      if (index < option_titles.length) {
        clean_title = sanitize_option_value(option_titles[index]);
      }
      if ('' !== clean_title) {
        output += ' "' + clean_title + '@@' + clean_value + '"';
      } else {
        output += ' "' + clean_value + '"';
      }
    });
    return output;
  }
  function collect_values(generator_root) {
    var values = {};
    generator_root.find('[data-role="dynamic-control"]').each(function () {
      var field = $(this);
      var field_key = field.attr('data-key');
      var control_type = field.attr('data-control-type');
      if ('checkbox' === control_type) {
        values[field_key] = field.is(':checked');
      } else {
        values[field_key] = field.val();
      }
    });
    return values;
  }
  function build_simple_shortcode(item) {
    var form_shortcode = '[' + item.tag + ']';
    var content_shortcode = '';
    if (item.supports_content_tag) {
      content_shortcode = '[' + item.tag + ']';
    }
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: ''
    };
  }
  function build_simple_with_default_shortcode(item, values) {
    var default_value = build_quoted_string(values.default || '');
    var form_shortcode = '[' + item.tag + default_value + ']';
    var content_shortcode = '[' + item.tag + ']';
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: ''
    };
  }
  function build_named_field_shortcode(item, values) {
    var name = sanitize_token(values.name || '');
    var required = values.required ? '*' : '';
    var form_shortcode = '';
    var content_shortcode = '';
    var default_value = build_quoted_string(values.default || '');
    var html_id = build_attribute_string(sanitize_token(values.html_id || ''), 'id:');
    var css_class = build_attribute_string(sanitize_token(values.css_class || ''), 'class:');
    var placeholder = build_attribute_string(sanitize_placeholder(values.placeholder || ''), 'placeholder:');
    var size_and_maxlength = build_size_and_maxlength_string(values);
    if ('' === name) {
      return {
        form: '',
        content: '',
        value: ''
      };
    }
    form_shortcode = '[' + item.tag + required + ' ' + name;
    form_shortcode += size_and_maxlength;
    form_shortcode += html_id;
    form_shortcode += css_class;
    form_shortcode += placeholder;
    form_shortcode += default_value;
    form_shortcode += ']';
    content_shortcode = '[' + name + ']';
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: ''
    };
  }
  function build_textarea_shortcode(item, values) {
    var name = sanitize_token(values.name || '');
    var required = values.required ? '*' : '';
    var form_shortcode = '';
    var content_shortcode = '';
    var default_value = build_quoted_string(values.default || '');
    var html_id = build_attribute_string(sanitize_token(values.html_id || ''), 'id:');
    var css_class = build_attribute_string(sanitize_token(values.css_class || ''), 'class:');
    var size_string = build_textarea_size_string(values);
    if ('' === name) {
      return {
        form: '',
        content: '',
        value: ''
      };
    }
    form_shortcode = '[' + item.tag + required + ' ' + name;
    form_shortcode += size_string;
    form_shortcode += html_id;
    form_shortcode += css_class;
    form_shortcode += default_value;
    form_shortcode += ']';
    content_shortcode = '[' + name + ']';
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: ''
    };
  }
  function build_select_shortcode(item, values) {
    var name = sanitize_token(values.name || '');
    var required = values.required ? '*' : '';
    var multiple = values.multiple ? ' multiple' : '';
    var default_value = sanitize_option_value(values.default || '');
    var html_id = build_attribute_string(sanitize_token(values.html_id || ''), 'id:');
    var css_class = build_attribute_string(sanitize_token(values.css_class || ''), 'class:');
    var options = build_choice_options_string(values);
    var form_shortcode = '';
    var content_shortcode = '';
    var value_shortcode = '';
    if ('' === name || '' === options) {
      return {
        form: '',
        content: '',
        value: ''
      };
    }
    form_shortcode = '[' + item.tag + required + ' ' + name;
    form_shortcode += html_id;
    form_shortcode += css_class;
    if ('' !== default_value) {
      form_shortcode += ' default:' + default_value;
    }
    form_shortcode += multiple;
    form_shortcode += options;
    form_shortcode += ']';
    content_shortcode = '[' + name + ']';
    value_shortcode = '[' + name + '_val]';
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: value_shortcode
    };
  }
  function build_choice_shortcode(item, values) {
    var name = sanitize_token(values.name || '');
    var required = values.required ? '*' : '';
    var default_value = sanitize_option_value(values.default || '');
    var html_id = build_attribute_string(sanitize_token(values.html_id || ''), 'id:');
    var css_class = build_attribute_string(sanitize_token(values.css_class || ''), 'class:');
    var options = build_choice_options_string(values);
    var form_shortcode = '';
    var content_shortcode = '';
    var value_shortcode = '';
    var extra_flags = '';
    if (values.use_label_element) {
      extra_flags += ' use_label_element';
    }
    if (values.label_wrap) {
      extra_flags += ' label_wrap';
    }
    if (values.label_first) {
      extra_flags += ' label_first';
    }
    if (values.exclusive) {
      extra_flags += ' exclusive';
    }
    if ('' === name || '' === options) {
      return {
        form: '',
        content: '',
        value: ''
      };
    }
    form_shortcode = '[' + item.tag + required + ' ' + name;
    form_shortcode += html_id;
    form_shortcode += css_class;
    if ('' !== default_value) {
      form_shortcode += ' default:' + default_value;
    }
    form_shortcode += extra_flags;
    form_shortcode += options;
    form_shortcode += ']';
    content_shortcode = '[' + name + ']';
    value_shortcode = '[' + name + '_val]';
    return {
      form: form_shortcode,
      content: content_shortcode,
      value: value_shortcode
    };
  }
  function build_submit_shortcode(item, values) {
    var label = build_quoted_string(values.label || '');
    var html_id = build_attribute_string(sanitize_token(values.html_id || ''), 'id:');
    var css_class = build_attribute_string(sanitize_token(values.css_class || ''), 'class:');
    var form_shortcode = '[' + item.tag + html_id + css_class + label + ']';
    return {
      form: form_shortcode,
      content: '',
      value: ''
    };
  }
  function build_key_value_attrs_shortcode(item, values) {
    var form_shortcode = '[' + item.tag;
    $.each(item.controls || [], function (index, control) {
      var attr_name = control.attr_name || '';
      var value = values[control.key];
      if ('' === attr_name) {
        return;
      }
      if ('checkbox' === control.type) {
        if (value) {
          form_shortcode += ' ' + attr_name + '="' + esc_attr_value(control.checked_val || '1') + '"';
        }
        return;
      }
      value = sanitize_text_value(value || '');
      if ('' !== value) {
        form_shortcode += ' ' + attr_name + '="' + esc_attr_value(value) + '"';
      }
    });
    form_shortcode += ']';
    return {
      form: form_shortcode,
      content: '',
      value: ''
    };
  }
  function build_outputs(item, values) {
    if (!item) {
      return {
        form: '',
        content: '',
        value: ''
      };
    }
    if ('simple' === item.mode) {
      return build_simple_shortcode(item);
    }
    if ('simple_with_default' === item.mode) {
      return build_simple_with_default_shortcode(item, values);
    }
    if ('named_field' === item.mode) {
      return build_named_field_shortcode(item, values);
    }
    if ('textarea_field' === item.mode) {
      return build_textarea_shortcode(item, values);
    }
    if ('select_field' === item.mode) {
      return build_select_shortcode(item, values);
    }
    if ('choice_field' === item.mode) {
      return build_choice_shortcode(item, values);
    }
    if ('submit_button' === item.mode) {
      return build_submit_shortcode(item, values);
    }
    if ('key_value_attrs' === item.mode) {
      return build_key_value_attrs_shortcode(item, values);
    }
    return {
      form: '',
      content: '',
      value: ''
    };
  }
  function render_notes(generator_root, item) {
    var notes_wrap = generator_root.find('[data-role="item-notes"]');
    var html = '';
    if (!item || !item.notes || !item.notes.length) {
      notes_wrap.html('');
      return;
    }
    html += '<ul class="wpbc_bfb__amg__notes_list">';
    $.each(item.notes, function (index, note) {
      html += '<li>' + esc_html(note) + '</li>';
    });
    html += '</ul>';
    notes_wrap.html(html);
  }
  function render_controls(generator_root, item) {
    var controls_wrap = generator_root.find('[data-role="item-controls"]');
    var html = '';
    if (!item || !item.controls || !item.controls.length) {
      controls_wrap.html('');
      return;
    }
    $.each(item.controls, function (index, control) {
      var default_value = undefined !== control.default ? control.default : '';
      var readonly_attr = control.readonly ? ' readonly="readonly"' : '';
      var checked_attr = 'checkbox' === control.type && control.default ? ' checked="checked"' : '';
      var control_classes = 'wpbc_bfb__amg__control';
      if ('textarea' === control.type || 'checkbox' === control.type || 'placeholder' === control.key || 'options' === control.key || 'titles' === control.key) {
        control_classes += ' is-full-row';
      }
      html += '<div class="' + control_classes + '">';
      if ('checkbox' === control.type) {
        html += '<label class="wpbc_bfb__amg__check_label">';
        html += '<input type="checkbox" data-role="dynamic-control" data-key="' + esc_html(control.key) + '" data-control-type="checkbox"' + checked_attr + ' />';
        html += '<span>' + esc_html(control.label) + '</span>';
        html += '</label>';
        if (control.description) {
          html += '<div class="description">' + esc_html(control.description) + '</div>';
        }
      } else {
        html += '<label class="wpbc_bfb__amg__label">' + esc_html(control.label) + '</label>';
        if ('textarea' === control.type) {
          html += '<textarea class="widefat" rows="4" data-role="dynamic-control" data-key="' + esc_html(control.key) + '" data-control-type="textarea"' + readonly_attr + '>' + esc_html(default_value) + '</textarea>';
        } else {
          html += '<input class="widefat" type="' + esc_html(control.type) + '" value="' + esc_html(default_value) + '" data-role="dynamic-control" data-key="' + esc_html(control.key) + '" data-control-type="' + esc_html(control.type) + '"' + readonly_attr + ' />';
        }
        if (control.description) {
          html += '<div class="description">' + esc_html(control.description) + '</div>';
        }
      }
      html += '</div>';
    });
    controls_wrap.html(html);
  }
  function update_outputs(generator_root) {
    var item_slug = generator_root.find('[data-role="item-select"]').val();
    var item = get_item_by_slug(item_slug);
    var values = collect_values(generator_root);
    var outputs = build_outputs(item, values);
    var form_wrap = generator_root.find('[data-role="output-form-wrap"]');
    var content_wrap = generator_root.find('[data-role="output-content-wrap"]');
    var value_wrap = generator_root.find('[data-role="output-value-wrap"]');
    generator_root.find('[data-role="output-form"]').val(outputs.form);
    generator_root.find('[data-role="output-content"]').val(outputs.content);
    generator_root.find('[data-role="output-value"]').val(outputs.value);
    form_wrap.show();
    if (item && item.supports_content_tag) {
      content_wrap.show();
    } else {
      content_wrap.hide();
    }
    if (item && item.supports_value_tag) {
      value_wrap.show();
    } else {
      value_wrap.hide();
    }
  }
  function render_item(generator_root) {
    var item_slug = generator_root.find('[data-role="item-select"]').val();
    var item = get_item_by_slug(item_slug);
    var description_wrap = generator_root.find('[data-role="item-description"]');
    if (!item) {
      description_wrap.text(i18n.no_item_selected || '');
      generator_root.find('[data-role="item-controls"]').html('');
      generator_root.find('[data-role="item-notes"]').html('');
      generator_root.find('[data-role="output-form"]').val('');
      generator_root.find('[data-role="output-content"]').val('');
      generator_root.find('[data-role="output-value"]').val('');
      generator_root.find('[data-role="output-form-wrap"]').hide();
      generator_root.find('[data-role="output-content-wrap"]').hide();
      generator_root.find('[data-role="output-value-wrap"]').hide();
      return;
    }
    description_wrap.text(item.description || '');
    generator_root.find('[data-role="output-form-wrap"]').show();
    render_notes(generator_root, item);
    render_controls(generator_root, item);
    update_outputs(generator_root);
  }
  function copy_text_to_clipboard(text, fallback_field) {
    if (navigator.clipboard && 'function' === typeof navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {
        if (fallback_field.length) {
          fallback_field.trigger('focus');
          fallback_field.trigger('select');
          try {
            document.execCommand('copy');
          } catch (err) {
            /* noop */
          }
        }
      });
      return;
    }
    if (fallback_field.length) {
      fallback_field.trigger('focus');
      fallback_field.trigger('select');
      try {
        document.execCommand('copy');
      } catch (err) {
        /* noop */
      }
    }
  }
  function copy_text_from_target(generator_root, target_name) {
    var selector = '[data-role="output-' + target_name + '"]';
    var field = generator_root.find(selector);
    if (!field.length) {
      return;
    }
    copy_text_to_clipboard(field.val(), field);
  }
  function init_generator(root_node) {
    var generator_root = $(root_node);
    generator_root.on('change', '[data-role="item-select"]', function () {
      render_item(generator_root);
    });
    generator_root.on('input change', '[data-role="dynamic-control"]', function () {
      var field = $(this);
      var raw_value = field.val();
      var field_key = field.attr('data-key');
      var item_slug = generator_root.find('[data-role="item-select"]').val();
      var item = get_item_by_slug(item_slug);
      if (item && item.controls) {
        $.each(item.controls, function (index, control) {
          if (control.key === field_key && 'checkbox' !== control.type) {
            field.val(get_sanitized_value(control, raw_value));
            return false;
          }
        });
      }
      update_outputs(generator_root);
    });
    generator_root.on('click', '[data-copy-target]', function (event) {
      var target_name = $(this).attr('data-copy-target');
      event.preventDefault();
      copy_text_from_target(generator_root, target_name);
    });
    render_item(generator_root);
  }
  $(function () {
    $('[data-wpbc-bfb-advanced-mode-generator="1"]').each(function () {
      init_generator(this);
    });
  });
})(jQuery, window);
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5jL19wcy9wYWdlLWZvcm0tYnVpbGRlci9hZHZhbmNlZC1tb2RlL19vdXQvYmZiLWFkdmFuY2VkLW1vZGUtc2lkZWJhci5qcyIsIm5hbWVzIjpbIiQiLCJ3aW5kb3dfb2JqIiwic2lkZWJhcl9kYXRhIiwiV1BCQ19CRkJfQWR2YW5jZWRfTW9kZV9TaWRlYmFyX0RhdGEiLCJzaG9ydGNvZGVfaXRlbXMiLCJpdGVtcyIsImdldF9lbXB0eV9hcnJheSIsImkxOG4iLCJnZXRfaXRlbV9ieV9zbHVnIiwiaXRlbV9zbHVnIiwiZm91bmRfaXRlbSIsImVhY2giLCJpbmRleCIsImN1cnJlbnRfaXRlbSIsInNsdWciLCJlc2NfaHRtbCIsInZhbHVlIiwidGV4dCIsImh0bWwiLCJlc2NfYXR0cl92YWx1ZSIsIlN0cmluZyIsInJlcGxhY2UiLCJzYW5pdGl6ZV90b2tlbiIsInNhbml0aXplX251bWJlciIsInNhbml0aXplX3RleHRfdmFsdWUiLCJzYW5pdGl6ZV9vcHRpb25fdmFsdWUiLCJzYW5pdGl6ZV9wbGFjZWhvbGRlciIsImdldF9zYW5pdGl6ZWRfdmFsdWUiLCJjb250cm9sIiwicmF3X3ZhbHVlIiwic2FuaXRpemVfdHlwZSIsInNhbml0aXplIiwidHlwZSIsInNwbGl0X25vbl9lbXB0eV9saW5lcyIsImxpbmVzIiwic3BsaXQiLCJjbGVhbl9saW5lcyIsImxpbmUiLCJ0cmltIiwicHVzaCIsImJ1aWxkX3NpemVfYW5kX21heGxlbmd0aF9zdHJpbmciLCJ2YWx1ZXMiLCJzaXplIiwibWF4bGVuZ3RoIiwiYnVpbGRfdGV4dGFyZWFfc2l6ZV9zdHJpbmciLCJjb2xzIiwicm93cyIsImJ1aWxkX2F0dHJpYnV0ZV9zdHJpbmciLCJwcmVmaXgiLCJidWlsZF9xdW90ZWRfc3RyaW5nIiwiYnVpbGRfY2hvaWNlX29wdGlvbnNfc3RyaW5nIiwib3B0aW9uX3ZhbHVlcyIsIm9wdGlvbnMiLCJvcHRpb25fdGl0bGVzIiwidGl0bGVzIiwib3V0cHV0Iiwib3B0aW9uX3ZhbHVlIiwiY2xlYW5fdmFsdWUiLCJjbGVhbl90aXRsZSIsImxlbmd0aCIsImNvbGxlY3RfdmFsdWVzIiwiZ2VuZXJhdG9yX3Jvb3QiLCJmaW5kIiwiZmllbGQiLCJmaWVsZF9rZXkiLCJhdHRyIiwiY29udHJvbF90eXBlIiwiaXMiLCJ2YWwiLCJidWlsZF9zaW1wbGVfc2hvcnRjb2RlIiwiaXRlbSIsImZvcm1fc2hvcnRjb2RlIiwidGFnIiwiY29udGVudF9zaG9ydGNvZGUiLCJzdXBwb3J0c19jb250ZW50X3RhZyIsImZvcm0iLCJjb250ZW50IiwiYnVpbGRfc2ltcGxlX3dpdGhfZGVmYXVsdF9zaG9ydGNvZGUiLCJkZWZhdWx0X3ZhbHVlIiwiZGVmYXVsdCIsImJ1aWxkX25hbWVkX2ZpZWxkX3Nob3J0Y29kZSIsIm5hbWUiLCJyZXF1aXJlZCIsImh0bWxfaWQiLCJjc3NfY2xhc3MiLCJwbGFjZWhvbGRlciIsInNpemVfYW5kX21heGxlbmd0aCIsImJ1aWxkX3RleHRhcmVhX3Nob3J0Y29kZSIsInNpemVfc3RyaW5nIiwiYnVpbGRfc2VsZWN0X3Nob3J0Y29kZSIsIm11bHRpcGxlIiwidmFsdWVfc2hvcnRjb2RlIiwiYnVpbGRfY2hvaWNlX3Nob3J0Y29kZSIsImV4dHJhX2ZsYWdzIiwidXNlX2xhYmVsX2VsZW1lbnQiLCJsYWJlbF93cmFwIiwibGFiZWxfZmlyc3QiLCJleGNsdXNpdmUiLCJidWlsZF9zdWJtaXRfc2hvcnRjb2RlIiwibGFiZWwiLCJidWlsZF9rZXlfdmFsdWVfYXR0cnNfc2hvcnRjb2RlIiwiY29udHJvbHMiLCJhdHRyX25hbWUiLCJrZXkiLCJjaGVja2VkX3ZhbCIsImJ1aWxkX291dHB1dHMiLCJtb2RlIiwicmVuZGVyX25vdGVzIiwibm90ZXNfd3JhcCIsIm5vdGVzIiwibm90ZSIsInJlbmRlcl9jb250cm9scyIsImNvbnRyb2xzX3dyYXAiLCJ1bmRlZmluZWQiLCJyZWFkb25seV9hdHRyIiwicmVhZG9ubHkiLCJjaGVja2VkX2F0dHIiLCJjb250cm9sX2NsYXNzZXMiLCJkZXNjcmlwdGlvbiIsInVwZGF0ZV9vdXRwdXRzIiwib3V0cHV0cyIsImZvcm1fd3JhcCIsImNvbnRlbnRfd3JhcCIsInZhbHVlX3dyYXAiLCJzaG93IiwiaGlkZSIsInN1cHBvcnRzX3ZhbHVlX3RhZyIsInJlbmRlcl9pdGVtIiwiZGVzY3JpcHRpb25fd3JhcCIsIm5vX2l0ZW1fc2VsZWN0ZWQiLCJjb3B5X3RleHRfdG9fY2xpcGJvYXJkIiwiZmFsbGJhY2tfZmllbGQiLCJuYXZpZ2F0b3IiLCJjbGlwYm9hcmQiLCJ3cml0ZVRleHQiLCJjYXRjaCIsInRyaWdnZXIiLCJkb2N1bWVudCIsImV4ZWNDb21tYW5kIiwiZXJyIiwiY29weV90ZXh0X2Zyb21fdGFyZ2V0IiwidGFyZ2V0X25hbWUiLCJzZWxlY3RvciIsImluaXRfZ2VuZXJhdG9yIiwicm9vdF9ub2RlIiwib24iLCJldmVudCIsInByZXZlbnREZWZhdWx0IiwialF1ZXJ5Iiwid2luZG93Il0sInNvdXJjZXMiOlsiaW5jL19wcy9wYWdlLWZvcm0tYnVpbGRlci9hZHZhbmNlZC1tb2RlL19zcmMvYmZiLWFkdmFuY2VkLW1vZGUtc2lkZWJhci5qcyJdLCJzb3VyY2VzQ29udGVudCI6WyIoZnVuY3Rpb24gKCAkLCB3aW5kb3dfb2JqICkge1xyXG5cdCd1c2Ugc3RyaWN0JztcclxuXHJcblx0dmFyIHNpZGViYXJfZGF0YSA9IHdpbmRvd19vYmouV1BCQ19CRkJfQWR2YW5jZWRfTW9kZV9TaWRlYmFyX0RhdGEgfHwge307XHJcblx0dmFyIHNob3J0Y29kZV9pdGVtcyA9IHNpZGViYXJfZGF0YS5pdGVtcyB8fCBnZXRfZW1wdHlfYXJyYXkoKTtcclxuXHR2YXIgaTE4biA9IHNpZGViYXJfZGF0YS5pMThuIHx8IHt9O1xyXG5cclxuXHRmdW5jdGlvbiBnZXRfZW1wdHlfYXJyYXkoKSB7XHJcblx0XHRyZXR1cm4gW107XHJcblx0fVxyXG5cclxuXHRmdW5jdGlvbiBnZXRfaXRlbV9ieV9zbHVnKCBpdGVtX3NsdWcgKSB7XHJcblx0XHR2YXIgZm91bmRfaXRlbSA9IG51bGw7XHJcblxyXG5cdFx0JC5lYWNoKCBzaG9ydGNvZGVfaXRlbXMsIGZ1bmN0aW9uKCBpbmRleCwgY3VycmVudF9pdGVtICkge1xyXG5cdFx0XHRpZiAoIGN1cnJlbnRfaXRlbS5zbHVnID09PSBpdGVtX3NsdWcgKSB7XHJcblx0XHRcdFx0Zm91bmRfaXRlbSA9IGN1cnJlbnRfaXRlbTtcclxuXHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdH1cclxuXHRcdH0gKTtcclxuXHJcblx0XHRyZXR1cm4gZm91bmRfaXRlbTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGVzY19odG1sKCB2YWx1ZSApIHtcclxuXHRcdHJldHVybiAkKCAnPGRpdiAvPicgKS50ZXh0KCB2YWx1ZSB8fCAnJyApLmh0bWwoKTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGVzY19hdHRyX3ZhbHVlKCB2YWx1ZSApIHtcclxuXHRcdHJldHVybiBTdHJpbmcoIHZhbHVlIHx8ICcnICkucmVwbGFjZSggL1wiL2csICcmcXVvdDsnICk7XHJcblx0fVxyXG5cclxuXHRmdW5jdGlvbiBzYW5pdGl6ZV90b2tlbiggdmFsdWUgKSB7XHJcblx0XHRyZXR1cm4gU3RyaW5nKCB2YWx1ZSB8fCAnJyApLnJlcGxhY2UoIC9bXkEtWmEtejAtOV8tXS9nLCAnJyApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gc2FuaXRpemVfbnVtYmVyKCB2YWx1ZSApIHtcclxuXHRcdHJldHVybiBTdHJpbmcoIHZhbHVlIHx8ICcnICkucmVwbGFjZSggL1teMC05XS9nLCAnJyApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gc2FuaXRpemVfdGV4dF92YWx1ZSggdmFsdWUgKSB7XHJcblx0XHRyZXR1cm4gU3RyaW5nKCB2YWx1ZSB8fCAnJyApXHJcblx0XHRcdC5yZXBsYWNlKCAvW1xcW1xcXV0vZywgJycgKVxyXG5cdFx0XHQucmVwbGFjZSggL1wiL2csICcmcXVvdDsnICk7XHJcblx0fVxyXG5cclxuXHRmdW5jdGlvbiBzYW5pdGl6ZV9vcHRpb25fdmFsdWUoIHZhbHVlICkge1xyXG5cdFx0cmV0dXJuIHNhbml0aXplX3RleHRfdmFsdWUoIHZhbHVlICkucmVwbGFjZSggL0BAL2csICdAJyApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gc2FuaXRpemVfcGxhY2Vob2xkZXIoIHZhbHVlICkge1xyXG5cdFx0dmFsdWUgPSBzYW5pdGl6ZV90ZXh0X3ZhbHVlKCB2YWx1ZSApO1xyXG5cdFx0dmFsdWUgPSB2YWx1ZS5yZXBsYWNlKCAvXFxzKy9nLCAnXycgKTtcclxuXHRcdHZhbHVlID0gdmFsdWUucmVwbGFjZSggL1teQS1aYS16MC05Xy1dL2csICdfJyApO1xyXG5cdFx0cmV0dXJuIHZhbHVlO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gZ2V0X3Nhbml0aXplZF92YWx1ZSggY29udHJvbCwgcmF3X3ZhbHVlICkge1xyXG5cdFx0dmFyIHNhbml0aXplX3R5cGUgPSBjb250cm9sLnNhbml0aXplIHx8ICcnO1xyXG5cclxuXHRcdGlmICggJ3Rva2VuJyA9PT0gc2FuaXRpemVfdHlwZSApIHtcclxuXHRcdFx0cmV0dXJuIHNhbml0aXplX3Rva2VuKCByYXdfdmFsdWUgKTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICdwbGFjZWhvbGRlcicgPT09IHNhbml0aXplX3R5cGUgKSB7XHJcblx0XHRcdHJldHVybiBzYW5pdGl6ZV9wbGFjZWhvbGRlciggcmF3X3ZhbHVlICk7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnbnVtYmVyJyA9PT0gY29udHJvbC50eXBlICkge1xyXG5cdFx0XHRyZXR1cm4gc2FuaXRpemVfbnVtYmVyKCByYXdfdmFsdWUgKTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICdkaWdpdHMnID09PSBzYW5pdGl6ZV90eXBlICkge1xyXG5cdFx0XHRyZXR1cm4gc2FuaXRpemVfbnVtYmVyKCByYXdfdmFsdWUgKTtcclxuXHRcdH1cclxuXHJcblx0XHRyZXR1cm4gcmF3X3ZhbHVlO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gc3BsaXRfbm9uX2VtcHR5X2xpbmVzKCB2YWx1ZSApIHtcclxuXHRcdHZhciBsaW5lcyA9IFN0cmluZyggdmFsdWUgfHwgJycgKS5zcGxpdCggL1xccj9cXG4vICk7XHJcblx0XHR2YXIgY2xlYW5fbGluZXMgPSBbXTtcclxuXHJcblx0XHQkLmVhY2goIGxpbmVzLCBmdW5jdGlvbiggaW5kZXgsIGxpbmUgKSB7XHJcblx0XHRcdGxpbmUgPSAkLnRyaW0oIGxpbmUgKTtcclxuXHJcblx0XHRcdGlmICggJycgIT09IGxpbmUgKSB7XHJcblx0XHRcdFx0Y2xlYW5fbGluZXMucHVzaCggbGluZSApO1xyXG5cdFx0XHR9XHJcblx0XHR9ICk7XHJcblxyXG5cdFx0cmV0dXJuIGNsZWFuX2xpbmVzO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gYnVpbGRfc2l6ZV9hbmRfbWF4bGVuZ3RoX3N0cmluZyggdmFsdWVzICkge1xyXG5cdFx0dmFyIHNpemUgPSBzYW5pdGl6ZV9udW1iZXIoIHZhbHVlcy5zaXplIHx8ICcnICk7XHJcblx0XHR2YXIgbWF4bGVuZ3RoID0gc2FuaXRpemVfbnVtYmVyKCB2YWx1ZXMubWF4bGVuZ3RoIHx8ICcnICk7XHJcblxyXG5cdFx0aWYgKCAnJyA9PT0gc2l6ZSAmJiAnJyA9PT0gbWF4bGVuZ3RoICkge1xyXG5cdFx0XHRyZXR1cm4gJyc7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnJyAhPT0gc2l6ZSAmJiAnJyAhPT0gbWF4bGVuZ3RoICkge1xyXG5cdFx0XHRyZXR1cm4gJyAnICsgc2l6ZSArICcvJyArIG1heGxlbmd0aDtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICcnICE9PSBzaXplICkge1xyXG5cdFx0XHRyZXR1cm4gJyAnICsgc2l6ZSArICcvJztcclxuXHRcdH1cclxuXHJcblx0XHRyZXR1cm4gJyAvJyArIG1heGxlbmd0aDtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX3RleHRhcmVhX3NpemVfc3RyaW5nKCB2YWx1ZXMgKSB7XHJcblx0XHR2YXIgY29scyA9IHNhbml0aXplX251bWJlciggdmFsdWVzLmNvbHMgfHwgJycgKTtcclxuXHRcdHZhciByb3dzID0gc2FuaXRpemVfbnVtYmVyKCB2YWx1ZXMucm93cyB8fCAnJyApO1xyXG5cclxuXHRcdGlmICggJycgPT09IGNvbHMgJiYgJycgPT09IHJvd3MgKSB7XHJcblx0XHRcdHJldHVybiAnJztcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICcnICE9PSBjb2xzICYmICcnICE9PSByb3dzICkge1xyXG5cdFx0XHRyZXR1cm4gJyAnICsgY29scyArICd4JyArIHJvd3M7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnJyAhPT0gY29scyApIHtcclxuXHRcdFx0cmV0dXJuICcgJyArIGNvbHMgKyAneCc7XHJcblx0XHR9XHJcblxyXG5cdFx0cmV0dXJuICcgeCcgKyByb3dzO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggdmFsdWUsIHByZWZpeCApIHtcclxuXHRcdHZhbHVlID0gU3RyaW5nKCB2YWx1ZSB8fCAnJyApO1xyXG5cclxuXHRcdGlmICggJycgPT09IHZhbHVlICkge1xyXG5cdFx0XHRyZXR1cm4gJyc7XHJcblx0XHR9XHJcblxyXG5cdFx0cmV0dXJuICcgJyArIHByZWZpeCArIHZhbHVlO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gYnVpbGRfcXVvdGVkX3N0cmluZyggdmFsdWUgKSB7XHJcblx0XHR2YWx1ZSA9IHNhbml0aXplX3RleHRfdmFsdWUoIHZhbHVlICk7XHJcblxyXG5cdFx0aWYgKCAnJyA9PT0gdmFsdWUgKSB7XHJcblx0XHRcdHJldHVybiAnJztcclxuXHRcdH1cclxuXHJcblx0XHRyZXR1cm4gJyBcIicgKyB2YWx1ZSArICdcIic7XHJcblx0fVxyXG5cclxuXHRmdW5jdGlvbiBidWlsZF9jaG9pY2Vfb3B0aW9uc19zdHJpbmcoIHZhbHVlcyApIHtcclxuXHRcdHZhciBvcHRpb25fdmFsdWVzID0gc3BsaXRfbm9uX2VtcHR5X2xpbmVzKCB2YWx1ZXMub3B0aW9ucyB8fCAnJyApO1xyXG5cdFx0dmFyIG9wdGlvbl90aXRsZXMgPSBzcGxpdF9ub25fZW1wdHlfbGluZXMoIHZhbHVlcy50aXRsZXMgfHwgJycgKTtcclxuXHRcdHZhciBvdXRwdXQgPSAnJztcclxuXHJcblx0XHQkLmVhY2goIG9wdGlvbl92YWx1ZXMsIGZ1bmN0aW9uKCBpbmRleCwgb3B0aW9uX3ZhbHVlICkge1xyXG5cdFx0XHR2YXIgY2xlYW5fdmFsdWUgPSBzYW5pdGl6ZV9vcHRpb25fdmFsdWUoIG9wdGlvbl92YWx1ZSApO1xyXG5cdFx0XHR2YXIgY2xlYW5fdGl0bGUgPSAnJztcclxuXHJcblx0XHRcdGlmICggaW5kZXggPCBvcHRpb25fdGl0bGVzLmxlbmd0aCApIHtcclxuXHRcdFx0XHRjbGVhbl90aXRsZSA9IHNhbml0aXplX29wdGlvbl92YWx1ZSggb3B0aW9uX3RpdGxlc1sgaW5kZXggXSApO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRpZiAoICcnICE9PSBjbGVhbl90aXRsZSApIHtcclxuXHRcdFx0XHRvdXRwdXQgKz0gJyBcIicgKyBjbGVhbl90aXRsZSArICdAQCcgKyBjbGVhbl92YWx1ZSArICdcIic7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0b3V0cHV0ICs9ICcgXCInICsgY2xlYW5fdmFsdWUgKyAnXCInO1xyXG5cdFx0XHR9XHJcblx0XHR9ICk7XHJcblxyXG5cdFx0cmV0dXJuIG91dHB1dDtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGNvbGxlY3RfdmFsdWVzKCBnZW5lcmF0b3Jfcm9vdCApIHtcclxuXHRcdHZhciB2YWx1ZXMgPSB7fTtcclxuXHJcblx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cImR5bmFtaWMtY29udHJvbFwiXScgKS5lYWNoKCBmdW5jdGlvbigpIHtcclxuXHRcdFx0dmFyIGZpZWxkID0gJCggdGhpcyApO1xyXG5cdFx0XHR2YXIgZmllbGRfa2V5ID0gZmllbGQuYXR0ciggJ2RhdGEta2V5JyApO1xyXG5cdFx0XHR2YXIgY29udHJvbF90eXBlID0gZmllbGQuYXR0ciggJ2RhdGEtY29udHJvbC10eXBlJyApO1xyXG5cclxuXHRcdFx0aWYgKCAnY2hlY2tib3gnID09PSBjb250cm9sX3R5cGUgKSB7XHJcblx0XHRcdFx0dmFsdWVzWyBmaWVsZF9rZXkgXSA9IGZpZWxkLmlzKCAnOmNoZWNrZWQnICk7XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0dmFsdWVzWyBmaWVsZF9rZXkgXSA9IGZpZWxkLnZhbCgpO1xyXG5cdFx0XHR9XHJcblx0XHR9ICk7XHJcblxyXG5cdFx0cmV0dXJuIHZhbHVlcztcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX3NpbXBsZV9zaG9ydGNvZGUoIGl0ZW0gKSB7XHJcblx0XHR2YXIgZm9ybV9zaG9ydGNvZGUgPSAnWycgKyBpdGVtLnRhZyArICddJztcclxuXHRcdHZhciBjb250ZW50X3Nob3J0Y29kZSA9ICcnO1xyXG5cclxuXHRcdGlmICggaXRlbS5zdXBwb3J0c19jb250ZW50X3RhZyApIHtcclxuXHRcdFx0Y29udGVudF9zaG9ydGNvZGUgPSAnWycgKyBpdGVtLnRhZyArICddJztcclxuXHRcdH1cclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogY29udGVudF9zaG9ydGNvZGUsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX3NpbXBsZV93aXRoX2RlZmF1bHRfc2hvcnRjb2RlKCBpdGVtLCB2YWx1ZXMgKSB7XHJcblx0XHR2YXIgZGVmYXVsdF92YWx1ZSA9IGJ1aWxkX3F1b3RlZF9zdHJpbmcoIHZhbHVlcy5kZWZhdWx0IHx8ICcnICk7XHJcblx0XHR2YXIgZm9ybV9zaG9ydGNvZGUgPSAnWycgKyBpdGVtLnRhZyArIGRlZmF1bHRfdmFsdWUgKyAnXSc7XHJcblx0XHR2YXIgY29udGVudF9zaG9ydGNvZGUgPSAnWycgKyBpdGVtLnRhZyArICddJztcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogY29udGVudF9zaG9ydGNvZGUsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX25hbWVkX2ZpZWxkX3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICkge1xyXG5cdFx0dmFyIG5hbWUgPSBzYW5pdGl6ZV90b2tlbiggdmFsdWVzLm5hbWUgfHwgJycgKTtcclxuXHRcdHZhciByZXF1aXJlZCA9IHZhbHVlcy5yZXF1aXJlZCA/ICcqJyA6ICcnO1xyXG5cdFx0dmFyIGZvcm1fc2hvcnRjb2RlID0gJyc7XHJcblx0XHR2YXIgY29udGVudF9zaG9ydGNvZGUgPSAnJztcclxuXHRcdHZhciBkZWZhdWx0X3ZhbHVlID0gYnVpbGRfcXVvdGVkX3N0cmluZyggdmFsdWVzLmRlZmF1bHQgfHwgJycgKTtcclxuXHRcdHZhciBodG1sX2lkID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5odG1sX2lkIHx8ICcnICksICdpZDonICk7XHJcblx0XHR2YXIgY3NzX2NsYXNzID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5jc3NfY2xhc3MgfHwgJycgKSwgJ2NsYXNzOicgKTtcclxuXHRcdHZhciBwbGFjZWhvbGRlciA9IGJ1aWxkX2F0dHJpYnV0ZV9zdHJpbmcoIHNhbml0aXplX3BsYWNlaG9sZGVyKCB2YWx1ZXMucGxhY2Vob2xkZXIgfHwgJycgKSwgJ3BsYWNlaG9sZGVyOicgKTtcclxuXHRcdHZhciBzaXplX2FuZF9tYXhsZW5ndGggPSBidWlsZF9zaXplX2FuZF9tYXhsZW5ndGhfc3RyaW5nKCB2YWx1ZXMgKTtcclxuXHJcblx0XHRpZiAoICcnID09PSBuYW1lICkge1xyXG5cdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdGZvcm06ICcnLFxyXG5cdFx0XHRcdGNvbnRlbnQ6ICcnLFxyXG5cdFx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGZvcm1fc2hvcnRjb2RlID0gJ1snICsgaXRlbS50YWcgKyByZXF1aXJlZCArICcgJyArIG5hbWU7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBzaXplX2FuZF9tYXhsZW5ndGg7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBodG1sX2lkO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gY3NzX2NsYXNzO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gcGxhY2Vob2xkZXI7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBkZWZhdWx0X3ZhbHVlO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gJ10nO1xyXG5cclxuXHRcdGNvbnRlbnRfc2hvcnRjb2RlID0gJ1snICsgbmFtZSArICddJztcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogY29udGVudF9zaG9ydGNvZGUsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX3RleHRhcmVhX3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICkge1xyXG5cdFx0dmFyIG5hbWUgPSBzYW5pdGl6ZV90b2tlbiggdmFsdWVzLm5hbWUgfHwgJycgKTtcclxuXHRcdHZhciByZXF1aXJlZCA9IHZhbHVlcy5yZXF1aXJlZCA/ICcqJyA6ICcnO1xyXG5cdFx0dmFyIGZvcm1fc2hvcnRjb2RlID0gJyc7XHJcblx0XHR2YXIgY29udGVudF9zaG9ydGNvZGUgPSAnJztcclxuXHRcdHZhciBkZWZhdWx0X3ZhbHVlID0gYnVpbGRfcXVvdGVkX3N0cmluZyggdmFsdWVzLmRlZmF1bHQgfHwgJycgKTtcclxuXHRcdHZhciBodG1sX2lkID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5odG1sX2lkIHx8ICcnICksICdpZDonICk7XHJcblx0XHR2YXIgY3NzX2NsYXNzID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5jc3NfY2xhc3MgfHwgJycgKSwgJ2NsYXNzOicgKTtcclxuXHRcdHZhciBzaXplX3N0cmluZyA9IGJ1aWxkX3RleHRhcmVhX3NpemVfc3RyaW5nKCB2YWx1ZXMgKTtcclxuXHJcblx0XHRpZiAoICcnID09PSBuYW1lICkge1xyXG5cdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdGZvcm06ICcnLFxyXG5cdFx0XHRcdGNvbnRlbnQ6ICcnLFxyXG5cdFx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGZvcm1fc2hvcnRjb2RlID0gJ1snICsgaXRlbS50YWcgKyByZXF1aXJlZCArICcgJyArIG5hbWU7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBzaXplX3N0cmluZztcclxuXHRcdGZvcm1fc2hvcnRjb2RlICs9IGh0bWxfaWQ7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBjc3NfY2xhc3M7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBkZWZhdWx0X3ZhbHVlO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gJ10nO1xyXG5cclxuXHRcdGNvbnRlbnRfc2hvcnRjb2RlID0gJ1snICsgbmFtZSArICddJztcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogY29udGVudF9zaG9ydGNvZGUsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX3NlbGVjdF9zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApIHtcclxuXHRcdHZhciBuYW1lID0gc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5uYW1lIHx8ICcnICk7XHJcblx0XHR2YXIgcmVxdWlyZWQgPSB2YWx1ZXMucmVxdWlyZWQgPyAnKicgOiAnJztcclxuXHRcdHZhciBtdWx0aXBsZSA9IHZhbHVlcy5tdWx0aXBsZSA/ICcgbXVsdGlwbGUnIDogJyc7XHJcblx0XHR2YXIgZGVmYXVsdF92YWx1ZSA9IHNhbml0aXplX29wdGlvbl92YWx1ZSggdmFsdWVzLmRlZmF1bHQgfHwgJycgKTtcclxuXHRcdHZhciBodG1sX2lkID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5odG1sX2lkIHx8ICcnICksICdpZDonICk7XHJcblx0XHR2YXIgY3NzX2NsYXNzID0gYnVpbGRfYXR0cmlidXRlX3N0cmluZyggc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5jc3NfY2xhc3MgfHwgJycgKSwgJ2NsYXNzOicgKTtcclxuXHRcdHZhciBvcHRpb25zID0gYnVpbGRfY2hvaWNlX29wdGlvbnNfc3RyaW5nKCB2YWx1ZXMgKTtcclxuXHRcdHZhciBmb3JtX3Nob3J0Y29kZSA9ICcnO1xyXG5cdFx0dmFyIGNvbnRlbnRfc2hvcnRjb2RlID0gJyc7XHJcblx0XHR2YXIgdmFsdWVfc2hvcnRjb2RlID0gJyc7XHJcblxyXG5cdFx0aWYgKCAnJyA9PT0gbmFtZSB8fCAnJyA9PT0gb3B0aW9ucyApIHtcclxuXHRcdFx0cmV0dXJuIHtcclxuXHRcdFx0XHRmb3JtOiAnJyxcclxuXHRcdFx0XHRjb250ZW50OiAnJyxcclxuXHRcdFx0XHR2YWx1ZTogJydcclxuXHRcdFx0fTtcclxuXHRcdH1cclxuXHJcblx0XHRmb3JtX3Nob3J0Y29kZSA9ICdbJyArIGl0ZW0udGFnICsgcmVxdWlyZWQgKyAnICcgKyBuYW1lO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gaHRtbF9pZDtcclxuXHRcdGZvcm1fc2hvcnRjb2RlICs9IGNzc19jbGFzcztcclxuXHJcblx0XHRpZiAoICcnICE9PSBkZWZhdWx0X3ZhbHVlICkge1xyXG5cdFx0XHRmb3JtX3Nob3J0Y29kZSArPSAnIGRlZmF1bHQ6JyArIGRlZmF1bHRfdmFsdWU7XHJcblx0XHR9XHJcblxyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gbXVsdGlwbGU7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBvcHRpb25zO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gJ10nO1xyXG5cclxuXHRcdGNvbnRlbnRfc2hvcnRjb2RlID0gJ1snICsgbmFtZSArICddJztcclxuXHRcdHZhbHVlX3Nob3J0Y29kZSA9ICdbJyArIG5hbWUgKyAnX3ZhbF0nO1xyXG5cclxuXHRcdHJldHVybiB7XHJcblx0XHRcdGZvcm06IGZvcm1fc2hvcnRjb2RlLFxyXG5cdFx0XHRjb250ZW50OiBjb250ZW50X3Nob3J0Y29kZSxcclxuXHRcdFx0dmFsdWU6IHZhbHVlX3Nob3J0Y29kZVxyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX2Nob2ljZV9zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApIHtcclxuXHRcdHZhciBuYW1lID0gc2FuaXRpemVfdG9rZW4oIHZhbHVlcy5uYW1lIHx8ICcnICk7XHJcblx0XHR2YXIgcmVxdWlyZWQgPSB2YWx1ZXMucmVxdWlyZWQgPyAnKicgOiAnJztcclxuXHRcdHZhciBkZWZhdWx0X3ZhbHVlID0gc2FuaXRpemVfb3B0aW9uX3ZhbHVlKCB2YWx1ZXMuZGVmYXVsdCB8fCAnJyApO1xyXG5cdFx0dmFyIGh0bWxfaWQgPSBidWlsZF9hdHRyaWJ1dGVfc3RyaW5nKCBzYW5pdGl6ZV90b2tlbiggdmFsdWVzLmh0bWxfaWQgfHwgJycgKSwgJ2lkOicgKTtcclxuXHRcdHZhciBjc3NfY2xhc3MgPSBidWlsZF9hdHRyaWJ1dGVfc3RyaW5nKCBzYW5pdGl6ZV90b2tlbiggdmFsdWVzLmNzc19jbGFzcyB8fCAnJyApLCAnY2xhc3M6JyApO1xyXG5cdFx0dmFyIG9wdGlvbnMgPSBidWlsZF9jaG9pY2Vfb3B0aW9uc19zdHJpbmcoIHZhbHVlcyApO1xyXG5cdFx0dmFyIGZvcm1fc2hvcnRjb2RlID0gJyc7XHJcblx0XHR2YXIgY29udGVudF9zaG9ydGNvZGUgPSAnJztcclxuXHRcdHZhciB2YWx1ZV9zaG9ydGNvZGUgPSAnJztcclxuXHRcdHZhciBleHRyYV9mbGFncyA9ICcnO1xyXG5cclxuXHRcdGlmICggdmFsdWVzLnVzZV9sYWJlbF9lbGVtZW50ICkge1xyXG5cdFx0XHRleHRyYV9mbGFncyArPSAnIHVzZV9sYWJlbF9lbGVtZW50JztcclxuXHRcdH1cclxuXHRcdGlmICggdmFsdWVzLmxhYmVsX3dyYXAgKSB7XHJcblx0XHRcdGV4dHJhX2ZsYWdzICs9ICcgbGFiZWxfd3JhcCc7XHJcblx0XHR9XHJcblx0XHRpZiAoIHZhbHVlcy5sYWJlbF9maXJzdCApIHtcclxuXHRcdFx0ZXh0cmFfZmxhZ3MgKz0gJyBsYWJlbF9maXJzdCc7XHJcblx0XHR9XHJcblx0XHRpZiAoIHZhbHVlcy5leGNsdXNpdmUgKSB7XHJcblx0XHRcdGV4dHJhX2ZsYWdzICs9ICcgZXhjbHVzaXZlJztcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICcnID09PSBuYW1lIHx8ICcnID09PSBvcHRpb25zICkge1xyXG5cdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdGZvcm06ICcnLFxyXG5cdFx0XHRcdGNvbnRlbnQ6ICcnLFxyXG5cdFx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGZvcm1fc2hvcnRjb2RlID0gJ1snICsgaXRlbS50YWcgKyByZXF1aXJlZCArICcgJyArIG5hbWU7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBodG1sX2lkO1xyXG5cdFx0Zm9ybV9zaG9ydGNvZGUgKz0gY3NzX2NsYXNzO1xyXG5cclxuXHRcdGlmICggJycgIT09IGRlZmF1bHRfdmFsdWUgKSB7XHJcblx0XHRcdGZvcm1fc2hvcnRjb2RlICs9ICcgZGVmYXVsdDonICsgZGVmYXVsdF92YWx1ZTtcclxuXHRcdH1cclxuXHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSBleHRyYV9mbGFncztcclxuXHRcdGZvcm1fc2hvcnRjb2RlICs9IG9wdGlvbnM7XHJcblx0XHRmb3JtX3Nob3J0Y29kZSArPSAnXSc7XHJcblxyXG5cdFx0Y29udGVudF9zaG9ydGNvZGUgPSAnWycgKyBuYW1lICsgJ10nO1xyXG5cdFx0dmFsdWVfc2hvcnRjb2RlID0gJ1snICsgbmFtZSArICdfdmFsXSc7XHJcblxyXG5cdFx0cmV0dXJuIHtcclxuXHRcdFx0Zm9ybTogZm9ybV9zaG9ydGNvZGUsXHJcblx0XHRcdGNvbnRlbnQ6IGNvbnRlbnRfc2hvcnRjb2RlLFxyXG5cdFx0XHR2YWx1ZTogdmFsdWVfc2hvcnRjb2RlXHJcblx0XHR9O1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gYnVpbGRfc3VibWl0X3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICkge1xyXG5cdFx0dmFyIGxhYmVsID0gYnVpbGRfcXVvdGVkX3N0cmluZyggdmFsdWVzLmxhYmVsIHx8ICcnICk7XHJcblx0XHR2YXIgaHRtbF9pZCA9IGJ1aWxkX2F0dHJpYnV0ZV9zdHJpbmcoIHNhbml0aXplX3Rva2VuKCB2YWx1ZXMuaHRtbF9pZCB8fCAnJyApLCAnaWQ6JyApO1xyXG5cdFx0dmFyIGNzc19jbGFzcyA9IGJ1aWxkX2F0dHJpYnV0ZV9zdHJpbmcoIHNhbml0aXplX3Rva2VuKCB2YWx1ZXMuY3NzX2NsYXNzIHx8ICcnICksICdjbGFzczonICk7XHJcblx0XHR2YXIgZm9ybV9zaG9ydGNvZGUgPSAnWycgKyBpdGVtLnRhZyArIGh0bWxfaWQgKyBjc3NfY2xhc3MgKyBsYWJlbCArICddJztcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogJycsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX2tleV92YWx1ZV9hdHRyc19zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApIHtcclxuXHRcdHZhciBmb3JtX3Nob3J0Y29kZSA9ICdbJyArIGl0ZW0udGFnO1xyXG5cclxuXHRcdCQuZWFjaCggaXRlbS5jb250cm9scyB8fCBbXSwgZnVuY3Rpb24oIGluZGV4LCBjb250cm9sICkge1xyXG5cdFx0XHR2YXIgYXR0cl9uYW1lID0gY29udHJvbC5hdHRyX25hbWUgfHwgJyc7XHJcblx0XHRcdHZhciB2YWx1ZSA9IHZhbHVlc1sgY29udHJvbC5rZXkgXTtcclxuXHJcblx0XHRcdGlmICggJycgPT09IGF0dHJfbmFtZSApIHtcclxuXHRcdFx0XHRyZXR1cm47XHJcblx0XHRcdH1cclxuXHJcblx0XHRcdGlmICggJ2NoZWNrYm94JyA9PT0gY29udHJvbC50eXBlICkge1xyXG5cdFx0XHRcdGlmICggdmFsdWUgKSB7XHJcblx0XHRcdFx0XHRmb3JtX3Nob3J0Y29kZSArPSAnICcgKyBhdHRyX25hbWUgKyAnPVwiJyArIGVzY19hdHRyX3ZhbHVlKCBjb250cm9sLmNoZWNrZWRfdmFsIHx8ICcxJyApICsgJ1wiJztcclxuXHRcdFx0XHR9XHJcblx0XHRcdFx0cmV0dXJuO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHR2YWx1ZSA9IHNhbml0aXplX3RleHRfdmFsdWUoIHZhbHVlIHx8ICcnICk7XHJcblxyXG5cdFx0XHRpZiAoICcnICE9PSB2YWx1ZSApIHtcclxuXHRcdFx0XHRmb3JtX3Nob3J0Y29kZSArPSAnICcgKyBhdHRyX25hbWUgKyAnPVwiJyArIGVzY19hdHRyX3ZhbHVlKCB2YWx1ZSApICsgJ1wiJztcclxuXHRcdFx0fVxyXG5cdFx0fSApO1xyXG5cclxuXHRcdGZvcm1fc2hvcnRjb2RlICs9ICddJztcclxuXHJcblx0XHRyZXR1cm4ge1xyXG5cdFx0XHRmb3JtOiBmb3JtX3Nob3J0Y29kZSxcclxuXHRcdFx0Y29udGVudDogJycsXHJcblx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0fTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGJ1aWxkX291dHB1dHMoIGl0ZW0sIHZhbHVlcyApIHtcclxuXHRcdGlmICggISBpdGVtICkge1xyXG5cdFx0XHRyZXR1cm4ge1xyXG5cdFx0XHRcdGZvcm06ICcnLFxyXG5cdFx0XHRcdGNvbnRlbnQ6ICcnLFxyXG5cdFx0XHRcdHZhbHVlOiAnJ1xyXG5cdFx0XHR9O1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICggJ3NpbXBsZScgPT09IGl0ZW0ubW9kZSApIHtcclxuXHRcdFx0cmV0dXJuIGJ1aWxkX3NpbXBsZV9zaG9ydGNvZGUoIGl0ZW0gKTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICdzaW1wbGVfd2l0aF9kZWZhdWx0JyA9PT0gaXRlbS5tb2RlICkge1xyXG5cdFx0XHRyZXR1cm4gYnVpbGRfc2ltcGxlX3dpdGhfZGVmYXVsdF9zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICggJ25hbWVkX2ZpZWxkJyA9PT0gaXRlbS5tb2RlICkge1xyXG5cdFx0XHRyZXR1cm4gYnVpbGRfbmFtZWRfZmllbGRfc2hvcnRjb2RlKCBpdGVtLCB2YWx1ZXMgKTtcclxuXHRcdH1cclxuXHJcblx0XHRpZiAoICd0ZXh0YXJlYV9maWVsZCcgPT09IGl0ZW0ubW9kZSApIHtcclxuXHRcdFx0cmV0dXJuIGJ1aWxkX3RleHRhcmVhX3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICk7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnc2VsZWN0X2ZpZWxkJyA9PT0gaXRlbS5tb2RlICkge1xyXG5cdFx0XHRyZXR1cm4gYnVpbGRfc2VsZWN0X3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICk7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnY2hvaWNlX2ZpZWxkJyA9PT0gaXRlbS5tb2RlICkge1xyXG5cdFx0XHRyZXR1cm4gYnVpbGRfY2hvaWNlX3Nob3J0Y29kZSggaXRlbSwgdmFsdWVzICk7XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCAnc3VibWl0X2J1dHRvbicgPT09IGl0ZW0ubW9kZSApIHtcclxuXHRcdFx0cmV0dXJuIGJ1aWxkX3N1Ym1pdF9zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICggJ2tleV92YWx1ZV9hdHRycycgPT09IGl0ZW0ubW9kZSApIHtcclxuXHRcdFx0cmV0dXJuIGJ1aWxkX2tleV92YWx1ZV9hdHRyc19zaG9ydGNvZGUoIGl0ZW0sIHZhbHVlcyApO1xyXG5cdFx0fVxyXG5cclxuXHRcdHJldHVybiB7XHJcblx0XHRcdGZvcm06ICcnLFxyXG5cdFx0XHRjb250ZW50OiAnJyxcclxuXHRcdFx0dmFsdWU6ICcnXHJcblx0XHR9O1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gcmVuZGVyX25vdGVzKCBnZW5lcmF0b3Jfcm9vdCwgaXRlbSApIHtcclxuXHRcdHZhciBub3Rlc193cmFwID0gZ2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJpdGVtLW5vdGVzXCJdJyApO1xyXG5cdFx0dmFyIGh0bWwgPSAnJztcclxuXHJcblx0XHRpZiAoICEgaXRlbSB8fCAhIGl0ZW0ubm90ZXMgfHwgISBpdGVtLm5vdGVzLmxlbmd0aCApIHtcclxuXHRcdFx0bm90ZXNfd3JhcC5odG1sKCAnJyApO1xyXG5cdFx0XHRyZXR1cm47XHJcblx0XHR9XHJcblxyXG5cdFx0aHRtbCArPSAnPHVsIGNsYXNzPVwid3BiY19iZmJfX2FtZ19fbm90ZXNfbGlzdFwiPic7XHJcblxyXG5cdFx0JC5lYWNoKCBpdGVtLm5vdGVzLCBmdW5jdGlvbiggaW5kZXgsIG5vdGUgKSB7XHJcblx0XHRcdGh0bWwgKz0gJzxsaT4nICsgZXNjX2h0bWwoIG5vdGUgKSArICc8L2xpPic7XHJcblx0XHR9ICk7XHJcblxyXG5cdFx0aHRtbCArPSAnPC91bD4nO1xyXG5cclxuXHRcdG5vdGVzX3dyYXAuaHRtbCggaHRtbCApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gcmVuZGVyX2NvbnRyb2xzKCBnZW5lcmF0b3Jfcm9vdCwgaXRlbSApIHtcclxuXHRcdHZhciBjb250cm9sc193cmFwID0gZ2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJpdGVtLWNvbnRyb2xzXCJdJyApO1xyXG5cdFx0dmFyIGh0bWwgPSAnJztcclxuXHJcblx0XHRpZiAoICEgaXRlbSB8fCAhIGl0ZW0uY29udHJvbHMgfHwgISBpdGVtLmNvbnRyb2xzLmxlbmd0aCApIHtcclxuXHRcdFx0Y29udHJvbHNfd3JhcC5odG1sKCAnJyApO1xyXG5cdFx0XHRyZXR1cm47XHJcblx0XHR9XHJcblxyXG5cdFx0JC5lYWNoKCBpdGVtLmNvbnRyb2xzLCBmdW5jdGlvbiggaW5kZXgsIGNvbnRyb2wgKSB7XHJcblx0XHRcdHZhciBkZWZhdWx0X3ZhbHVlID0gKCB1bmRlZmluZWQgIT09IGNvbnRyb2wuZGVmYXVsdCApID8gY29udHJvbC5kZWZhdWx0IDogJyc7XHJcblx0XHRcdHZhciByZWFkb25seV9hdHRyID0gY29udHJvbC5yZWFkb25seSA/ICcgcmVhZG9ubHk9XCJyZWFkb25seVwiJyA6ICcnO1xyXG5cdFx0XHR2YXIgY2hlY2tlZF9hdHRyID0gKCAnY2hlY2tib3gnID09PSBjb250cm9sLnR5cGUgJiYgY29udHJvbC5kZWZhdWx0ICkgPyAnIGNoZWNrZWQ9XCJjaGVja2VkXCInIDogJyc7XHJcblx0XHRcdHZhciBjb250cm9sX2NsYXNzZXMgPSAnd3BiY19iZmJfX2FtZ19fY29udHJvbCc7XHJcblxyXG5cdFx0XHRpZiAoXHJcblx0XHRcdFx0J3RleHRhcmVhJyA9PT0gY29udHJvbC50eXBlIHx8XHJcblx0XHRcdFx0J2NoZWNrYm94JyA9PT0gY29udHJvbC50eXBlIHx8XHJcblx0XHRcdFx0J3BsYWNlaG9sZGVyJyA9PT0gY29udHJvbC5rZXkgfHxcclxuXHRcdFx0XHQnb3B0aW9ucycgPT09IGNvbnRyb2wua2V5IHx8XHJcblx0XHRcdFx0J3RpdGxlcycgPT09IGNvbnRyb2wua2V5XHJcblx0XHRcdCkge1xyXG5cdFx0XHRcdGNvbnRyb2xfY2xhc3NlcyArPSAnIGlzLWZ1bGwtcm93JztcclxuXHRcdFx0fVxyXG5cclxuXHRcdFx0aHRtbCArPSAnPGRpdiBjbGFzcz1cIicgKyBjb250cm9sX2NsYXNzZXMgKyAnXCI+JztcclxuXHJcblx0XHRcdGlmICggJ2NoZWNrYm94JyA9PT0gY29udHJvbC50eXBlICkge1xyXG5cdFx0XHRcdGh0bWwgKz0gJzxsYWJlbCBjbGFzcz1cIndwYmNfYmZiX19hbWdfX2NoZWNrX2xhYmVsXCI+JztcclxuXHRcdFx0XHRodG1sICs9ICc8aW5wdXQgdHlwZT1cImNoZWNrYm94XCIgZGF0YS1yb2xlPVwiZHluYW1pYy1jb250cm9sXCIgZGF0YS1rZXk9XCInICsgZXNjX2h0bWwoIGNvbnRyb2wua2V5ICkgKyAnXCIgZGF0YS1jb250cm9sLXR5cGU9XCJjaGVja2JveFwiJyArIGNoZWNrZWRfYXR0ciArICcgLz4nO1xyXG5cdFx0XHRcdGh0bWwgKz0gJzxzcGFuPicgKyBlc2NfaHRtbCggY29udHJvbC5sYWJlbCApICsgJzwvc3Bhbj4nO1xyXG5cdFx0XHRcdGh0bWwgKz0gJzwvbGFiZWw+JztcclxuXHJcblx0XHRcdFx0aWYgKCBjb250cm9sLmRlc2NyaXB0aW9uICkge1xyXG5cdFx0XHRcdFx0aHRtbCArPSAnPGRpdiBjbGFzcz1cImRlc2NyaXB0aW9uXCI+JyArIGVzY19odG1sKCBjb250cm9sLmRlc2NyaXB0aW9uICkgKyAnPC9kaXY+JztcclxuXHRcdFx0XHR9XHJcblx0XHRcdH0gZWxzZSB7XHJcblx0XHRcdFx0aHRtbCArPSAnPGxhYmVsIGNsYXNzPVwid3BiY19iZmJfX2FtZ19fbGFiZWxcIj4nICsgZXNjX2h0bWwoIGNvbnRyb2wubGFiZWwgKSArICc8L2xhYmVsPic7XHJcblxyXG5cdFx0XHRcdGlmICggJ3RleHRhcmVhJyA9PT0gY29udHJvbC50eXBlICkge1xyXG5cdFx0XHRcdFx0aHRtbCArPSAnPHRleHRhcmVhIGNsYXNzPVwid2lkZWZhdFwiIHJvd3M9XCI0XCIgZGF0YS1yb2xlPVwiZHluYW1pYy1jb250cm9sXCIgZGF0YS1rZXk9XCInICsgZXNjX2h0bWwoIGNvbnRyb2wua2V5ICkgKyAnXCIgZGF0YS1jb250cm9sLXR5cGU9XCJ0ZXh0YXJlYVwiJyArIHJlYWRvbmx5X2F0dHIgKyAnPicgKyBlc2NfaHRtbCggZGVmYXVsdF92YWx1ZSApICsgJzwvdGV4dGFyZWE+JztcclxuXHRcdFx0XHR9IGVsc2Uge1xyXG5cdFx0XHRcdFx0aHRtbCArPSAnPGlucHV0IGNsYXNzPVwid2lkZWZhdFwiIHR5cGU9XCInICsgZXNjX2h0bWwoIGNvbnRyb2wudHlwZSApICsgJ1wiIHZhbHVlPVwiJyArIGVzY19odG1sKCBkZWZhdWx0X3ZhbHVlICkgKyAnXCIgZGF0YS1yb2xlPVwiZHluYW1pYy1jb250cm9sXCIgZGF0YS1rZXk9XCInICsgZXNjX2h0bWwoIGNvbnRyb2wua2V5ICkgKyAnXCIgZGF0YS1jb250cm9sLXR5cGU9XCInICsgZXNjX2h0bWwoIGNvbnRyb2wudHlwZSApICsgJ1wiJyArIHJlYWRvbmx5X2F0dHIgKyAnIC8+JztcclxuXHRcdFx0XHR9XHJcblxyXG5cdFx0XHRcdGlmICggY29udHJvbC5kZXNjcmlwdGlvbiApIHtcclxuXHRcdFx0XHRcdGh0bWwgKz0gJzxkaXYgY2xhc3M9XCJkZXNjcmlwdGlvblwiPicgKyBlc2NfaHRtbCggY29udHJvbC5kZXNjcmlwdGlvbiApICsgJzwvZGl2Pic7XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHRodG1sICs9ICc8L2Rpdj4nO1xyXG5cdFx0fSApO1xyXG5cclxuXHRcdGNvbnRyb2xzX3dyYXAuaHRtbCggaHRtbCApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gdXBkYXRlX291dHB1dHMoIGdlbmVyYXRvcl9yb290ICkge1xyXG5cdFx0dmFyIGl0ZW1fc2x1ZyA9IGdlbmVyYXRvcl9yb290LmZpbmQoICdbZGF0YS1yb2xlPVwiaXRlbS1zZWxlY3RcIl0nICkudmFsKCk7XHJcblx0XHR2YXIgaXRlbSA9IGdldF9pdGVtX2J5X3NsdWcoIGl0ZW1fc2x1ZyApO1xyXG5cdFx0dmFyIHZhbHVlcyA9IGNvbGxlY3RfdmFsdWVzKCBnZW5lcmF0b3Jfcm9vdCApO1xyXG5cdFx0dmFyIG91dHB1dHMgPSBidWlsZF9vdXRwdXRzKCBpdGVtLCB2YWx1ZXMgKTtcclxuXHRcdHZhciBmb3JtX3dyYXAgPSBnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC1mb3JtLXdyYXBcIl0nICk7XHJcblx0XHR2YXIgY29udGVudF93cmFwID0gZ2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJvdXRwdXQtY29udGVudC13cmFwXCJdJyApO1xyXG5cdFx0dmFyIHZhbHVlX3dyYXAgPSBnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC12YWx1ZS13cmFwXCJdJyApO1xyXG5cclxuXHRcdGdlbmVyYXRvcl9yb290LmZpbmQoICdbZGF0YS1yb2xlPVwib3V0cHV0LWZvcm1cIl0nICkudmFsKCBvdXRwdXRzLmZvcm0gKTtcclxuXHRcdGdlbmVyYXRvcl9yb290LmZpbmQoICdbZGF0YS1yb2xlPVwib3V0cHV0LWNvbnRlbnRcIl0nICkudmFsKCBvdXRwdXRzLmNvbnRlbnQgKTtcclxuXHRcdGdlbmVyYXRvcl9yb290LmZpbmQoICdbZGF0YS1yb2xlPVwib3V0cHV0LXZhbHVlXCJdJyApLnZhbCggb3V0cHV0cy52YWx1ZSApO1xyXG5cclxuXHRcdGZvcm1fd3JhcC5zaG93KCk7XHJcblxyXG5cdFx0aWYgKCBpdGVtICYmIGl0ZW0uc3VwcG9ydHNfY29udGVudF90YWcgKSB7XHJcblx0XHRcdGNvbnRlbnRfd3JhcC5zaG93KCk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHRjb250ZW50X3dyYXAuaGlkZSgpO1xyXG5cdFx0fVxyXG5cclxuXHRcdGlmICggaXRlbSAmJiBpdGVtLnN1cHBvcnRzX3ZhbHVlX3RhZyApIHtcclxuXHRcdFx0dmFsdWVfd3JhcC5zaG93KCk7XHJcblx0XHR9IGVsc2Uge1xyXG5cdFx0XHR2YWx1ZV93cmFwLmhpZGUoKTtcclxuXHRcdH1cclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIHJlbmRlcl9pdGVtKCBnZW5lcmF0b3Jfcm9vdCApIHtcclxuXHRcdHZhciBpdGVtX3NsdWcgPSBnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIml0ZW0tc2VsZWN0XCJdJyApLnZhbCgpO1xyXG5cdFx0dmFyIGl0ZW0gPSBnZXRfaXRlbV9ieV9zbHVnKCBpdGVtX3NsdWcgKTtcclxuXHRcdHZhciBkZXNjcmlwdGlvbl93cmFwID0gZ2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJpdGVtLWRlc2NyaXB0aW9uXCJdJyApO1xyXG5cclxuXHRcdGlmICggISBpdGVtICkge1xyXG5cdFx0XHRkZXNjcmlwdGlvbl93cmFwLnRleHQoIGkxOG4ubm9faXRlbV9zZWxlY3RlZCB8fCAnJyApO1xyXG5cdFx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIml0ZW0tY29udHJvbHNcIl0nICkuaHRtbCggJycgKTtcclxuXHRcdFx0Z2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJpdGVtLW5vdGVzXCJdJyApLmh0bWwoICcnICk7XHJcblx0XHRcdGdlbmVyYXRvcl9yb290LmZpbmQoICdbZGF0YS1yb2xlPVwib3V0cHV0LWZvcm1cIl0nICkudmFsKCAnJyApO1xyXG5cdFx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC1jb250ZW50XCJdJyApLnZhbCggJycgKTtcclxuXHRcdFx0Z2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJvdXRwdXQtdmFsdWVcIl0nICkudmFsKCAnJyApO1xyXG5cdFx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC1mb3JtLXdyYXBcIl0nICkuaGlkZSgpO1xyXG5cdFx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC1jb250ZW50LXdyYXBcIl0nICkuaGlkZSgpO1xyXG5cdFx0XHRnZW5lcmF0b3Jfcm9vdC5maW5kKCAnW2RhdGEtcm9sZT1cIm91dHB1dC12YWx1ZS13cmFwXCJdJyApLmhpZGUoKTtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGRlc2NyaXB0aW9uX3dyYXAudGV4dCggaXRlbS5kZXNjcmlwdGlvbiB8fCAnJyApO1xyXG5cdFx0Z2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJvdXRwdXQtZm9ybS13cmFwXCJdJyApLnNob3coKTtcclxuXHJcblx0XHRyZW5kZXJfbm90ZXMoIGdlbmVyYXRvcl9yb290LCBpdGVtICk7XHJcblx0XHRyZW5kZXJfY29udHJvbHMoIGdlbmVyYXRvcl9yb290LCBpdGVtICk7XHJcblx0XHR1cGRhdGVfb3V0cHV0cyggZ2VuZXJhdG9yX3Jvb3QgKTtcclxuXHR9XHJcblxyXG5cdGZ1bmN0aW9uIGNvcHlfdGV4dF90b19jbGlwYm9hcmQoIHRleHQsIGZhbGxiYWNrX2ZpZWxkICkge1xyXG5cdFx0aWYgKFxyXG5cdFx0XHRuYXZpZ2F0b3IuY2xpcGJvYXJkICYmXHJcblx0XHRcdCdmdW5jdGlvbicgPT09IHR5cGVvZiBuYXZpZ2F0b3IuY2xpcGJvYXJkLndyaXRlVGV4dFxyXG5cdFx0KSB7XHJcblx0XHRcdG5hdmlnYXRvci5jbGlwYm9hcmQud3JpdGVUZXh0KCB0ZXh0ICkuY2F0Y2goIGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRcdGlmICggZmFsbGJhY2tfZmllbGQubGVuZ3RoICkge1xyXG5cdFx0XHRcdFx0ZmFsbGJhY2tfZmllbGQudHJpZ2dlciggJ2ZvY3VzJyApO1xyXG5cdFx0XHRcdFx0ZmFsbGJhY2tfZmllbGQudHJpZ2dlciggJ3NlbGVjdCcgKTtcclxuXHJcblx0XHRcdFx0XHR0cnkge1xyXG5cdFx0XHRcdFx0XHRkb2N1bWVudC5leGVjQ29tbWFuZCggJ2NvcHknICk7XHJcblx0XHRcdFx0XHR9IGNhdGNoICggZXJyICkge1xyXG5cdFx0XHRcdFx0XHQvKiBub29wICovXHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fVxyXG5cdFx0XHR9ICk7XHJcblxyXG5cdFx0XHRyZXR1cm47XHJcblx0XHR9XHJcblxyXG5cdFx0aWYgKCBmYWxsYmFja19maWVsZC5sZW5ndGggKSB7XHJcblx0XHRcdGZhbGxiYWNrX2ZpZWxkLnRyaWdnZXIoICdmb2N1cycgKTtcclxuXHRcdFx0ZmFsbGJhY2tfZmllbGQudHJpZ2dlciggJ3NlbGVjdCcgKTtcclxuXHJcblx0XHRcdHRyeSB7XHJcblx0XHRcdFx0ZG9jdW1lbnQuZXhlY0NvbW1hbmQoICdjb3B5JyApO1xyXG5cdFx0XHR9IGNhdGNoICggZXJyICkge1xyXG5cdFx0XHRcdC8qIG5vb3AgKi9cclxuXHRcdFx0fVxyXG5cdFx0fVxyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gY29weV90ZXh0X2Zyb21fdGFyZ2V0KCBnZW5lcmF0b3Jfcm9vdCwgdGFyZ2V0X25hbWUgKSB7XHJcblx0XHR2YXIgc2VsZWN0b3IgPSAnW2RhdGEtcm9sZT1cIm91dHB1dC0nICsgdGFyZ2V0X25hbWUgKyAnXCJdJztcclxuXHRcdHZhciBmaWVsZCA9IGdlbmVyYXRvcl9yb290LmZpbmQoIHNlbGVjdG9yICk7XHJcblxyXG5cdFx0aWYgKCAhIGZpZWxkLmxlbmd0aCApIHtcclxuXHRcdFx0cmV0dXJuO1xyXG5cdFx0fVxyXG5cclxuXHRcdGNvcHlfdGV4dF90b19jbGlwYm9hcmQoIGZpZWxkLnZhbCgpLCBmaWVsZCApO1xyXG5cdH1cclxuXHJcblx0ZnVuY3Rpb24gaW5pdF9nZW5lcmF0b3IoIHJvb3Rfbm9kZSApIHtcclxuXHRcdHZhciBnZW5lcmF0b3Jfcm9vdCA9ICQoIHJvb3Rfbm9kZSApO1xyXG5cclxuXHRcdGdlbmVyYXRvcl9yb290Lm9uKCAnY2hhbmdlJywgJ1tkYXRhLXJvbGU9XCJpdGVtLXNlbGVjdFwiXScsIGZ1bmN0aW9uKCkge1xyXG5cdFx0XHRyZW5kZXJfaXRlbSggZ2VuZXJhdG9yX3Jvb3QgKTtcclxuXHRcdH0gKTtcclxuXHJcblx0XHRnZW5lcmF0b3Jfcm9vdC5vbiggJ2lucHV0IGNoYW5nZScsICdbZGF0YS1yb2xlPVwiZHluYW1pYy1jb250cm9sXCJdJywgZnVuY3Rpb24oKSB7XHJcblx0XHRcdHZhciBmaWVsZCA9ICQoIHRoaXMgKTtcclxuXHRcdFx0dmFyIHJhd192YWx1ZSA9IGZpZWxkLnZhbCgpO1xyXG5cdFx0XHR2YXIgZmllbGRfa2V5ID0gZmllbGQuYXR0ciggJ2RhdGEta2V5JyApO1xyXG5cdFx0XHR2YXIgaXRlbV9zbHVnID0gZ2VuZXJhdG9yX3Jvb3QuZmluZCggJ1tkYXRhLXJvbGU9XCJpdGVtLXNlbGVjdFwiXScgKS52YWwoKTtcclxuXHRcdFx0dmFyIGl0ZW0gPSBnZXRfaXRlbV9ieV9zbHVnKCBpdGVtX3NsdWcgKTtcclxuXHJcblx0XHRcdGlmICggaXRlbSAmJiBpdGVtLmNvbnRyb2xzICkge1xyXG5cdFx0XHRcdCQuZWFjaCggaXRlbS5jb250cm9scywgZnVuY3Rpb24oIGluZGV4LCBjb250cm9sICkge1xyXG5cdFx0XHRcdFx0aWYgKCBjb250cm9sLmtleSA9PT0gZmllbGRfa2V5ICYmICdjaGVja2JveCcgIT09IGNvbnRyb2wudHlwZSApIHtcclxuXHRcdFx0XHRcdFx0ZmllbGQudmFsKCBnZXRfc2FuaXRpemVkX3ZhbHVlKCBjb250cm9sLCByYXdfdmFsdWUgKSApO1xyXG5cdFx0XHRcdFx0XHRyZXR1cm4gZmFsc2U7XHJcblx0XHRcdFx0XHR9XHJcblx0XHRcdFx0fSApO1xyXG5cdFx0XHR9XHJcblxyXG5cdFx0XHR1cGRhdGVfb3V0cHV0cyggZ2VuZXJhdG9yX3Jvb3QgKTtcclxuXHRcdH0gKTtcclxuXHJcblx0XHRnZW5lcmF0b3Jfcm9vdC5vbiggJ2NsaWNrJywgJ1tkYXRhLWNvcHktdGFyZ2V0XScsIGZ1bmN0aW9uKCBldmVudCApIHtcclxuXHRcdFx0dmFyIHRhcmdldF9uYW1lID0gJCggdGhpcyApLmF0dHIoICdkYXRhLWNvcHktdGFyZ2V0JyApO1xyXG5cclxuXHRcdFx0ZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHRcdFx0Y29weV90ZXh0X2Zyb21fdGFyZ2V0KCBnZW5lcmF0b3Jfcm9vdCwgdGFyZ2V0X25hbWUgKTtcclxuXHRcdH0gKTtcclxuXHJcblx0XHRyZW5kZXJfaXRlbSggZ2VuZXJhdG9yX3Jvb3QgKTtcclxuXHR9XHJcblxyXG5cdCQoIGZ1bmN0aW9uKCkge1xyXG5cdFx0JCggJ1tkYXRhLXdwYmMtYmZiLWFkdmFuY2VkLW1vZGUtZ2VuZXJhdG9yPVwiMVwiXScgKS5lYWNoKCBmdW5jdGlvbigpIHtcclxuXHRcdFx0aW5pdF9nZW5lcmF0b3IoIHRoaXMgKTtcclxuXHRcdH0gKTtcclxuXHR9ICk7XHJcblxyXG59KSggalF1ZXJ5LCB3aW5kb3cgKTsiXSwibWFwcGluZ3MiOiI7O0FBQUEsQ0FBQyxVQUFXQSxDQUFDLEVBQUVDLFVBQVUsRUFBRztFQUMzQixZQUFZOztFQUVaLElBQUlDLFlBQVksR0FBR0QsVUFBVSxDQUFDRSxtQ0FBbUMsSUFBSSxDQUFDLENBQUM7RUFDdkUsSUFBSUMsZUFBZSxHQUFHRixZQUFZLENBQUNHLEtBQUssSUFBSUMsZUFBZSxDQUFDLENBQUM7RUFDN0QsSUFBSUMsSUFBSSxHQUFHTCxZQUFZLENBQUNLLElBQUksSUFBSSxDQUFDLENBQUM7RUFFbEMsU0FBU0QsZUFBZUEsQ0FBQSxFQUFHO0lBQzFCLE9BQU8sRUFBRTtFQUNWO0VBRUEsU0FBU0UsZ0JBQWdCQSxDQUFFQyxTQUFTLEVBQUc7SUFDdEMsSUFBSUMsVUFBVSxHQUFHLElBQUk7SUFFckJWLENBQUMsQ0FBQ1csSUFBSSxDQUFFUCxlQUFlLEVBQUUsVUFBVVEsS0FBSyxFQUFFQyxZQUFZLEVBQUc7TUFDeEQsSUFBS0EsWUFBWSxDQUFDQyxJQUFJLEtBQUtMLFNBQVMsRUFBRztRQUN0Q0MsVUFBVSxHQUFHRyxZQUFZO1FBQ3pCLE9BQU8sS0FBSztNQUNiO0lBQ0QsQ0FBRSxDQUFDO0lBRUgsT0FBT0gsVUFBVTtFQUNsQjtFQUVBLFNBQVNLLFFBQVFBLENBQUVDLEtBQUssRUFBRztJQUMxQixPQUFPaEIsQ0FBQyxDQUFFLFNBQVUsQ0FBQyxDQUFDaUIsSUFBSSxDQUFFRCxLQUFLLElBQUksRUFBRyxDQUFDLENBQUNFLElBQUksQ0FBQyxDQUFDO0VBQ2pEO0VBRUEsU0FBU0MsY0FBY0EsQ0FBRUgsS0FBSyxFQUFHO0lBQ2hDLE9BQU9JLE1BQU0sQ0FBRUosS0FBSyxJQUFJLEVBQUcsQ0FBQyxDQUFDSyxPQUFPLENBQUUsSUFBSSxFQUFFLFFBQVMsQ0FBQztFQUN2RDtFQUVBLFNBQVNDLGNBQWNBLENBQUVOLEtBQUssRUFBRztJQUNoQyxPQUFPSSxNQUFNLENBQUVKLEtBQUssSUFBSSxFQUFHLENBQUMsQ0FBQ0ssT0FBTyxDQUFFLGlCQUFpQixFQUFFLEVBQUcsQ0FBQztFQUM5RDtFQUVBLFNBQVNFLGVBQWVBLENBQUVQLEtBQUssRUFBRztJQUNqQyxPQUFPSSxNQUFNLENBQUVKLEtBQUssSUFBSSxFQUFHLENBQUMsQ0FBQ0ssT0FBTyxDQUFFLFNBQVMsRUFBRSxFQUFHLENBQUM7RUFDdEQ7RUFFQSxTQUFTRyxtQkFBbUJBLENBQUVSLEtBQUssRUFBRztJQUNyQyxPQUFPSSxNQUFNLENBQUVKLEtBQUssSUFBSSxFQUFHLENBQUMsQ0FDMUJLLE9BQU8sQ0FBRSxTQUFTLEVBQUUsRUFBRyxDQUFDLENBQ3hCQSxPQUFPLENBQUUsSUFBSSxFQUFFLFFBQVMsQ0FBQztFQUM1QjtFQUVBLFNBQVNJLHFCQUFxQkEsQ0FBRVQsS0FBSyxFQUFHO0lBQ3ZDLE9BQU9RLG1CQUFtQixDQUFFUixLQUFNLENBQUMsQ0FBQ0ssT0FBTyxDQUFFLEtBQUssRUFBRSxHQUFJLENBQUM7RUFDMUQ7RUFFQSxTQUFTSyxvQkFBb0JBLENBQUVWLEtBQUssRUFBRztJQUN0Q0EsS0FBSyxHQUFHUSxtQkFBbUIsQ0FBRVIsS0FBTSxDQUFDO0lBQ3BDQSxLQUFLLEdBQUdBLEtBQUssQ0FBQ0ssT0FBTyxDQUFFLE1BQU0sRUFBRSxHQUFJLENBQUM7SUFDcENMLEtBQUssR0FBR0EsS0FBSyxDQUFDSyxPQUFPLENBQUUsaUJBQWlCLEVBQUUsR0FBSSxDQUFDO0lBQy9DLE9BQU9MLEtBQUs7RUFDYjtFQUVBLFNBQVNXLG1CQUFtQkEsQ0FBRUMsT0FBTyxFQUFFQyxTQUFTLEVBQUc7SUFDbEQsSUFBSUMsYUFBYSxHQUFHRixPQUFPLENBQUNHLFFBQVEsSUFBSSxFQUFFO0lBRTFDLElBQUssT0FBTyxLQUFLRCxhQUFhLEVBQUc7TUFDaEMsT0FBT1IsY0FBYyxDQUFFTyxTQUFVLENBQUM7SUFDbkM7SUFFQSxJQUFLLGFBQWEsS0FBS0MsYUFBYSxFQUFHO01BQ3RDLE9BQU9KLG9CQUFvQixDQUFFRyxTQUFVLENBQUM7SUFDekM7SUFFQSxJQUFLLFFBQVEsS0FBS0QsT0FBTyxDQUFDSSxJQUFJLEVBQUc7TUFDaEMsT0FBT1QsZUFBZSxDQUFFTSxTQUFVLENBQUM7SUFDcEM7SUFFQSxJQUFLLFFBQVEsS0FBS0MsYUFBYSxFQUFHO01BQ2pDLE9BQU9QLGVBQWUsQ0FBRU0sU0FBVSxDQUFDO0lBQ3BDO0lBRUEsT0FBT0EsU0FBUztFQUNqQjtFQUVBLFNBQVNJLHFCQUFxQkEsQ0FBRWpCLEtBQUssRUFBRztJQUN2QyxJQUFJa0IsS0FBSyxHQUFHZCxNQUFNLENBQUVKLEtBQUssSUFBSSxFQUFHLENBQUMsQ0FBQ21CLEtBQUssQ0FBRSxPQUFRLENBQUM7SUFDbEQsSUFBSUMsV0FBVyxHQUFHLEVBQUU7SUFFcEJwQyxDQUFDLENBQUNXLElBQUksQ0FBRXVCLEtBQUssRUFBRSxVQUFVdEIsS0FBSyxFQUFFeUIsSUFBSSxFQUFHO01BQ3RDQSxJQUFJLEdBQUdyQyxDQUFDLENBQUNzQyxJQUFJLENBQUVELElBQUssQ0FBQztNQUVyQixJQUFLLEVBQUUsS0FBS0EsSUFBSSxFQUFHO1FBQ2xCRCxXQUFXLENBQUNHLElBQUksQ0FBRUYsSUFBSyxDQUFDO01BQ3pCO0lBQ0QsQ0FBRSxDQUFDO0lBRUgsT0FBT0QsV0FBVztFQUNuQjtFQUVBLFNBQVNJLCtCQUErQkEsQ0FBRUMsTUFBTSxFQUFHO0lBQ2xELElBQUlDLElBQUksR0FBR25CLGVBQWUsQ0FBRWtCLE1BQU0sQ0FBQ0MsSUFBSSxJQUFJLEVBQUcsQ0FBQztJQUMvQyxJQUFJQyxTQUFTLEdBQUdwQixlQUFlLENBQUVrQixNQUFNLENBQUNFLFNBQVMsSUFBSSxFQUFHLENBQUM7SUFFekQsSUFBSyxFQUFFLEtBQUtELElBQUksSUFBSSxFQUFFLEtBQUtDLFNBQVMsRUFBRztNQUN0QyxPQUFPLEVBQUU7SUFDVjtJQUVBLElBQUssRUFBRSxLQUFLRCxJQUFJLElBQUksRUFBRSxLQUFLQyxTQUFTLEVBQUc7TUFDdEMsT0FBTyxHQUFHLEdBQUdELElBQUksR0FBRyxHQUFHLEdBQUdDLFNBQVM7SUFDcEM7SUFFQSxJQUFLLEVBQUUsS0FBS0QsSUFBSSxFQUFHO01BQ2xCLE9BQU8sR0FBRyxHQUFHQSxJQUFJLEdBQUcsR0FBRztJQUN4QjtJQUVBLE9BQU8sSUFBSSxHQUFHQyxTQUFTO0VBQ3hCO0VBRUEsU0FBU0MsMEJBQTBCQSxDQUFFSCxNQUFNLEVBQUc7SUFDN0MsSUFBSUksSUFBSSxHQUFHdEIsZUFBZSxDQUFFa0IsTUFBTSxDQUFDSSxJQUFJLElBQUksRUFBRyxDQUFDO0lBQy9DLElBQUlDLElBQUksR0FBR3ZCLGVBQWUsQ0FBRWtCLE1BQU0sQ0FBQ0ssSUFBSSxJQUFJLEVBQUcsQ0FBQztJQUUvQyxJQUFLLEVBQUUsS0FBS0QsSUFBSSxJQUFJLEVBQUUsS0FBS0MsSUFBSSxFQUFHO01BQ2pDLE9BQU8sRUFBRTtJQUNWO0lBRUEsSUFBSyxFQUFFLEtBQUtELElBQUksSUFBSSxFQUFFLEtBQUtDLElBQUksRUFBRztNQUNqQyxPQUFPLEdBQUcsR0FBR0QsSUFBSSxHQUFHLEdBQUcsR0FBR0MsSUFBSTtJQUMvQjtJQUVBLElBQUssRUFBRSxLQUFLRCxJQUFJLEVBQUc7TUFDbEIsT0FBTyxHQUFHLEdBQUdBLElBQUksR0FBRyxHQUFHO0lBQ3hCO0lBRUEsT0FBTyxJQUFJLEdBQUdDLElBQUk7RUFDbkI7RUFFQSxTQUFTQyxzQkFBc0JBLENBQUUvQixLQUFLLEVBQUVnQyxNQUFNLEVBQUc7SUFDaERoQyxLQUFLLEdBQUdJLE1BQU0sQ0FBRUosS0FBSyxJQUFJLEVBQUcsQ0FBQztJQUU3QixJQUFLLEVBQUUsS0FBS0EsS0FBSyxFQUFHO01BQ25CLE9BQU8sRUFBRTtJQUNWO0lBRUEsT0FBTyxHQUFHLEdBQUdnQyxNQUFNLEdBQUdoQyxLQUFLO0VBQzVCO0VBRUEsU0FBU2lDLG1CQUFtQkEsQ0FBRWpDLEtBQUssRUFBRztJQUNyQ0EsS0FBSyxHQUFHUSxtQkFBbUIsQ0FBRVIsS0FBTSxDQUFDO0lBRXBDLElBQUssRUFBRSxLQUFLQSxLQUFLLEVBQUc7TUFDbkIsT0FBTyxFQUFFO0lBQ1Y7SUFFQSxPQUFPLElBQUksR0FBR0EsS0FBSyxHQUFHLEdBQUc7RUFDMUI7RUFFQSxTQUFTa0MsMkJBQTJCQSxDQUFFVCxNQUFNLEVBQUc7SUFDOUMsSUFBSVUsYUFBYSxHQUFHbEIscUJBQXFCLENBQUVRLE1BQU0sQ0FBQ1csT0FBTyxJQUFJLEVBQUcsQ0FBQztJQUNqRSxJQUFJQyxhQUFhLEdBQUdwQixxQkFBcUIsQ0FBRVEsTUFBTSxDQUFDYSxNQUFNLElBQUksRUFBRyxDQUFDO0lBQ2hFLElBQUlDLE1BQU0sR0FBRyxFQUFFO0lBRWZ2RCxDQUFDLENBQUNXLElBQUksQ0FBRXdDLGFBQWEsRUFBRSxVQUFVdkMsS0FBSyxFQUFFNEMsWUFBWSxFQUFHO01BQ3RELElBQUlDLFdBQVcsR0FBR2hDLHFCQUFxQixDQUFFK0IsWUFBYSxDQUFDO01BQ3ZELElBQUlFLFdBQVcsR0FBRyxFQUFFO01BRXBCLElBQUs5QyxLQUFLLEdBQUd5QyxhQUFhLENBQUNNLE1BQU0sRUFBRztRQUNuQ0QsV0FBVyxHQUFHakMscUJBQXFCLENBQUU0QixhQUFhLENBQUV6QyxLQUFLLENBQUcsQ0FBQztNQUM5RDtNQUVBLElBQUssRUFBRSxLQUFLOEMsV0FBVyxFQUFHO1FBQ3pCSCxNQUFNLElBQUksSUFBSSxHQUFHRyxXQUFXLEdBQUcsSUFBSSxHQUFHRCxXQUFXLEdBQUcsR0FBRztNQUN4RCxDQUFDLE1BQU07UUFDTkYsTUFBTSxJQUFJLElBQUksR0FBR0UsV0FBVyxHQUFHLEdBQUc7TUFDbkM7SUFDRCxDQUFFLENBQUM7SUFFSCxPQUFPRixNQUFNO0VBQ2Q7RUFFQSxTQUFTSyxjQUFjQSxDQUFFQyxjQUFjLEVBQUc7SUFDekMsSUFBSXBCLE1BQU0sR0FBRyxDQUFDLENBQUM7SUFFZm9CLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLCtCQUFnQyxDQUFDLENBQUNuRCxJQUFJLENBQUUsWUFBVztNQUN2RSxJQUFJb0QsS0FBSyxHQUFHL0QsQ0FBQyxDQUFFLElBQUssQ0FBQztNQUNyQixJQUFJZ0UsU0FBUyxHQUFHRCxLQUFLLENBQUNFLElBQUksQ0FBRSxVQUFXLENBQUM7TUFDeEMsSUFBSUMsWUFBWSxHQUFHSCxLQUFLLENBQUNFLElBQUksQ0FBRSxtQkFBb0IsQ0FBQztNQUVwRCxJQUFLLFVBQVUsS0FBS0MsWUFBWSxFQUFHO1FBQ2xDekIsTUFBTSxDQUFFdUIsU0FBUyxDQUFFLEdBQUdELEtBQUssQ0FBQ0ksRUFBRSxDQUFFLFVBQVcsQ0FBQztNQUM3QyxDQUFDLE1BQU07UUFDTjFCLE1BQU0sQ0FBRXVCLFNBQVMsQ0FBRSxHQUFHRCxLQUFLLENBQUNLLEdBQUcsQ0FBQyxDQUFDO01BQ2xDO0lBQ0QsQ0FBRSxDQUFDO0lBRUgsT0FBTzNCLE1BQU07RUFDZDtFQUVBLFNBQVM0QixzQkFBc0JBLENBQUVDLElBQUksRUFBRztJQUN2QyxJQUFJQyxjQUFjLEdBQUcsR0FBRyxHQUFHRCxJQUFJLENBQUNFLEdBQUcsR0FBRyxHQUFHO0lBQ3pDLElBQUlDLGlCQUFpQixHQUFHLEVBQUU7SUFFMUIsSUFBS0gsSUFBSSxDQUFDSSxvQkFBb0IsRUFBRztNQUNoQ0QsaUJBQWlCLEdBQUcsR0FBRyxHQUFHSCxJQUFJLENBQUNFLEdBQUcsR0FBRyxHQUFHO0lBQ3pDO0lBRUEsT0FBTztNQUNORyxJQUFJLEVBQUVKLGNBQWM7TUFDcEJLLE9BQU8sRUFBRUgsaUJBQWlCO01BQzFCekQsS0FBSyxFQUFFO0lBQ1IsQ0FBQztFQUNGO0VBRUEsU0FBUzZELG1DQUFtQ0EsQ0FBRVAsSUFBSSxFQUFFN0IsTUFBTSxFQUFHO0lBQzVELElBQUlxQyxhQUFhLEdBQUc3QixtQkFBbUIsQ0FBRVIsTUFBTSxDQUFDc0MsT0FBTyxJQUFJLEVBQUcsQ0FBQztJQUMvRCxJQUFJUixjQUFjLEdBQUcsR0FBRyxHQUFHRCxJQUFJLENBQUNFLEdBQUcsR0FBR00sYUFBYSxHQUFHLEdBQUc7SUFDekQsSUFBSUwsaUJBQWlCLEdBQUcsR0FBRyxHQUFHSCxJQUFJLENBQUNFLEdBQUcsR0FBRyxHQUFHO0lBRTVDLE9BQU87TUFDTkcsSUFBSSxFQUFFSixjQUFjO01BQ3BCSyxPQUFPLEVBQUVILGlCQUFpQjtNQUMxQnpELEtBQUssRUFBRTtJQUNSLENBQUM7RUFDRjtFQUVBLFNBQVNnRSwyQkFBMkJBLENBQUVWLElBQUksRUFBRTdCLE1BQU0sRUFBRztJQUNwRCxJQUFJd0MsSUFBSSxHQUFHM0QsY0FBYyxDQUFFbUIsTUFBTSxDQUFDd0MsSUFBSSxJQUFJLEVBQUcsQ0FBQztJQUM5QyxJQUFJQyxRQUFRLEdBQUd6QyxNQUFNLENBQUN5QyxRQUFRLEdBQUcsR0FBRyxHQUFHLEVBQUU7SUFDekMsSUFBSVgsY0FBYyxHQUFHLEVBQUU7SUFDdkIsSUFBSUUsaUJBQWlCLEdBQUcsRUFBRTtJQUMxQixJQUFJSyxhQUFhLEdBQUc3QixtQkFBbUIsQ0FBRVIsTUFBTSxDQUFDc0MsT0FBTyxJQUFJLEVBQUcsQ0FBQztJQUMvRCxJQUFJSSxPQUFPLEdBQUdwQyxzQkFBc0IsQ0FBRXpCLGNBQWMsQ0FBRW1CLE1BQU0sQ0FBQzBDLE9BQU8sSUFBSSxFQUFHLENBQUMsRUFBRSxLQUFNLENBQUM7SUFDckYsSUFBSUMsU0FBUyxHQUFHckMsc0JBQXNCLENBQUV6QixjQUFjLENBQUVtQixNQUFNLENBQUMyQyxTQUFTLElBQUksRUFBRyxDQUFDLEVBQUUsUUFBUyxDQUFDO0lBQzVGLElBQUlDLFdBQVcsR0FBR3RDLHNCQUFzQixDQUFFckIsb0JBQW9CLENBQUVlLE1BQU0sQ0FBQzRDLFdBQVcsSUFBSSxFQUFHLENBQUMsRUFBRSxjQUFlLENBQUM7SUFDNUcsSUFBSUMsa0JBQWtCLEdBQUc5QywrQkFBK0IsQ0FBRUMsTUFBTyxDQUFDO0lBRWxFLElBQUssRUFBRSxLQUFLd0MsSUFBSSxFQUFHO01BQ2xCLE9BQU87UUFDTk4sSUFBSSxFQUFFLEVBQUU7UUFDUkMsT0FBTyxFQUFFLEVBQUU7UUFDWDVELEtBQUssRUFBRTtNQUNSLENBQUM7SUFDRjtJQUVBdUQsY0FBYyxHQUFHLEdBQUcsR0FBR0QsSUFBSSxDQUFDRSxHQUFHLEdBQUdVLFFBQVEsR0FBRyxHQUFHLEdBQUdELElBQUk7SUFDdkRWLGNBQWMsSUFBSWUsa0JBQWtCO0lBQ3BDZixjQUFjLElBQUlZLE9BQU87SUFDekJaLGNBQWMsSUFBSWEsU0FBUztJQUMzQmIsY0FBYyxJQUFJYyxXQUFXO0lBQzdCZCxjQUFjLElBQUlPLGFBQWE7SUFDL0JQLGNBQWMsSUFBSSxHQUFHO0lBRXJCRSxpQkFBaUIsR0FBRyxHQUFHLEdBQUdRLElBQUksR0FBRyxHQUFHO0lBRXBDLE9BQU87TUFDTk4sSUFBSSxFQUFFSixjQUFjO01BQ3BCSyxPQUFPLEVBQUVILGlCQUFpQjtNQUMxQnpELEtBQUssRUFBRTtJQUNSLENBQUM7RUFDRjtFQUVBLFNBQVN1RSx3QkFBd0JBLENBQUVqQixJQUFJLEVBQUU3QixNQUFNLEVBQUc7SUFDakQsSUFBSXdDLElBQUksR0FBRzNELGNBQWMsQ0FBRW1CLE1BQU0sQ0FBQ3dDLElBQUksSUFBSSxFQUFHLENBQUM7SUFDOUMsSUFBSUMsUUFBUSxHQUFHekMsTUFBTSxDQUFDeUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxFQUFFO0lBQ3pDLElBQUlYLGNBQWMsR0FBRyxFQUFFO0lBQ3ZCLElBQUlFLGlCQUFpQixHQUFHLEVBQUU7SUFDMUIsSUFBSUssYUFBYSxHQUFHN0IsbUJBQW1CLENBQUVSLE1BQU0sQ0FBQ3NDLE9BQU8sSUFBSSxFQUFHLENBQUM7SUFDL0QsSUFBSUksT0FBTyxHQUFHcEMsc0JBQXNCLENBQUV6QixjQUFjLENBQUVtQixNQUFNLENBQUMwQyxPQUFPLElBQUksRUFBRyxDQUFDLEVBQUUsS0FBTSxDQUFDO0lBQ3JGLElBQUlDLFNBQVMsR0FBR3JDLHNCQUFzQixDQUFFekIsY0FBYyxDQUFFbUIsTUFBTSxDQUFDMkMsU0FBUyxJQUFJLEVBQUcsQ0FBQyxFQUFFLFFBQVMsQ0FBQztJQUM1RixJQUFJSSxXQUFXLEdBQUc1QywwQkFBMEIsQ0FBRUgsTUFBTyxDQUFDO0lBRXRELElBQUssRUFBRSxLQUFLd0MsSUFBSSxFQUFHO01BQ2xCLE9BQU87UUFDTk4sSUFBSSxFQUFFLEVBQUU7UUFDUkMsT0FBTyxFQUFFLEVBQUU7UUFDWDVELEtBQUssRUFBRTtNQUNSLENBQUM7SUFDRjtJQUVBdUQsY0FBYyxHQUFHLEdBQUcsR0FBR0QsSUFBSSxDQUFDRSxHQUFHLEdBQUdVLFFBQVEsR0FBRyxHQUFHLEdBQUdELElBQUk7SUFDdkRWLGNBQWMsSUFBSWlCLFdBQVc7SUFDN0JqQixjQUFjLElBQUlZLE9BQU87SUFDekJaLGNBQWMsSUFBSWEsU0FBUztJQUMzQmIsY0FBYyxJQUFJTyxhQUFhO0lBQy9CUCxjQUFjLElBQUksR0FBRztJQUVyQkUsaUJBQWlCLEdBQUcsR0FBRyxHQUFHUSxJQUFJLEdBQUcsR0FBRztJQUVwQyxPQUFPO01BQ05OLElBQUksRUFBRUosY0FBYztNQUNwQkssT0FBTyxFQUFFSCxpQkFBaUI7TUFDMUJ6RCxLQUFLLEVBQUU7SUFDUixDQUFDO0VBQ0Y7RUFFQSxTQUFTeUUsc0JBQXNCQSxDQUFFbkIsSUFBSSxFQUFFN0IsTUFBTSxFQUFHO0lBQy9DLElBQUl3QyxJQUFJLEdBQUczRCxjQUFjLENBQUVtQixNQUFNLENBQUN3QyxJQUFJLElBQUksRUFBRyxDQUFDO0lBQzlDLElBQUlDLFFBQVEsR0FBR3pDLE1BQU0sQ0FBQ3lDLFFBQVEsR0FBRyxHQUFHLEdBQUcsRUFBRTtJQUN6QyxJQUFJUSxRQUFRLEdBQUdqRCxNQUFNLENBQUNpRCxRQUFRLEdBQUcsV0FBVyxHQUFHLEVBQUU7SUFDakQsSUFBSVosYUFBYSxHQUFHckQscUJBQXFCLENBQUVnQixNQUFNLENBQUNzQyxPQUFPLElBQUksRUFBRyxDQUFDO0lBQ2pFLElBQUlJLE9BQU8sR0FBR3BDLHNCQUFzQixDQUFFekIsY0FBYyxDQUFFbUIsTUFBTSxDQUFDMEMsT0FBTyxJQUFJLEVBQUcsQ0FBQyxFQUFFLEtBQU0sQ0FBQztJQUNyRixJQUFJQyxTQUFTLEdBQUdyQyxzQkFBc0IsQ0FBRXpCLGNBQWMsQ0FBRW1CLE1BQU0sQ0FBQzJDLFNBQVMsSUFBSSxFQUFHLENBQUMsRUFBRSxRQUFTLENBQUM7SUFDNUYsSUFBSWhDLE9BQU8sR0FBR0YsMkJBQTJCLENBQUVULE1BQU8sQ0FBQztJQUNuRCxJQUFJOEIsY0FBYyxHQUFHLEVBQUU7SUFDdkIsSUFBSUUsaUJBQWlCLEdBQUcsRUFBRTtJQUMxQixJQUFJa0IsZUFBZSxHQUFHLEVBQUU7SUFFeEIsSUFBSyxFQUFFLEtBQUtWLElBQUksSUFBSSxFQUFFLEtBQUs3QixPQUFPLEVBQUc7TUFDcEMsT0FBTztRQUNOdUIsSUFBSSxFQUFFLEVBQUU7UUFDUkMsT0FBTyxFQUFFLEVBQUU7UUFDWDVELEtBQUssRUFBRTtNQUNSLENBQUM7SUFDRjtJQUVBdUQsY0FBYyxHQUFHLEdBQUcsR0FBR0QsSUFBSSxDQUFDRSxHQUFHLEdBQUdVLFFBQVEsR0FBRyxHQUFHLEdBQUdELElBQUk7SUFDdkRWLGNBQWMsSUFBSVksT0FBTztJQUN6QlosY0FBYyxJQUFJYSxTQUFTO0lBRTNCLElBQUssRUFBRSxLQUFLTixhQUFhLEVBQUc7TUFDM0JQLGNBQWMsSUFBSSxXQUFXLEdBQUdPLGFBQWE7SUFDOUM7SUFFQVAsY0FBYyxJQUFJbUIsUUFBUTtJQUMxQm5CLGNBQWMsSUFBSW5CLE9BQU87SUFDekJtQixjQUFjLElBQUksR0FBRztJQUVyQkUsaUJBQWlCLEdBQUcsR0FBRyxHQUFHUSxJQUFJLEdBQUcsR0FBRztJQUNwQ1UsZUFBZSxHQUFHLEdBQUcsR0FBR1YsSUFBSSxHQUFHLE9BQU87SUFFdEMsT0FBTztNQUNOTixJQUFJLEVBQUVKLGNBQWM7TUFDcEJLLE9BQU8sRUFBRUgsaUJBQWlCO01BQzFCekQsS0FBSyxFQUFFMkU7SUFDUixDQUFDO0VBQ0Y7RUFFQSxTQUFTQyxzQkFBc0JBLENBQUV0QixJQUFJLEVBQUU3QixNQUFNLEVBQUc7SUFDL0MsSUFBSXdDLElBQUksR0FBRzNELGNBQWMsQ0FBRW1CLE1BQU0sQ0FBQ3dDLElBQUksSUFBSSxFQUFHLENBQUM7SUFDOUMsSUFBSUMsUUFBUSxHQUFHekMsTUFBTSxDQUFDeUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxFQUFFO0lBQ3pDLElBQUlKLGFBQWEsR0FBR3JELHFCQUFxQixDQUFFZ0IsTUFBTSxDQUFDc0MsT0FBTyxJQUFJLEVBQUcsQ0FBQztJQUNqRSxJQUFJSSxPQUFPLEdBQUdwQyxzQkFBc0IsQ0FBRXpCLGNBQWMsQ0FBRW1CLE1BQU0sQ0FBQzBDLE9BQU8sSUFBSSxFQUFHLENBQUMsRUFBRSxLQUFNLENBQUM7SUFDckYsSUFBSUMsU0FBUyxHQUFHckMsc0JBQXNCLENBQUV6QixjQUFjLENBQUVtQixNQUFNLENBQUMyQyxTQUFTLElBQUksRUFBRyxDQUFDLEVBQUUsUUFBUyxDQUFDO0lBQzVGLElBQUloQyxPQUFPLEdBQUdGLDJCQUEyQixDQUFFVCxNQUFPLENBQUM7SUFDbkQsSUFBSThCLGNBQWMsR0FBRyxFQUFFO0lBQ3ZCLElBQUlFLGlCQUFpQixHQUFHLEVBQUU7SUFDMUIsSUFBSWtCLGVBQWUsR0FBRyxFQUFFO0lBQ3hCLElBQUlFLFdBQVcsR0FBRyxFQUFFO0lBRXBCLElBQUtwRCxNQUFNLENBQUNxRCxpQkFBaUIsRUFBRztNQUMvQkQsV0FBVyxJQUFJLG9CQUFvQjtJQUNwQztJQUNBLElBQUtwRCxNQUFNLENBQUNzRCxVQUFVLEVBQUc7TUFDeEJGLFdBQVcsSUFBSSxhQUFhO0lBQzdCO0lBQ0EsSUFBS3BELE1BQU0sQ0FBQ3VELFdBQVcsRUFBRztNQUN6QkgsV0FBVyxJQUFJLGNBQWM7SUFDOUI7SUFDQSxJQUFLcEQsTUFBTSxDQUFDd0QsU0FBUyxFQUFHO01BQ3ZCSixXQUFXLElBQUksWUFBWTtJQUM1QjtJQUVBLElBQUssRUFBRSxLQUFLWixJQUFJLElBQUksRUFBRSxLQUFLN0IsT0FBTyxFQUFHO01BQ3BDLE9BQU87UUFDTnVCLElBQUksRUFBRSxFQUFFO1FBQ1JDLE9BQU8sRUFBRSxFQUFFO1FBQ1g1RCxLQUFLLEVBQUU7TUFDUixDQUFDO0lBQ0Y7SUFFQXVELGNBQWMsR0FBRyxHQUFHLEdBQUdELElBQUksQ0FBQ0UsR0FBRyxHQUFHVSxRQUFRLEdBQUcsR0FBRyxHQUFHRCxJQUFJO0lBQ3ZEVixjQUFjLElBQUlZLE9BQU87SUFDekJaLGNBQWMsSUFBSWEsU0FBUztJQUUzQixJQUFLLEVBQUUsS0FBS04sYUFBYSxFQUFHO01BQzNCUCxjQUFjLElBQUksV0FBVyxHQUFHTyxhQUFhO0lBQzlDO0lBRUFQLGNBQWMsSUFBSXNCLFdBQVc7SUFDN0J0QixjQUFjLElBQUluQixPQUFPO0lBQ3pCbUIsY0FBYyxJQUFJLEdBQUc7SUFFckJFLGlCQUFpQixHQUFHLEdBQUcsR0FBR1EsSUFBSSxHQUFHLEdBQUc7SUFDcENVLGVBQWUsR0FBRyxHQUFHLEdBQUdWLElBQUksR0FBRyxPQUFPO0lBRXRDLE9BQU87TUFDTk4sSUFBSSxFQUFFSixjQUFjO01BQ3BCSyxPQUFPLEVBQUVILGlCQUFpQjtNQUMxQnpELEtBQUssRUFBRTJFO0lBQ1IsQ0FBQztFQUNGO0VBRUEsU0FBU08sc0JBQXNCQSxDQUFFNUIsSUFBSSxFQUFFN0IsTUFBTSxFQUFHO0lBQy9DLElBQUkwRCxLQUFLLEdBQUdsRCxtQkFBbUIsQ0FBRVIsTUFBTSxDQUFDMEQsS0FBSyxJQUFJLEVBQUcsQ0FBQztJQUNyRCxJQUFJaEIsT0FBTyxHQUFHcEMsc0JBQXNCLENBQUV6QixjQUFjLENBQUVtQixNQUFNLENBQUMwQyxPQUFPLElBQUksRUFBRyxDQUFDLEVBQUUsS0FBTSxDQUFDO0lBQ3JGLElBQUlDLFNBQVMsR0FBR3JDLHNCQUFzQixDQUFFekIsY0FBYyxDQUFFbUIsTUFBTSxDQUFDMkMsU0FBUyxJQUFJLEVBQUcsQ0FBQyxFQUFFLFFBQVMsQ0FBQztJQUM1RixJQUFJYixjQUFjLEdBQUcsR0FBRyxHQUFHRCxJQUFJLENBQUNFLEdBQUcsR0FBR1csT0FBTyxHQUFHQyxTQUFTLEdBQUdlLEtBQUssR0FBRyxHQUFHO0lBRXZFLE9BQU87TUFDTnhCLElBQUksRUFBRUosY0FBYztNQUNwQkssT0FBTyxFQUFFLEVBQUU7TUFDWDVELEtBQUssRUFBRTtJQUNSLENBQUM7RUFDRjtFQUVBLFNBQVNvRiwrQkFBK0JBLENBQUU5QixJQUFJLEVBQUU3QixNQUFNLEVBQUc7SUFDeEQsSUFBSThCLGNBQWMsR0FBRyxHQUFHLEdBQUdELElBQUksQ0FBQ0UsR0FBRztJQUVuQ3hFLENBQUMsQ0FBQ1csSUFBSSxDQUFFMkQsSUFBSSxDQUFDK0IsUUFBUSxJQUFJLEVBQUUsRUFBRSxVQUFVekYsS0FBSyxFQUFFZ0IsT0FBTyxFQUFHO01BQ3ZELElBQUkwRSxTQUFTLEdBQUcxRSxPQUFPLENBQUMwRSxTQUFTLElBQUksRUFBRTtNQUN2QyxJQUFJdEYsS0FBSyxHQUFHeUIsTUFBTSxDQUFFYixPQUFPLENBQUMyRSxHQUFHLENBQUU7TUFFakMsSUFBSyxFQUFFLEtBQUtELFNBQVMsRUFBRztRQUN2QjtNQUNEO01BRUEsSUFBSyxVQUFVLEtBQUsxRSxPQUFPLENBQUNJLElBQUksRUFBRztRQUNsQyxJQUFLaEIsS0FBSyxFQUFHO1VBQ1p1RCxjQUFjLElBQUksR0FBRyxHQUFHK0IsU0FBUyxHQUFHLElBQUksR0FBR25GLGNBQWMsQ0FBRVMsT0FBTyxDQUFDNEUsV0FBVyxJQUFJLEdBQUksQ0FBQyxHQUFHLEdBQUc7UUFDOUY7UUFDQTtNQUNEO01BRUF4RixLQUFLLEdBQUdRLG1CQUFtQixDQUFFUixLQUFLLElBQUksRUFBRyxDQUFDO01BRTFDLElBQUssRUFBRSxLQUFLQSxLQUFLLEVBQUc7UUFDbkJ1RCxjQUFjLElBQUksR0FBRyxHQUFHK0IsU0FBUyxHQUFHLElBQUksR0FBR25GLGNBQWMsQ0FBRUgsS0FBTSxDQUFDLEdBQUcsR0FBRztNQUN6RTtJQUNELENBQUUsQ0FBQztJQUVIdUQsY0FBYyxJQUFJLEdBQUc7SUFFckIsT0FBTztNQUNOSSxJQUFJLEVBQUVKLGNBQWM7TUFDcEJLLE9BQU8sRUFBRSxFQUFFO01BQ1g1RCxLQUFLLEVBQUU7SUFDUixDQUFDO0VBQ0Y7RUFFQSxTQUFTeUYsYUFBYUEsQ0FBRW5DLElBQUksRUFBRTdCLE1BQU0sRUFBRztJQUN0QyxJQUFLLENBQUU2QixJQUFJLEVBQUc7TUFDYixPQUFPO1FBQ05LLElBQUksRUFBRSxFQUFFO1FBQ1JDLE9BQU8sRUFBRSxFQUFFO1FBQ1g1RCxLQUFLLEVBQUU7TUFDUixDQUFDO0lBQ0Y7SUFFQSxJQUFLLFFBQVEsS0FBS3NELElBQUksQ0FBQ29DLElBQUksRUFBRztNQUM3QixPQUFPckMsc0JBQXNCLENBQUVDLElBQUssQ0FBQztJQUN0QztJQUVBLElBQUsscUJBQXFCLEtBQUtBLElBQUksQ0FBQ29DLElBQUksRUFBRztNQUMxQyxPQUFPN0IsbUNBQW1DLENBQUVQLElBQUksRUFBRTdCLE1BQU8sQ0FBQztJQUMzRDtJQUVBLElBQUssYUFBYSxLQUFLNkIsSUFBSSxDQUFDb0MsSUFBSSxFQUFHO01BQ2xDLE9BQU8xQiwyQkFBMkIsQ0FBRVYsSUFBSSxFQUFFN0IsTUFBTyxDQUFDO0lBQ25EO0lBRUEsSUFBSyxnQkFBZ0IsS0FBSzZCLElBQUksQ0FBQ29DLElBQUksRUFBRztNQUNyQyxPQUFPbkIsd0JBQXdCLENBQUVqQixJQUFJLEVBQUU3QixNQUFPLENBQUM7SUFDaEQ7SUFFQSxJQUFLLGNBQWMsS0FBSzZCLElBQUksQ0FBQ29DLElBQUksRUFBRztNQUNuQyxPQUFPakIsc0JBQXNCLENBQUVuQixJQUFJLEVBQUU3QixNQUFPLENBQUM7SUFDOUM7SUFFQSxJQUFLLGNBQWMsS0FBSzZCLElBQUksQ0FBQ29DLElBQUksRUFBRztNQUNuQyxPQUFPZCxzQkFBc0IsQ0FBRXRCLElBQUksRUFBRTdCLE1BQU8sQ0FBQztJQUM5QztJQUVBLElBQUssZUFBZSxLQUFLNkIsSUFBSSxDQUFDb0MsSUFBSSxFQUFHO01BQ3BDLE9BQU9SLHNCQUFzQixDQUFFNUIsSUFBSSxFQUFFN0IsTUFBTyxDQUFDO0lBQzlDO0lBRUEsSUFBSyxpQkFBaUIsS0FBSzZCLElBQUksQ0FBQ29DLElBQUksRUFBRztNQUN0QyxPQUFPTiwrQkFBK0IsQ0FBRTlCLElBQUksRUFBRTdCLE1BQU8sQ0FBQztJQUN2RDtJQUVBLE9BQU87TUFDTmtDLElBQUksRUFBRSxFQUFFO01BQ1JDLE9BQU8sRUFBRSxFQUFFO01BQ1g1RCxLQUFLLEVBQUU7SUFDUixDQUFDO0VBQ0Y7RUFFQSxTQUFTMkYsWUFBWUEsQ0FBRTlDLGNBQWMsRUFBRVMsSUFBSSxFQUFHO0lBQzdDLElBQUlzQyxVQUFVLEdBQUcvQyxjQUFjLENBQUNDLElBQUksQ0FBRSwwQkFBMkIsQ0FBQztJQUNsRSxJQUFJNUMsSUFBSSxHQUFHLEVBQUU7SUFFYixJQUFLLENBQUVvRCxJQUFJLElBQUksQ0FBRUEsSUFBSSxDQUFDdUMsS0FBSyxJQUFJLENBQUV2QyxJQUFJLENBQUN1QyxLQUFLLENBQUNsRCxNQUFNLEVBQUc7TUFDcERpRCxVQUFVLENBQUMxRixJQUFJLENBQUUsRUFBRyxDQUFDO01BQ3JCO0lBQ0Q7SUFFQUEsSUFBSSxJQUFJLHdDQUF3QztJQUVoRGxCLENBQUMsQ0FBQ1csSUFBSSxDQUFFMkQsSUFBSSxDQUFDdUMsS0FBSyxFQUFFLFVBQVVqRyxLQUFLLEVBQUVrRyxJQUFJLEVBQUc7TUFDM0M1RixJQUFJLElBQUksTUFBTSxHQUFHSCxRQUFRLENBQUUrRixJQUFLLENBQUMsR0FBRyxPQUFPO0lBQzVDLENBQUUsQ0FBQztJQUVINUYsSUFBSSxJQUFJLE9BQU87SUFFZjBGLFVBQVUsQ0FBQzFGLElBQUksQ0FBRUEsSUFBSyxDQUFDO0VBQ3hCO0VBRUEsU0FBUzZGLGVBQWVBLENBQUVsRCxjQUFjLEVBQUVTLElBQUksRUFBRztJQUNoRCxJQUFJMEMsYUFBYSxHQUFHbkQsY0FBYyxDQUFDQyxJQUFJLENBQUUsNkJBQThCLENBQUM7SUFDeEUsSUFBSTVDLElBQUksR0FBRyxFQUFFO0lBRWIsSUFBSyxDQUFFb0QsSUFBSSxJQUFJLENBQUVBLElBQUksQ0FBQytCLFFBQVEsSUFBSSxDQUFFL0IsSUFBSSxDQUFDK0IsUUFBUSxDQUFDMUMsTUFBTSxFQUFHO01BQzFEcUQsYUFBYSxDQUFDOUYsSUFBSSxDQUFFLEVBQUcsQ0FBQztNQUN4QjtJQUNEO0lBRUFsQixDQUFDLENBQUNXLElBQUksQ0FBRTJELElBQUksQ0FBQytCLFFBQVEsRUFBRSxVQUFVekYsS0FBSyxFQUFFZ0IsT0FBTyxFQUFHO01BQ2pELElBQUlrRCxhQUFhLEdBQUttQyxTQUFTLEtBQUtyRixPQUFPLENBQUNtRCxPQUFPLEdBQUtuRCxPQUFPLENBQUNtRCxPQUFPLEdBQUcsRUFBRTtNQUM1RSxJQUFJbUMsYUFBYSxHQUFHdEYsT0FBTyxDQUFDdUYsUUFBUSxHQUFHLHNCQUFzQixHQUFHLEVBQUU7TUFDbEUsSUFBSUMsWUFBWSxHQUFLLFVBQVUsS0FBS3hGLE9BQU8sQ0FBQ0ksSUFBSSxJQUFJSixPQUFPLENBQUNtRCxPQUFPLEdBQUssb0JBQW9CLEdBQUcsRUFBRTtNQUNqRyxJQUFJc0MsZUFBZSxHQUFHLHdCQUF3QjtNQUU5QyxJQUNDLFVBQVUsS0FBS3pGLE9BQU8sQ0FBQ0ksSUFBSSxJQUMzQixVQUFVLEtBQUtKLE9BQU8sQ0FBQ0ksSUFBSSxJQUMzQixhQUFhLEtBQUtKLE9BQU8sQ0FBQzJFLEdBQUcsSUFDN0IsU0FBUyxLQUFLM0UsT0FBTyxDQUFDMkUsR0FBRyxJQUN6QixRQUFRLEtBQUszRSxPQUFPLENBQUMyRSxHQUFHLEVBQ3ZCO1FBQ0RjLGVBQWUsSUFBSSxjQUFjO01BQ2xDO01BRUFuRyxJQUFJLElBQUksY0FBYyxHQUFHbUcsZUFBZSxHQUFHLElBQUk7TUFFL0MsSUFBSyxVQUFVLEtBQUt6RixPQUFPLENBQUNJLElBQUksRUFBRztRQUNsQ2QsSUFBSSxJQUFJLDRDQUE0QztRQUNwREEsSUFBSSxJQUFJLCtEQUErRCxHQUFHSCxRQUFRLENBQUVhLE9BQU8sQ0FBQzJFLEdBQUksQ0FBQyxHQUFHLGdDQUFnQyxHQUFHYSxZQUFZLEdBQUcsS0FBSztRQUMzSmxHLElBQUksSUFBSSxRQUFRLEdBQUdILFFBQVEsQ0FBRWEsT0FBTyxDQUFDdUUsS0FBTSxDQUFDLEdBQUcsU0FBUztRQUN4RGpGLElBQUksSUFBSSxVQUFVO1FBRWxCLElBQUtVLE9BQU8sQ0FBQzBGLFdBQVcsRUFBRztVQUMxQnBHLElBQUksSUFBSSwyQkFBMkIsR0FBR0gsUUFBUSxDQUFFYSxPQUFPLENBQUMwRixXQUFZLENBQUMsR0FBRyxRQUFRO1FBQ2pGO01BQ0QsQ0FBQyxNQUFNO1FBQ05wRyxJQUFJLElBQUksc0NBQXNDLEdBQUdILFFBQVEsQ0FBRWEsT0FBTyxDQUFDdUUsS0FBTSxDQUFDLEdBQUcsVUFBVTtRQUV2RixJQUFLLFVBQVUsS0FBS3ZFLE9BQU8sQ0FBQ0ksSUFBSSxFQUFHO1VBQ2xDZCxJQUFJLElBQUksMkVBQTJFLEdBQUdILFFBQVEsQ0FBRWEsT0FBTyxDQUFDMkUsR0FBSSxDQUFDLEdBQUcsZ0NBQWdDLEdBQUdXLGFBQWEsR0FBRyxHQUFHLEdBQUduRyxRQUFRLENBQUUrRCxhQUFjLENBQUMsR0FBRyxhQUFhO1FBQ25OLENBQUMsTUFBTTtVQUNONUQsSUFBSSxJQUFJLCtCQUErQixHQUFHSCxRQUFRLENBQUVhLE9BQU8sQ0FBQ0ksSUFBSyxDQUFDLEdBQUcsV0FBVyxHQUFHakIsUUFBUSxDQUFFK0QsYUFBYyxDQUFDLEdBQUcsMENBQTBDLEdBQUcvRCxRQUFRLENBQUVhLE9BQU8sQ0FBQzJFLEdBQUksQ0FBQyxHQUFHLHVCQUF1QixHQUFHeEYsUUFBUSxDQUFFYSxPQUFPLENBQUNJLElBQUssQ0FBQyxHQUFHLEdBQUcsR0FBR2tGLGFBQWEsR0FBRyxLQUFLO1FBQ3ZRO1FBRUEsSUFBS3RGLE9BQU8sQ0FBQzBGLFdBQVcsRUFBRztVQUMxQnBHLElBQUksSUFBSSwyQkFBMkIsR0FBR0gsUUFBUSxDQUFFYSxPQUFPLENBQUMwRixXQUFZLENBQUMsR0FBRyxRQUFRO1FBQ2pGO01BQ0Q7TUFFQXBHLElBQUksSUFBSSxRQUFRO0lBQ2pCLENBQUUsQ0FBQztJQUVIOEYsYUFBYSxDQUFDOUYsSUFBSSxDQUFFQSxJQUFLLENBQUM7RUFDM0I7RUFFQSxTQUFTcUcsY0FBY0EsQ0FBRTFELGNBQWMsRUFBRztJQUN6QyxJQUFJcEQsU0FBUyxHQUFHb0QsY0FBYyxDQUFDQyxJQUFJLENBQUUsMkJBQTRCLENBQUMsQ0FBQ00sR0FBRyxDQUFDLENBQUM7SUFDeEUsSUFBSUUsSUFBSSxHQUFHOUQsZ0JBQWdCLENBQUVDLFNBQVUsQ0FBQztJQUN4QyxJQUFJZ0MsTUFBTSxHQUFHbUIsY0FBYyxDQUFFQyxjQUFlLENBQUM7SUFDN0MsSUFBSTJELE9BQU8sR0FBR2YsYUFBYSxDQUFFbkMsSUFBSSxFQUFFN0IsTUFBTyxDQUFDO0lBQzNDLElBQUlnRixTQUFTLEdBQUc1RCxjQUFjLENBQUNDLElBQUksQ0FBRSxnQ0FBaUMsQ0FBQztJQUN2RSxJQUFJNEQsWUFBWSxHQUFHN0QsY0FBYyxDQUFDQyxJQUFJLENBQUUsbUNBQW9DLENBQUM7SUFDN0UsSUFBSTZELFVBQVUsR0FBRzlELGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLGlDQUFrQyxDQUFDO0lBRXpFRCxjQUFjLENBQUNDLElBQUksQ0FBRSwyQkFBNEIsQ0FBQyxDQUFDTSxHQUFHLENBQUVvRCxPQUFPLENBQUM3QyxJQUFLLENBQUM7SUFDdEVkLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLDhCQUErQixDQUFDLENBQUNNLEdBQUcsQ0FBRW9ELE9BQU8sQ0FBQzVDLE9BQVEsQ0FBQztJQUM1RWYsY0FBYyxDQUFDQyxJQUFJLENBQUUsNEJBQTZCLENBQUMsQ0FBQ00sR0FBRyxDQUFFb0QsT0FBTyxDQUFDeEcsS0FBTSxDQUFDO0lBRXhFeUcsU0FBUyxDQUFDRyxJQUFJLENBQUMsQ0FBQztJQUVoQixJQUFLdEQsSUFBSSxJQUFJQSxJQUFJLENBQUNJLG9CQUFvQixFQUFHO01BQ3hDZ0QsWUFBWSxDQUFDRSxJQUFJLENBQUMsQ0FBQztJQUNwQixDQUFDLE1BQU07TUFDTkYsWUFBWSxDQUFDRyxJQUFJLENBQUMsQ0FBQztJQUNwQjtJQUVBLElBQUt2RCxJQUFJLElBQUlBLElBQUksQ0FBQ3dELGtCQUFrQixFQUFHO01BQ3RDSCxVQUFVLENBQUNDLElBQUksQ0FBQyxDQUFDO0lBQ2xCLENBQUMsTUFBTTtNQUNORCxVQUFVLENBQUNFLElBQUksQ0FBQyxDQUFDO0lBQ2xCO0VBQ0Q7RUFFQSxTQUFTRSxXQUFXQSxDQUFFbEUsY0FBYyxFQUFHO0lBQ3RDLElBQUlwRCxTQUFTLEdBQUdvRCxjQUFjLENBQUNDLElBQUksQ0FBRSwyQkFBNEIsQ0FBQyxDQUFDTSxHQUFHLENBQUMsQ0FBQztJQUN4RSxJQUFJRSxJQUFJLEdBQUc5RCxnQkFBZ0IsQ0FBRUMsU0FBVSxDQUFDO0lBQ3hDLElBQUl1SCxnQkFBZ0IsR0FBR25FLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLGdDQUFpQyxDQUFDO0lBRTlFLElBQUssQ0FBRVEsSUFBSSxFQUFHO01BQ2IwRCxnQkFBZ0IsQ0FBQy9HLElBQUksQ0FBRVYsSUFBSSxDQUFDMEgsZ0JBQWdCLElBQUksRUFBRyxDQUFDO01BQ3BEcEUsY0FBYyxDQUFDQyxJQUFJLENBQUUsNkJBQThCLENBQUMsQ0FBQzVDLElBQUksQ0FBRSxFQUFHLENBQUM7TUFDL0QyQyxjQUFjLENBQUNDLElBQUksQ0FBRSwwQkFBMkIsQ0FBQyxDQUFDNUMsSUFBSSxDQUFFLEVBQUcsQ0FBQztNQUM1RDJDLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLDJCQUE0QixDQUFDLENBQUNNLEdBQUcsQ0FBRSxFQUFHLENBQUM7TUFDNURQLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLDhCQUErQixDQUFDLENBQUNNLEdBQUcsQ0FBRSxFQUFHLENBQUM7TUFDL0RQLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLDRCQUE2QixDQUFDLENBQUNNLEdBQUcsQ0FBRSxFQUFHLENBQUM7TUFDN0RQLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLGdDQUFpQyxDQUFDLENBQUMrRCxJQUFJLENBQUMsQ0FBQztNQUM5RGhFLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLG1DQUFvQyxDQUFDLENBQUMrRCxJQUFJLENBQUMsQ0FBQztNQUNqRWhFLGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLGlDQUFrQyxDQUFDLENBQUMrRCxJQUFJLENBQUMsQ0FBQztNQUMvRDtJQUNEO0lBRUFHLGdCQUFnQixDQUFDL0csSUFBSSxDQUFFcUQsSUFBSSxDQUFDZ0QsV0FBVyxJQUFJLEVBQUcsQ0FBQztJQUMvQ3pELGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLGdDQUFpQyxDQUFDLENBQUM4RCxJQUFJLENBQUMsQ0FBQztJQUU5RGpCLFlBQVksQ0FBRTlDLGNBQWMsRUFBRVMsSUFBSyxDQUFDO0lBQ3BDeUMsZUFBZSxDQUFFbEQsY0FBYyxFQUFFUyxJQUFLLENBQUM7SUFDdkNpRCxjQUFjLENBQUUxRCxjQUFlLENBQUM7RUFDakM7RUFFQSxTQUFTcUUsc0JBQXNCQSxDQUFFakgsSUFBSSxFQUFFa0gsY0FBYyxFQUFHO0lBQ3ZELElBQ0NDLFNBQVMsQ0FBQ0MsU0FBUyxJQUNuQixVQUFVLEtBQUssT0FBT0QsU0FBUyxDQUFDQyxTQUFTLENBQUNDLFNBQVMsRUFDbEQ7TUFDREYsU0FBUyxDQUFDQyxTQUFTLENBQUNDLFNBQVMsQ0FBRXJILElBQUssQ0FBQyxDQUFDc0gsS0FBSyxDQUFFLFlBQVc7UUFDdkQsSUFBS0osY0FBYyxDQUFDeEUsTUFBTSxFQUFHO1VBQzVCd0UsY0FBYyxDQUFDSyxPQUFPLENBQUUsT0FBUSxDQUFDO1VBQ2pDTCxjQUFjLENBQUNLLE9BQU8sQ0FBRSxRQUFTLENBQUM7VUFFbEMsSUFBSTtZQUNIQyxRQUFRLENBQUNDLFdBQVcsQ0FBRSxNQUFPLENBQUM7VUFDL0IsQ0FBQyxDQUFDLE9BQVFDLEdBQUcsRUFBRztZQUNmO1VBQUE7UUFFRjtNQUNELENBQUUsQ0FBQztNQUVIO0lBQ0Q7SUFFQSxJQUFLUixjQUFjLENBQUN4RSxNQUFNLEVBQUc7TUFDNUJ3RSxjQUFjLENBQUNLLE9BQU8sQ0FBRSxPQUFRLENBQUM7TUFDakNMLGNBQWMsQ0FBQ0ssT0FBTyxDQUFFLFFBQVMsQ0FBQztNQUVsQyxJQUFJO1FBQ0hDLFFBQVEsQ0FBQ0MsV0FBVyxDQUFFLE1BQU8sQ0FBQztNQUMvQixDQUFDLENBQUMsT0FBUUMsR0FBRyxFQUFHO1FBQ2Y7TUFBQTtJQUVGO0VBQ0Q7RUFFQSxTQUFTQyxxQkFBcUJBLENBQUUvRSxjQUFjLEVBQUVnRixXQUFXLEVBQUc7SUFDN0QsSUFBSUMsUUFBUSxHQUFHLHFCQUFxQixHQUFHRCxXQUFXLEdBQUcsSUFBSTtJQUN6RCxJQUFJOUUsS0FBSyxHQUFHRixjQUFjLENBQUNDLElBQUksQ0FBRWdGLFFBQVMsQ0FBQztJQUUzQyxJQUFLLENBQUUvRSxLQUFLLENBQUNKLE1BQU0sRUFBRztNQUNyQjtJQUNEO0lBRUF1RSxzQkFBc0IsQ0FBRW5FLEtBQUssQ0FBQ0ssR0FBRyxDQUFDLENBQUMsRUFBRUwsS0FBTSxDQUFDO0VBQzdDO0VBRUEsU0FBU2dGLGNBQWNBLENBQUVDLFNBQVMsRUFBRztJQUNwQyxJQUFJbkYsY0FBYyxHQUFHN0QsQ0FBQyxDQUFFZ0osU0FBVSxDQUFDO0lBRW5DbkYsY0FBYyxDQUFDb0YsRUFBRSxDQUFFLFFBQVEsRUFBRSwyQkFBMkIsRUFBRSxZQUFXO01BQ3BFbEIsV0FBVyxDQUFFbEUsY0FBZSxDQUFDO0lBQzlCLENBQUUsQ0FBQztJQUVIQSxjQUFjLENBQUNvRixFQUFFLENBQUUsY0FBYyxFQUFFLCtCQUErQixFQUFFLFlBQVc7TUFDOUUsSUFBSWxGLEtBQUssR0FBRy9ELENBQUMsQ0FBRSxJQUFLLENBQUM7TUFDckIsSUFBSTZCLFNBQVMsR0FBR2tDLEtBQUssQ0FBQ0ssR0FBRyxDQUFDLENBQUM7TUFDM0IsSUFBSUosU0FBUyxHQUFHRCxLQUFLLENBQUNFLElBQUksQ0FBRSxVQUFXLENBQUM7TUFDeEMsSUFBSXhELFNBQVMsR0FBR29ELGNBQWMsQ0FBQ0MsSUFBSSxDQUFFLDJCQUE0QixDQUFDLENBQUNNLEdBQUcsQ0FBQyxDQUFDO01BQ3hFLElBQUlFLElBQUksR0FBRzlELGdCQUFnQixDQUFFQyxTQUFVLENBQUM7TUFFeEMsSUFBSzZELElBQUksSUFBSUEsSUFBSSxDQUFDK0IsUUFBUSxFQUFHO1FBQzVCckcsQ0FBQyxDQUFDVyxJQUFJLENBQUUyRCxJQUFJLENBQUMrQixRQUFRLEVBQUUsVUFBVXpGLEtBQUssRUFBRWdCLE9BQU8sRUFBRztVQUNqRCxJQUFLQSxPQUFPLENBQUMyRSxHQUFHLEtBQUt2QyxTQUFTLElBQUksVUFBVSxLQUFLcEMsT0FBTyxDQUFDSSxJQUFJLEVBQUc7WUFDL0QrQixLQUFLLENBQUNLLEdBQUcsQ0FBRXpDLG1CQUFtQixDQUFFQyxPQUFPLEVBQUVDLFNBQVUsQ0FBRSxDQUFDO1lBQ3RELE9BQU8sS0FBSztVQUNiO1FBQ0QsQ0FBRSxDQUFDO01BQ0o7TUFFQTBGLGNBQWMsQ0FBRTFELGNBQWUsQ0FBQztJQUNqQyxDQUFFLENBQUM7SUFFSEEsY0FBYyxDQUFDb0YsRUFBRSxDQUFFLE9BQU8sRUFBRSxvQkFBb0IsRUFBRSxVQUFVQyxLQUFLLEVBQUc7TUFDbkUsSUFBSUwsV0FBVyxHQUFHN0ksQ0FBQyxDQUFFLElBQUssQ0FBQyxDQUFDaUUsSUFBSSxDQUFFLGtCQUFtQixDQUFDO01BRXREaUYsS0FBSyxDQUFDQyxjQUFjLENBQUMsQ0FBQztNQUN0QlAscUJBQXFCLENBQUUvRSxjQUFjLEVBQUVnRixXQUFZLENBQUM7SUFDckQsQ0FBRSxDQUFDO0lBRUhkLFdBQVcsQ0FBRWxFLGNBQWUsQ0FBQztFQUM5QjtFQUVBN0QsQ0FBQyxDQUFFLFlBQVc7SUFDYkEsQ0FBQyxDQUFFLDZDQUE4QyxDQUFDLENBQUNXLElBQUksQ0FBRSxZQUFXO01BQ25Fb0ksY0FBYyxDQUFFLElBQUssQ0FBQztJQUN2QixDQUFFLENBQUM7RUFDSixDQUFFLENBQUM7QUFFSixDQUFDLEVBQUdLLE1BQU0sRUFBRUMsTUFBTyxDQUFDIiwiaWdub3JlTGlzdCI6W119
