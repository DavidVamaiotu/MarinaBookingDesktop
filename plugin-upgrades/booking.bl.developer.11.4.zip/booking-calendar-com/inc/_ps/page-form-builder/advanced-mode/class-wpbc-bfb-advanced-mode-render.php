<?php
/**
 * Advanced Mode sidebar renderer.
 *
 * @package Booking Calendar
 * @subpackage Form Builder
 * @since 11.0.0
 * @file ../wp-content/plugins/booking-calendar-com/inc/_ps/page-form-builder/advanced-mode/class-wpbc-bfb-advanced-mode-render.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Renderer for Advanced Mode sidebar sections.
 */
class WPBC_BFB_Advanced_Mode_Render {

	/**
	 * Render one section content.
	 *
	 * @param array $tool_section    Tool section.
	 * @param array $shortcode_items Shortcode items.
	 *
	 * @return void
	 */
	public static function render_section( $tool_section, $shortcode_items ) {

		if ( ! empty( $tool_section['description'] ) ) {
			?>
			<p class="description wpbc_bfb__am_section_desc">
				<?php echo esc_html( $tool_section['description'] ); ?>
			</p>
			<?php
		}

		if ( ! empty( $tool_section['generator_item_slugs'] ) ) {
			self::render_generator_instance( $tool_section, $shortcode_items );
		}

		if ( ! empty( $tool_section['help_panels'] ) ) {
			self::render_help_panels( $tool_section['help_panels'] );
		}
	}

	/**
	 * Render generator instance for a section.
	 *
	 * @param array $tool_section    Tool section.
	 * @param array $shortcode_items All shortcode items.
	 *
	 * @return void
	 */
	private static function render_generator_instance( $tool_section, $shortcode_items ) {

		$section_items = array();

		foreach ( $tool_section['generator_item_slugs'] as $item_slug ) {
			if ( isset( $shortcode_items[ $item_slug ] ) ) {
				$section_items[] = $shortcode_items[ $item_slug ];
			}
		}

		if ( empty( $section_items ) ) {
			return;
		}

		$select_id = 'wpbc_bfb__advanced_mode_item_select__' . sanitize_html_class( $tool_section['slug'] );
		?>
		<div class="wpbc_bfb__amg" data-wpbc-bfb-advanced-mode-generator="1">

			<div class="wpbc_bfb__amg__field">
				<label class="wpbc_bfb__amg__label" for="<?php echo esc_attr( $select_id ); ?>">
					<?php esc_html_e( 'Shortcode Type', 'booking' ); ?>
				</label>

				<select id="<?php echo esc_attr( $select_id ); ?>" class="widefat" data-role="item-select">
					<option value=""><?php esc_html_e( 'Select shortcode type', 'booking' ); ?></option>
					<?php foreach ( $section_items as $item ) : ?>
						<option value="<?php echo esc_attr( $item['slug'] ); ?>">
							<?php echo esc_html( $item['label'] ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</div>

			<div class="wpbc_bfb__amg__description" data-role="item-description">
				<?php esc_html_e( 'Select a shortcode type to generate code.', 'booking' ); ?>
			</div>

			<div class="wpbc_bfb__amg__notes" data-role="item-notes"></div>

			<div class="wpbc_bfb__amg__controls" data-role="item-controls"></div>

			<div class="wpbc_bfb__amg__outputs">
				<div class="wpbc_bfb__amg__output" data-role="output-form-wrap" style="display:none;">
					<div class="wpbc_bfb__amg__output_header">
						<strong><?php esc_html_e( 'Shortcode for booking form', 'booking' ); ?></strong>
						<button type="button" class="button button-small" data-copy-target="form">
							<?php esc_html_e( 'Copy', 'booking' ); ?>
						</button>
					</div>
					<textarea class="widefat" rows="3" readonly="readonly" data-role="output-form"></textarea>
				</div>

				<div class="wpbc_bfb__amg__output" data-role="output-content-wrap" style="display:none;">
					<div class="wpbc_bfb__amg__output_header">
						<strong><?php esc_html_e( 'Shortcode for field data content', 'booking' ); ?></strong>
						<button type="button" class="button button-small" data-copy-target="content">
							<?php esc_html_e( 'Copy', 'booking' ); ?>
						</button>
					</div>
					<textarea class="widefat" rows="2" readonly="readonly" data-role="output-content"></textarea>
				</div>

				<div class="wpbc_bfb__amg__output" data-role="output-value-wrap" style="display:none;">
					<div class="wpbc_bfb__amg__output_header">
						<strong><?php esc_html_e( 'Shortcode for selected option title', 'booking' ); ?></strong>
						<button type="button" class="button button-small" data-copy-target="value">
							<?php esc_html_e( 'Copy', 'booking' ); ?>
						</button>
					</div>
					<textarea class="widefat" rows="2" readonly="readonly" data-role="output-value"></textarea>
				</div>
			</div>

		</div>
		<?php
	}

	/**
	 * Render nested help panels.
	 *
	 * @param array $help_panels Help panels.
	 *
	 * @return void
	 */
	private static function render_help_panels( $help_panels ) {

		foreach ( $help_panels as $help_panel ) {

			$is_open_class = ! empty( $help_panel['open'] ) ? '' : ' wpbc_container_closed';
			$content_style = ! empty( $help_panel['open'] ) ? '' : 'display:none;';
			?>
			<div class="wpbc_container_open_or_closed<?php echo esc_attr( $is_open_class ); ?> wpbc_bfb__am_help_panel">
				<a href="javascript:void(0)" class="wpbc_container_open_or_closed__link wpbc_bfb__am_help_panel_link">
					<?php echo esc_html( $help_panel['title'] ); ?>
				</a>

				<div class="wpbc_container_open_or_closed__content wpbc_bfb__am_help_panel_content" style="<?php echo esc_attr( $content_style ); ?>">
					<?php
					if ( ! empty( $help_panel['paragraphs'] ) ) {
						foreach ( $help_panel['paragraphs'] as $paragraph ) {
							echo '<p class="description">' . esc_html( $paragraph ) . '</p>';
						}
					}

					if ( ! empty( $help_panel['help_boxes'] ) ) {
						self::render_help_boxes( $help_panel['help_boxes'] );
					}

					if ( ! empty( $help_panel['entries'] ) ) {
						foreach ( $help_panel['entries'] as $entry ) {
							echo '<p class="description"><code>' . esc_html( $entry['code'] ) . '</code> - ' . esc_html( $entry['description'] ) . '</p>';
						}
					}

					if ( ! empty( $help_panel['notes'] ) ) {
						echo '<ul class="wpbc_bfb__am_help__notes">';
						foreach ( $help_panel['notes'] as $note ) {
							echo '<li>' . esc_html( $note ) . '</li>';
						}
						echo '</ul>';
					}
					?>
				</div>
			</div>
			<?php
		}
	}

	/**
	 * Render formatted help boxes.
	 *
	 * @param array $help_boxes Help boxes configuration.
	 *
	 * @return void
	 */
	private static function render_help_boxes( $help_boxes ) {

		foreach ( $help_boxes as $help_box ) {

			echo '<div class="wpbc-help-message one-row wpbc_bfb__am_help_box">';

			if ( ! empty( $help_box['title'] ) ) {
				echo '<strong>' . esc_html( $help_box['title'] ) . '</strong><br>';
			}

			if ( ! empty( $help_box['rows'] ) ) {

				$rows_count = count( $help_box['rows'] );
				$row_index  = 0;

				foreach ( $help_box['rows'] as $row ) {

					++$row_index;

					if ( ! empty( $row['label'] ) ) {
						echo esc_html( $row['label'] ) . ': ';
					}

					if ( ! empty( $row['code'] ) ) {
						echo '<code><strong>' . esc_html( $row['code'] ) . '</strong></code>';
					}

					if ( $row_index < $rows_count ) {
						echo '<br>';
					}
				}
			}

			echo '</div>';
		}
	}
}