<?php
/**
 * Advanced Mode sidebar data registry.
 *
 * @package Booking Calendar
 * @subpackage Form Builder
 * @since 11.0.0
 * @file ../wp-content/plugins/booking-calendar-com/inc/_ps/page-form-builder/advanced-mode/class-wpbc-bfb-advanced-mode-data.php
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Central registry for generator items and help content.
 */
class WPBC_BFB_Advanced_Mode_Data {

	/**
	 * Get shortcode items for the generator.
	 *
	 * Modes:
	 * - simple
	 * - simple_with_default
	 * - named_field
	 * - textarea_field
	 * - select_field
	 * - choice_field
	 * - submit_button
	 * - key_value_attrs
	 *
	 * @return array
	 */
	public static function get_shortcode_items() {

		return array(

			'calendar' => array(
				'slug'                 => 'calendar',
				'group'                => __( 'Required Fields', 'booking' ),
				'label'                => __( 'Calendar', 'booking' ),
				'description'          => __( 'Required booking calendar field.', 'booking' ),
				'mode'                 => 'simple',
				'tag'                  => 'calendar',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(),
				'notes'                => array(
					__( 'Use this shortcode only once in a standard booking form.', 'booking' ),
				),
			),

			'email' => array(
				'slug'                 => 'email',
				'group'                => __( 'Required Fields', 'booking' ),
				'label'                => __( 'Email Field', 'booking' ),
				'description'          => __( 'Primary visitor email field used for email notifications.', 'booking' ),
				'mode'                 => 'named_field',
				'tag'                  => 'email',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => true,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required. Usually keep it as "email".', 'booking' ),
						'default'     => 'email',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'placeholder',
						'type'        => 'text',
						'label'       => __( 'Placeholder', 'booking' ),
						'description' => __( 'Optional. Spaces are converted to underscores.', 'booking' ),
						'sanitize'    => 'placeholder',
					),
					array(
						'key'         => 'size',
						'type'        => 'number',
						'label'       => __( 'Size', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'maxlength',
						'type'        => 'number',
						'label'       => __( 'Maxlength', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
				),
				'notes'                => array(
					__( 'Every booking form should contain one primary email field.', 'booking' ),
				),
			),

			'text' => array(
				'slug'                 => 'text',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Text Field', 'booking' ),
				'description'          => __( 'Single-line text field.', 'booking' ),
				'mode'                 => 'named_field',
				'tag'                  => 'text',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'name',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'placeholder',
						'type'        => 'text',
						'label'       => __( 'Placeholder', 'booking' ),
						'description' => __( 'Optional. Spaces are converted to underscores.', 'booking' ),
						'sanitize'    => 'placeholder',
					),
					array(
						'key'         => 'size',
						'type'        => 'number',
						'label'       => __( 'Size', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'maxlength',
						'type'        => 'number',
						'label'       => __( 'Maxlength', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
				),
				'notes'                => array(),
			),

			'textarea' => array(
				'slug'                 => 'textarea',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Textarea', 'booking' ),
				'description'          => __( 'Multi-line text area field.', 'booking' ),
				'mode'                 => 'textarea_field',
				'tag'                  => 'textarea',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'details',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'cols',
						'type'        => 'number',
						'label'       => __( 'Columns', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'rows',
						'type'        => 'number',
						'label'       => __( 'Rows', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(),
			),

			'selectbox' => array(
				'slug'                 => 'selectbox',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Drop Down', 'booking' ),
				'description'          => __( 'Select field with one or multiple options.', 'booking' ),
				'mode'                 => 'select_field',
				'tag'                  => 'selectbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'multiple',
						'type'    => 'checkbox',
						'label'   => __( 'Allow multiple selections', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'visitors',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Options', 'booking' ),
						'description' => __( 'Required. One value per line.', 'booking' ),
						'default'     => "1\n2\n3\n4",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles of options', 'booking' ),
						'description' => __( 'Optional. One title per line. Creates Title@@Value pairs.', 'booking' ),
						'default'     => '',
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(
					__( 'Use separate titles when you want AM/PM labels with 24-hour values.', 'booking' ),
				),
			),

			'checkbox' => array(
				'slug'                 => 'checkbox',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Checkbox(es)', 'booking' ),
				'description'          => __( 'Checkbox field with one or multiple options.', 'booking' ),
				'mode'                 => 'choice_field',
				'tag'                  => 'checkbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'extras',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. Use one value or "on" for all.', 'booking' ),
					),
					array(
						'key'     => 'use_label_element',
						'type'    => 'checkbox',
						'label'   => __( 'Wrap each item with <label>', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'label_wrap',
						'type'    => 'checkbox',
						'label'   => __( 'Wrap checkbox with a label', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'label_first',
						'type'    => 'checkbox',
						'label'   => __( 'Put label before field', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'exclusive',
						'type'    => 'checkbox',
						'label'   => __( 'Make it exclusive', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Options', 'booking' ),
						'description' => __( 'Required. One value per line.', 'booking' ),
						'default'     => "wifi\nparking\nbreakfast",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles of options', 'booking' ),
						'description' => __( 'Optional. One title per line. Creates Title@@Value pairs.', 'booking' ),
						'default'     => "WiFi\nParking\nBreakfast",
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(),
			),

			'radio' => array(
				'slug'                 => 'radio',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Radio Button(s)', 'booking' ),
				'description'          => __( 'Radio buttons with a single selected option.', 'booking' ),
				'mode'                 => 'choice_field',
				'tag'                  => 'radio',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'service',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'     => 'use_label_element',
						'type'    => 'checkbox',
						'label'   => __( 'Wrap each item with <label>', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'label_wrap',
						'type'    => 'checkbox',
						'label'   => __( 'Wrap radio with a label', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'label_first',
						'type'    => 'checkbox',
						'label'   => __( 'Put label before field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Options', 'booking' ),
						'description' => __( 'Required. One value per line.', 'booking' ),
						'default'     => "standard\npremium\nvip",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles of options', 'booking' ),
						'description' => __( 'Optional. One title per line. Creates Title@@Value pairs.', 'booking' ),
						'default'     => "Standard\nPremium\nVIP",
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(),
			),

			'submit' => array(
				'slug'                 => 'submit',
				'group'                => __( 'Standard Fields', 'booking' ),
				'label'                => __( 'Submit Button', 'booking' ),
				'description'          => __( 'Submit button shortcode.', 'booking' ),
				'mode'                 => 'submit_button',
				'tag'                  => 'submit',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'         => 'label',
						'type'        => 'text',
						'label'       => __( 'Button label', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
						'default'     => __( 'Send', 'booking' ),
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(),
			),

			'rangetime' => array(
				'slug'                 => 'rangetime',
				'group'                => __( 'Time Fields', 'booking' ),
				'label'                => __( 'Time Slot List', 'booking' ),
				'description'          => __( 'Selectbox with time slots. Best for appointment forms.', 'booking' ),
				'mode'                 => 'select_field',
				'tag'                  => 'selectbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'     => 'multiple',
						'type'    => 'checkbox',
						'label'   => __( 'Long selection view', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Reserved. Keep it as "rangetime".', 'booking' ),
						'default'     => 'rangetime',
						'sanitize'    => 'token',
						'readonly'    => true,
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Values', 'booking' ),
						'description' => __( 'Required. Use 24-hour values, one per line.', 'booking' ),
						'default'     => "10:00 - 12:00\n12:00 - 14:00\n14:00 - 16:00\n16:00 - 18:00\n18:00 - 20:00",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles', 'booking' ),
						'description' => __( 'Optional. Use AM/PM titles here. One per line.', 'booking' ),
						'default'     => "10:00 AM - 12:00 PM\n12:00 PM - 02:00 PM\n02:00 PM - 04:00 PM\n04:00 PM - 06:00 PM\n06:00 PM - 08:00 PM",
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(
					__( 'Time values should stay in 24-hour format for correct logic.', 'booking' ),
					__( 'AM/PM labels should be placed in Titles, which will generate Title@@Value pairs.', 'booking' ),
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

			'starttime' => array(
				'slug'                 => 'starttime',
				'group'                => __( 'Time Fields', 'booking' ),
				'label'                => __( 'Start Time', 'booking' ),
				'description'          => __( 'Start time field shortcode.', 'booking' ),
				'mode'                 => 'simple',
				'tag'                  => 'starttime',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(),
				'notes'                => array(
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

			'endtime' => array(
				'slug'                 => 'endtime',
				'group'                => __( 'Time Fields', 'booking' ),
				'label'                => __( 'End Time', 'booking' ),
				'description'          => __( 'End time field shortcode.', 'booking' ),
				'mode'                 => 'simple',
				'tag'                  => 'endtime',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(),
				'notes'                => array(
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

			'durationtime' => array(
				'slug'                 => 'durationtime',
				'group'                => __( 'Time Fields', 'booking' ),
				'label'                => __( 'Duration Time', 'booking' ),
				'description'          => __( 'Selectbox for service duration.', 'booking' ),
				'mode'                 => 'select_field',
				'tag'                  => 'selectbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Reserved. Keep it as "durationtime".', 'booking' ),
						'default'     => 'durationtime',
						'sanitize'    => 'token',
						'readonly'    => true,
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Values', 'booking' ),
						'description' => __( 'Required. Use 24-hour duration values.', 'booking' ),
						'default'     => "00:15\n00:30\n00:45\n01:00\n01:30",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles', 'booking' ),
						'description' => __( 'Optional. One title per line.', 'booking' ),
						'default'     => "15 min\n30 min\n45 min\n1 hour\n1 hour 30 min",
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

			'steps_timeline' => array(
				'slug'                 => 'steps_timeline',
				'group'                => __( 'Other Utilities', 'booking' ),
				'label'                => __( 'Steps Timeline', 'booking' ),
				'description'          => __( 'Progress indicator for multi-step forms.', 'booking' ),
				'mode'                 => 'key_value_attrs',
				'tag'                  => 'steps_timeline',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'         => 'steps_count',
						'type'        => 'number',
						'label'       => __( 'Steps count', 'booking' ),
						'description' => __( 'Total number of steps.', 'booking' ),
						'default'     => '3',
						'attr_name'   => 'steps_count',
					),
					array(
						'key'         => 'active_step',
						'type'        => 'number',
						'label'       => __( 'Active step', 'booking' ),
						'description' => __( 'Current active step.', 'booking' ),
						'default'     => '1',
						'attr_name'   => 'active_step',
					),
					array(
						'key'         => 'color',
						'type'        => 'text',
						'label'       => __( 'Color', 'booking' ),
						'description' => __( 'Optional hex color.', 'booking' ),
						'default'     => '#619d40',
						'attr_name'   => 'color',
					),
				),
				'notes'                => array(),
			),

			'legend_items' => array(
				'slug'                 => 'legend_items',
				'group'                => __( 'Other Utilities', 'booking' ),
				'label'                => __( 'Calendar Legend', 'booking' ),
				'description'          => __( 'Show calendar legend anywhere inside the form.', 'booking' ),
				'mode'                 => 'key_value_attrs',
				'tag'                  => 'legend_items',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'         => 'items',
						'type'        => 'text',
						'label'       => __( 'Items', 'booking' ),
						'description' => __( 'Comma-separated legend item keys.', 'booking' ),
						'default'     => 'available,unavailable,pending,approved,partially',
						'attr_name'   => 'items',
					),
					array(
						'key'         => 'is_vertical',
						'type'        => 'checkbox',
						'label'       => __( 'Vertical layout', 'booking' ),
						'description' => __( 'Adds is_vertical="1".', 'booking' ),
						'default'     => false,
						'attr_name'   => 'is_vertical',
						'checked_val' => '1',
					),
					array(
						'key'         => 'text_for_day_cell',
						'type'        => 'text',
						'label'       => __( 'Text for day cell', 'booking' ),
						'description' => __( 'Optional symbol or empty space marker.', 'booking' ),
						'default'     => '',
						'attr_name'   => 'text_for_day_cell',
					),
				),
				'notes'                => array(),
			),

			'captcha' => array(
				'slug'                 => 'captcha',
				'group'                => __( 'Booking Essentials', 'booking' ),
				'label'                => __( 'CAPTCHA', 'booking' ),
				'description'          => __( 'Insert CAPTCHA shortcode to prevent SPAM bookings.', 'booking' ),
				'mode'                 => 'simple',
				'tag'                  => 'captcha',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(),
				'notes'                => array(
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

			'time' => array(
				'slug'                 => 'time',
				'group'                => __( 'Other Fields', 'booking' ),
				'label'                => __( 'Time Field', 'booking' ),
				'description'          => __( 'Text field for entering time value.', 'booking' ),
				'mode'                 => 'named_field',
				'tag'                  => 'time',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'time',
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
					),
					array(
						'key'         => 'html_id',
						'type'        => 'text',
						'label'       => __( 'ID', 'booking' ),
						'description' => __( 'Optional HTML id.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'css_class',
						'type'        => 'text',
						'label'       => __( 'Class', 'booking' ),
						'description' => __( 'Optional CSS class.', 'booking' ),
						'sanitize'    => 'token',
					),
					array(
						'key'         => 'placeholder',
						'type'        => 'text',
						'label'       => __( 'Placeholder', 'booking' ),
						'description' => __( 'Optional.', 'booking' ),
						'sanitize'    => 'placeholder',
					),
				),
				'notes'                => array(
					__( 'This field only saves time into the database and does not affect availability.', 'booking' ),
					__( 'Use 24-hour format for entered time values.', 'booking' ),
				),
			),

			'country' => array(
				'slug'                 => 'country',
				'group'                => __( 'Other Fields', 'booking' ),
				'label'                => __( 'Country List', 'booking' ),
				'description'          => __( 'Select field with predefined country list.', 'booking' ),
				'mode'                 => 'simple_with_default',
				'tag'                  => 'country',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default country code', 'booking' ),
						'description' => __( 'Optional. Example: US', 'booking' ),
						'default'     => '',
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(
					__( 'Example: [country "US"]', 'booking' ),
				),
			),

			'starttime_select' => array(
				'slug'                 => 'starttime_select',
				'group'                => __( 'Time & Services', 'booking' ),
				'label'                => __( 'Start Time - Drop Down list', 'booking' ),
				'description'          => __( 'Selectbox for start time values.', 'booking' ),
				'mode'                 => 'select_field',
				'tag'                  => 'selectbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Reserved. Keep it as "starttime".', 'booking' ),
						'default'     => 'starttime',
						'sanitize'    => 'token',
						'readonly'    => true,
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Values', 'booking' ),
						'description' => __( 'Required. One value per line.', 'booking' ),
						'default'     => "08:00\n08:30\n09:00\n09:30\n10:00\n10:30\n11:00\n11:30\n12:00\n12:30\n13:00\n13:30\n14:00\n14:30\n15:00\n15:30\n16:00\n16:30\n17:00\n17:30\n18:00\n18:30\n19:00\n19:30\n20:00\n20:30\n21:00",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles', 'booking' ),
						'description' => __( 'Optional. One title per line.', 'booking' ),
						'default'     => '',
					),
				),
				'notes'                => array(
					__( 'Use 24-hour values.', 'booking' ),
				),
			),

			'endtime_select' => array(
				'slug'                 => 'endtime_select',
				'group'                => __( 'Time & Services', 'booking' ),
				'label'                => __( 'End Time - Drop Down list', 'booking' ),
				'description'          => __( 'Selectbox for end time values.', 'booking' ),
				'mode'                 => 'select_field',
				'tag'                  => 'selectbox',
				'supports_content_tag' => true,
				'supports_value_tag'   => true,
				'controls'             => array(
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Reserved. Keep it as "endtime".', 'booking' ),
						'default'     => 'endtime',
						'sanitize'    => 'token',
						'readonly'    => true,
					),
					array(
						'key'         => 'default',
						'type'        => 'text',
						'label'       => __( 'Default value', 'booking' ),
						'description' => __( 'Optional. One value from the options list.', 'booking' ),
					),
					array(
						'key'         => 'options',
						'type'        => 'textarea',
						'label'       => __( 'Values', 'booking' ),
						'description' => __( 'Required. One value per line.', 'booking' ),
						'default'     => "08:00\n09:00\n10:00\n11:00\n12:00\n13:00\n14:00\n15:00\n16:00\n17:00\n18:00\n19:00\n20:00\n21:00\n22:00\n23:00",
					),
					array(
						'key'         => 'titles',
						'type'        => 'textarea',
						'label'       => __( 'Titles', 'booking' ),
						'description' => __( 'Optional. One title per line.', 'booking' ),
						'default'     => '',
					),
				),
				'notes'                => array(
					__( 'Use 24-hour values.', 'booking' ),
				),
			),

			'cost_corrections' => array(
				'slug'                 => 'cost_corrections',
				'group'                => __( 'Other Fields', 'booking' ),
				'label'                => __( 'Cost Correction Field', 'booking' ),
				'description'          => __( 'Visible in Admin Panel while adding bookings.', 'booking' ),
				'mode'                 => 'simple',
				'tag'                  => 'cost_corrections',
				'supports_content_tag' => false,
				'supports_value_tag'   => false,
				'controls'             => array(),
				'notes'                => array(
					__( 'Use this field for correcting booking cost while adding a booking in Admin.', 'booking' ),
				),
			),

			'coupon' => array(
				'slug'                 => 'coupon',
				'group'                => __( 'Other Fields', 'booking' ),
				'label'                => __( 'Discount Coupon field', 'booking' ),
				'description'          => __( 'Field for using coupon discounts.', 'booking' ),
				'mode'                 => 'named_field',
				'tag'                  => 'coupon',
				'supports_content_tag' => true,
				'supports_value_tag'   => false,
				'controls'             => array(
					array(
						'key'     => 'required',
						'type'    => 'checkbox',
						'label'   => __( 'Required field', 'booking' ),
						'default' => false,
					),
					array(
						'key'         => 'name',
						'type'        => 'text',
						'label'       => __( 'Name', 'booking' ),
						'description' => __( 'Required shortcode field name.', 'booking' ),
						'default'     => 'my_coupon',
						'sanitize'    => 'token',
					),
				),
				'notes'                => array(
					__( 'Usually use this shortcode only once in the form.', 'booking' ),
				),
			),

		);
	}

	/**
	 * Get one Advanced Mode tool section by slug.
	 *
	 * @param string $section_slug Section slug.
	 *
	 * @return array
	 */
	public static function get_tool_section( $section_slug ) {

		$tool_sections = self::get_tool_sections();

		if ( isset( $tool_sections[ $section_slug ] ) ) {
			return $tool_sections[ $section_slug ];
		}

		return array();
	}

	/**
	 * Get Advanced Mode tool sections.
	 *
	 * @return array
	 */
	public static function get_tool_sections() {

		return array(

			'booking_essentials' => array(
				'slug'                 => 'booking_essentials',
				'title'                => __( 'Booking Essentials', 'booking' ),
				'description'          => __( 'Required shortcodes and the main building blocks of a booking form.', 'booking' ),
				'generator_item_slugs' => array( 'calendar', 'email', 'submit', 'captcha' ),
				'help_panels'          => array(
					array(
						'title'      => __( 'Required Shortcodes', 'booking' ),
						'open'       => false,
						'paragraphs' => array(
							__( 'Most booking forms should include the booking calendar and the primary email field.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Booking Calendar', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[calendar]',
									),
								),
							),
							array(
								'title' => __( 'Primary Email Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[email* email]',
									),
								),
							),
							array(
								'title' => __( 'Submit Button', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[submit "Send"]',
									),
								),
							),
							array(
								'title' => __( 'CAPTCHA', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[captcha]',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'General Information', 'booking' ),
						'paragraphs' => array(
							__( 'You can use HTML tags in the booking form. Be sure all open tags are properly closed.', 'booking' ),
						),
					),
				),
			),

			'fields' => array(
				'slug'                 => 'fields',
				'title'                => __( 'Fields', 'booking' ),
				'description'          => __( 'Standard input fields and field-data shortcodes.', 'booking' ),
				'generator_item_slugs' => array( 'text', 'textarea', 'selectbox', 'checkbox', 'radio' ),
				'help_panels'          => array(
					array(
						'title'      => __( 'Field Data Shortcodes', 'booking' ),
						'paragraphs' => array(
							__( 'Use these shortcodes in Booking Fields Data and in email templates.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Insert Field Value', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[field_name]',
									),
								),
							),
							array(
								'title' => __( 'Insert Selected Option Title', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[field_name_val]',
									),
								),
							),
							array(
								'title' => __( 'Custom HTML Wrapper', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<f>[name]</f>',
									),
								),
							),
							array(
								'title' => __( 'Line Break', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<br>',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'Standard Field Examples', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Required Text Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[text* name placeholder:First_Name]',
									),
								),
							),
							array(
								'title' => __( 'Textarea with Custom Size', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[textarea details 50x7]',
									),
								),
							),
							array(
								'title' => __( 'Simple Drop Down Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selectbox visitors "1" "2" "3" "4"]',
									),
								),
							),
							array(
								'title' => __( 'Checkbox Field with Title / Value Pairs', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[checkbox extras "WiFi@@wifi" "Parking@@parking"]',
									),
								),
							),
							array(
								'title' => __( 'Radio Buttons with Title / Value Pairs', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[radio service "Standard@@standard" "Premium@@premium"]',
									),
								),
							),
						),
					),
				),
			),

			'time_services' => array(
				'slug'                 => 'time_services',
				'title'                => __( 'Time & Services', 'booking' ),
				'description'          => __( 'Time-slot, start time, end time, and duration related shortcodes.', 'booking' ),
				'generator_item_slugs' => array( 'rangetime', 'starttime', 'endtime', 'starttime_select', 'endtime_select', 'durationtime' ),
				'help_panels'          => array(
					array(
						'title'      => __( 'Time Shortcodes', 'booking' ),
						'open'       => false,
						'paragraphs' => array(
							__( 'Use these shortcodes for appointment and time-slot booking forms.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Time Slot List', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"]',
									),
									array(
										'code' => '[selectbox rangetime "10:00 AM - 12:00 PM@@10:00 - 12:00" "12:00 PM - 02:00 PM@@12:00 - 14:00"]',
									),
								),
							),
							array(
								'title' => __( 'Start Time Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[starttime]',
									),
								),
							),
							array(
								'title' => __( 'End Time Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[endtime]',
									),
								),
							),
							array(
								'title' => __( 'Duration Time Drop Down', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selectbox durationtime "15 min@@00:15" "30 min@@00:30" "1 hour@@01:00"]',
									),
								),
							),
						),
					),
				),
			),

			'layouts' => array(
				'slug'                 => 'layouts',
				'title'                => __( 'Layouts', 'booking' ),
				'description'          => __( 'Progress and legend related shortcodes for advanced form layouts.', 'booking' ),
				'generator_item_slugs' => array( 'steps_timeline', 'legend_items' ),
				'help_panels'          => array(
					array(
						'title'      => __( 'Layout Helpers', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Steps Timeline', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[steps_timeline steps_count="3" active_step="1" color="#619d40"]',
									),
								),
							),
							array(
								'title' => __( 'Calendar Legend', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[legend_items items="available,unavailable,pending,approved,partially"]',
									),
								),
							),
						),
					),
				),
			),

			'hints' => array(
				'slug'                 => 'hints',
				'title'                => __( 'Hints', 'booking' ),
				'description'          => __( 'Dynamic values that can be shown after dates or fields are selected.', 'booking' ),
				'generator_item_slugs' => array(),
				'help_panels'          => array(
					array(
						'title'      => __( 'Cost Hints', 'booking' ),
						'open'       => true,
						'help_boxes' => array(
							array(
								'title' => __( 'Full Booking Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[cost_hint]',
									),
								),
							),
							array(
								'title' => __( 'Original Booking Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[original_cost_hint]',
									),
								),
							),
							array(
								'title' => __( 'Additional Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[additional_cost_hint]',
									),
								),
							),
							array(
								'title' => __( 'Deposit Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[deposit_hint]',
									),
								),
							),
							array(
								'title' => __( 'Balance Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[balance_hint]',
									),
								),
							),
							array(
								'title' => __( 'Coupon Discount', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[coupon_discount_hint]',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'Date Hints', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Check-in Date', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[check_in_date_hint]',
									),
								),
							),
							array(
								'title' => __( 'Check-out Date', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[check_out_date_hint]',
									),
								),
							),
							array(
								'title' => __( 'Check-out Date Plus One Day', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[check_out_plus1day_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected Start Time', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[start_time_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected End Time', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[end_time_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected Dates', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selected_dates_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected Dates with Times', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selected_timedates_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected Short Dates', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selected_short_dates_hint]',
									),
								),
							),
							array(
								'title' => __( 'Selected Short Dates with Times', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[selected_short_timedates_hint]',
									),
								),
							),
							array(
								'title' => __( 'Number of Selected Days', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[days_number_hint]',
									),
								),
							),
							array(
								'title' => __( 'Number of Selected Nights', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[nights_number_hint]',
									),
								),
							),
							array(
								'title' => __( 'Cancellation Date', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[cancel_date_hint]',
									),
								),
							),
							array(
								'title' => __( 'Pre Check-in Date', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[pre_checkin_date_hint]',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'Other Hints', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Remaining Capacity', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[capacity_hint]',
									),
								),
							),
							array(
								'title' => __( 'Resource Title Hint', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[resource_title_hint]',
									),
								),
							),
							array(
								'title' => __( 'Booking Resource ID', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[bookingresource show=\'id\']',
									),
								),
							),
							array(
								'title' => __( 'Booking Resource Title', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[bookingresource show=\'title\']',
									),
								),
							),
							array(
								'title' => __( 'Booking Resource Cost', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[bookingresource show=\'cost\']',
									),
								),
							),
						),
					),
				),
			),

			'conditional_rules' => array(
				'slug'                 => 'conditional_rules',
				'title'                => __( 'Conditional Rules', 'booking' ),
				'description'          => __( 'Use condition shortcodes for weekdays and season-based content.', 'booking' ),
				'generator_item_slugs' => array(),
				'help_panels'          => array(
					array(
						'title'      => __( 'Weekday Conditions', 'booking' ),
						'open'       => true,
						'paragraphs' => array(
							__( 'Use condition rules for showing different form fields or time selections depending on selected weekday.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Default Condition', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[condition name="weekday-condition" type="weekday" value="*"] [selectbox rangetime "10:00 - 11:00" "11:00 - 12:00"] [/condition]',
									),
								),
							),
							array(
								'title' => __( 'Monday and Tuesday', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[condition name="weekday-condition" type="weekday" value="1,2"] [selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"] [/condition]',
									),
								),
							),
							array(
								'title' => __( 'Wednesday and Thursday', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[condition name="weekday-condition" type="weekday" value="3,4"] [selectbox rangetime "14:00 - 16:00" "16:00 - 18:00"] [/condition]',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'Season Conditions', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Default Season Condition', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[condition name="season-times" type="season" value="*"] [selectbox rangetime "14:00 - 16:00" "16:00 - 18:00"] [/condition]',
									),
								),
							),
							array(
								'title' => __( 'High Season Condition', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[condition name="season-times" type="season" value="High_season"] [selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"] [/condition]',
									),
								),
							),
						),
					),
				),
			),

			'simple_html_layout' => array(
				'slug'                 => 'simple_html_layout',
				'title'                => __( 'Simple HTML Layout', 'booking' ),
				'description'          => __( 'Simple HTML tags for rows, columns, labels, and spacers.', 'booking' ),
				'generator_item_slugs' => array(),
				'help_panels'          => array(
					array(
						'title'      => __( 'Simple HTML', 'booking' ),
						'open'       => true,
						'paragraphs' => array(
							__( 'Booking Calendar supports a simple way to configure rows and several columns in Advanced Mode.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Configuration', 'booking' ),
								'rows'  => array(
									array(
										'label' => __( 'Row', 'booking' ),
										'code'  => '<r>...</r>',
									),
									array(
										'label' => __( 'Columns', 'booking' ),
										'code'  => '<c>...</c>',
									),
									array(
										'label' => __( 'Labels', 'booking' ),
										'code'  => '<l>...</l>',
									),
									array(
										'label' => __( 'Spacer', 'booking' ),
										'code'  => '<spacer></spacer>',
									),
								),
							),
							array(
								'title' => __( 'Row with 1 Column', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<r><c>...</c></r>',
									),
								),
							),
							array(
								'title' => __( 'Row with 2 Columns', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<r><c>...</c><c>...</c></r>',
									),
								),
							),
							array(
								'title' => __( 'Row with 2 Fields', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<r><c><l>First Name:</l><br>[text* name]</c><c><l>Last Name:</l><br>[text secondname]</c></r>',
									),
								),
							),
							array(
								'title' => __( 'Horizontal Spacer', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<spacer></spacer>',
									),
									array(
										'code' => '<spacer>width:1em;</spacer>',
									),
								),
							),
							array(
								'title' => __( 'Vertical Spacer', 'booking' ),
								'rows'  => array(
									array(
										'code' => '<spacer></spacer>',
									),
									array(
										'code' => '<spacer>height:10px;</spacer>',
									),
								),
							),
						),
					),
				),
			),

			'tips_and_tricks' => array(
				'slug'                 => 'tips_and_tricks',
				'title'                => __( 'Tips and Tricks', 'booking' ),
				'description'          => __( 'Useful Advanced Mode tricks and validation patterns.', 'booking' ),
				'generator_item_slugs' => array(),
				'help_panels'          => array(
					array(
						'title'      => __( 'Email Verification Field', 'booking' ),
						'open'       => true,
						'help_boxes' => array(
							array(
								'title' => __( 'Confirmation Email Field', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[email* other_verify_email class:same_as_email]',
									),
								),
							),
						),
					),
					array(
						'title'      => __( 'Validate Text Field for Digits', 'booking' ),
						'help_boxes' => array(
							array(
								'title' => __( 'Digits Only', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[text* dig_field class:validate_as_digit]',
									),
								),
							),
							array(
								'title' => __( 'Phone Number with 9 Digits', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[text* phone class:validate_digit_9]',
									),
								),
							),
							array(
								'title' => __( 'ZIP Code with 5 Digits', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[text* zip class:validate_digit_5]',
									),
								),
							),
						),
					),
				),
			),

			'other_fields' => array(
				'slug'                 => 'other_fields',
				'title'                => __( 'Other Fields', 'booking' ),
				'description'          => __( 'Additional fields and multilingual helpers.', 'booking' ),
				'generator_item_slugs' => array( 'time', 'country', 'cost_corrections', 'coupon' ),
				'help_panels'          => array(
					array(
						'title'      => __( 'Language Sections', 'booking' ),
						'open'       => true,
						'paragraphs' => array(
							__( 'Plugin supports booking form configurations in different languages.', 'booking' ),
						),
						'help_boxes' => array(
							array(
								'title' => __( 'Start a Language Section', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[lang=fr_FR]',
									),
								),
							),
							array(
								'title' => __( 'WPML String Translation', 'booking' ),
								'rows'  => array(
									array(
										'code' => '[wpml]Some Text to translate[/wpml]',
									),
								),
							),
						),
					),
				),
			),

		);
	}

	/**
	 * Get help sections for the sidebar.
	 *
	 * @return array
	 */
	public static function get_help_sections() {

		return array(

			array(
				'slug'        => 'required_shortcodes',
				'title'       => __( 'Required Shortcodes', 'booking' ),
				'description' => __( 'Most booking forms should include a calendar and the main email field.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[calendar]',
						'description' => __( 'Booking calendar field.', 'booking' ),
					),
					array(
						'code'        => '[email* email]',
						'description' => __( 'Required primary email field.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'Use [calendar] only once in a standard booking form.', 'booking' ),
					__( 'Use [email* email] as the main visitor email field for notifications.', 'booking' ),
				),
			),

			array(
				'slug'        => 'field_data_shortcodes',
				'title'       => __( 'Field Data Shortcodes', 'booking' ),
				'description' => __( 'Use these shortcodes in booking content templates and email templates.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[name]',
						'description' => __( 'Outputs saved value of the "name" field.', 'booking' ),
					),
					array(
						'code'        => '[service_val]',
						'description' => __( 'Outputs selected option title for select, checkbox, or radio fields.', 'booking' ),
					),
					array(
						'code'        => '<f>[name]</f>',
						'description' => __( 'Custom HTML shortcode wrapper for field output.', 'booking' ),
					),
					array(
						'code'        => '<br>',
						'description' => __( 'Insert a new line.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'Use [field_name] to output saved values.', 'booking' ),
					__( 'Use [field_name_val] when you need the selected option title instead of the raw saved value.', 'booking' ),
				),
			),

			array(
				'slug'        => 'simple_html_helpers',
				'title'       => __( 'Simple HTML Layout Helpers', 'booking' ),
				'description' => __( 'These helper tags make Advanced Mode layout easier to read and maintain.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '<r><c>...</c></r>',
						'description' => __( 'Row with one column.', 'booking' ),
					),
					array(
						'code'        => '<r><c>...</c><c>...</c></r>',
						'description' => __( 'Row with two columns.', 'booking' ),
					),
					array(
						'code'        => '<l>First Name:</l>',
						'description' => __( 'Label helper.', 'booking' ),
					),
					array(
						'code'        => '<spacer></spacer>',
						'description' => __( 'Default spacer.', 'booking' ),
					),
					array(
						'code'        => '<spacer>height:10px;</spacer>',
						'description' => __( 'Vertical spacer.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'These layout tags are useful when manually composing booking forms in code.', 'booking' ),
				),
			),

			array(
				'slug'        => 'standard_field_examples',
				'title'       => __( 'Standard Field Examples', 'booking' ),
				'description' => __( 'Typical field shortcode patterns for Advanced Mode.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[text* name placeholder:First_Name]',
						'description' => __( 'Required text field.', 'booking' ),
					),
					array(
						'code'        => '[textarea details 50x7]',
						'description' => __( 'Textarea with custom size.', 'booking' ),
					),
					array(
						'code'        => '[selectbox visitors "1" "2" "3" "4"]',
						'description' => __( 'Simple dropdown field.', 'booking' ),
					),
					array(
						'code'        => '[checkbox extras "WiFi@@wifi" "Parking@@parking"]',
						'description' => __( 'Checkbox field with title/value pairs.', 'booking' ),
					),
					array(
						'code'        => '[submit "Send"]',
						'description' => __( 'Submit button.', 'booking' ),
					),
				),
				'notes'       => array(),
			),

			array(
				'slug'        => 'time_fields',
				'title'       => __( 'Time and Appointment Shortcodes', 'booking' ),
				'description' => __( 'Use these shortcodes for appointment and time-slot booking forms.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"]',
						'description' => __( 'Time slot dropdown with 24-hour values.', 'booking' ),
					),
					array(
						'code'        => '[selectbox rangetime "10:00 AM - 12:00 PM@@10:00 - 12:00" "12:00 PM - 02:00 PM@@12:00 - 14:00"]',
						'description' => __( 'AM/PM titles with 24-hour values using Title@@Value format.', 'booking' ),
					),
					array(
						'code'        => '[starttime]',
						'description' => __( 'Start time field shortcode.', 'booking' ),
					),
					array(
						'code'        => '[endtime]',
						'description' => __( 'End time field shortcode.', 'booking' ),
					),
					array(
						'code'        => '[selectbox durationtime "15 min@@00:15" "30 min@@00:30" "1 hour@@01:00"]',
						'description' => __( 'Duration time dropdown.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'Keep logic values in 24-hour format.', 'booking' ),
					__( 'Use Title@@Value pairs when you want human-friendly labels like AM/PM.', 'booking' ),
				),
			),

			array(
				'slug'        => 'conditions_and_languages',
				'title'       => __( 'Conditions and Language Sections', 'booking' ),
				'description' => __( 'Advanced patterns for conditional output and multilingual forms.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[condition name="weekday-condition" type="weekday" value="1,2"] [selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"] [/condition]',
						'description' => __( 'Show different content for specific weekdays.', 'booking' ),
					),
					array(
						'code'        => '[condition name="season-times" type="season" value="High_season"] [selectbox rangetime "10:00 - 12:00" "12:00 - 14:00"] [/condition]',
						'description' => __( 'Show different content for a season filter.', 'booking' ),
					),
					array(
						'code'        => '[lang=fr_FR]',
						'description' => __( 'Start a language-specific section.', 'booking' ),
					),
					array(
						'code'        => '[wpml]Some text[/wpml]',
						'description' => __( 'Register text for WPML string translation.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'Condition shortcodes are especially useful for different time slots per weekday or season.', 'booking' ),
				),
			),

			array(
				'slug'        => 'hints',
				'title'       => __( 'Hints and Dynamic Values', 'booking' ),
				'description' => __( 'These shortcodes show live dynamic values after date or field selection.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[cost_hint]',
						'description' => __( 'Full booking cost.', 'booking' ),
					),
					array(
						'code'        => '[selected_short_dates_hint]',
						'description' => __( 'Selected dates in short format.', 'booking' ),
					),
					array(
						'code'        => '[start_time_hint]',
						'description' => __( 'Selected start time.', 'booking' ),
					),
					array(
						'code'        => '[days_number_hint]',
						'description' => __( 'Number of selected days.', 'booking' ),
					),
					array(
						'code'        => '[resource_title_hint]',
						'description' => __( 'Booking resource title.', 'booking' ),
					),
				),
				'notes'       => array(
					__( 'Some hint shortcodes are edition-specific.', 'booking' ),
				),
			),

			array(
				'slug'        => 'other_utilities',
				'title'       => __( 'Other Utilities', 'booking' ),
				'description' => __( 'Additional useful shortcodes for more advanced layouts.', 'booking' ),
				'examples'    => array(
					array(
						'code'        => '[steps_timeline steps_count="3" active_step="1" color="#619d40"]',
						'description' => __( 'Progress indicator for multi-step forms.', 'booking' ),
					),
					array(
						'code'        => '[legend_items items="available,unavailable,pending,approved,partially"]',
						'description' => __( 'Calendar legend inside the form.', 'booking' ),
					),
					array(
						'code'        => '[bookingresource show=\'title\']',
						'description' => __( 'Booking resource title.', 'booking' ),
					),
					array(
						'code'        => '[bookingresource show=\'id\']',
						'description' => __( 'Booking resource ID.', 'booking' ),
					),
				),
				'notes'       => array(),
			),
		);
	}
}