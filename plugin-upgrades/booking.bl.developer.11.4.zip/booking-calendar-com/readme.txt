﻿=== Booking Calendar Pro ===
Contributors: wpdevelop, oplugins
Donate link: https://wpbookingcalendar.com/buy/
Tags: booking calendar, bookings, booking, appointments, events
Requires at least: 6.5
Requires PHP: 5.6
Tested up to: 7.0
Stable tag: 11.4
License: Commercial Plugin
License URI: https://wpbookingcalendar.com/terms/

Original "Booking Calendar" plugin. Easily manage full-day bookings, time-slot appointments, or events in our all-in-one, outstanding booking system.

== Description ==

= The #1 must have Booking Plugin for WordPress =

WP Booking Calendar - the original ["Booking Calendar"](https://wpbookingcalendar.com/ "WP Booking Calendar") is the 1st booking system developed for WordPress. Easily manage **full-day bookings**, **time-slot appointments**, or **events** in an all-in-one, **outstanding booking system**  on your WordPress website.

Booking Calendar Pro Requires PHP: 5.6 or newer
Redsys Requires PHP: 7.0 or newer
Sage Requires PHP: 7.1 or newer